package br.com.bbprevidencia.devolucao.dto;

public class TermoExtratoPrevDTO {

	private String cnpb;
	private String nomePatrocinadora;
	private String nomeParticipante;
	private String dataNascimento;
	private String cpf;
	private String email;
	private String endereco;
	private String bairro;
	private String cidade;
	private String cep;
	private String uf;
	private String telefoneResidencial = "";
	private String telefoneComercial = "";
	private String telefoneCelular = "";
	private String telefoneOutros = "";
	private Integer numMaxPacelaResgate;
	private Integer codigoPlanoGC;
	private String dscTipoEmpresa;
	private String dscTextoInformativo;
	private boolean possuiResgate;
	private boolean possuiBpd;
	private boolean possuiAutopatrocinio;
	private boolean possuiPortabilidade;
	private boolean mostrarOpcaoContribuicao;
	private boolean possuiRisco;

	public String getCnpb() {
		return cnpb;
	}

	public void setCnpb(String cnpb) {
		this.cnpb = cnpb;
	}

	public String getNomePatrocinadora() {
		return nomePatrocinadora;
	}

	public void setNomePatrocinadora(String nomePatrocinadora) {
		this.nomePatrocinadora = nomePatrocinadora;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTelefoneResidencial() {
		return telefoneResidencial;
	}

	public void setTelefoneResidencial(String telefoneResidencial) {
		this.telefoneResidencial = telefoneResidencial;
	}

	public String getTelefoneComercial() {
		return telefoneComercial;
	}

	public void setTelefoneComercial(String telefoneComercial) {
		this.telefoneComercial = telefoneComercial;
	}

	public String getTelefoneCelular() {
		return telefoneCelular;
	}

	public void setTelefoneCelular(String telefoneCelular) {
		this.telefoneCelular = telefoneCelular;
	}

	public String getTelefoneOutros() {
		return telefoneOutros;
	}

	public void setTelefoneOutros(String telefoneOutros) {
		this.telefoneOutros = telefoneOutros;
	}

	public Integer getNumMaxPacelaResgate() {
		return numMaxPacelaResgate;
	}

	public void setNumMaxPacelaResgate(Integer numMaxPacelaResgate) {
		this.numMaxPacelaResgate = numMaxPacelaResgate;
	}

	public Integer getCodigoPlanoGC() {
		return codigoPlanoGC;
	}

	public void setCodigoPlanoGC(Integer codigoPlanoGC) {
		this.codigoPlanoGC = codigoPlanoGC;
	}

	public String getDscTipoEmpresa() {
		return dscTipoEmpresa;
	}

	public void setDscTipoEmpresa(String dscTipoEmpresa) {
		this.dscTipoEmpresa = dscTipoEmpresa;
	}

	public String getDscTextoInformativo() {
		return dscTextoInformativo;
	}

	public void setDscTextoInformativo(String dscTextoInformativo) {
		this.dscTextoInformativo = dscTextoInformativo;
	}

	public boolean isPossuiResgate() {
		return possuiResgate;
	}

	public void setPossuiResgate(boolean possuiResgate) {
		this.possuiResgate = possuiResgate;
	}

	public boolean isPossuiBpd() {
		return possuiBpd;
	}

	public void setPossuiBpd(boolean possuiBpd) {
		this.possuiBpd = possuiBpd;
	}

	public boolean isPossuiAutopatrocinio() {
		return possuiAutopatrocinio;
	}

	public boolean isMostrarOpcaoContribuicao() {
		return mostrarOpcaoContribuicao;
	}

	public void setMostrarOpcaoContribuicao(boolean mostrarOpcaoContribuicao) {
		this.mostrarOpcaoContribuicao = mostrarOpcaoContribuicao;
	}

	public void setPossuiAutopatrocinio(boolean possuiAutopatrocinio) {
		this.possuiAutopatrocinio = possuiAutopatrocinio;
	}

	public boolean isPossuiPortabilidade() {
		return possuiPortabilidade;
	}

	public void setPossuiPortabilidade(boolean possuiPortabilidade) {
		this.possuiPortabilidade = possuiPortabilidade;
	}

	public boolean isPossuiRisco() {
		return possuiRisco;
	}

	public void setPossuiRisco(boolean possuiRisco) {
		this.possuiRisco = possuiRisco;
	}

}
