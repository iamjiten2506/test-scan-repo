package br.com.bbprevidencia.devolucao.dto;

public class EntidadeDTO {

	private Long codigoEntidade;

	public Long getCodigoEntidade() {
		return codigoEntidade;
	}

	public void setCodigoEntidade(Long codigoEntidade) {
		this.codigoEntidade = codigoEntidade;
	}

}
