package br.com.bbprevidencia.devolucao.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.cadastroweb.dao.FeriadoBancarioDAO;

@Component("dataUtil")
public class DataUtil {

	@Autowired
	private FeriadoBancarioDAO feriadoBancarioDAO;

	public Date adicionarDiasUteisData(Date data, Integer qtdDias) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(data);

		for (int i = 0; i < qtdDias; i++) {
			calendar.add(Calendar.DAY_OF_MONTH, 1);

			while (feriadoBancarioDAO.isFeriadoNacional(calendar.getTime()) || dataFimDeSemana(calendar))
				calendar.add(Calendar.DAY_OF_MONTH, 1);
		}

		return calendar.getTime();
	}

	public Date zerarHora(Date data) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(data);

		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.HOUR_OF_DAY, 0);

		return calendar.getTime();
	}

	private boolean dataFimDeSemana(Calendar calendar) {
		if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
			return true;

		return false;
	}

	public static Date localDateToDate(LocalDate localDate) {
		return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
	}

	public static LocalDate dateToLocalDate(Date date) {
		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
	}

	public static LocalDate primeiroDiaMesAnterior(LocalDate valor) throws ParseException {
		LocalDate novaData = LocalDate.of(valor.getYear(), valor.getMonth(), 1);
		novaData = novaData.plusMonths(-1);
		return novaData;
	}

	public static int monthsBetWeenDates(Date dataInicial, Date dataFinal) {
		LocalDate initDate = dateToLocalDate(dataInicial);
		LocalDate endDate = dateToLocalDate(dataFinal);
		Period age = Period.between(initDate, endDate);
		boolean flag = true;
		int mesIni = initDate.getMonth().getValue();
		int mesFim = endDate.getMonth().getValue();
		int monthPeriod = 0;

		while (flag) {
			;
			monthPeriod++;
			if (mesIni == mesFim)
				flag = false;
			mesIni++;
			if (mesIni == 12 && initDate.getMonth().getValue() > endDate.getMonth().getValue())
				mesIni = 1;
		}

		return monthPeriod;
	}

	public static Integer calcularDiferencaEmMeses(Date dataInicial, Date dataFinal) {
		long diferenca = dataFinal.getTime() - dataInicial.getTime();
		int tempoMes = 1000 * 60 * 60 * 24 * 30;
		return (int) (diferenca / tempoMes);
	}

	public static Integer calcularDiferencaEmDias(Date dataInicial, Date dataFinal) {
		long diferenca = dataFinal.getTime() - dataInicial.getTime();
		int tempoDia = 1000 * 60 * 60 * 24;
		return (int) (diferenca / tempoDia);
	}

	public static Date lastDayOfMonth(Date data) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		LocalDate actualDate = LocalDate.parse(sdf.format(data));
		LocalDate lastDayActualDate = actualDate.with(TemporalAdjusters.lastDayOfMonth());
		return localDateToDate(lastDayActualDate);
	}

	public static Date firstDayOfNextMonth(Date data) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		LocalDate actualDate = LocalDate.parse(sdf.format(data));

		LocalDate firstDayNextMonth = actualDate.plusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
		return localDateToDate(firstDayNextMonth);
	}

	public static Date firstDayOfPreviusMonth(Date data) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		LocalDate actualDate = LocalDate.parse(sdf.format(data));

		LocalDate firstDayNextMonth = actualDate.plusMonths(-1).with(TemporalAdjusters.firstDayOfMonth());
		return localDateToDate(firstDayNextMonth);
	}

	public static int qtdDayOfMonth(Date data) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		LocalDate actualDate = LocalDate.parse(sdf.format(data));
		return actualDate.lengthOfMonth();
	}

	public static long daysBetWeenDates(Date dataInicio, Date dataFinal) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			//Parsing the date
			LocalDate dateBefore = LocalDate.parse(sdf.format(dataInicio));
			LocalDate dateAfter = LocalDate.parse(sdf.format(dataFinal));

			return ChronoUnit.DAYS.between(dateBefore, dateAfter) + 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0L;
		}
	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
		Map<Object, Boolean> map = new ConcurrentHashMap<>();
		return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}
}
