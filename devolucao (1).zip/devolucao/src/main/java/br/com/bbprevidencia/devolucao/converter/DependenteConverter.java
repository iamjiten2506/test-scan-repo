package br.com.bbprevidencia.devolucao.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import br.com.bbprevidencia.bbpcomum.util.FabricaManagedBean;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.bo.DependenteParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.DependenteParticipante;
import br.com.bbprevidencia.cadastroweb.dto.DependenteParticipantePK;

@FacesConverter(value = "dependenteConverter")
public class DependenteConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent comp, String valor) {
		try {

			if (UtilJava.isStringVazia(valor)) {
				return new DependenteParticipante();
			} else {
				return consultarPorChaveDependente(valor);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public String getAsString(FacesContext context, UIComponent component, Object obj) {
		if (obj != null && obj instanceof DependenteParticipante) {

			DependenteParticipante dependenteParticipante = (DependenteParticipante) obj;

			if (dependenteParticipante.getChavePrimaria() != null && dependenteParticipante.getChavePrimaria().getCodigoDependente() != null
					&& dependenteParticipante.getChavePrimaria().getParticipante().getCodigo() != null) {
				return dependenteParticipante.getChavePrimaria().getParticipante().getCodigo() + "@@@" + dependenteParticipante.getChavePrimaria().getCodigoDependente().toString();
			}
		}
		return null;
	}

	/**
	 * Consulta pessoa através da chave passada como argumento.
	 * 
	 * @param chavePessoa
	 * @return Pessoa
	 */
	public DependenteParticipante consultarPorChaveDependente(String codigoPK) {
		DependenteParticipante dependenteParticipanteRetorno = null;
		if (codigoPK != null) {
			if (codigoPK.indexOf("@@@") > 0) {
				String[] arrayChave = codigoPK.split("@@@");
				DependenteParticipantePK chavePrimaria = new DependenteParticipantePK();
				ParticipanteBO participantebo = (ParticipanteBO) FabricaManagedBean.getManagedBean(ParticipanteBO.class);
				//ParticipanteBO participantebo = new ParticipanteBO();
				chavePrimaria.setParticipante(participantebo.consultarParticipantePorCodigo(new Long(arrayChave[0])));

				chavePrimaria.setCodigoDependente(new Long(arrayChave[1]));
				DependenteParticipanteBO dependenteParticipanteBO = (DependenteParticipanteBO) FabricaManagedBean.getManagedBean(DependenteParticipanteBO.class);
				try {

					dependenteParticipanteRetorno = dependenteParticipanteBO.consultarPorChavePrimaria(chavePrimaria);

				} catch (Exception e) {
				}
			}
		}

		return dependenteParticipanteRetorno;
	}

}
