package br.com.bbprevidencia.devolucao.dto;

public class ApresentacaoExtratoPrevDTO {

	private String nomeParticipante;

	private String sexo;

	private String logradouro;

	private String bairro;

	private String cep;

	private String cidade;

	private String uf;

	private String nomeEmpresaBbp;

	private String enderecoBbp;

	private String cidadeBbp;

	private String paragrafoUm;

	private String paragrafoDois;

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getNomeEmpresaBbp() {
		return nomeEmpresaBbp;
	}

	public void setNomeEmpresaBbp(String nomeEmpresaBbp) {
		this.nomeEmpresaBbp = nomeEmpresaBbp;
	}

	public String getEnderecoBbp() {
		return enderecoBbp;
	}

	public void setEnderecoBbp(String enderecoBbp) {
		this.enderecoBbp = enderecoBbp;
	}

	public String getCidadeBbp() {
		return cidadeBbp;
	}

	public void setCidadeBbp(String cidadeBbp) {
		this.cidadeBbp = cidadeBbp;
	}

	public String getParagrafoUm() {
		return paragrafoUm;
	}

	public void setParagrafoUm(String paragrafoUm) {
		this.paragrafoUm = paragrafoUm;
	}

	public String getParagrafoDois() {
		return paragrafoDois;
	}

	public void setParagrafoDois(String paragrafoDois) {
		this.paragrafoDois = paragrafoDois;
	}

}
