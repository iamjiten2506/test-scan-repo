package br.com.bbprevidencia.devolucao.dto;

public class RelatorioPagamentoFolhaDTO implements Comparable<RelatorioPagamentoFolhaDTO> {

	private Long numeroProcessoDevolucao;

	private String nomeEntidadeParticipante;

	private String nomePlano;

	private String matricula;

	private String cpfParticipante;

	private String nomeParticipante;

	private String nomeRecebedor;

	private String cpfRecebedor;

	private String endLogradouroRecebedor;

	private String endNumeroLogradouroRecebedor;

	private String endComplementoRecebedor;

	private String endBairroRecebedor;

	private String endCidadeRecebedor;

	private String endUfRecebedor;

	private String endCepRecebedor;

	private String tipoConta;

	private String codigoBanco;

	private String codigoAgenciaBanco;

	private String numeroConta;

	private String numeroDvConta;

	private String dataIntegracao;

	private String dataPagamento;

	private String dataRequerimento;

	private String tipoFolha;

	private String tipoDevolucao;

	private String situacaoFolha;

	private String nomeRubrica;

	private String indicadorProgressivoRegressivo;

	private Double qtdeCotas;

	private Double valor;

	private String qtdeParcelaDevolucao;

	private String qtdeParcelaPaga;

	public Long getNumeroProcessoDevolucao() {
		return numeroProcessoDevolucao;
	}

	public void setNumeroProcessoDevolucao(Long numeroProcessoDevolucao) {
		this.numeroProcessoDevolucao = numeroProcessoDevolucao;
	}

	public String getNomeEntidadeParticipante() {
		return nomeEntidadeParticipante;
	}

	public void setNomeEntidadeParticipante(String nomeEntidadeParticipante) {
		this.nomeEntidadeParticipante = nomeEntidadeParticipante;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCpfParticipante() {
		return cpfParticipante;
	}

	public void setCpfParticipante(String cpfParticipante) {
		this.cpfParticipante = cpfParticipante;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getNomeRecebedor() {
		return nomeRecebedor;
	}

	public void setNomeRecebedor(String nomeRecebedor) {
		this.nomeRecebedor = nomeRecebedor;
	}

	public String getCpfRecebedor() {
		return cpfRecebedor;
	}

	public void setCpfRecebedor(String cpfRecebedor) {
		this.cpfRecebedor = cpfRecebedor;
	}

	public String getEndLogradouroRecebedor() {
		return endLogradouroRecebedor;
	}

	public void setEndLogradouroRecebedor(String endLogradouroRecebedor) {
		this.endLogradouroRecebedor = endLogradouroRecebedor;
	}

	public String getEndNumeroLogradouroRecebedor() {
		return endNumeroLogradouroRecebedor;
	}

	public void setEndNumeroLogradouroRecebedor(String endNumeroLogradouroRecebedor) {
		this.endNumeroLogradouroRecebedor = endNumeroLogradouroRecebedor;
	}

	public String getEndComplementoRecebedor() {
		return endComplementoRecebedor;
	}

	public void setEndComplementoRecebedor(String endComplementoRecebedor) {
		this.endComplementoRecebedor = endComplementoRecebedor;
	}

	public String getEndBairroRecebedor() {
		return endBairroRecebedor;
	}

	public void setEndBairroRecebedor(String endBairroRecebedor) {
		this.endBairroRecebedor = endBairroRecebedor;
	}

	public String getEndCidadeRecebedor() {
		return endCidadeRecebedor;
	}

	public void setEndCidadeRecebedor(String endCidadeRecebedor) {
		this.endCidadeRecebedor = endCidadeRecebedor;
	}

	public String getEndUfRecebedor() {
		return endUfRecebedor;
	}

	public void setEndUfRecebedor(String endUfRecebedor) {
		this.endUfRecebedor = endUfRecebedor;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public String getNumeroDvConta() {
		return numeroDvConta;
	}

	public void setNumeroDvConta(String numeroDvConta) {
		this.numeroDvConta = numeroDvConta;
	}

	public String getDataIntegracao() {
		return dataIntegracao;
	}

	public void setDataIntegracao(String dataIntegracao) {
		this.dataIntegracao = dataIntegracao;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getTipoFolha() {
		return tipoFolha;
	}

	public void setTipoFolha(String tipoFolha) {
		this.tipoFolha = tipoFolha;
	}

	public String getSituacaoFolha() {
		return situacaoFolha;
	}

	public void setSituacaoFolha(String situacaoFolha) {
		this.situacaoFolha = situacaoFolha;
	}

	public String getNomeRubrica() {
		return nomeRubrica;
	}

	public void setNomeRubrica(String nomeRubrica) {
		this.nomeRubrica = nomeRubrica;
	}

	public String getIndicadorProgressivoRegressivo() {
		return indicadorProgressivoRegressivo;
	}

	public void setIndicadorProgressivoRegressivo(String indicadorProgressivoRegressivo) {
		this.indicadorProgressivoRegressivo = indicadorProgressivoRegressivo;
	}

	public Double getQtdeCotas() {
		return qtdeCotas;
	}

	public void setQtdeCotas(Double qtdeCotas) {
		this.qtdeCotas = qtdeCotas;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public String getEndCepRecebedor() {
		return endCepRecebedor;
	}

	public void setEndCepRecebedor(String endCepRecebedor) {
		this.endCepRecebedor = endCepRecebedor;
	}

	public String getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(String dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public String getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(String tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public String getCodigoAgenciaBanco() {
		return codigoAgenciaBanco;
	}

	public void setCodigoAgenciaBanco(String codigoAgenciaBanco) {
		this.codigoAgenciaBanco = codigoAgenciaBanco;
	}

	public String getQtdeParcelaDevolucao() {
		return qtdeParcelaDevolucao;
	}

	public void setQtdeParcelaDevolucao(String qtdeParcelaDevolucao) {
		this.qtdeParcelaDevolucao = qtdeParcelaDevolucao;
	}

	public String getQtdeParcelaPaga() {
		return qtdeParcelaPaga;
	}

	public void setQtdeParcelaPaga(String qtdeParcelaPaga) {
		this.qtdeParcelaPaga = qtdeParcelaPaga;
	}

	@Override
	public int compareTo(RelatorioPagamentoFolhaDTO o) {
		int valor = this.tipoFolha.compareTo(o.tipoFolha) * 1;

		if (valor == 0) {
			valor = this.nomeEntidadeParticipante.compareTo(o.nomeEntidadeParticipante) * 1;

			if (valor == 0) {
				valor = this.nomeParticipante.compareTo(o.nomeParticipante) * 1;

				if (valor == 0) {
					valor = this.nomeRecebedor.compareTo(o.nomeRecebedor) * 1;
				}
			}

		}

		return valor;
	}

}
