package br.com.bbprevidencia.devolucao.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;

/**
 * Classe utilitária responsável por realizar a importação e exportação de
 * imagens.
 * 
 * @author tiago.menezes
 * @since 13/03/2012
 */
public abstract class ImagemUtil {

	public static final String DIRETORIO_DE_IMAGENS = UtilSession.getRealPath("imagens") + "\\LogotiposExterno\\";

	private static final String DIRETORIO_RECURSO = "/imagens/LogoTipos/";

	/**
	 * Recupera o caminho da imagem no contexto da aplicação, e .
	 * 
	 * @deprecated
	 * @param nomeArquivo
	 * @return String
	 * @throws PrevidenciaException
	 */
	public static String visualizarImagem(String nomeArquivo) throws PrevidenciaException {
		try {
			// importa a imagem
			byte[] data = importar(DIRETORIO_DE_IMAGENS, nomeArquivo);

			String diretorioDestino = UtilSession.getRealPath(DIRETORIO_RECURSO);

			// exporta a imagem
			exportar(nomeArquivo, data, diretorioDestino);

			return DIRETORIO_RECURSO + nomeArquivo;

		} catch (Exception e) {
			throw new PrevidenciaException(e);
		}
	}

	/**
	 * Método responsável por exportar a imagem para o diretorio informado, com
	 * o nome e dados passados como argumentos.
	 * 
	 * @param nomeArquivo
	 *            Nome do arquivo
	 * @param dados
	 *            Conteudo do arquivo
	 * @param diretorio
	 *            Diretório para onde o arquivo será exportado.
	 * @throws PrevidenciaException
	 */
	public static void exportar(String nomeArquivo, byte[] dados, String diretorio) throws PrevidenciaException {
		try {

			// Exporta o arquivo
			String caminhoDestino = diretorio + "\\" + nomeArquivo;

			if (new File(diretorio).exists()) {

				FileOutputStream fos = new FileOutputStream(caminhoDestino);
				fos.write(dados);
				fos.flush();
				fos.close();

			} else {
				throw new PrevidenciaException("Arquivo ou diretório inexistente.");
			}

		} catch (FileNotFoundException e) {
			throw new PrevidenciaException(e);
		} catch (IOException e) {
			throw new PrevidenciaException(e);
		}
	}

	/**
	 * Método resopnsável por importar a imagem do diretório e nome do arquivo
	 * informado.
	 * 
	 * @param caminho
	 *            Diretório no qual se encontra o arquivo.
	 * @param nomeArquivo
	 *            Nome do arquivo.
	 * @return byte[] Conteúdo do arquivo.
	 * @throws PrevidenciaException
	 */
	private static byte[] importar(String caminho, String nomeArquivo) throws PrevidenciaException {
		byte[] data = new byte[20000];
		try {

			// importa o arquivo
			String pathOrigem = caminho + nomeArquivo;

			File diretorioArquivo = new File(pathOrigem);
			if (diretorioArquivo.exists()) {

				FileInputStream fis = new FileInputStream(pathOrigem);
				fis.read(data);
				fis.close();

				return data;

			} else {
				throw new PrevidenciaException("Arquivo ou diretório inexistente.");
			}

		} catch (FileNotFoundException e) {
			throw new PrevidenciaException(e);
		} catch (IOException e) {
			throw new PrevidenciaException(e);
		}
	}

	public static byte[] importarBytesImagem(String caminho, String nomeArquivo) throws PrevidenciaException {
		byte[] data = new byte[500000];
		try {

			// importa o arquivo
			String pathOrigem = caminho + nomeArquivo;

			File diretorioArquivo = new File(pathOrigem);
			if (diretorioArquivo.exists()) {

				FileInputStream fis = new FileInputStream(pathOrigem);
				fis.read(data);
				fis.close();

				return data;

			} else {
				throw new PrevidenciaException("Arquivo ou diretório inexistente.");
			}

		} catch (FileNotFoundException e) {
			throw new PrevidenciaException(e);
		} catch (IOException e) {
			throw new PrevidenciaException(e);
		}
	}

	/**
	 * Apresenta a imagem na tela.
	 * 
	 * @param nomeArquivo
	 * @return String
	 */
	public static String mostrarLogoTipo(String nomeArquivo) {

		FileInputStream fis = null;
		FileOutputStream fos = null;

		String diretorioDestino = UtilSession.getRealPath(DIRETORIO_RECURSO);
		String caminhoDestino = diretorioDestino + "\\" + nomeArquivo;

		try {

			//verifica se o arquivo ja foi importado.
			if (new File(caminhoDestino).exists()) {
				return DIRETORIO_RECURSO + nomeArquivo;
			}

			// importa o arquivo 
			String diretorioOrigem = DIRETORIO_DE_IMAGENS + nomeArquivo;

			if (new File(diretorioOrigem).exists()) {

				fis = new FileInputStream(diretorioOrigem);
				fos = new FileOutputStream(caminhoDestino);

				while (true) {
					int data = fis.read();
					if (data == -1) {
						break;
					}
					fos.write(data);
				}

			} else {
				throw new PrevidenciaException("Arquivo " + nomeArquivo + " não encontrado.");
			}

			return DIRETORIO_RECURSO + nomeArquivo;

		} catch (Exception e) {
			throw new PrevidenciaException(e);
		} finally {
			try {

				if (fis != null) {
					fis.close();
				}

				if (fos != null) {
					fos.flush();
					fos.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

}
