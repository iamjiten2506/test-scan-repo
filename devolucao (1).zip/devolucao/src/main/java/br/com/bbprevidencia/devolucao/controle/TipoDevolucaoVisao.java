package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import javax.faces.component.UIOutput;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import org.primefaces.PrimeFaces;
import org.primefaces.event.SlideEndEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.MotivoDesligamentoBO;
import br.com.bbprevidencia.cadastroweb.bo.SituacaoParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.MotivoDesligamento;
import br.com.bbprevidencia.cadastroweb.dto.SituacaoParticipantePlano;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.contabilidade.bo.OperacaoInternaBO;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.devolucao.bo.RubricaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoMotDesligamentoBO;
import br.com.bbprevidencia.devolucao.dto.RubricaDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucaoMotDesligamento;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio para
 * manter a Tipo Devolução
 * 
 * @author BBPF0333 - Daniel Martins
 * @since 02/02/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("tipoDevolucaoVisao")
public class TipoDevolucaoVisao {

	private static String FW_TIPO_DEVOLUCAO = "/paginas/tipoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private RubricaDevolucaoBO rubricaDevolucaoBO;

	@Autowired
	private OperacaoInternaBO operacaoInternaBO;

	@Autowired
	private SituacaoParticipantePlanoBO situacaoParticipantePlanoBO;

	@Autowired
	private TipoDevolucaoMotDesligamentoBO tipoDevolucaoMotDesligamentoBO;

	@Autowired
	private MotivoDesligamentoBO motivoDesligamentoBO;

	private List<TipoDevolucao> listaTipoDevolucao;
	private Long codigoTipoDevolucao;

	private List<RubricaDevolucao> listaRubricaDevolucao;
	private List<OperacaoInterna> listaOperacaoInterna;
	private List<SituacaoParticipantePlano> listaSituacaoParticipantePlano;
	private List<TipoDevolucaoMotDesligamento> listaTipoDevolucaoMotDesligamento;
	private List<MotivoDesligamento> listaMotivoDesligamento;

	private TipoDevolucaoMotDesligamento tipoDevolucaoMotDesligamento;
	private MotivoDesligamento motivoDesligamento;

	private TipoDevolucao tipoDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;
	private boolean listarMotivo;
	private boolean insercao;
	private boolean mostraRubricaPortabilidade;
	private String textoRubricaProgressivo;
	private String textoRubricaRegressivo;
	private String abasVisiveis;

	/**
	 * Método encarregado por iniciar a página da tipo folha Devolução
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 02/02/2017
	 * @return {@link String}
	 */
	public String iniciarTipoDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("tipoDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.tipoDevolucao = null;

		this.listarStatus = true;

		tipoDevolucao = new TipoDevolucao();

		this.abasVisiveis = "0";

		listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBO.listarTodosTipoDevolucao());
		listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBO.listarRubricaDevolucao());
		listaOperacaoInterna = new ArrayList<OperacaoInterna>(operacaoInternaBO.listarTodasOperacaoInterna());
		listaSituacaoParticipantePlano = new ArrayList<SituacaoParticipantePlano>(situacaoParticipantePlanoBO.listarSituacaoParticipantePlano());
		listaMotivoDesligamento = new ArrayList<MotivoDesligamento>(listarMotivoDesligamentoDisponiveisTipoDevolucao(tipoDevolucao));

		return FW_TIPO_DEVOLUCAO;
	}

	// Métodos de funcionamento da página
	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 03/02/2017
	 */
	public void controlarEdicaoVisualizacao() {
		if (isListarStatus()) {

			listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBO.listarTodosTipoDevolucao());
		}

		listarStatus = listarStatus == true ? false : true;

	}

	/**
	 * Método que seleciona uma Tipo de Devolução e a coloca em modo de edição
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 03/02/2017
	 * @param {@link
	 * 			TipoDevolucao}
	 */
	public void editarTipoDevolucao(TipoDevolucao tipoDevolucao) {

		this.setTipoDevolucao(tipoDevolucao);
		this.setMotivoDesligamento(null);
		this.setListarMotivo(true);
		this.setInsercao(false);
		this.setMostraRubricaPortabilidade(false);
		this.setTextoRubricaProgressivo("Resgate Progressivo");
		this.setTextoRubricaRegressivo("Resgate Regressivo");

		if (tipoDevolucao.getIndicadorTipoDevolucao().equals("P")) {
			this.setMostraRubricaPortabilidade(true);
			this.setTextoRubricaProgressivo("Empréstimo Progressivo");
			this.setTextoRubricaRegressivo("Empréstimo Regressivo");
		}

		listaTipoDevolucaoMotDesligamento = tipoDevolucaoMotDesligamentoBO.listarTipoDevolucaoMotDesligamentoPorTipoDevolucao(tipoDevolucao);
		listaMotivoDesligamento = listarMotivoDesligamentoDisponiveisTipoDevolucao(tipoDevolucao);

		definirAbasVisiveis();
		controlarEdicaoVisualizacao();

	}

	/**
	 * Método que coloca a pagina em modo de edição
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 03/02/2017
	 */
	public void cadastrarNovoTipoDevolucao() {

		tipoDevolucao = new TipoDevolucao();
		setMotivoDesligamento(null);
		setListaTipoDevolucaoMotDesligamento(null);
		listaMotivoDesligamento = motivoDesligamentoBO.listarTodos();
		this.setListarMotivo(false);
		this.setInsercao(true);
		this.setMostraRubricaPortabilidade(true);
		this.setTextoRubricaProgressivo("Resgate Progressivo");
		this.setTextoRubricaRegressivo("Resgate Regressivo");

		definirAbasVisiveis();
		controlarEdicaoVisualizacao();

	}

	/**
	 * Método para salvar ou atualizar uma Tipo Devolução
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 03/02/2017
	 * 
	 */
	public String salvarTipoDevolucao() {
		try {

			Boolean atualiza;

			atualiza = true;

			if (tipoDevolucao.getIndicadorFormaDevolucao().equals("T")) {

				if (tipoDevolucao.getMinimoPercentualDevolucao() != 100) {
					Mensagens.addError("DEV_VMSG010", "Mínimo");
					atualiza = false;
				}

				if (tipoDevolucao.getMaximoPercentualDevolucao() != 100) {
					Mensagens.addError("DEV_VMSG010", "Máximo");
					atualiza = false;
				}

				if (tipoDevolucao.getMesesCarenciaProxDevolucao() != 0) {
					Mensagens.addError("DEV_VMSG016");
					atualiza = false;
				}
			} else {
				if (tipoDevolucao.getIndicadorTipoDevolucao().equals("P")) {
					if (tipoDevolucao.getMinimoPercentualDevolucao() == 100) {
						Mensagens.addError("O percentual Mínimo não pode ser igual a 100%!");
						atualiza = false;
					}

					if (tipoDevolucao.getMinimoPercentualDevolucao() > tipoDevolucao.getMaximoPercentualDevolucao()) {
						Mensagens.addError("O percentual Máximo tem que ser maior que o Mínimo");
						atualiza = false;
					}
				}
			}

			if (tipoDevolucao.getIndicadorTipoDevolucao().equals("P")) {

				if (tipoDevolucao.getRubricaDevolucaoPortabilidadeAbertaProgressivo() == null) {
					Mensagens.addError("DEV_VMSG011");
					atualiza = false;
				}

				if (tipoDevolucao.getRubricaDevolucaoPortabilidadeFecProgressivo() == null) {
					Mensagens.addError("DEV_VMSG012");
					atualiza = false;
				}

				if (tipoDevolucao.getRubricaDevolucaoPortabilidadeAbertaRegressivo() == null) {
					Mensagens.addError("DEV_VMSG013");
					atualiza = false;
				}

				if (tipoDevolucao.getRubricaDevolucaoPortabilidadeFecRegressivo() == null) {
					Mensagens.addError("DEV_VMSG014");
					atualiza = false;
				}

				if (tipoDevolucao.getIndicadorTipoRecebedor().equals("P")) {
					Mensagens.addError("DEV_VMSG015");
					atualiza = false;
				}
				//Retirado conforme demanada 40050 
				//				if (tipoDevolucao.getIndicadorFormaDevolucao().equals("P")) {
				//					Mensagens.addError("DEV_VMSG017");
				//					atualiza = false;
				//				}

			}

			if (atualiza) {
				tipoDevolucaoBO.salvarTipoDevolucao(tipoDevolucao, this.getLoginTemporariaDTO());

				controlarEdicaoVisualizacao();

				Mensagens.addMessage("DEV_VMSG006", tipoDevolucao.getCodigo() == null ? "salva" : "atualizada");

				listaTipoDevolucao = tipoDevolucaoBO.listarTodosTipoDevolucao();
			} else {
				Mensagens.addError("DEV_VMSG009", tipoDevolucao.getCodigo() == null ? "salvo" : "atualizado");
				return FW_TIPO_DEVOLUCAO;
			}

			this.listarStatus = false;
			this.setListarMotivo(true);
			return "";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar a Tipo de Devolução");
			return "";
		}

	}

	/**
	 * Método para retornar a lista de Tipo de Devolucao para preencher a lista
	 * de pesquisa ou edição/inserção
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 03/02/2017
	 * @return {@link SelectItem}
	 * 
	 */
	public List<SelectItem> listarTipoDevolucaoParaPesquisa() {
		List<SelectItem> itens = new ArrayList<SelectItem>();

		List<TipoDevolucao> listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBO.listarTodosTipoDevolucao());

		if (!UtilJava.isColecaoVazia(listaTipoDevolucao)) {
			for (TipoDevolucao tipoDevolucao : listaTipoDevolucao) {
				itens.add(new SelectItem(tipoDevolucao.getCodigo(), tipoDevolucao.getNome()));
			}
		}
		return itens;
	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da
	 * página
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 03/02/2017
	 * 
	 */
	public void limparPesquisa() {

		// this.caracteristicaDirf = null;
		// this.tipoRubrica = null;
		// this.consignatario = null;

		this.codigoTipoDevolucao = null;

		listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBO.listarTodosTipoDevolucao());
	}

	/**
	 * Método para deletar uma Tipo Devolução
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 03/02/2017
	 * @param {@link
	 * 			TipoDevolucao}
	 * @return {@link String}
	 */
	public String deletarTipoDevolucao(TipoDevolucao tipoDevolucao) {
		try {
			tipoDevolucaoBO.apagarTipoDevolucao(tipoDevolucao);

			Mensagens.addMessage("DEV_VMSG006");

			listaTipoDevolucao = tipoDevolucaoBO.listarTodosTipoDevolucao();

			return "";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar a Tipo de Devolução");
			return "";
		}
	}

	/**
	 * Método para deletar uma Tipo Devolução Motivo de Deslisgamento
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 07/02/2017
	 * @param {@link
	 * 			TipoDevolucaoMotDesligamento}
	 * @return {@link String}
	 */
	public String deletarTipoDevolucaoMotDesligamento(TipoDevolucaoMotDesligamento tipoDevolucaoMotDesligamento) {
		try {
			tipoDevolucaoMotDesligamentoBO.apagarTipoDevolucaoMotDesligamento(tipoDevolucaoMotDesligamento);

			Mensagens.addMessage("DEV_VMSG008");

			listaTipoDevolucaoMotDesligamento = tipoDevolucaoMotDesligamentoBO.listarTipoDevolucaoMotDesligamentoPorTipoDevolucao(tipoDevolucao);
			listaMotivoDesligamento = listarMotivoDesligamentoDisponiveisTipoDevolucao(this.tipoDevolucao);

			return "";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de excluir a Motivo de Desligamento.");
			return "";
		}
	}

	/**
	 * Método para salvar ou atualizar uma Tipo Devolução Motivo Desligamento
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 07/02/2017
	 * 
	 */
	public String incluirMotivoDesligamento() {
		try {

			if (this.tipoDevolucao == null) {
				Mensagens.addError("DEV_VMSG005");
				return FW_TIPO_DEVOLUCAO;
			} else {
				if (this.tipoDevolucao.getCodigo() == null) {
					Mensagens.addError("DEV_VMSG005");
					return FW_TIPO_DEVOLUCAO;
				}
			}

			TipoDevolucaoMotDesligamento tipoDevolucaoMotDesligamentoIncluir = new TipoDevolucaoMotDesligamento();

			tipoDevolucaoMotDesligamentoIncluir.setTipoDevolucao(this.tipoDevolucao);
			tipoDevolucaoMotDesligamentoIncluir.setMotivoDesligamento(this.motivoDesligamento);

			if (this.motivoDesligamento != null) {

				tipoDevolucaoMotDesligamentoBO.salvarTipoDevolucaoMotDesligamento(tipoDevolucaoMotDesligamentoIncluir, this.getLoginTemporariaDTO());

				Mensagens.addMessage("DEV_VMSG004");

				listaTipoDevolucaoMotDesligamento = tipoDevolucaoMotDesligamentoBO.listarTipoDevolucaoMotDesligamentoPorTipoDevolucao(this.tipoDevolucao);
				listaMotivoDesligamento = listarMotivoDesligamentoDisponiveisTipoDevolucao(this.tipoDevolucao);
				setMotivoDesligamento(null);

			} else {

				Mensagens.addError("DEV_VMSG003");
				PrimeFaces.current().executeScript("PF('inserirMotivo').show();");

			}

		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar motivo desligamento");
		}

		return FW_TIPO_DEVOLUCAO;

	}

	public List<MotivoDesligamento> listarMotivoDesligamentoDisponiveisTipoDevolucao(TipoDevolucao tipoDevolucao) throws PrevidenciaException {
		try {

			boolean jaInserido;

			List<MotivoDesligamento> listaMotivoDesligamentoBase = new ArrayList<MotivoDesligamento>();
			List<MotivoDesligamento> listaMotivoDesligamentoFinal = new ArrayList<MotivoDesligamento>();

			// Buscando todos os motivos de desligamento
			listaMotivoDesligamentoBase = motivoDesligamentoBO.listarTodos();

			List<TipoDevolucaoMotDesligamento> listaTipoDevolucaoMotDesligamentoBase = new ArrayList<TipoDevolucaoMotDesligamento>();

			if (tipoDevolucao.getCodigo() == null) {
				listaMotivoDesligamentoFinal = listaMotivoDesligamentoBase;
			} else {

				listaTipoDevolucaoMotDesligamentoBase = tipoDevolucaoMotDesligamentoBO.listarTipoDevolucaoMotDesligamentoPorTipoDevolucao(tipoDevolucao);

				if (listaTipoDevolucaoMotDesligamentoBase == null) {
					listaMotivoDesligamentoFinal = listaMotivoDesligamentoBase;
				} else {

					for (MotivoDesligamento motivoDesligamentoLista : listaMotivoDesligamentoBase) {

						jaInserido = false;

						for (TipoDevolucaoMotDesligamento tipoDevolucaoMotDesligamentoLista : listaTipoDevolucaoMotDesligamentoBase) {

							if (tipoDevolucaoMotDesligamentoLista.getMotivoDesligamento().equals(motivoDesligamentoLista)) {
								jaInserido = true;
							}
						}

						if (!jaInserido) {
							listaMotivoDesligamentoFinal.add(motivoDesligamentoLista);
						}

					}

				}

			}

			return listaMotivoDesligamentoFinal;

		} catch (Exception e) {
			throw new PrevidenciaException("Nao foi possivel fazer operacao", e);
		}
	}

	public void verificarIndTipoDevolucao(AjaxBehaviorEvent event) {
		this.setMostraRubricaPortabilidade(true);
		this.setTextoRubricaProgressivo("Empréstimo Progressivo");
		this.setTextoRubricaRegressivo("Empréstimo Regressivo");

		if (((String) ((UIOutput) event.getSource()).getValue()).equals("R")) {
			this.setMostraRubricaPortabilidade(false);
			this.setTextoRubricaProgressivo("Resgate Progressivo");
			this.setTextoRubricaRegressivo("Resgate Regressivo");
		}
	}

	/**
	 * Define quais são as abas visiveis conforme a açaõ executada
	 */
	public void definirAbasVisiveis() {
		abasVisiveis = null;
		int i = 1;

		this.abasVisiveis = "0,1";

		if (this.mostraRubricaPortabilidade) {
			this.abasVisiveis = this.abasVisiveis + "," + ++i;
		}

		for (int j = 0; j < 3; j++) {
			this.abasVisiveis = this.abasVisiveis + "," + ++i;
		}

		if (this.listarMotivo) {
			this.abasVisiveis = this.abasVisiveis + "," + ++i;
		}
	}

	public static String getFW_TIPO_DEVOLUCAO() {
		return FW_TIPO_DEVOLUCAO;
	}

	public static void setFW_TIPO_DEVOLUCAO(String fW_TIPO_DEVOLUCAO) {
		FW_TIPO_DEVOLUCAO = fW_TIPO_DEVOLUCAO;
	}

	public void onSlideEnd(SlideEndEvent event) {
		this.tipoDevolucao.setMaximoPercentualDevolucao((double) event.getValue());
	}

	public TipoDevolucaoBO getTipoDevolucaoBO() {
		return tipoDevolucaoBO;
	}

	public void setTipoDevolucaoBO(TipoDevolucaoBO tipoDevolucaoBO) {
		this.tipoDevolucaoBO = tipoDevolucaoBO;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public Long getCodigoTipoDevolucao() {
		return codigoTipoDevolucao;
	}

	public void setCodigoTipoDevolucao(Long codigoTipoDevolucao) {
		this.codigoTipoDevolucao = codigoTipoDevolucao;
	}

	public List<RubricaDevolucao> getListaRubricaDevolucao() {
		return listaRubricaDevolucao;
	}

	public void setListaRubricaDevolucao(List<RubricaDevolucao> listaRubricaDevolucao) {
		this.listaRubricaDevolucao = listaRubricaDevolucao;
	}

	public RubricaDevolucaoBO getRubricaDevolucaoBO() {
		return rubricaDevolucaoBO;
	}

	public void setRubricaDevolucaoBO(RubricaDevolucaoBO rubricaDevolucaoBO) {
		this.rubricaDevolucaoBO = rubricaDevolucaoBO;
	}

	public List<OperacaoInterna> getListaOperacaoInterna() {
		return listaOperacaoInterna;
	}

	public void setListaOperacaoInterna(List<OperacaoInterna> listaOperacaoInterna) {
		this.listaOperacaoInterna = listaOperacaoInterna;
	}

	public OperacaoInternaBO getOperacaoInternaBO() {
		return operacaoInternaBO;
	}

	public void setOperacaoInternaBO(OperacaoInternaBO operacaoInternaBO) {
		this.operacaoInternaBO = operacaoInternaBO;
	}

	public SituacaoParticipantePlanoBO getSituacaoParticipantePlanoBO() {
		return situacaoParticipantePlanoBO;
	}

	public void setSituacaoParticipantePlanoBO(SituacaoParticipantePlanoBO situacaoParticipantePlanoBO) {
		this.situacaoParticipantePlanoBO = situacaoParticipantePlanoBO;
	}

	public List<SituacaoParticipantePlano> getListaSituacaoParticipantePlano() {
		return listaSituacaoParticipantePlano;
	}

	public void setListaSituacaoParticipantePlano(List<SituacaoParticipantePlano> listaSituacaoParticipantePlano) {
		this.listaSituacaoParticipantePlano = listaSituacaoParticipantePlano;
	}

	public TipoDevolucaoMotDesligamentoBO getTipoDevolucaoMotDesligamentoBO() {
		return tipoDevolucaoMotDesligamentoBO;
	}

	public void setTipoDevolucaoMotDesligamentoBO(TipoDevolucaoMotDesligamentoBO tipoDevolucaoMotDesligamentoBO) {
		this.tipoDevolucaoMotDesligamentoBO = tipoDevolucaoMotDesligamentoBO;
	}

	public MotivoDesligamentoBO getMotivoDesligamentoBO() {
		return motivoDesligamentoBO;
	}

	public void setMotivoDesligamentoBO(MotivoDesligamentoBO motivoDesligamentoBO) {
		this.motivoDesligamentoBO = motivoDesligamentoBO;
	}

	public List<TipoDevolucaoMotDesligamento> getListaTipoDevolucaoMotDesligamento() {
		return listaTipoDevolucaoMotDesligamento;
	}

	public void setListaTipoDevolucaoMotDesligamento(List<TipoDevolucaoMotDesligamento> listaTipoDevolucaoMotDesligamento) {
		this.listaTipoDevolucaoMotDesligamento = listaTipoDevolucaoMotDesligamento;
	}

	public List<MotivoDesligamento> getListaMotivoDesligamento() {
		return listaMotivoDesligamento;
	}

	public void setListaMotivoDesligamento(List<MotivoDesligamento> listaMotivoDesligamento) {
		this.listaMotivoDesligamento = listaMotivoDesligamento;
	}

	public TipoDevolucaoMotDesligamento getTipoDevolucaoMotDesligamento() {
		return tipoDevolucaoMotDesligamento;
	}

	public void setTipoDevolucaoMotDesligamento(TipoDevolucaoMotDesligamento tipoDevolucaoMotDesligamento) {
		this.tipoDevolucaoMotDesligamento = tipoDevolucaoMotDesligamento;
	}

	public MotivoDesligamento getMotivoDesligamento() {
		return motivoDesligamento;
	}

	public void setMotivoDesligamento(MotivoDesligamento motivoDesligamento) {
		this.motivoDesligamento = motivoDesligamento;
	}

	public boolean isListarMotivo() {
		return listarMotivo;
	}

	public void setListarMotivo(boolean listarMotivo) {
		this.listarMotivo = listarMotivo;
	}

	public boolean isInsercao() {
		return insercao;
	}

	public void setInsercao(boolean insercao) {
		this.insercao = insercao;
	}

	public boolean isMostraRubricaPortabilidade() {
		return mostraRubricaPortabilidade;
	}

	public void setMostraRubricaPortabilidade(boolean mostraRubricaPortabilidade) {
		this.mostraRubricaPortabilidade = mostraRubricaPortabilidade;
	}

	public String getTextoRubricaProgressivo() {
		return textoRubricaProgressivo;
	}

	public void setTextoRubricaProgressivo(String textoRubricaProgressivo) {
		this.textoRubricaProgressivo = textoRubricaProgressivo;
	}

	public String getTextoRubricaRegressivo() {
		return textoRubricaRegressivo;
	}

	public void setTextoRubricaRegressivo(String textoRubricaRegressivo) {
		this.textoRubricaRegressivo = textoRubricaRegressivo;
	}

	public String getAbasVisiveis() {
		return abasVisiveis;
	}

	public void setAbasVisiveis(String abasVisiveis) {
		this.abasVisiveis = abasVisiveis;
	}

}
