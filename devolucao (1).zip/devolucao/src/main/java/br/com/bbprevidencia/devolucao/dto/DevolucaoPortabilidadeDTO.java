package br.com.bbprevidencia.devolucao.dto;

public class DevolucaoPortabilidadeDTO {

	private Long codigoParticipante;
	private Long codigoParticipantePlano;
	private String regimeTributacao;

	public DevolucaoPortabilidadeDTO(Long codigoParticipante, Long codigoParticipantePlano, String regimeTributacao) {
		super();
		this.codigoParticipante = codigoParticipante;
		this.codigoParticipantePlano = codigoParticipantePlano;
		this.regimeTributacao = regimeTributacao;
	}

	public DevolucaoPortabilidadeDTO() {
		super();
	}

	public Long getCodigoParticipante() {
		return codigoParticipante;
	}

	public void setCodigoParticipante(Long codigoParticipante) {
		this.codigoParticipante = codigoParticipante;
	}

	public Long getCodigoParticipantePlano() {
		return codigoParticipantePlano;
	}

	public void setCodigoParticipantePlano(Long codigoParticipantePlano) {
		this.codigoParticipantePlano = codigoParticipantePlano;
	}

	public String getRegimeTributacao() {
		return regimeTributacao;
	}

	public void setRegimeTributacao(String regimeTributacao) {
		this.regimeTributacao = regimeTributacao;
	}

}
