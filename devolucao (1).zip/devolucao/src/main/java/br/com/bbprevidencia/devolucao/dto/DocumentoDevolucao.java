package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   14/03/2017
 * Classe de persistência para tabela DOCUMENTO_DEVOLUCAO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
@Entity
@Table(name = "DOCUMENTO_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "DocumentoDevolucao.findAll", query = "SELECT q FROM DocumentoDevolucao q")
public class DocumentoDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DOCUMENTO_DEVOLUCAO_GER", sequenceName = "S_DDEV_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOCUMENTO_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_DOC_DEV")
	private Long codigo;

	@Column(name = "NOM_DOC_DEV")
	private String nome;

	@Column(name = "IND_TIP_DOC")
	private String indicativoTipoDocumento;

	@Column(name = "DSC_SOL_DOC_DEV_01")
	private String descricaoSolicitacao01;

	@Column(name = "DSC_SOL_DOC_DEV_02")
	private String descricaoSolicitacao02;

	@Column(name = "DSC_SOL_DOC_DEV_03")
	private String descricaoSolicitacao03;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;
}