package br.com.bbprevidencia.devolucao.controle;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.google.gson.Gson;

import br.com.bbprevidencia.devolucao.bo.OptOutBO;
import br.com.bbprevidencia.devolucao.dto.RequisicaoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.RequisicaoSolicitacaoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoSolicitacaoOptOutDTO;

@CrossOrigin("*")
@Controller
@EnableWebMvc
public class OptOutWs {

	public static Logger logger = Logger.getLogger(OptOutWs.class);

	@Autowired
	private OptOutBO optOutBO;

	@RequestMapping(method = RequestMethod.POST, value = "/verificarParticipanteApto", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> verificarParticipanteApto(HttpServletRequest req) throws IOException {

		RetornoOptOutDTO retornoOptOutDTO = new RetornoOptOutDTO();
		Gson gson = new Gson();

		try {
			RequisicaoOptOutDTO reqOptOutDTO = gson.fromJson(req.getReader(), RequisicaoOptOutDTO.class);

			logger.info(">> Objeto solicitação Opt Out: " + reqOptOutDTO.toString());

			//verifica se o participante está logado no portal, caso contrario retorna 
			if (!this.optOutBO.verificaSessaoPortalLogada(Long.parseLong(reqOptOutDTO.getCodigoParticipante()))) {
				logger.info(">>Sessão portal não validada");
				return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Participante não logado na área restrita.");
			}

			retornoOptOutDTO = this.optOutBO.validarParticipanteAptoOptOut(Long.parseLong(reqOptOutDTO.getCodigoParticipante()));

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.OK).body(retornoOptOutDTO);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/processarSolicitacao", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> processarSolicitacao(HttpServletRequest req) throws IOException {

		RetornoSolicitacaoOptOutDTO retSolicitacaoOptOutDTO = new RetornoSolicitacaoOptOutDTO();
		Gson gson = new Gson();

		try {
			RequisicaoSolicitacaoOptOutDTO reqSolOptOutDTO = gson.fromJson(req.getReader(), RequisicaoSolicitacaoOptOutDTO.class);
			logger.info("JSON " + reqSolOptOutDTO);

			//verifica se o participante está logado no portal, caso contrario retorna 
			if (!this.optOutBO.verificaSessaoPortalLogada(reqSolOptOutDTO.getCodigoParticipante())) {
				return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Participante não logado na área restrita.");
			}

			retSolicitacaoOptOutDTO = this.optOutBO.processarSolicitacaoOptOut(reqSolOptOutDTO.getCodigoParticipante(), null);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());

		}

		return ResponseEntity.status(HttpStatus.OK).body(retSolicitacaoOptOutDTO);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/opt-out/verificar", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> verificarOptOut(HttpServletRequest req) throws IOException {

		RetornoOptOutDTO retornoOptOutDTO = new RetornoOptOutDTO();
		Gson gson = new Gson();

		try {
			RequisicaoOptOutDTO reqOptOutDTO = gson.fromJson(req.getReader(), RequisicaoOptOutDTO.class);

			retornoOptOutDTO = this.optOutBO.validarParticipanteAptoOptOut(Long.parseLong(reqOptOutDTO.getCodigoParticipante()));

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}

		return ResponseEntity.status(HttpStatus.OK).body(retornoOptOutDTO);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/opt-out/solicitar", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> solicitarOptOut(HttpServletRequest req) throws IOException {

		RetornoSolicitacaoOptOutDTO retSolicitacaoOptOutDTO = new RetornoSolicitacaoOptOutDTO();
		Gson gson = new Gson();

		try {
			RequisicaoSolicitacaoOptOutDTO reqSolOptOutDTO = gson.fromJson(req.getReader(), RequisicaoSolicitacaoOptOutDTO.class);
			logger.info("JSON " + reqSolOptOutDTO);

			retSolicitacaoOptOutDTO = this.optOutBO.processarSolicitacaoOptOut(reqSolOptOutDTO.getCodigoParticipante(), null);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());

		}

		return ResponseEntity.status(HttpStatus.OK).body(retSolicitacaoOptOutDTO);

	}

}
