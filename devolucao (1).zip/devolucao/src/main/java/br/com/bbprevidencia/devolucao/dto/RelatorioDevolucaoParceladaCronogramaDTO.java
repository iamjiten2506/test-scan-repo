package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

public class RelatorioDevolucaoParceladaCronogramaDTO {

	private String nomeEntidadeParticipante;

	private String nomePlano;

	private String matriculaParticipante;

	private String nomeParticipante;

	private Double quantidadeCotas;

	private Double parcela;

	private Double valorImpostos;

	private Date dataPagamento;

	public String getNomeEntidadeParticipante() {
		return nomeEntidadeParticipante;
	}

	public void setNomeEntidadeParticipante(String nomeEntidadeParticipante) {
		this.nomeEntidadeParticipante = nomeEntidadeParticipante;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public Double getQuantidadeCotas() {
		return quantidadeCotas;
	}

	public void setQuantidadeCotas(Double quantidadeCotas) {
		this.quantidadeCotas = quantidadeCotas;
	}

	public Double getParcela() {
		return parcela;
	}

	public void setParcela(Double parcela) {
		this.parcela = parcela;
	}

	public Double getValorImpostos() {
		return valorImpostos;
	}

	public void setValorImpostos(Double valorImpostos) {
		this.valorImpostos = valorImpostos;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

}
