package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;

/**
 * Classe de Objeto que recebe todas as informações relacionadas com a parametrização
 * das Regras de Devolução 
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 08/02/2017
 *
 */
public class RegraDevolucaoParametrizacaoDTO implements Serializable {

	private static final long serialVersionUID = 3638776777470705645L;

	private PlanoPrevidencia planoPrevidencia;

	private PlanoVigenciaDevolucao planoVigenciaDevolucao;

	private RegraDevolucao regraDevolucao;

	private List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

	private List<RegraElegibilidadeDevolucao> listaRegraElegibilidadeDevolucao = new ArrayList<RegraElegibilidadeDevolucao>();

	private List<RegraDevolucaoContribuicao> listaRegraDevolucaoContribuicao = new ArrayList<RegraDevolucaoContribuicao>();

	private List<RegraDevolucaoContribFaixas> listaRegraDevolucaoContribFaixas = new ArrayList<RegraDevolucaoContribFaixas>();

	private List<PlanoContribFaixasDev> listaRegraPlanoContibFaixasDevolucao = new ArrayList<PlanoContribFaixasDev>();

	private HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao = new HistoricoSituacaoRegraDevolucao();

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public PlanoVigenciaDevolucao getPlanoVigenciaDevolucao() {
		return planoVigenciaDevolucao;
	}

	public void setPlanoVigenciaDevolucao(PlanoVigenciaDevolucao planoVigenciaDevolucao) {
		this.planoVigenciaDevolucao = planoVigenciaDevolucao;
	}

	public List<RegraCalculoDevolucao> getListaRegraCalculoDevolucao() {
		return listaRegraCalculoDevolucao;
	}

	public void setListaRegraCalculoDevolucao(List<RegraCalculoDevolucao> listaRegraCalculoDevolucao) {
		this.listaRegraCalculoDevolucao = listaRegraCalculoDevolucao;
	}

	public List<RegraDevolucaoContribuicao> getListaRegraDevolucaoContribuicao() {
		return listaRegraDevolucaoContribuicao;
	}

	public void setListaRegraDevolucaoContribuicao(List<RegraDevolucaoContribuicao> listaRegraDevolucaoContribuicao) {
		this.listaRegraDevolucaoContribuicao = listaRegraDevolucaoContribuicao;
	}

	public List<RegraDevolucaoContribFaixas> getListaRegraDevolucaoContribFaixas() {
		return listaRegraDevolucaoContribFaixas;
	}

	public void setListaRegraDevolucaoContribFaixas(List<RegraDevolucaoContribFaixas> listaRegraDevolucaoContribFaixas) {
		this.listaRegraDevolucaoContribFaixas = listaRegraDevolucaoContribFaixas;
	}

	public List<PlanoContribFaixasDev> getListaRegraPlanoContibFaixasDevolucao() {
		return listaRegraPlanoContibFaixasDevolucao;
	}

	public void setListaRegraPlanoContibFaixasDevolucao(List<PlanoContribFaixasDev> listaRegraPlanoContibFaixasDevolucao) {
		this.listaRegraPlanoContibFaixasDevolucao = listaRegraPlanoContibFaixasDevolucao;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public HistoricoSituacaoRegraDevolucao getHistoricoSituacaoRegraDevolucao() {
		return historicoSituacaoRegraDevolucao;
	}

	public void setHistoricoSituacaoRegraDevolucao(HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao) {
		this.historicoSituacaoRegraDevolucao = historicoSituacaoRegraDevolucao;
	}

	public List<RegraElegibilidadeDevolucao> getListaRegraElegibilidadeDevolucao() {
		return listaRegraElegibilidadeDevolucao;
	}

	public void setListaRegraElegibilidadeDevolucao(List<RegraElegibilidadeDevolucao> listaRegraElegibilidadeDevolucao) {
		this.listaRegraElegibilidadeDevolucao = listaRegraElegibilidadeDevolucao;
	}

}
