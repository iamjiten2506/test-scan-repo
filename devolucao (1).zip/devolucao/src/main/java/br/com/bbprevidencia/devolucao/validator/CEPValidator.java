/**
 * 
 */
package br.com.bbprevidencia.devolucao.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.apache.commons.lang.StringUtils;

/**
 *
 * @author tiago
 * @since 11/10/2013
 * 
 * Copyright notice (c) 2013 BBPrevidência S/A 
 */
@FacesValidator(value = "br.com.bbprevidencia.cadastroweb.validador.CEPValidator")
public class CEPValidator implements Validator {

	private static final String MENSAGEM = "CEP inválido.";

	public static final String CEP_PARTNER = "[0-9]{5}-[0-9]{3}";

	public static final String NUMERO_CEP_PARTNER = "[0-9]{8}";

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {

		if (value != null) {

			String cep = (String) value;

			if (StringUtils.isNotEmpty(cep) && !isCEPValido(cep)) {

				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", MENSAGEM);

				throw new ValidatorException(message);
			}
		}
	}

	/**
	 * 
	 * @param cep
	 * @return boolean
	 */
	public static boolean isCEPValido(String cep) {

		if (StringUtils.isNotBlank(cep)) {

			Pattern pattern = Pattern.compile(NUMERO_CEP_PARTNER);
			Matcher matcher = pattern.matcher(cep);

			return matcher.matches();
		}

		return false;
	}

}
