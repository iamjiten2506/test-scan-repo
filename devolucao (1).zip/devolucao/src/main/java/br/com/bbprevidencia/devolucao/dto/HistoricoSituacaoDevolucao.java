package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   08/12/2016
 * Classe de persistência para tabela HIS_SIT_DEV.
 */
@Entity
@Table(name = "HST_SIT_DEV", schema = "OWN_DCR")
@NamedQuery(name = "HistoricoSituacaoDevolucao.findAll", query = "SELECT q FROM HistoricoSituacaoDevolucao q")
public class HistoricoSituacaoDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "HIS_SIT_DEV_GER", sequenceName = "S_HSD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "HIS_SIT_DEV_GER")
	@Column(name = "NUM_SEQ_HST_SIT_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SIT_DEV")
	private SituacaoDevolucao situacaoDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_HST_SIT")
	private Date dataHistorico;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_COT")
	private Date dataCota;

	@Column(name = "VAL_COT")
	private double valorCota;

	@Column(name = "VAL_IND_AJU")
	private double valorIndiceAjustado;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public HistoricoSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao, Devolucao devolucao, Date dataHistorico, Date dataCota, double valorCota, double valorIndiceAjustado, Date dataInclusao,
			String nomeUsuarioInclusao) {
		super();
		this.situacaoDevolucao = situacaoDevolucao;
		this.devolucao = devolucao;
		this.dataHistorico = dataHistorico;
		this.dataCota = dataCota;
		this.valorCota = valorCota;
		this.valorIndiceAjustado = valorIndiceAjustado;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
		this.dataInclusao = dataInclusao;
	}

	public HistoricoSituacaoDevolucao() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public SituacaoDevolucao getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public Date getDataHistorico() {
		return dataHistorico;
	}

	public void setDataHistorico(Date dataHistorico) {
		this.dataHistorico = dataHistorico;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public double getValorCota() {
		return valorCota;
	}

	public void setValorCota(double valorCota) {
		this.valorCota = valorCota;
	}

	public double getValorIndiceAjustado() {
		return valorIndiceAjustado;
	}

	public void setValorIndiceAjustado(double valorIndiceAjustado) {
		this.valorIndiceAjustado = valorIndiceAjustado;
	}

}