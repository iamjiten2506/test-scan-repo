package br.com.bbprevidencia.devolucao.util;

import java.util.List;

import javax.faces.model.ListDataModel;

import org.primefaces.model.SelectableDataModel;

import br.com.bbprevidencia.cadastroweb.dto.Texto;

/**
 * Classe responsável por criar uma tabela com 
 * cada linha da tabela sendo um mapeada por radioButton
 * 
 */

public class TextoDataModel extends ListDataModel<Texto> implements SelectableDataModel<Texto> {

	public TextoDataModel() {
	}

	public TextoDataModel(List<Texto> texto) {
		super(texto);
	}

	@Override
	public Object getRowKey(Texto texto) {
		return texto.getCodigo();
	}

	@Override
	@SuppressWarnings("unchecked")
	public Texto getRowData(String codigo) {

		List<Texto> listaTexto = (List<Texto>) getWrappedData();

		for (Texto texto : listaTexto) {
			if (texto.getCodigo().equals(codigo))
				return texto;
		}

		return null;
	}

}
