package br.com.bbprevidencia.devolucao.enumerador;

public enum PesquisaRelatoriosEnum {

	SQL_CONSULTA_RELATORIO_VALOR_TESOURARIA(" ", sqlRelatorioValorTesousaria()),
	SQL_CONSULTA_RELATORIO_COAF(" ", sqlCOAF()),
	SQL_CONSULTA_RELATORIO_IN1452(" ", sqlIN1452()),
	SQL_CONSULTA_RELATORIO_HISTORICO_PAGAMENTOS_FICHA_DEVOLUCAO(" ", sqlHistPagFichDev()),
	SQL_CONSULTA_RELATORIO_RESUMO_CRONOGRAMA(" ", sqlResumoCronograma());

	private String descricao;
	private String sql;

	private PesquisaRelatoriosEnum(String descricao, String sql) {
		this.descricao = descricao;
		this.sql = sql;
	}

	private static String sqlRelatorioValorTesousaria() {

		StringBuilder sb = new StringBuilder();

		sb.append(" SELECT SUM(DECODE(RP.IND_PRO_DES, 'P', VAL_RUB, 0)) AS VALOR_PROVENTO,  ");
		sb.append(" SUM(DECODE(RP.IND_PRO_DES, 'D', VAL_RUB, 0)) AS VALOR_DESCONTO,  		");
		sb.append(" SUM(DECODE(RP.NUM_SEQ_TIPO_RUBRICA, 4, VAL_RUB, 0)) AS  VALOR_IR,		");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" NULL AS NUM_SEQ_RECEBEDOR,   											");
		sb.append(" NULL AS NOM_RECEBEDOR,        											");
		sb.append(" NULL AS DAT_REQ, 														");
		sb.append(" NULL AS CPF,     														");
		sb.append(" NULL AS NUM_CNPJ,  														");
		sb.append(" NULL AS NUM_SEQ_PARTIC_PLANO,											");
		sb.append(" NUM_SEQ_DEV,															");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" DAT_COT,																");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" VAL_IND_AJU																");
		sb.append(" FROM MOV_CAL_PGT_DEV MC,												");
		sb.append(" RUBRICA_DEVOLUCAO RP,													");
		sb.append(" CRONOGRAMA_DEVOLUCAO CD,												");
		sb.append(" RECEBEDOR RE,															");
		sb.append(" PARTICIPANTE PA,     													");
		sb.append(" ENTIDADE_PARTICIPANTE EP     											");
		sb.append(" WHERE MC.NUM_SEQ_RUB_DEV = RP.NUM_SEQ_RUB_DEV							");
		sb.append(" AND MC.NUM_SEQ_CRO_DEV = CD.NUM_SEQ_CRO_DEV								");
		sb.append(" AND MC.NUM_SEQ_RECEBEDOR = RE.NUM_SEQ_RECEBEDOR							");
		sb.append(" AND PA.NUM_SEQ_PARTIC = RE.NUM_SEQ_PARTIC								");
		sb.append(" AND EP.NUM_SEQ_ENTID_PARTIC = PA.NUM_SEQ_ENTID_PARTIC					");
		sb.append(" AND EP.NUM_SEQ_FUNDO_PREVD = PA.NUM_SEQ_FUNDO_PREVD  					");
		sb.append(" AND CD.NUM_SEQ_CRO_DEV = :codigoCronograma								");
		sb.append(" GROUP BY NUM_SEQ_DEV,													");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" DAT_COT,																");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" VAL_IND_AJU																");
		sb.append("          																");
		sb.append(" UNION																	");
		sb.append(" 																		");
		sb.append(" SELECT SUM(DECODE(RP.IND_PRO_DES, 'P', VAL_RUB, 0)) AS VALOR_PROVENTO,	");
		sb.append(" SUM(DECODE(RP.IND_PRO_DES, 'D', VAL_RUB, 0)) AS VALOR_DESCONTO,  		");
		sb.append(" SUM(DECODE(RP.NUM_SEQ_TIPO_RUBRICA, 4, VAL_RUB, 0)) AS  VALOR_IR,		");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" NULL AS NUM_SEQ_RECEBEDOR,   											");
		sb.append(" NULL AS NOM_RECEBEDOR,        											");
		sb.append(" NULL AS DAT_REQ, 														");
		sb.append(" NULL AS CPF,     														");
		sb.append(" NULL AS NUM_CNPJ,  														");
		sb.append(" NULL AS NUM_SEQ_PARTIC_PLANO,											");
		sb.append(" NUM_SEQ_DEV,															");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" DAT_COT,																");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" VAL_IND_AJU																");
		sb.append(" FROM HST_PGT_DEV MC,													");
		sb.append(" RUBRICA_DEVOLUCAO RP,													");
		sb.append(" CRONOGRAMA_DEVOLUCAO CD,												");
		sb.append(" RECEBEDOR RE,															");
		sb.append(" PARTICIPANTE PA,     													");
		sb.append(" ENTIDADE_PARTICIPANTE EP     											");
		sb.append(" WHERE MC.NUM_SEQ_RUB_DEV = RP.NUM_SEQ_RUB_DEV							");
		sb.append(" AND MC.NUM_SEQ_CRO_DEV = CD.NUM_SEQ_CRO_DEV								");
		sb.append(" AND MC.NUM_SEQ_RECEBEDOR = RE.NUM_SEQ_RECEBEDOR							");
		sb.append(" AND PA.NUM_SEQ_PARTIC = RE.NUM_SEQ_PARTIC								");
		sb.append(" AND EP.NUM_SEQ_ENTID_PARTIC = PA.NUM_SEQ_ENTID_PARTIC					");
		sb.append(" AND EP.NUM_SEQ_FUNDO_PREVD = PA.NUM_SEQ_FUNDO_PREVD  					");
		sb.append(" AND CD.NUM_SEQ_CRO_DEV = :codigoCronograma								");
		sb.append(" GROUP BY NUM_SEQ_DEV,													");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,													    ");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" DAT_COT,																");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" VAL_IND_AJU																");
		sb.append(" ORDER BY 3, 4    														");

		return sb.toString();

	}

	private static String sqlIN1452() {

		StringBuilder sb = new StringBuilder();

		sb.append(" SELECT SUM(DECODE(RP.IND_PRO_DES, 'P', VAL_RUB, 0)) AS VALOR_PROVENTO,  ");
		sb.append(" SUM(DECODE(RP.IND_PRO_DES, 'D', VAL_RUB, 0)) AS VALOR_DESCONTO,  		");
		sb.append(" SUM(DECODE(RP.NUM_SEQ_TIPO_RUBRICA, 4, VAL_RUB, 0)) AS  VALOR_IR,		");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" LPAD( RE.NUM_CPF, 9, '0' ) || LPAD( RE.NUM_COMPL_CPF, 2, '0' ) AS CPF,  ");
		sb.append(" LPAD(FP.NUM_CNPJ, 14, '0') 	NUM_CNPJ,  									");
		sb.append(" DE.NUM_SEQ_PARTIC_PLANO,												");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" DE.NUM_SEQ_DEV,															");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" MC.DAT_COT,																");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" MC.VAL_IND_AJU															");
		sb.append(" FROM MOV_CAL_PGT_DEV MC,												");
		sb.append(" RUBRICA_DEVOLUCAO RP,													");
		sb.append(" CRONOGRAMA_DEVOLUCAO CD,												");
		sb.append(" RECEBEDOR RE,															");
		sb.append(" PARTICIPANTE PA,     													");
		sb.append(" PARTICIPANTE_PLANO PP,    													");
		sb.append(" DEVOLUCAO DE,       													");
		sb.append(" FUNDO_PREVIDENCIA FP,  													");
		sb.append(" ENTIDADE_PARTICIPANTE EP     											");
		sb.append(" WHERE MC.NUM_SEQ_RUB_DEV = RP.NUM_SEQ_RUB_DEV							");
		sb.append(" AND MC.NUM_SEQ_CRO_DEV = CD.NUM_SEQ_CRO_DEV								");
		sb.append(" AND MC.NUM_SEQ_RECEBEDOR = RE.NUM_SEQ_RECEBEDOR							");
		sb.append(" AND PA.NUM_SEQ_PARTIC = RE.NUM_SEQ_PARTIC								");
		sb.append(" AND EP.NUM_SEQ_ENTID_PARTIC = PA.NUM_SEQ_ENTID_PARTIC					");
		sb.append(" AND EP.NUM_SEQ_FUNDO_PREVD = PA.NUM_SEQ_FUNDO_PREVD  					");
		sb.append(" AND MC.NUM_SEQ_DEV = DE.NUM_SEQ_DEV                 					");
		sb.append(" AND FP.NUM_SEQ_FUNDO_PREVD = EP.NUM_SEQ_FUNDO_PREVD						");
		sb.append(" AND PP.NUM_SEQ_PARTIC_PLANO = DE.NUM_SEQ_PARTIC_PLANO					");
		sb.append(" AND CD.DAT_PGT  >= :dataInicial    										");
		sb.append(" AND CD.DAT_PGT  <= :dataFinal    										");
		sb.append(" GROUP BY DE.NUM_SEQ_DEV,												");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" MC.DAT_COT,																");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" RE.NUM_CPF,																");
		sb.append(" RE.NUM_COMPL_CPF,														");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" DE.NUM_SEQ_PARTIC_PLANO,												");
		sb.append(" FP.NUM_CNPJ,															");
		sb.append(" MC.VAL_IND_AJU																");
		sb.append("          																");
		sb.append(" UNION																	");
		sb.append(" 																		");
		sb.append(" SELECT SUM(DECODE(RP.IND_PRO_DES, 'P', VAL_RUB, 0)) AS VALOR_PROVENTO,	");
		sb.append(" SUM(DECODE(RP.IND_PRO_DES, 'D', VAL_RUB, 0)) AS VALOR_DESCONTO,  		");
		sb.append(" SUM(DECODE(RP.NUM_SEQ_TIPO_RUBRICA, 4, VAL_RUB, 0)) AS  VALOR_IR,		");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" LPAD( RE.NUM_CPF, 9, '0' ) || LPAD( RE.NUM_COMPL_CPF, 2, '0' ) AS CPF,  ");
		sb.append(" LPAD(FP.NUM_CNPJ, 14, '0') 	NUM_CNPJ, 									");
		sb.append(" DE.NUM_SEQ_PARTIC_PLANO,												");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" DE.NUM_SEQ_DEV,															");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" MC.DAT_COT,																");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" MC.VAL_IND_AJU																");
		sb.append(" FROM HST_PGT_DEV MC,													");
		sb.append(" RUBRICA_DEVOLUCAO RP,													");
		sb.append(" CRONOGRAMA_DEVOLUCAO CD,												");
		sb.append(" RECEBEDOR RE,															");
		sb.append(" PARTICIPANTE PA,     													");
		sb.append(" PARTICIPANTE_PLANO PP,    													");
		sb.append(" DEVOLUCAO DE,       													");
		sb.append(" FUNDO_PREVIDENCIA FP,  													");
		sb.append(" ENTIDADE_PARTICIPANTE EP     											");
		sb.append(" WHERE MC.NUM_SEQ_RUB_DEV = RP.NUM_SEQ_RUB_DEV							");
		sb.append(" AND MC.NUM_SEQ_CRO_DEV = CD.NUM_SEQ_CRO_DEV								");
		sb.append(" AND MC.NUM_SEQ_RECEBEDOR = RE.NUM_SEQ_RECEBEDOR							");
		sb.append(" AND PA.NUM_SEQ_PARTIC = RE.NUM_SEQ_PARTIC								");
		sb.append(" AND EP.NUM_SEQ_ENTID_PARTIC = PA.NUM_SEQ_ENTID_PARTIC					");
		sb.append(" AND EP.NUM_SEQ_FUNDO_PREVD = PA.NUM_SEQ_FUNDO_PREVD  					");
		sb.append(" AND MC.NUM_SEQ_DEV = DE.NUM_SEQ_DEV                 					");
		sb.append(" AND FP.NUM_SEQ_FUNDO_PREVD = EP.NUM_SEQ_FUNDO_PREVD						");
		sb.append(" AND PP.NUM_SEQ_PARTIC_PLANO = DE.NUM_SEQ_PARTIC_PLANO					");
		sb.append(" AND CD.DAT_PGT  >= :dataInicial    										");
		sb.append(" AND CD.DAT_PGT  <= :dataFinal    										");
		sb.append(" GROUP BY DE.NUM_SEQ_DEV,												");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,													    ");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" MC.DAT_COT,																");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" RE.NUM_CPF,																");
		sb.append(" RE.NUM_COMPL_CPF,														");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" DE.NUM_SEQ_PARTIC_PLANO,												");
		sb.append(" FP.NUM_CNPJ,															");
		sb.append(" MC.VAL_IND_AJU																");
		sb.append(" ORDER BY 3, 4    														");

		return sb.toString();

	}

	private static String sqlCOAF() {

		StringBuilder sb = new StringBuilder();

		sb.append(" SELECT SUM(DECODE(RP.IND_PRO_DES, 'P', VAL_RUB, 0)) AS VALOR_PROVENTO,  ");
		sb.append(" SUM(DECODE(RP.IND_PRO_DES, 'D', VAL_RUB, 0)) AS VALOR_DESCONTO,  		");
		sb.append(" SUM(DECODE(RP.NUM_SEQ_TIPO_RUBRICA, 4, VAL_RUB, 0)) AS  VALOR_IR,		");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" LPAD( RE.NUM_CPF, 9, '0' ) || LPAD( RE.NUM_COMPL_CPF, 2, '0' ) AS CPF,  ");
		sb.append(" FP.NUM_CNPJ,															");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" PA.NUM_MATRIC_PATROC													");
		sb.append(" FROM MOV_CAL_PGT_DEV MC,												");
		sb.append(" RUBRICA_DEVOLUCAO RP,													");
		sb.append(" CRONOGRAMA_DEVOLUCAO CD,												");
		sb.append(" RECEBEDOR RE,															");
		sb.append(" PARTICIPANTE PA,     													");
		sb.append(" PARTICIPANTE_PLANO PP,    													");
		sb.append(" DEVOLUCAO DE,       													");
		sb.append(" FUNDO_PREVIDENCIA FP,  													");
		sb.append(" ENTIDADE_PARTICIPANTE EP     											");
		sb.append(" WHERE MC.NUM_SEQ_RUB_DEV = RP.NUM_SEQ_RUB_DEV							");
		sb.append(" AND MC.NUM_SEQ_CRO_DEV = CD.NUM_SEQ_CRO_DEV								");
		sb.append(" AND MC.NUM_SEQ_RECEBEDOR = RE.NUM_SEQ_RECEBEDOR							");
		sb.append(" AND PA.NUM_SEQ_PARTIC = RE.NUM_SEQ_PARTIC								");
		sb.append(" AND EP.NUM_SEQ_ENTID_PARTIC = PA.NUM_SEQ_ENTID_PARTIC					");
		sb.append(" AND EP.NUM_SEQ_FUNDO_PREVD = PA.NUM_SEQ_FUNDO_PREVD  					");
		sb.append(" AND MC.NUM_SEQ_DEV = DE.NUM_SEQ_DEV                 					");
		sb.append(" AND FP.NUM_SEQ_FUNDO_PREVD = EP.NUM_SEQ_FUNDO_PREVD						");
		sb.append(" AND PP.NUM_SEQ_PARTIC_PLANO = DE.NUM_SEQ_PARTIC_PLANO					");
		sb.append(" AND CD.DAT_PGT  >= :dataInicial    										");
		sb.append(" AND CD.DAT_PGT  <= :dataFinal    										");
		sb.append(" GROUP BY NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" RE.NUM_CPF,																");
		sb.append(" RE.NUM_COMPL_CPF,														");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" FP.NUM_CNPJ  															");
		sb.append("          																");
		sb.append(" UNION																	");
		sb.append(" 																		");
		sb.append(" SELECT SUM(DECODE(RP.IND_PRO_DES, 'P', VAL_RUB, 0)) AS VALOR_PROVENTO,	");
		sb.append(" SUM(DECODE(RP.IND_PRO_DES, 'D', VAL_RUB, 0)) AS VALOR_DESCONTO,  		");
		sb.append(" SUM(DECODE(RP.NUM_SEQ_TIPO_RUBRICA, 4, VAL_RUB, 0)) AS  VALOR_IR,		");
		sb.append(" NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" LPAD( RE.NUM_CPF, 9, '0' ) || LPAD( RE.NUM_COMPL_CPF, 2, '0' ) AS CPF,  ");
		sb.append(" FP.NUM_CNPJ,															");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,														");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" PA.NUM_MATRIC_PATROC													");
		sb.append(" FROM HST_PGT_DEV MC,													");
		sb.append(" RUBRICA_DEVOLUCAO RP,													");
		sb.append(" CRONOGRAMA_DEVOLUCAO CD,												");
		sb.append(" RECEBEDOR RE,															");
		sb.append(" PARTICIPANTE PA,     													");
		sb.append(" PARTICIPANTE_PLANO PP,    													");
		sb.append(" DEVOLUCAO DE,       													");
		sb.append(" FUNDO_PREVIDENCIA FP,  													");
		sb.append(" ENTIDADE_PARTICIPANTE EP     											");
		sb.append(" WHERE MC.NUM_SEQ_RUB_DEV = RP.NUM_SEQ_RUB_DEV							");
		sb.append(" AND MC.NUM_SEQ_CRO_DEV = CD.NUM_SEQ_CRO_DEV								");
		sb.append(" AND MC.NUM_SEQ_RECEBEDOR = RE.NUM_SEQ_RECEBEDOR							");
		sb.append(" AND PA.NUM_SEQ_PARTIC = RE.NUM_SEQ_PARTIC								");
		sb.append(" AND EP.NUM_SEQ_ENTID_PARTIC = PA.NUM_SEQ_ENTID_PARTIC					");
		sb.append(" AND EP.NUM_SEQ_FUNDO_PREVD = PA.NUM_SEQ_FUNDO_PREVD  					");
		sb.append(" AND MC.NUM_SEQ_DEV = DE.NUM_SEQ_DEV                 					");
		sb.append(" AND FP.NUM_SEQ_FUNDO_PREVD = EP.NUM_SEQ_FUNDO_PREVD						");
		sb.append(" AND PP.NUM_SEQ_PARTIC_PLANO = DE.NUM_SEQ_PARTIC_PLANO					");
		sb.append(" AND CD.DAT_PGT  >= :dataInicial    										");
		sb.append(" AND CD.DAT_PGT  <= :dataFinal    										");
		sb.append(" GROUP BY NOM_ABREV_ENTID_PARTIC,													");
		sb.append(" CD.DAT_PGT,																");
		sb.append(" PA.NUM_SEQ_PARTIC,													    ");
		sb.append(" PA.NOM_PARTIC,															");
		sb.append(" RE.NUM_SEQ_RECEBEDOR,   												");
		sb.append(" PA.NUM_MATRIC_PATROC,													");
		sb.append(" DE.DAT_REQ, 															");
		sb.append(" RE.NUM_CPF,																");
		sb.append(" RE.NUM_COMPL_CPF,														");
		sb.append(" RE.NOM_RECEBEDOR,        												");
		sb.append(" FP.NUM_CNPJ															");
		sb.append(" ORDER BY 3, 4    														");

		return sb.toString();

	}

	private static String sqlHistPagFichDev() {
		StringBuilder sb = new StringBuilder();

		sb.append("SELECT FD.NUM_SEQ_CRONOGRAMA_FOLHA , ");
		sb.append("       TF.NOM_TIPO_FOLHA, ");
		sb.append("       CF.DAT_REFCIA, ");
		sb.append("       A.DAT_COTA AS DAT_COTA, ");
		sb.append("       CB.NUM_SEQ_PARTIC_PLANO, ");
		sb.append("       CF.NUM_SEQ_TIPO_FOLHA, ");
		sb.append("       CB.NUM_MATRIC_PATROC, ");
		sb.append("       CB.NOM_PARTIC, ");
		sb.append("       SUM(FD.QTD_COTA_UTIL) AS QTD_COTA_UTIL, ");
		sb.append("       B.QTD_TOTAL_RESTANTE, ");
		sb.append("       NVL(CB.VAL_SALDO_CONTA_INIC, 0) + ");
		sb.append("       CASE WHEN (D.CONT_FICHA = 0 OR D.CONT_FICHA IS NULL) AND (E.CONT_FICHA_INI = 0 OR E.CONT_FICHA_INI IS NULL) ");
		sb.append("            THEN NVL(C.QTD_TOTAL_AMAIOR, 0) ");
		sb.append("            ELSE 0 ");
		sb.append("       END AS QTD_TOTAL, ");
		sb.append("       CB.NOM_ABREV_ENTID_PARTIC, ");
		sb.append("       CB.NOM_PLANO, ");
		sb.append("       CB.NUM_SEQ_ENTID_PARTIC, ");
		sb.append("       CB.NUM_SEQ_PLANO, ");
		sb.append("       CB.NUM_SEQ_FUNDO_PREVD, ");
		sb.append("       FD.NUM_SEQ_PERFIL_INVEST, ");
		sb.append("       CASE WHEN D.CONT_FICHA = 0 OR D.CONT_FICHA IS NULL ");
		sb.append("            THEN 0 ");
		sb.append("            ELSE NVL(C.QTD_TOTAL_AMAIOR, 0) ");
		sb.append("       END AS QTD_TOTAL_AMAIOR, ");
		sb.append("       CB.val_cota_concessao AS val_cota_concessao, ");
		sb.append("       CF.dat_credito_bancario, ");
		sb.append("       CB.VAL_SALDO_CONTA_INIC ");
		sb.append("FROM CRONOGRAMA_FOLHA CF, ");
		sb.append("     TIPO_FOLHA TF, ");
		sb.append("     FICHA_DEV_DETALHE FD, ");
		sb.append("     FICHA_DEVOLUCOES FF, ");
		sb.append("     HISTORICO_FINANCEIRO_PAGO FP, ");
		sb.append("     V_PARTIC_CONCESSAO CB, ");
		sb.append("     (SELECT DISTINCT DAT_COTA, ");
		sb.append("                      NUM_SEQ_BENEF, ");
		sb.append("                      NUM_SEQ_CRONOGRAMA_FOLHA ");
		sb.append("      FROM HISTORICO_PAG_BENEFICIO PB) A, ");
		sb.append("     (SELECT NUM_SEQ_BENEF, ");
		sb.append("             SUM(NVL(FD.QTD_COTA_CONTRI, 0) + ");
		sb.append("                 NVL(FD.QTD_COTA_JUROS, 0) + ");
		sb.append("                 NVL(FD.QTD_COTA_CORR, 0) + ");
		sb.append("                 NVL(FD.QTD_COTA_MULTA, 0) ");
		sb.append("                ) AS QTD_TOTAL, ");
		sb.append("             SUM((NVL(FD.QTD_COTA_CONTRI, 0) * (1 - FD.FATOR_DEV_FICHA)) + ");
		sb.append("                 (NVL(FD.QTD_COTA_JUROS, 0) * (1 - FD.FATOR_DEV_FICHA)) + ");
		sb.append("                 (NVL(FD.QTD_COTA_CORR, 0) * (1 - FD.FATOR_DEV_FICHA)) + ");
		sb.append("                 (NVL(FD.QTD_COTA_MULTA, 0) * (1 - FD.FATOR_DEV_FICHA)) ");
		sb.append("                ) AS QTD_TOTAL_RESTANTE ");
		sb.append("      FROM FICHA_DEVOLUCOES FD ");
		sb.append("      WHERE FD.NUM_SEQ_BENEF = NVL(:numSeqBenef, FD.NUM_SEQ_BENEF) ");
		sb.append("        AND (FD.IND_MANTENEDOR != 'S' AND FD.NUM_SEQ_HIST_FIN_PAGO IS NOT NULL) ");
		sb.append("      GROUP BY NUM_SEQ_BENEF) B, ");
		sb.append("     (SELECT NUM_SEQ_BENEF, ");
		sb.append("             SUM(NVL(FD.QTD_COTA_CONTRI, 0) + ");
		sb.append("                 NVL(FD.QTD_COTA_JUROS, 0) + ");
		sb.append("                 NVL(FD.QTD_COTA_CORR, 0) + ");
		sb.append("                 NVL(FD.QTD_COTA_MULTA, 0) ");
		sb.append("                ) AS QTD_TOTAL_AMAIOR ");
		sb.append("      FROM FICHA_DEVOLUCOES FD ");
		sb.append("      WHERE FD.NUM_SEQ_BENEF = NVL(:numSeqBenef, FD.NUM_SEQ_BENEF) ");
		sb.append("        AND (FD.IND_MANTENEDOR = 'S' AND FD.NUM_SEQ_HIST_FIN_PAGO IS NULL AND FD.SIG_VARIAV IS NULL) ");
		sb.append("      GROUP BY NUM_SEQ_BENEF) C, ");
		sb.append("     (SELECT COUNT(1) AS CONT_FICHA, ");
		sb.append("             FDD.NUM_SEQ_BENEF ");
		sb.append("      FROM FICHA_DEVOLUCOES FDD ");
		sb.append("      WHERE FDD.NUM_SEQ_BENEF = NVL(:numSeqBenef, FDD.NUM_SEQ_BENEF) ");
		sb.append("        AND FDD.NUM_SEQ_HIST_FIN_PAGO IS NOT NULL ");
		sb.append("      GROUP BY FDD.NUM_SEQ_BENEF) D, ");
		sb.append("     (SELECT COUNT(1) AS CONT_FICHA_INI, ");
		sb.append("             FDD.NUM_SEQ_BENEF ");
		sb.append("      FROM FICHA_DEVOLUCOES FDD ");
		sb.append("      WHERE FDD.NUM_SEQ_BENEF = NVL(:numSeqBenef, FDD.NUM_SEQ_BENEF) ");
		sb.append("        AND (FDD.IND_MANTENEDOR = 'S' AND FDD.NUM_SEQ_HIST_FIN_PAGO IS NULL AND FDD.SIG_VARIAV IS NULL) ");
		sb.append("      GROUP BY FDD.NUM_SEQ_BENEF) E ");
		sb.append("WHERE FD.NUM_SEQ_CRONOGRAMA_FOLHA = CF.NUM_SEQ_CRONOGRAMA_FOLHA ");
		sb.append("  AND FF.NUM_SEQ_FICHA_DEV = FD.NUM_SEQ_FICHA_DEV ");
		sb.append("  AND TF.NUM_SEQ_TIPO_FOLHA = CF.NUM_SEQ_TIPO_FOLHA ");
		sb.append("  AND FP.NUM_SEQ_HIST_FIN_PAGO(+) = FF.NUM_SEQ_HIST_FIN_PAGO ");
		sb.append("  AND FF.NUM_SEQ_BENEF = CB.NUM_SEQ_BENEF ");
		sb.append("  AND FF.NUM_SEQ_BENEF = NVL(:numSeqBenef, FF.NUM_SEQ_BENEF) ");
		sb.append("  AND A.NUM_SEQ_BENEF = FF.NUM_SEQ_BENEF ");
		sb.append("  AND A.NUM_SEQ_CRONOGRAMA_FOLHA = FD.NUM_SEQ_CRONOGRAMA_FOLHA ");
		sb.append("  AND B.NUM_SEQ_BENEF(+) = CB.NUM_SEQ_BENEF ");
		sb.append("  AND CB.NUM_SEQ_BENEF = C.NUM_SEQ_BENEF(+) ");
		sb.append("  AND CB.NUM_SEQ_BENEF = D.NUM_SEQ_BENEF(+) ");
		sb.append("  AND CB.NUM_SEQ_BENEF = E.NUM_SEQ_BENEF(+) ");
		sb.append("GROUP BY FD.NUM_SEQ_CRONOGRAMA_FOLHA, ");
		sb.append("         TF.NOM_TIPO_FOLHA, ");
		sb.append("         CF.DAT_REFCIA, ");
		sb.append("         CB.NUM_SEQ_PARTIC_PLANO, ");
		sb.append("         CB.NUM_MATRIC_PATROC, ");
		sb.append("         CB.NOM_PARTIC, ");
		sb.append("         A.DAT_COTA, ");
		sb.append("         CF.NUM_SEQ_TIPO_FOLHA, ");
		sb.append("         B.QTD_TOTAL_RESTANTE, ");
		sb.append("         B.QTD_TOTAL, ");
		sb.append("         CB.NOM_ABREV_ENTID_PARTIC, ");
		sb.append("         CB.NOM_PLANO, ");
		sb.append("         CB.NUM_SEQ_ENTID_PARTIC, ");
		sb.append("         CB.NUM_SEQ_PLANO, ");
		sb.append("         CB.NUM_SEQ_FUNDO_PREVD, ");
		sb.append("         FD.NUM_SEQ_PERFIL_INVEST, ");
		sb.append("         C.QTD_TOTAL_AMAIOR, ");
		sb.append("         D.CONT_FICHA, ");
		sb.append("         E.CONT_FICHA_INI, ");
		sb.append("         CB.val_cota_concessao, ");
		sb.append("         CF.dat_credito_bancario, ");
		sb.append("         CB.VAL_SALDO_CONTA_INIC ");
		sb.append("ORDER BY CF.DAT_REFCIA, ");
		sb.append("         CF.NUM_SEQ_TIPO_FOLHA ");

		return sb.toString();
	}

	private static String sqlResumoCronograma() {
		StringBuilder sb = new StringBuilder();

		sb.append(" SELECT DE.NUM_SEQ_DEV, ");
		sb.append("       PR.NOM_PLANO       PLANO, ");
		sb.append("       PA.NOM_PARTIC      PARTICIPANTE, ");
		sb.append("       CD.DAT_PGT         DATA_PAGAMENTO, ");
		sb.append("       HS.DAT_COT         DATA_COTA, ");
		sb.append("       NVL(CO.RESG_PARTIC, 0) + NVL(CO.REMA_PARTIC, 0) QTDE_COTAS_PARTIC, ");
		sb.append("       NVL(CO.RESG_PATROC, 0) + NVL(CO.REMA_PATROC, 0) QTDE_COTAS_PATROC, ");
		sb.append("       NVL(CO.REVER_PARTIC, 0) + NVL(CO.REVER_PATROC, 0) QTDE_COTAS_REVER, ");
		sb.append("       (NVL(CO.RESG_PARTIC, 0) + NVL(CO.REMA_PARTIC, 0)) * HS.val_cot VALOR_PARTIC, ");
		sb.append("       (NVL(CO.RESG_PATROC, 0) + NVL(CO.REMA_PATROC, 0))  * HS.val_cot VALOR_PATROC, ");
		sb.append("       (NVL(CO.REVER_PARTIC, 0) + NVL(CO.REVER_PATROC, 0)) * HS.val_cot VALOR_REVER ");
		sb.append("  FROM DEVOLUCAO            DE, ");
		sb.append("       PARTICIPANTE_PLANO   PP, ");
		sb.append("       PARTICIPANTE         PA, ");
		sb.append("       PLANO_PREVIDENCIA    PR, ");
		sb.append("       HST_PGT_DEV          HS, ");
		sb.append("       CRONOGRAMA_DEVOLUCAO CD, ");
		sb.append("      (SELECT * FROM  ");
		sb.append("        (SELECT CD.NUM_SEQ_DEV, ");
		sb.append("                CD.num_seq_tip_con_dev || CD.ind_man CONV, ");
		sb.append("                CD.QTD_TOT_COT_CON ");
		sb.append("           FROM CONTA_DEVOLUCAO CD  ");
		sb.append("          WHERE CD.NUM_SEQ_TIP_CON_DEV IN (1, 2, 3)  ");
		sb.append("            AND CD.IND_MAN IN (1, 2) ");
		sb.append("            AND CD.QTD_TOT_COT_CON >= 0) ");
		sb
				.append("         PIVOT (SUM(QTD_TOT_COT_CON) FOR (CONV) IN ('11' AS RESG_PARTIC, '12' AS RESG_PATROC, '21' AS REVER_PARTIC, '22' AS REVER_PATROC, '31' REMA_PARTIC, '32' REMA_PATROC))) CO ");
		sb.append(" WHERE DE.NUM_SEQ_PARTIC_PLANO = PP.NUM_SEQ_PARTIC_PLANO ");
		sb.append("  AND PP.NUM_SEQ_PLANO = PR.NUM_SEQ_PLANO ");
		sb.append("  AND PP.NUM_SEQ_PARTIC = PA.NUM_SEQ_PARTIC ");
		sb.append("  AND DE.NUM_SEQ_DEV = HS.NUM_SEQ_DEV ");
		sb.append("  AND DE.NUM_SEQ_DEV = CO.NUM_SEQ_DEV ");
		sb.append("  AND HS.num_seq_cro_dev = CD.NUM_SEQ_CRO_DEV ");
		sb.append("  AND HS.num_seq_rub_dev <= 8 ");

		return sb.toString();
	}

	public String getSql() {
		return sql;
	}

	public String getDescricao() {
		return descricao;
	}
}
