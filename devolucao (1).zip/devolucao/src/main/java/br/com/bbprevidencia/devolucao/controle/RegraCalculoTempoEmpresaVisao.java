package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoEmpresaBO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoEmpresa;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter as Regras de Cálculo de Tempo de Empresa
 * 
 * @author  BBPF0415 - Yanisley Mora  Ritchie
 * @since 25/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("regraCalculoTempoEmpresaVisao")
public class RegraCalculoTempoEmpresaVisao {

	private static final String FW_REGRA_CALC_TEMPO_EMP = "/paginas/regraCalculoTempoEmpresa.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private RegraCalculoTempoEmpresaBO regraCalculoTempoEmpresaBO;

	private List<RegraCalculoTempoEmpresa> listaRegraCalculoTempoEmpresa;

	private RegraCalculoTempoEmpresa regraCalculoTempoEmpresa;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página das Regras de Cálculo Tempo Empresa
	 * @author  BBPF0415 - Yanisley Mora  Ritchie
	 * @since 26/01/2017
	 * @return {@link String}
	 */
	public String inciciarRegraCalculoTempoEmpresa() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("regraCalculoTempoEmpresa");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.regraCalculoTempoEmpresa = null;

		this.listarStatus = true;

		listaRegraCalculoTempoEmpresa = new ArrayList<RegraCalculoTempoEmpresa>(regraCalculoTempoEmpresaBO.listarRegraCalculoTempoEmpresa());

		return FW_REGRA_CALC_TEMPO_EMP;
	}

	public List<RegraCalculoTempoEmpresa> getListaRegraCalculoTempoEmpresa() {
		return listaRegraCalculoTempoEmpresa;
	}

	public void setListaRegraCalculoTempoEmpresa(List<RegraCalculoTempoEmpresa> listaRegraCalculoTempoEmpresa) {
		this.listaRegraCalculoTempoEmpresa = listaRegraCalculoTempoEmpresa;
	}

	public RegraCalculoTempoEmpresa getRegraCalculoTempoEmpresa() {
		return regraCalculoTempoEmpresa;
	}

	public void setRegraCalculoTempoEmpresa(RegraCalculoTempoEmpresa regraCalculoTempoEmpresa) {
		this.regraCalculoTempoEmpresa = regraCalculoTempoEmpresa;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

}
