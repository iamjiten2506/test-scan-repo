package br.com.bbprevidencia.devolucao.dto;

public class RelatorioImpostoRendaDTO {

	private String codigoModalidadePlano;

	private String patrocinadora;

	private String participante;

	private String cpf;

	private Double valorIRRF;

	private String codigoRetencao;

	private Long codigoDirf;

	private String indicadorRetencao;

	private String codigoNaturezaRendimento;

	public Long getCodigoDirf() {
		return codigoDirf;
	}

	public void setCodigoDirf(Long codigoDirf) {
		this.codigoDirf = codigoDirf;
	}

	public String getIndicadorRetencao() {
		return indicadorRetencao;
	}

	public void setIndicadorRetencao(String indicadorRetencao) {
		this.indicadorRetencao = indicadorRetencao;
	}

	public String getCodigoModalidadePlano() {
		return codigoModalidadePlano;
	}

	public void setCodigoModalidadePlano(String codigoModalidadePlano) {
		this.codigoModalidadePlano = codigoModalidadePlano;
	}

	public String getPatrocinadora() {
		return patrocinadora;
	}

	public void setPatrocinadora(String patrocinadora) {
		this.patrocinadora = patrocinadora;
	}

	public String getParticipante() {
		return participante;
	}

	public void setParticipante(String participante) {
		this.participante = participante;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Double getValorIRRF() {
		return valorIRRF;
	}

	public void setValorIRRF(Double valorIRRF) {
		this.valorIRRF = valorIRRF;
	}

	public String getCodigoRetencao() {
		return codigoRetencao;
	}

	public void setCodigoRetencao(String codigoRetencao) {
		this.codigoRetencao = codigoRetencao;
	}

	public String getCodigoNaturezaRendimento() {
		return codigoNaturezaRendimento;
	}

	public void setCodigoNaturezaRendimento(String codigoNaturezaRendimento) {
		this.codigoNaturezaRendimento = codigoNaturezaRendimento;
	}

}
