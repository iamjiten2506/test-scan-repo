package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class ComprovanteRendimentosJasperDTO {

	private String cpf;

	private String anoCalendario;

	private Long numeroTipoRetencao;

	private String lote;

	private String nomeRecebedor;

	private String dataAtual;

	private String nomeTipoRetencao;

	private String nomeFuncionario;

	private String anoDire;

	private String valor301;

	private String valor302;

	private String valor303;

	private String valor304;

	private String valor305;

	private String valor401;

	private String valor402;

	private String valor403;

	private String valor404;

	private String valor405;

	private String valor406;

	private String valor407;

	private String valor408;

	private String valor409;

	private String valor501;

	private String valor502;

	private String valor503;

	private String valor701;

	private String valor702;

	private String valor703;

	private String valor704;

	private String valor705;

	private String valor706;

	private String valor707;

	private String valor708;

	private String valor709;

	private String valor710;

	private String descOutros;

	private String informacoesComplementares;

}
