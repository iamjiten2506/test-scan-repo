package br.com.bbprevidencia.devolucao.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 * Conversor genérico para acrescentar 0 as esquerda com 9 digitos.
 * 
 * 
 * @author Magson Dias
 */
@FacesConverter(value = "zerosEsquerdaMatriculaConverter")
public class ZerosEsquerdaMatriculaConverter implements Converter {

	/**
	 * @return Object Retorna o objeto 
	 */
	@Override
	public Object getAsObject(FacesContext facesContext, UIComponent uiComponent, String objeto) {
		if (objeto != null) {
			return objeto;
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext facesContext, UIComponent uiComponent, Object objeto) {
		return zerosEsquerda((String) objeto);
	}

	public String zerosEsquerda(String valor) {
		if (!valor.equals("")) {
			while (valor.length() < 9) {
				valor = "0" + valor;
			}
		}
		return valor;
	}
}
