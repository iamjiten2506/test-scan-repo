package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoMensagemEnum {

	ERRO("E", "Erro ocorrido durante cálculo"),
	AVISO("A", "Aviso de problemas ocorridos"),
	RESUMO("R", "Resumo de Processamento");

	private String codigo;
	private String descricao;

	private TipoMensagemEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return TipoMensagemEnum
	 */
	public static TipoMensagemEnum getTipoMensagemEnum(String codigo) {
		if (codigo != null) {
			for (TipoMensagemEnum tipoMensagemEnum : values()) {
				if (tipoMensagemEnum.getCodigo().equals(codigo)) {
					return tipoMensagemEnum;
				}
			}
		}
		return null;
	}

}