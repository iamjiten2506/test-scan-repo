package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@EqualsAndHashCode
public class UsuarioLoginSmsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String login;
	private String senha;
	private String nome;
	private Long codigo;
	private Long codigoPlano;

	public UsuarioLoginSmsDTO(String login, String senha, String nome, Long codigo, Long codigoPlano) {
		super();
		this.login = login;
		this.senha = senha;
		this.nome = nome;
		this.codigo = codigo;
		this.codigoPlano = codigoPlano;
	}

}
