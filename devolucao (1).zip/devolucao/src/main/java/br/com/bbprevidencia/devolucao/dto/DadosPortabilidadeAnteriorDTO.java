package br.com.bbprevidencia.devolucao.dto;

public class DadosPortabilidadeAnteriorDTO {

	private String tipoEntidade;
	private Double valor;

	public String getTipoEntidade() {
		return tipoEntidade;
	}

	public void setTipoEntidade(String tipoEntidade) {
		this.tipoEntidade = tipoEntidade;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

}
