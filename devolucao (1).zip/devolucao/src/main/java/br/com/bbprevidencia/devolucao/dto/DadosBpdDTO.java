package br.com.bbprevidencia.devolucao.dto;

public class DadosBpdDTO {

	private String nomePlano;
	private Double valorMontanteGarantidor;
	private Double valorTaxaAdmin;
	private Double valorIncapacidadeMorte;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public Double getValorMontanteGarantidor() {
		return valorMontanteGarantidor;
	}

	public void setValorMontanteGarantidor(Double valorMontanteGarantidor) {
		this.valorMontanteGarantidor = valorMontanteGarantidor;
	}

	public Double getValorTaxaAdmin() {
		return valorTaxaAdmin;
	}

	public void setValorTaxaAdmin(Double valorTaxaAdmin) {
		this.valorTaxaAdmin = valorTaxaAdmin;
	}

	public Double getValorIncapacidadeMorte() {
		return valorIncapacidadeMorte;
	}

	public void setValorIncapacidadeMorte(Double valorIncapacidadeMorte) {
		this.valorIncapacidadeMorte = valorIncapacidadeMorte;
	}

}
