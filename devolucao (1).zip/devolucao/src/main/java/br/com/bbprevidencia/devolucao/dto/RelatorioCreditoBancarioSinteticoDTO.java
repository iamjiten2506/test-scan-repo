package br.com.bbprevidencia.devolucao.dto;

public class RelatorioCreditoBancarioSinteticoDTO {

	private String nomeBanco;

	private String tipoPagamentoConta;

	private Double valorPago;

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public String getTipoPagamentoConta() {
		return tipoPagamentoConta;
	}

	public void setTipoPagamentoConta(String tipoPagamentoConta) {
		this.tipoPagamentoConta = tipoPagamentoConta;
	}

	public Double getValorPago() {
		return valorPago;
	}

	public void setValorPago(Double valorPago) {
		this.valorPago = valorPago;
	}

}
