package br.com.bbprevidencia.devolucao.controle;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import br.com.bbprevidencia.devolucao.bo.*;
import br.com.bbprevidencia.devolucao.dao.ParticipantePlanoProcessoDAO;
import br.com.bbprevidencia.devolucao.dto.request.CalcularProcessoDevolucaoRequest;
import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.RowEditEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.ToggleEvent;
import org.primefaces.event.data.SortEvent;
import org.primefaces.model.Visibility;
import org.primefaces.model.chart.PieChartModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import br.com.bbprevidencia.bbpcomum.util.Criptografia;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.beneficio.bo.IdentificadorDevolucaoBO;
import br.com.bbprevidencia.cadastroweb.bo.BloqueioParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.HistoricoFinanceiroPagoBO;
import br.com.bbprevidencia.cadastroweb.bo.HistoricoFinanceiroSpParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PerfilInvestimentoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.BloqueioParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.SaldoHistoricoFinanceiroPagoDTO;
import br.com.bbprevidencia.cadastroweb.enumerador.MantenedorEnum;
import br.com.bbprevidencia.cadastroweb.enumerador.OrigemAcesso;
import br.com.bbprevidencia.cadastroweb.enumerador.TipoBloqueioParticipante;
import br.com.bbprevidencia.cadastroweb.exception.RegistroNaoEncontradoException;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.cotas.bo.ValorCotaPlanoBO;
import br.com.bbprevidencia.cotas.dto.ValorCotaPlano;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.AprovacaoAlcadaDTO;
import br.com.bbprevidencia.devolucao.dto.CalculoDevolucaoBaseVisao;
import br.com.bbprevidencia.devolucao.dto.CloudDocsDTO;
import br.com.bbprevidencia.devolucao.dto.ContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.DescontoDevolucao;
import br.com.bbprevidencia.devolucao.dto.DetalhePortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DevolucaoAntigoDTO;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucaoVisaoItem;
import br.com.bbprevidencia.devolucao.dto.DocumentoPlanoTipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.ElegibilidadeDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.GrupoRecebimentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucaoDetalheImposto;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucaoDetalheImpostoDTO;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucaoPagto;
import br.com.bbprevidencia.devolucao.dto.ParticipanteEmprestimoDTO;
import br.com.bbprevidencia.devolucao.dto.ProcessoRetencaoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RetornoLoginDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoSaldoDevedorEmprestimoDTO;
import br.com.bbprevidencia.devolucao.dto.SaldoHFPDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.SaldoParticipanteIsento;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.SumulaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.UsuarioLoginDTO;
import br.com.bbprevidencia.devolucao.enumerador.IndicadorFormaPagamentoContribCarencia;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.devolucao.enumerador.TipoMensagensUrlRetorno;
import br.com.bbprevidencia.devolucao.exceptions.DevolucaoException;
import br.com.bbprevidencia.devolucao.interceptor.HeaderRequestInterceptor;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.seguranca.bo.ParmSistemBO;
import br.com.bbprevidencia.seguranca.dto.ParmSistem;
import br.com.bbprevidencia.utils.data.UtilData;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio para
 * o Cálculo / Visualização das Devoluções
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 26/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("devolucaoVisao")
public class DevolucaoVisao {

	private static final String FW_PESQUISA_DEVOLUCAO = "/paginas/pesquisaDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_CALCULO_DEVOLUCAO = "/paginas/calculoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final String FW_ENVIO_DEFERIMENTO = "/paginas/processoEnvioDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_CANCELAMENTO_DEVOLUCAO = "/paginas/processoCancelamento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_VERIFICACAO_DEFERIMENTO = "/paginas/processoVerificacaoDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_CONFERENCIA = "/paginas/processoConferencia.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_RECEBIMENTO = "/paginas/processoAtualizacaoRecebimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_DEVOLUCAO_MANUAL_REQUERIMENTO = "/paginas/devolucaoManualRequerimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final String FW_PESQUISA_MIGRACAODEVOLUCAO = "/paginas/pesquisaDevolucaoMigracao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(DevolucaoVisao.class);

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private CalculoDevolucaoBO calculoDevolucao;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBo;

	@Autowired
	private PerfilInvestimentoBO perfilInvestimentoBO;

	@Autowired
	private ValorCotaPlanoBO valorCotaPlanoBO;

	@Autowired
	private RegraDevolucaoBO regraDevolucaoBO;

	@Autowired
	private RegraCalculoDevolucaoBO regraCalculoDevolucaoBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private DescontoDevolucaoBO descontoDevolucaoBO;

	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;

	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoDetalheBO parcelaContaDevolucaoDetalheBO;

	@Autowired
	private ParcelaContaDevolucaoDetalheImpostoBO parcelaContaDevolucaoDetalheImpostoBO;

	@Autowired
	private RegraElegibilidadeDevolucaoBO regraElegibilidadeDevolucaoBO;

	@Autowired
	private DocumentoDevolucaoVisaoItemBO documentoDevolucaoVisaoItemBO;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private DocumentoPlanoTipoDevolucaoBO documentoPlanoTipoDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoPagtoBO parcelaContaDevolucaoPagtoBO;

	@Autowired
	private HistoricoFinanceiroSpParticipanteBO historicoFinanceiroSpParticipanteBO;

	@Autowired
	private HistoricoFinanceiroPagoBO historicoFinanceiroPagoBO;

	@Autowired
	private GrupoRecebimentoDevolucaoBO grupoRecebimentoDevolucaoBO;

	@Autowired
	private DetalhePortabilidadeDevolucaoBO detalhePortabilidadeDevolucaoBO;

	@Autowired
	private BloqueioParticipanteBO bloqueioParticipanteBO;

	@Autowired
	private IdentificadorDevolucaoBO identificadorDevolucaoBO;

	@Autowired
	private ParmSistemBO parmSistemBO;

	@Autowired
	private OptOutBO optOutBO;

	@Autowired
	private MovimentoAlcadaBO movimentoAlcadaBO;

	@Autowired
	private SaldoParticipanteIsentoBO saldoParticipanteIsentoBO;

	@Value("#{propriedades['url.emprestimo_service']}")
	private String urlEmprestimoService;

	@Value("#{propriedades['url.ambiente']}")
	private String urlAmbiente;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<Participante> listaParticipante;

	private List<Devolucao> listaDevolucao;

	private List<TipoDevolucao> listaTipoDevolucao;

	private List<SelectItem> listaIndicadorFormaPagamentoContribCarencia;

	private List<SituacaoDevolucao> listaSituacaoDevolucao;

	private String indicadorFormaPagamentoContribCarencia;

	private TipoDevolucao tipoDevolucao;

	private Devolucao devolucao;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private Participante participante;

	private SituacaoDevolucao situacaoDevolucao;

	private boolean patrocinadoraEditavel;

	private boolean listarStatus;

	private boolean cadastrarNovaDevolucao;

	private Integer numTotalParcelas;

	private Date dataRequerimento;

	private ValorCotaPlano valorCotaPlano;

	private RegraDevolucao regraDevolucao;

	private RegraCalculoDevolucao regraCalculoDevolucao;

	private DevolucaoCompletoDTO devolucaoCalculoCompleto;

	private boolean processoCalculoConcluido;

	private boolean processoSalvo;

	private boolean possueEmprestimo;

	private boolean possuiAcessoConsulta;

	private CalculoDevolucaoBaseVisao calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();

	private int colunaOrdenadaContasDevolucao = 1;

	private int colunaOrdenadaParcelasContasDevolucao = 1;

	// private List<ParcelaContaDevolucaoDetalheImposto>
	// listaParcelaContaDevolucaoDetalheImposto = new ArrayList<>();
	// private List<ParcelaContaDevolucaoDetalheImpostoDTO>
	// listaParcelaContaDevolucaoDetalheImpostoDTO = new ArrayList<>();

	// private List<ParcelaContaDevolucaoDetalheImposto>
	// listaParcelaContaDevolucaoDetalheImpostoFiltro = new ArrayList<>();

	private AnotacaoDevolucao anotacaoDevolucao;

	private double percentualOpcao;
	private double valorEmprestimo;
	private boolean alteraPercentual;

	// Variaveis de controle de ambiente
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean possuiAcessoTotal;

	private String urlRetorno;
	private String variavelRetorno;

	private boolean permiteSalvarProcessoCalculado;

	private String mensagemAntesSalvar;

	private List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem;

	private boolean possuiDocumentoDevolucao;
	private boolean possuiDocumentoDevolucaoPendente;
	private boolean chamaPendenciasAberturaTela;
	private String descricaoPendencias;
	private Double totalSaldoReserva;
	private boolean devolucaoManual;

	private Date dataRequerimentoAte;
	private Date dataRequerimentoDesde;

	private boolean pesquisaTotal;

	private List<SaldoHFPDevolucaoDTO> listaSaldoHFPDevolucaoDTO;

	// propriedades dos gráficos
	private boolean mostrarGraficos;

	private PieChartModel graficoParticipante;
	private PieChartModel graficoPatrocinadora;
	private PieChartModel graficoTotal;

	private boolean processoCalculoConcluidoPago;
	private String cpfPesquisa;
	private String matriculaPesquisa;

	private List<Participante> listaParticipantePesquisa;

	// Url para redirecionamento do Cloud Docs
	// private final String urlCloudDocs = "http://www.google.com.br";
	private CloudDocsDTO cloudDocsDTO = new CloudDocsDTO();
	private final String urlCloudDocs = cloudDocsDTO.getUrlRedirect();

	private boolean valorEmprestimoRecuperado;

	private Date dataFuturaPagamento;

	private boolean indicadorPagamentoEditavel;

	private List<Boolean> listaControl;

	private Devolucao devolucaoBuscarDeferimento;

	private List<AprovacaoAlcadaDTO> listaDeferimentoDevolucao;

	private boolean patronicinadoraBasa;

	private SaldoParticipanteIsento saldoParticipanteIsento;

	/**
	 * Método encarredado por iniciar a página de pesquisa de das devoluções
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return {@link String}
	 */
	public String iniciarDevolucao() {

		validarAcessoFuncionalidade();

		limparFormularioPesquisa();

		this.listaEntidadeParticipante = listarEntidadeParticipante();

		this.listaTipoDevolucao = listarTipoDevolucao();

		this.listaIndicadorFormaPagamentoContribCarencia = listarIndicadorPagamentoContribCarencia();

		this.listaSituacaoDevolucao = listarSituacaoDevolucao();

		this.listaPlanoPrevidencia = listarPlanoPrevidencia();

		this.listaControl = Arrays.asList(true, true, true, true, true, true, true, true, true, true, false, false, false, false);

		return FW_PESQUISA_DEVOLUCAO;
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/06/2017
	 * @return
	 */
	private List<PlanoPrevidencia> listarPlanoPrevidencia() {
		try {
			if (this.entidadeParticipante == null || this.entidadeParticipante.getChavePrimaria() == null) {
				return this.planoPrevidenciaBO.listarPlanoPrevidencia();
			} else {
				return this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante());
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new PrevidenciaException(e.getMessage());
		}
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 05/06/2017
	 * @return
	 */
	private List<SituacaoDevolucao> listarSituacaoDevolucao() {
		return this.situacaoDevolucaoBO.listarTodosSituacaoDevolucao();
	}

	/**
	 * Valida o tipo de acesso à página
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/05/2017
	 */
	public void validarAcessoFuncionalidade() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("pesquisaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
	}

	private void carregarUrlPesquisa() {

		if (this.variavelRetorno.equals("pesquisa")) {
			setUrlRetorno(FW_PESQUISA_DEVOLUCAO);
			this.setPossuiAcessoConsulta(false);
			return;
		}

		if (this.variavelRetorno.equals("cancelamento")) {
			setUrlRetorno(FW_CANCELAMENTO_DEVOLUCAO);
			this.setPossuiAcessoConsulta(true);
			paginaRetornoMessage(TipoMensagensUrlRetorno.CANCELAMENTO.getDescricao());
			return;
		}

		if (this.variavelRetorno.equals("deferimento")) {
			setUrlRetorno(FW_ENVIO_DEFERIMENTO);
			this.setPossuiAcessoConsulta(true);
			paginaRetornoMessage(TipoMensagensUrlRetorno.ENVIO_DEFERIMENTO.getDescricao());
			return;
		}

		if (this.variavelRetorno.equals("verificarDeferimento")) {
			setUrlRetorno(FW_PROCESSO_VERIFICACAO_DEFERIMENTO);
			this.setPossuiAcessoConsulta(true);
			paginaRetornoMessage(TipoMensagensUrlRetorno.VERIFICAR_DEFERIMENTO.getDescricao());
			return;
		}

		if (this.variavelRetorno.equals("conferencia")) {
			setUrlRetorno(FW_PROCESSO_CONFERENCIA);
			this.setPossuiAcessoConsulta(true);
			paginaRetornoMessage(TipoMensagensUrlRetorno.CONFERENCIA.getDescricao());
			return;
		}
		if (this.variavelRetorno.equals("atualizacao")) {
			setUrlRetorno(FW_PROCESSO_RECEBIMENTO);
			this.setPossuiAcessoConsulta(true);
			paginaRetornoMessage(TipoMensagensUrlRetorno.ATUALIZ_RECEB.getDescricao());
			return;
		}
		if (this.variavelRetorno.equals("calculoManual")) {
			setUrlRetorno(FW_DEVOLUCAO_MANUAL_REQUERIMENTO);
			this.setPossuiAcessoConsulta(true);
			// paginaRetornoMessage(TipoMensagensUrlRetorno.CALCULO_DEVOLUCAO_MANUAL.getDescricao());
			return;
		}

		if (this.variavelRetorno.equals("migracao")) {
			setUrlRetorno(FW_PESQUISA_MIGRACAODEVOLUCAO);
			this.setPossuiAcessoConsulta(true);
			return;
		}

	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo inicial
	 * de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * 
	 */
	public void limparFormularioPesquisa() {
		this.patrocinadoraEditavel = true;
		this.listarStatus = true;

		this.planoPrevidencia = null;
		this.listaPlanoPrevidencia = null;
		this.entidadeParticipante = null;
		this.participante = null;
		this.setParticipante(new Participante());
		this.listaParticipante = null;
		this.listaDevolucao = null;
		this.devolucao = null;
		this.cadastrarNovaDevolucao = false;
		this.tipoDevolucao = null;
		this.valorEmprestimo = 0D;
		this.setValorCotaPlano(null);
		this.setDataRequerimento(null);
		this.setNumTotalParcelas(1);
		this.setProcessoCalculoConcluido(false);
		this.setColunaOrdenadaContasDevolucao(1);
		this.setProcessoSalvo(false);
		this.setPermiteSalvarProcessoCalculado(false);
		this.setDataRequerimentoAte(null);
		this.setDataRequerimentoDesde(null);
		this.setSituacaoDevolucao(null);
		this.pesquisaTotal = true;
		this.devolucaoManual = false;
		this.mostrarGraficos = false;

		this.matriculaPesquisa = null;
		this.cpfPesquisa = null;
		this.setPatronicinadoraBasa(false);

	}

	/**
	 * Método responsável por retornar a lista de Planos associados à patrocionadora
	 * selecionada.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return {@link String}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {

		// Limapdo os valores antigos à pesquisa
		setPlanoPrevidencia(null);
		setParticipante(new Participante());
		setListaParticipante(null);

		try {
			this.listaPlanoPrevidencia = listarPlanoPrevidencia();

		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}

		return FW_PESQUISA_DEVOLUCAO;
	}

	/**
	 * Cria uma lista de itens da entidade participante.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return
	 */
	public List<EntidadeParticipante> listarEntidadeParticipante() {
		List<EntidadeParticipante> listaPatrocinadora = new ArrayList<EntidadeParticipante>();

		listaPatrocinadora = entidadeParticipanteBO.listarEntidadeParticipante();

		return listaPatrocinadora;
	}

	/**
	 * Retorna o estado inicial da página
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return
	 */
	public String limparPesquisa() {
		PrimeFaces.current().resetInputs("formDevolucao");
		return iniciarDevolucao();
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo
	 * digitado no autocomplete
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.planoPrevidencia != null && this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantePorNomeEPatrocinadoraEPlanoPrevidencia(nome, this.entidadeParticipante, this.planoPrevidencia);
		} else if (this.planoPrevidencia != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else if (this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			return new ArrayList<Participante>();
		}

	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setTipoDevolucao(null);
		setParticipante((Participante) event.getObject());
		/*
		 * if (this.getEntidadeParticipante() != null && this.getPlanoPrevidencia() !=
		 * null && this.getParticipante() != null) { this.listaDevolucao = new
		 * ArrayList<Devolucao>(); ParticipantePlano participantePlano =
		 * participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(),
		 * this.getPlanoPrevidencia()); this.listaDevolucao =
		 * this.devolucaoBO.pesquisarDevolucaoPorParticipantePlano(participantePlano);
		 * 
		 * if (!UtilJava.isStringVazia(getParticipante().getNomeParticipante()) &&
		 * getParticipante().getCodigo() != null) {
		 * UtilSession.adicionarObjetoSessao("participante", getParticipante()); } else
		 * { setParticipante(new Participante()); } }
		 */
	}

	/**
	 * Método responsável por setar o Plano escolhido no select do plano
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link SelectEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		setParticipante(new Participante());
		setListaParticipante(null);
		setTipoDevolucao(null);

		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

			// Fazer recargar a lista de tipos de devolução por plano
			this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBo.listarTodosTipoDevolucaoPorPlanoPrevidencia(this.getPlanoPrevidencia()));

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Método responsável por listar todos os tipos de devoluções
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2017
	 * @return
	 */
	public List<TipoDevolucao> listarTipoDevolucao() {
		List<TipoDevolucao> listaTipoDevolucaoTemp = new ArrayList<TipoDevolucao>();
		listaTipoDevolucaoTemp = tipoDevolucaoBo.listarTodosTipoDevolucao();

		return listaTipoDevolucaoTemp;
	}

	/**
	 * Método responsável por pesquisar o participante por cpf, nome e matricula.
	 * Para atender o chamado CEC - 36855, Para incluir dois campos texto de
	 * pesquina na pagina pesquisa devolução.
	 * 
	 * 
	 * @author BBPF0170 - Magson Dias de Oliveira
	 * @since 06/06/2017
	 * @return boolean
	 */
	public boolean pesquisarParticipanteCpfMatricula() {
		boolean valido = true;
		if (this.participante.getCodigo() == null) {
			if ((this.cpfPesquisa != null && !this.cpfPesquisa.equals("")) || (this.matriculaPesquisa != null && !this.matriculaPesquisa.equals(""))) {

				if (this.cpfPesquisa.length() >= 3 || this.matriculaPesquisa.length() >= 1) {

					this.listaParticipantePesquisa = this.participanteBO.listarParticipantesPorNomeOuCpfEMatricula(
							this.entidadeParticipante,
							this.planoPrevidencia,
							this.cpfPesquisa,
							this.matriculaPesquisa);
					if (UtilJava.isColecaoDiferenteDeVazia(this.listaParticipantePesquisa)) {
						if (this.listaParticipantePesquisa.size() > 1) {
							System.out.println("Retornar uma lista de participante para selecionar.");
							PrimeFaces.current().executeScript("PF('dgListaParticipante').show()");
							valido = false;
						} else {
							this.participante = this.listaParticipantePesquisa.get(0);
						}
					} else {
						Mensagens.addMsgInfo("Não foram encontrados participantes com os parâmetros informado.");
						valido = false;
					}
				} else {
					Mensagens.addMsgInfo("O campo CPF/NOME tem que ter mais de 3 caracteres.");
					valido = false;
				}

			}
		}
		return valido;
	}

	/**
	 * Método responsável por limpar os objetos de pesquisa. Atender o chamado CEC -
	 * 36855, Para incluir dois campos texto de pesquina na pagina pesquisa
	 * devolução.
	 * 
	 * 
	 * @author BBPF0170 - Magson Dias de Oliveira
	 * @since 06/06/2017
	 * @return void
	 */
	public void limparPesquisaParticipante() {
		this.listaParticipantePesquisa = new ArrayList<>();
		this.participante = new Participante();
	}

	/**
	 * Método responsável por limpar os objetos de pesquisa. Atender o chamado CEC -
	 * 36855, Para incluir dois campos texto de pesquina na pagina pesquisa
	 * devolução.
	 * 
	 * 
	 * @author BBPF0170 - Magson Dias de Oliveira
	 * @since 06/06/2017
	 * @param participantePesquisado
	 * @return void
	 */
	public void carregarParticipantePesquisa(Participante participantePesquisado) {
		this.participante = participantePesquisado;
		pesquisarDevolucao();
	}

	/**
	 * Método encarregado de pesquisar a devolução conforme os parâmetros de
	 * pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/06/2017
	 */
	public void pesquisarDevolucao() {
		try {

			this.cadastrarNovaDevolucao = false;
			boolean possuiBloqueio = false;
			// inclução do metodo que retorna um boolean, caso a pesquisa seja feita pelos
			// campo texto cpf/nome e matricula.
			if (pesquisarParticipanteCpfMatricula()) {
				this.listaDevolucao = new ArrayList<Devolucao>(devolucaoBO.listarDevolucaoParametrizada(
						this.entidadeParticipante,
						this.planoPrevidencia,
						this.participante,
						this.tipoDevolucao,
						this.situacaoDevolucao,
						this.dataRequerimentoDesde,
						this.dataRequerimentoAte));
				
				this.listaDevolucao.forEach(e -> {
					/*Somar a quantidade de cotas das parcelas do tipo resgatavel*/
					e.setQtdBruto(e.getListaParcelaContaDevolucao().stream()
							.filter(f -> f.getTipoContaDevolucao().getCodigo().equals(1L))
							.map(x -> x.getQtdCotaParcela().doubleValue())
							.collect(Collectors.summingDouble(Double::doubleValue)));

					Double valor = 0D;
					
					/*Caso a situação da devolução seja 7 - PAGO, pegar o valor de IR que tenham o cronograma*/
					if (e.getSituacaoDevolucao().getCodigo() == 7L) {
						valor = parcelaContaDevolucaoDetalheImpostoBO
								.pesquisarParcelaContaDevolucaoDetalheImpostoPorDevolucao(e).stream()
								.filter(f -> f.getCronogramaDevolucao() != null)
								.map(x -> x.getValorIrrf().doubleValue())
								.collect(Collectors.summingDouble(Double::doubleValue));
					} else {
						valor = parcelaContaDevolucaoDetalheImpostoBO
								.pesquisarParcelaContaDevolucaoDetalheImpostoPorDevolucao(e).stream()
								.filter(f -> f.getCronogramaDevolucao() == null)
								.map(x -> x.getValorIrrf().doubleValue())
								.collect(Collectors.summingDouble(Double::doubleValue));
					}
					/*Faz o calculo de valor de IR / pelo valor do indice para encontrar a quantidade de cota de imposto*/
					e.setQtdImposto((valor / e.getValorIndiceAjustado()));

				});
										

				if (this.participante.getCodigo() != null) {
					// Verificar se o participante possui bloqueios
					
					//Verifica se o participante tem direito a Opt-Out
					RetornoOptOutDTO retornoOptOut = this.optOutBO.validarParticipanteAptoOptOut(this.participante.getCodigo());
					
					if (retornoOptOut.getSolicitacaoExistente() != null && retornoOptOut.getSolicitacaoExistente()) {
						throw new PrevidenciaException(retornoOptOut.getMgErro());
					} else if (retornoOptOut.getParticipanteAptoOptOut()) {
						throw new PrevidenciaException("O participante está no prazo para fazer OptOut. Não é possível realizar processos de devolução.");
					}

					if (UtilJava.isColecaoVazia(this.listaDevolucao)) {
						Mensagens.addMsgInfo("Não foram encontradas devoluções!");
						this.cadastrarNovaDevolucao = true;
					} else {
						Devolucao ultimaDevolucao = this.listaDevolucao
								.stream()
								.filter(x -> x.getSituacaoDevolucao().getCodigo() == 7 
									&& x.getRegraCalculoDevolucao().getTipoDevolucao().isResgate()
									&& x.getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorFormaDevolucao().equalsIgnoreCase("P")
									&& x.getRegraCalculoDevolucao().getTipoDevolucao().getMesesCarenciaProxDevolucao() > 0)
								.sorted(Comparator.comparing(Devolucao::getDataRequerimento))
								.reduce((f,l) -> l).orElse(null);
						
						if (ultimaDevolucao == null) {
							this.cadastrarNovaDevolucao = true;
						} else {
							if (UtilJava.dataDiffMeses(ultimaDevolucao.getDataRequerimento(), new Date()) >= ultimaDevolucao.getRegraCalculoDevolucao().getTipoDevolucao().getMesesCarenciaProxDevolucao()) {
								this.cadastrarNovaDevolucao = true;
							} else {
								this.cadastrarNovaDevolucao = false;
							}
						}
						
					}
				} else {
					if (UtilJava.isColecaoVazia(this.listaDevolucao) && !possuiBloqueio) {
						Mensagens.addMsgInfo("Não foram encontradas devoluções!");
					}
				}

			}

		} catch (Exception e) {
			log.error(e.getMessage());
			Mensagens.addMsgErro(e.getMessage());
//			throw new PrevidenciaException(e.getMessage());
		}
	}

	private boolean possuiBloqueiosParticipante() {
		List<BloqueioParticipante> listaBloqueios = this.bloqueioParticipanteBO.pesquisarBloqueioValidasPorParticipanteETipo(
				participante,
				this.tipoDevolucao.isPortabilidade() ? TipoBloqueioParticipante.PORTABILIDADE : TipoBloqueioParticipante.RESGATE);

		if (UtilJava.isColecaoDiferenteDeVazia(listaBloqueios)) {
			String msg = "";
			for (BloqueioParticipante bloqueioParticipante : listaBloqueios) {
				msg += bloqueioParticipante.getDescricaoMotivoBloqueio();
				this.cadastrarNovaDevolucao = false;
			}
			Mensagens.addMsgErro("Participante possui bloqueio para Devolução.");
			Mensagens.addMsgErro(msg);
			;
			return true;
		}

		return false;
	}

	/**
	 * Método para redicionar a página de pesquisa para a página de visualização dos
	 * detalhes da Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2017
	 * 
	 * @param {@link Devolucao}
	 * @return {@link String}
	 * 
	 */
	public String mostrarResumoDevolucao(Devolucao devolucao) {

		this.setPossuiAcessoConsulta(true);

		carregarUrlPesquisa();
		this.setCalculoDevolucaoTela(null);
		this.setCadastrarNovaDevolucao(false);
		this.setProcessoCalculoConcluido(true);
		this.setProcessoSalvo(true);
		this.setTipoDevolucao(null);
		this.setIndicadorFormaPagamentoContribCarencia(null);
		this.setParticipante(new Participante());
		this.setPlanoPrevidencia(null);
		this.setPermiteSalvarProcessoCalculado(false);
		this.setDevolucaoManual(false);
		this.setEntidadeParticipante(null);
		this.setRegraCalculoDevolucao(null);
		this.processoCalculoConcluidoPago = true;

		if (this.listaEntidadeParticipante == null) {
			this.listaEntidadeParticipante = this.listarEntidadeParticipante();

		}

		if (this.listaIndicadorFormaPagamentoContribCarencia == null) {
			this.listaIndicadorFormaPagamentoContribCarencia = listarIndicadorPagamentoContribCarencia();
		}

		try {
			this.setListaPlanoPrevidencia(planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(devolucao.getParticipantePlano().getParticipante().getEntidadeParticipante()));
		} catch (RegistroNaoEncontradoException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (UtilJava.isColecaoVazia(this.listaTipoDevolucao)) {
			this.listaTipoDevolucao = listarTipoDevolucao();
		}

		if (this.getCalculoDevolucaoTela() == null) {
			this.calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();
		}

		if (devolucao != null) {
			this.setParticipante(devolucao.getParticipantePlano().getParticipante());

		}

		if (this.entidadeParticipante == null) {
			this.setEntidadeParticipante(devolucao.getParticipantePlano().getParticipante().getEntidadeParticipante());
		}

		if (this.planoPrevidencia == null) {
			this.setPlanoPrevidencia(devolucao.getParticipantePlano().getPlanoPrevidencia());
		}

		if (this.getRegraCalculoDevolucao() == null) {
			this.setRegraCalculoDevolucao(devolucao.getRegraCalculoDevolucao());
		}

		if (this.getTipoDevolucao() == null) {
			this.setTipoDevolucao(devolucao.getRegraCalculoDevolucao().getTipoDevolucao());
		}

		if (this.indicadorFormaPagamentoContribCarencia == null) {
			this.setIndicadorFormaPagamentoContribCarencia(devolucao.getIndicadorFormaPagtoContribCarencia());
		}

		if (!UtilJava.isNumeroNuloOuZero(devolucao.getPercentualDevolucao())) {
			this.setPercentualOpcao(devolucao.getPercentualDevolucao());
		}

		if (this.calculoDevolucaoTela.getDataRequerimento() == null) {
			this.calculoDevolucaoTela.setDataRequerimento(devolucao.getDataRequerimento());
		}

		if (!UtilJava.isNumeroNuloOuZero(devolucao.getNumeroTotalParcelas())) {
			this.setNumTotalParcelas(devolucao.getNumeroTotalParcelas());
		}

		this.devolucaoManual = devolucao.getIndicadorDevManual().equalsIgnoreCase("S");

		verificarDocumentosDevolucao(devolucao);

		pesquisarValorCotaPlano(devolucao.getDataCota());

		this.devolucaoCalculoCompleto = new DevolucaoCompletoDTO();

		this.devolucaoCalculoCompleto.setDevolucao(devolucao);
		this.devolucaoCalculoCompleto.setListaAnotacaoDevolucao(anotacaoDevolucaoBO.listaTodasPorDevolucao(devolucao));
		this.devolucaoCalculoCompleto.setListaHistoricoSituacaoDevolucao(historicoSituacaoDevolucaoBO.pesquisarHistoricoSituacaoDevolucaoPorDevolucao(devolucao));
		this.devolucaoCalculoCompleto.setListaContaDevolucao(contaDevolucaoBO.listarTodasPorDevolucao(devolucao));
		this.devolucaoCalculoCompleto.setListaParcelaContaDevolucao(parcelaContaDevolucaoBO.pesquisarParcelaContaDevolucaoPorDevolucao(devolucao));
		this.devolucaoCalculoCompleto.setListaParcelaContaDevolucaoDetalhe(parcelaContaDevolucaoDetalheBO.pesquisarParcelaContaDevolucaoDetalhePorDevolucao(devolucao));
		this.devolucaoCalculoCompleto.setListaParcelaContaDevolucaoDetalheImposto(parcelaContaDevolucaoDetalheImpostoBO.pesquisarParcelaContaDevolucaoDetalheImpostoPorDevolucao(devolucao));
		this.devolucaoCalculoCompleto.setSaldoHistoricoFinanceiroPagoDTO(calculoDevolucao.carregarSaldoHistoricoFinanceiroPagoDevolucao(devolucao));

		//Caso for patrocinadora Basa verifiar se possui saldo isento
		if (devolucao.getParticipantePlano().getParticipante().getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante().equals(10031L)) {

			setPatronicinadoraBasa(true);

			this.saldoParticipanteIsento = this.saldoParticipanteIsentoBO.calcularSaldoParticipanteIsento(this.devolucaoCalculoCompleto);

			if (this.saldoParticipanteIsento.getCodigo() != null && this.saldoParticipanteIsento.getSaldoAtual().doubleValue() > 0.00D) {

				this.devolucaoCalculoCompleto.setSaldoAtualIsento(this.saldoParticipanteIsento.getSaldoAtual().doubleValue());

			}

		} else {
			setPatronicinadoraBasa(false);
		}

		if (!this.devolucaoCalculoCompleto.getDevolucao().getSituacaoDevolucao().getNome().equals(SituacaoDevolucaoEnum.PAGO.getDescricao())) {
			this.processoCalculoConcluidoPago = false;
		}

		List<ParcelaContaDevolucaoPagto> listaParcelaContaDevolucaoPagto = new ArrayList<ParcelaContaDevolucaoPagto>();

		for (ParcelaContaDevolucao parcelaContaDevolucao : this.devolucaoCalculoCompleto.getListaParcelaContaDevolucao()) {
			List<ParcelaContaDevolucaoPagto> listparcelaContaDevolucaoPagto = parcelaContaDevolucaoPagtoBO.pesquisarParcelaContaDevolucaoPagtoPorParcelaContaDevolucao(parcelaContaDevolucao);
			if (!UtilJava.isColecaoVazia(listparcelaContaDevolucaoPagto)) {
				for (ParcelaContaDevolucaoPagto pgto : listparcelaContaDevolucaoPagto) {
					listaParcelaContaDevolucaoPagto.add(pgto);
				}
			}
		}

		this.devolucaoCalculoCompleto.setListaParcelaContaDevolucaoPagto(listaParcelaContaDevolucaoPagto);
		this.devolucaoCalculoCompleto.setSimulacao(false);

		calcularTotalSaldoResgatavel(this.devolucaoCalculoCompleto.getListaContaDevolucao());

		expandirDetalheParcelaDevolucao(this.devolucaoCalculoCompleto.getListaParcelaContaDevolucao());

		// Montar lista de saldos de Ficha
		if (this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO() == null || this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO().getParticipantePlano() == null) {
			this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>();
		} else {
			this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>(montarListaSaldoHFPDevolucaoDTO(this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO()));
		}

		// Montar informações dos gráficos
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaSaldoHFPDevolucaoDTO)) {
			this.preencherInformacoesGraficas(this.listaSaldoHFPDevolucaoDTO, this.devolucaoCalculoCompleto.getListaContaDevolucao());
		}

		// Demanda 36118 - Daniel Martins - 07/03/2018 - Buscar data de referencias
		if (devolucao.getIndicadorDevManual().equals("N")) {
			devolucao.setDataReferenciaMinima(historicoFinanceiroPagoBO.buscarMinimaDataReferenciaPorCodigoDevolucao(devolucao.getCodigo()));
			devolucao.setDataReferenciaMaxima(historicoFinanceiroPagoBO.buscarMaximaDataReferenciaPorCodigoDevolucao(devolucao.getCodigo()));
		} else {
			devolucao.setDataReferenciaMinima(historicoFinanceiroPagoBO.buscarMinimaDataReferenciaPorParticipantePlanoAteSequencial(devolucao.getParticipantePlano(), devolucao
					.getNumeroUltimoHistoricoFinanceiroPagoUltilizado()));
			devolucao.setDataReferenciaMaxima(historicoFinanceiroPagoBO.buscarMaximaDataReferenciaPorParticipantePlanoAteSequencial(devolucao.getParticipantePlano(), devolucao
					.getNumeroUltimoHistoricoFinanceiroPagoUltilizado()));
		}

		return FW_CALCULO_DEVOLUCAO;
	}

	/**
	 * Método resposável por preenher as informações dos gáficos
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 09/06/2017
	 * @param listaSaldoHFPDevolucaoDTO
	 * @param listaContaDevolucao
	 */
	private void preencherInformacoesGraficas(List<SaldoHFPDevolucaoDTO> listaSaldoHFPDevolucaoDTO, List<ContaDevolucao> listaContaDevolucao) {
		this.graficoParticipante = new PieChartModel();
		this.graficoPatrocinadora = new PieChartModel();
		this.graficoTotal = new PieChartModel();

		double totalParticipante = 0D;
		double totalPatrocionadora = 0D;

		double totalResgParticipante = 0D;
		double totalResgPatrocionadora = 0D;

		// Calcular Totais
		for (SaldoHFPDevolucaoDTO item : listaSaldoHFPDevolucaoDTO) {
			if (item.getTipo().equalsIgnoreCase("Participante") || item.getTipo().equalsIgnoreCase("Autopatrocinado")) {
				totalParticipante += item.getQtdCotaContribuicao();
			} else {
				totalPatrocionadora += item.getQtdCotaContribuicao();
			}
		}

		// Calcular devolvível
		for (ContaDevolucao cd : listaContaDevolucao) {
			if (cd.getTipoContaDevolucao().getNomeTipoConta().equalsIgnoreCase("RESGATAVEL") || cd.getTipoContaDevolucao().getNomeTipoConta().equalsIgnoreCase("REMANESCENTE")) {
				if (cd.getIndicadorMantenedor().equalsIgnoreCase("1")) {
					totalResgParticipante += cd.getQtdTotalCotasContribuicao();
				} else {
					totalResgPatrocionadora += cd.getQtdTotalCotasContribuicao();
				}
			}
		}

		// Infromações do gráfico do partipante
		this.graficoParticipante.setTitle("Participante");
		this.graficoParticipante.set("Devolvível", totalResgParticipante);
		this.graficoParticipante.set("Não Devolvível", (totalParticipante - totalResgParticipante));
		this.graficoParticipante.setShowDataLabels(true);
		this.graficoParticipante.setSliceMargin(3);
		this.graficoParticipante.setShadow(false);
		this.graficoParticipante.setExtender("ext");
		this.graficoParticipante.setSeriesColors("7CB37A, FF6257");
		// this.graficoParticipante.setLegendPosition("s");

		// Infromações do gráfico da patrocinadora
		this.graficoPatrocinadora.setTitle("Patrocinadora");
		this.graficoPatrocinadora.set("Devolvível", totalResgPatrocionadora);
		this.graficoPatrocinadora.set("Não Devolvível", (totalPatrocionadora - totalResgPatrocionadora));
		this.graficoPatrocinadora.setShowDataLabels(true);
		this.graficoPatrocinadora.setSliceMargin(3);
		this.graficoPatrocinadora.setShadow(false);
		this.graficoPatrocinadora.setExtender("ext");
		this.graficoPatrocinadora.setSeriesColors("7CB37A, FF6257");
		// this.graficoPatrocinadora.setLegendPosition("s");

		// Informações do Gráfico total
		this.graficoTotal.setTitle("Total");
		this.graficoTotal.set("Devolvível", (totalResgPatrocionadora + totalResgParticipante));
		this.graficoTotal.set("Não Devolvível", (totalPatrocionadora + totalParticipante) - (totalResgPatrocionadora + totalResgParticipante));
		this.graficoTotal.setShowDataLabels(true);
		this.graficoTotal.setSliceMargin(3);
		this.graficoTotal.setShadow(false);
		this.graficoTotal.setExtender("ext");
		this.graficoTotal.setSeriesColors("7CB37A, FF6257");
		// this.graficoTotal.setLegendPosition("s");

		this.mostrarGraficos = true;
	}

	/**
	 * Método para redicionar a página de pesquisa para a página de visualização dos
	 * detalhes da Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/05/2017
	 * 
	 * @param {@link DevolucaoCompletoDTO}
	 * @return {@link String}
	 * 
	 */
	public String mostrarResumoDevolucaoManualCalculada(DevolucaoCompletoDTO devolucaoCompletoDTO) {
		validarAcessoFuncionalidade();

		this.setPossuiAcessoConsulta(true);
		this.setDevolucaoManual(true);

		carregarUrlPesquisa();
		this.setCadastrarNovaDevolucao(false);
		this.setProcessoCalculoConcluido(true);
		this.setProcessoSalvo(false);
		this.setTipoDevolucao(null);
		this.setIndicadorFormaPagamentoContribCarencia(null);
		this.setParticipante(new Participante());
		this.setPlanoPrevidencia(null);
		this.setPermiteSalvarProcessoCalculado(true);
		this.setEntidadeParticipante(null);
		this.setCalculoDevolucaoTela(null);
		this.setRegraCalculoDevolucao(null);

		if (this.listaEntidadeParticipante == null) {
			this.listaEntidadeParticipante = this.listarEntidadeParticipante();

		}

		if (this.listaIndicadorFormaPagamentoContribCarencia == null) {
			this.listaIndicadorFormaPagamentoContribCarencia = listarIndicadorPagamentoContribCarencia();
		}

		try {
			this.setListaPlanoPrevidencia(planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(devolucaoCompletoDTO.getDevolucao().getParticipantePlano().getParticipante()
					.getEntidadeParticipante()));
		} catch (RegistroNaoEncontradoException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		this.listaTipoDevolucao = listarTipoDevolucao();

		if (this.getCalculoDevolucaoTela() == null) {
			this.calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();
		}

		if (devolucaoCompletoDTO.getDevolucao() != null) {
			this.setParticipante(devolucaoCompletoDTO.getDevolucao().getParticipantePlano().getParticipante());
		}

		if (this.entidadeParticipante == null) {
			this.setEntidadeParticipante(devolucaoCompletoDTO.getDevolucao().getParticipantePlano().getParticipante().getEntidadeParticipante());
		}

		if (this.planoPrevidencia == null) {
			this.setPlanoPrevidencia(devolucaoCompletoDTO.getDevolucao().getParticipantePlano().getPlanoPrevidencia());
		}

		if (this.getRegraCalculoDevolucao() == null) {
			this.setRegraCalculoDevolucao(devolucaoCompletoDTO.getDevolucao().getRegraCalculoDevolucao());
		}

		if (UtilJava.isColecaoVazia(this.listaTipoDevolucao)) {
			this.listaTipoDevolucao = listarTipoDevolucao();
		}

		if (this.getTipoDevolucao() == null) {
			this.setTipoDevolucao(devolucaoCompletoDTO.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao());
		}

		if (this.indicadorFormaPagamentoContribCarencia == null) {
			this.setIndicadorFormaPagamentoContribCarencia(devolucaoCompletoDTO.getDevolucao().getIndicadorFormaPagtoContribCarencia());
		}

		if (this.calculoDevolucaoTela.getDataRequerimento() == null) {
			this.calculoDevolucaoTela.setDataRequerimento(devolucaoCompletoDTO.getDevolucao().getDataRequerimento());
		}

		if (!UtilJava.isNumeroNuloOuZero(devolucaoCompletoDTO.getDevolucao().getNumeroTotalParcelas())) {
			this.setNumTotalParcelas(devolucaoCompletoDTO.getDevolucao().getNumeroTotalParcelas());
		}

		if (!UtilJava.isNumeroNuloOuZero(devolucaoCompletoDTO.getDevolucao().getPercentualDevolucao())) {
			this.setPercentualOpcao(devolucaoCompletoDTO.getDevolucao().getPercentualDevolucao());
		}

		pesquisarValorCotaPlano(devolucaoCompletoDTO.getDevolucao().getDataCota());

		this.devolucaoCalculoCompleto = new DevolucaoCompletoDTO();
		this.devolucaoCalculoCompleto = devolucaoCompletoDTO;

		this.devolucaoManual = devolucaoCompletoDTO.getDevolucao().getIndicadorDevManual().equalsIgnoreCase("S");

		this.devolucaoCalculoCompleto.setSimulacao(false);

		this.setMensagemAntesSalvar("Confirma Salvar o processo de Devolução?");

		calcularTotalSaldoResgatavel(this.devolucaoCalculoCompleto.getListaContaDevolucao());

		expandirDetalheParcelaDevolucao(this.devolucaoCalculoCompleto.getListaParcelaContaDevolucao());

		// Montar lista de saldos de Ficha
		if (this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO() == null || this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO().getParticipantePlano() == null) {
			this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>();
		} else {
			this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>(montarListaSaldoHFPDevolucaoDTO(this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO()));
		}

		return FW_CALCULO_DEVOLUCAO;
	}

	/**
	 * Método encarregado de calcular o total resgatável da devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/04/2017
	 * 
	 * @return {@link String}
	 */
	private void calcularTotalSaldoResgatavel(List<ContaDevolucao> listaContaDevolucao) {
		this.totalSaldoReserva = 0D;
		
		this.totalSaldoReserva = listaContaDevolucao
				.stream()
				.mapToDouble(cd -> (cd.getQtdTotalCotasContribuicao() + cd.getQtdTotalCotasCorrecao() + cd.getQtdTotalCotasJuros() + cd.getQtdTotalCotasMulta()))
				.sum();
//		for (ContaDevolucao cd : listaContaDevolucao) {
//			this.totalSaldoReserva += (cd.getQtdTotalCotasContribuicao() + cd.getQtdTotalCotasCorrecao() + cd.getQtdTotalCotasJuros() + cd.getQtdTotalCotasMulta());
//		}

	}

	/**
	 * Método para redirecionar a página de pesquisa para a página de cadastro de
	 * uma nova devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/01/2017
	 * 
	 * @return {@link String}
	 */
	public String mostrarPaginaDevolucaoModoCalculo() {

		try {

			// Validar Preenchimento Previo antes de ir à página de Cálculo
			validarPreenchimentoPrevioAoCalculo();

			if (possuiBloqueiosParticipante()) {
				return FW_PESQUISA_DEVOLUCAO;
			}

			this.setValorEmprestimo(0D);

			// pesquisar o Valor Cota Plano Atual
			pesquisarValorCotaPlano(new Date());

			this.processoCalculoConcluido = false;

			this.regraDevolucao = this.regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigencia(this.planoPrevidencia, new Date());

			this.regraCalculoDevolucao = this.regraCalculoDevolucaoBO.pesquisarRegraCalculoDevolucaoPorRegraVigenciaTipo(this.regraDevolucao, new Date(), this.getTipoDevolucao());

			preenchePercentualMaximoDevolucao();

			this.setCadastrarNovaDevolucao(true);
			this.setDevolucaoManual(false);

			getCalculoDevolucaoTela();

			carregarUrlPesquisa();

			this.setPossueEmprestimo(false);
			this.setValorEmprestimoRecuperado(false);

			this.valorEmprestimo = this.buscarValorEmprestimo(this.participante, new Date());
			if (valorEmprestimo != 0) {
				this.setPossueEmprestimo(true);
			}

			verificarDocumentosDevolucao(devolucao);

			this.devolucaoManual = false;
			this.mostrarGraficos = false;

			return FW_CALCULO_DEVOLUCAO;
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao gerar dados devolução. Erro: " + e.getMessage());
			return FW_PESQUISA_DEVOLUCAO;// Retorna para tela de pesquisa
		}
	}

	public void onRowEdit(RowEditEvent event) {
		DescontoDevolucao descontoDevolucaoConsulta = ((DescontoDevolucao) event.getObject());
		DescontoDevolucao descontoDevolucao = descontoDevolucaoBO.pesquisarTipoDevolucaoPorCodigo(descontoDevolucaoConsulta.getCodigo());
		descontoDevolucao.setValorDesconto(descontoDevolucaoConsulta.getValorDesconto());
		descontoDevolucaoBO.salvarDescontoDevolucao(descontoDevolucao);
	}

	private void preenchePercentualMaximoDevolucao() {

		this.setPercentualOpcao(regraCalculoDevolucao.getTipoDevolucao().getMaximoPercentualDevolucao());

		// Se devolução for total, não deixa editar e utiliza o máximo
		if (regraCalculoDevolucao.getTipoDevolucao().getIndicadorFormaDevolucao().equals("T")) {
			this.alteraPercentual = true;
		} else {
			this.alteraPercentual = false;
		}

	}

	/**
	 * Método para verificar que as informações prévias para o cálculo foram
	 * preenchidas
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 */
	private void validarPreenchimentoPrevioAoCalculo() {

		if (getEntidadeParticipante() == null) {
			throw new PrevidenciaException("Favor, selecionar uma patrocinadora.");
		}

		if (getPlanoPrevidencia() == null) {
			throw new PrevidenciaException("Favor, selecionar um Plano.");
		}

		if (getParticipante().getCodigo() == null) {
			throw new PrevidenciaException("Favor, selecionar um Participante.");
		}

		if (this.getTipoDevolucao() == null) {
			throw new PrevidenciaException("Favor, selecionar um Tipo de Devolução.");
		}

	}

	/**
	 * Método para pesquisar Valor Cota Plano
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link Date}
	 */
	public String pesquisarValorCotaPlano(Date dataPosicaoCota) {
		if (this.getEntidadeParticipante() == null) {
			Mensagens.addMsgErro("Favor, selecionar uma patrocinadora.");
			return null;
		}

		ParticipantePlano participantePlano = new ParticipantePlano();

		participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(), this.getPlanoPrevidencia());

		// List<PerfilInvestimento> listaPefilIvestimento = new
		// ArrayList<PerfilInvestimento>(perfilInvestimentoBO.listarPerfilInvestimentoPorEntidadeParticipante(getEntidadeParticipante()));
		List<PerfilInvestimento> listaPefilIvestimento = new ArrayList<PerfilInvestimento>(perfilInvestimentoBO.listarPerfilInvestimentoPorParticipantePlano(participantePlano));

		for (PerfilInvestimento perfilInvestimento : listaPefilIvestimento) {

			ValorCotaPlano valorCotaPlano = valorCotaPlanoBO.pesquisarCotaPlanoPorEmpresaPlanoPerfil(dataPosicaoCota, participantePlano.getParticipante().getEntidadeParticipante(), participantePlano
					.getPlanoPrevidencia(), perfilInvestimento);

			if (valorCotaPlano != null) {
				this.valorCotaPlano = valorCotaPlano;
			} else {
				this.valorCotaPlano = null;
			}
		}

		if (valorCotaPlano != null) {
			this.valorCotaPlano = valorCotaPlano;
		} else {
			this.valorCotaPlano = null;
		}

		return "S";
	}

	/**
	 * Método encarregado de retornar todos os Indicadores da Forma de Pagamento da
	 * Contribuição de Carência
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/01/2017
	 * @return {@link List<SelectItem>}
	 */
	public List<SelectItem> listarIndicadorPagamentoContribCarencia() {
		return IndicadorFormaPagamentoContribCarencia.listaElementosEnum();

	}

	/**
	 * Método encarregado de Calcular o Processo de devolução e preencher a tela com
	 * as informações retornadas
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/02/2017
	 * @return {@link String}
	 */
	public String calcularProcessoDevolucao() {
		FacesContext context = FacesContext.getCurrentInstance();

		try {

			String dataCotaCalculo;

			String dataRequerimento;

			if (this.getValorCotaPlano().getChavePrimaria().getDataPosicaoCota() != null) {
				dataCotaCalculo = UtilJava.formataDataPorPadrao(this.getValorCotaPlano().getChavePrimaria().getDataPosicaoCota(), "dd/MM/yyyy");
			} else {
				// pesquiso novamente o ValorCotaPlano para a data atual
				pesquisarValorCotaPlano(new Date());
				dataCotaCalculo = UtilJava.formataDataPorPadrao(this.getValorCotaPlano().getChavePrimaria().getDataPosicaoCota(), "dd/MM/yyyy");
			}

			if (this.getCalculoDevolucaoTela().getDataRequerimento() != null) {
				dataRequerimento = UtilJava.formataDataPorPadrao(this.getCalculoDevolucaoTela().getDataRequerimento(), "dd/MM/yyyy");
			} else {
				dataRequerimento = UtilJava.formataDataPorPadrao(new Date(), "dd/MM/yyyy");
			}

			// Verificação de empréstimo
			if (participante.getIndicadorEmprestimo().toString().equals("S") && valorEmprestimo == 0 ) {

					context.addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_WARN,
									"Aviso", "Favor preencher valor de empréstimo.")
					);

					return FW_CALCULO_DEVOLUCAO;

			}

			//Verificar Basa para poder mostar saldo isento
			if (this.entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante().equals(10031L)) {

				setPatronicinadoraBasa(true);

			} else {
				setPatronicinadoraBasa(false);
			}

			ParticipantePlano participantePlano = new ParticipantePlano();

			participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(), this.getPlanoPrevidencia());

			String opcaoTributacao = participantePlano.getTipoRegimeTributacao().getCodigo();

			if ( (!opcaoTributacao.equalsIgnoreCase("P") && !opcaoTributacao.equalsIgnoreCase("R"))
					&&  (this.getTipoDevolucao().getIndicadorTipoDevolucao().equals("R")
							|| (this.getTipoDevolucao().getIndicadorTipoDevolucao().equals("P") && this.isPossueEmprestimo() )
							)
					) {
						throw new DevolucaoException("Participante com tipo de tributação Não Definido.");
			}

			this.devolucaoCalculoCompleto = this.calculoDevolucao.calcularDevolucao(this.getParticipante().getCodigo(), // código
					// do
					// participante
					this.getPlanoPrevidencia().getCodigo(), // codigo do plano
					this.getTipoDevolucao().getCodigo(), // tipo de volu
					dataRequerimento, // data do requerimento em string
					null, // tipo de devoluçao
					"S", // s o n
					this.getNumTotalParcelas(), // Quantidade Total de parcelas
					dataCotaCalculo, // data da cota tipo string
					this.getIndicadorFormaPagamentoContribCarencia(),
					null,
					getPercentualOpcao(),
					this.valorEmprestimo,
					opcaoTributacao);// forma
			// de
			// pagamento
			
			
			expandirDetalheParcelaDevolucao(devolucaoCalculoCompleto.getListaParcelaContaDevolucao());

			setProcessoCalculoConcluido(true);

			if (isProcessoCalculoConcluido()) {

				// Verificar se existem documentos devolução para o Plano - Yanisley
				List<DocumentoPlanoTipoDevolucao> listaDocPlanoDev = new ArrayList<DocumentoPlanoTipoDevolucao>(documentoPlanoTipoDevolucaoBO.listaDocumentoPlanoTipoDevolucaoPorPlanoTipoDevolucao(
						this.planoPrevidencia,
						this.tipoDevolucao.getCodigo()));

				if (UtilJava.isColecaoDiferenteDeVazia(listaDocPlanoDev)) {
					this.setPermiteSalvarProcessoCalculado(true);
				} else {
					String mensagemSaidaDevolucao = "Plano " + this.planoPrevidencia.getNomePlano() + " sem documentos de devolução cadastrados.";
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));
					PrimeFaces.current().ajax().update(":txtPopup");
					this.setPermiteSalvarProcessoCalculado(false);
				}

				this.setIndicadorFormaPagamentoContribCarencia(this.devolucaoCalculoCompleto.getDevolucao().getIndicadorFormaPagtoContribCarencia());
				this.setNumTotalParcelas(this.devolucaoCalculoCompleto.getDevolucao().getNumeroTotalParcelas());
				this.getCalculoDevolucaoTela().setDataRequerimento(this.devolucaoCalculoCompleto.getDevolucao().getDataRequerimento());

				ElegibilidadeDevolucaoDTO elegibilidadeDevolucaoDTO = new ElegibilidadeDevolucaoDTO();

				elegibilidadeDevolucaoDTO = regraElegibilidadeDevolucaoBO.isElegivelPorDevolucao(this.devolucaoCalculoCompleto.getDevolucao());

				if (elegibilidadeDevolucaoDTO.isElegivel()) {
					System.out.println("Elegível");
				} else {
					System.out.println("Não Elegível");

					// Mensagem de carta de indeferimento
					String mensagemSaidaDevolucao = "O Participante não é elegível para efetuar o "
							+ this.devolucaoCalculoCompleto.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getNome() + "<br /> Motivo: " + elegibilidadeDevolucaoDTO.getDescricao()
							+ ".<br />" + "Clique <b><a href='#'>aqui</a></b> para imprimir a carta de indeferimento.";
					// Mensagens.addMsgWarn(mensagemSaidaDevolucao);
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));
					PrimeFaces.current().ajax().update(":txtPopup");
					this.setPermiteSalvarProcessoCalculado(false);

				}

				// Exigencia de desligamento
				if (elegibilidadeDevolucaoDTO.isNaoDesligadoDevolucaoExigeDesligamento()) {
					String mensagemSaidaDevolucao = "O Participante não está desligado.";
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));

					this.setPermiteSalvarProcessoCalculado(false);
				}

				if (elegibilidadeDevolucaoDTO.isMotivoDesligamentoNuloOuDiferenteExigido()) {

					String mensagemSaidaDevolucao = new String();

					if (this.devolucaoCalculoCompleto.getDevolucao().getParticipantePlano().getParticipante().getMotivoDesligamento() == null) {
						mensagemSaidaDevolucao = "Participante sem motivo de desligamento preenchido.";
					} else {
						mensagemSaidaDevolucao = "Participante com motivo de desligamento diferente do exigido.";
					}
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));

					this.setPermiteSalvarProcessoCalculado(false);
				}

				if (UtilJava.isColecaoDiferenteDeVazia(this.devolucaoCalculoCompleto.getDevolucao().getListaDescontoDevolucao())) {
					this.setMensagemAntesSalvar("O participante possui descontos. Deseja continuar?");
				} else {
					this.setMensagemAntesSalvar("Confirma Salvar o processo de Devolução?");
				}

				calcularTotalSaldoResgatavel(this.devolucaoCalculoCompleto.getListaContaDevolucao());

				// Montar lista de saldos de Ficha
				if (this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO() == null || this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO().getParticipantePlano() == null) {
					this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>();
				} else {
					this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>(montarListaSaldoHFPDevolucaoDTO(this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO()));
				}

				// Montar informações dos gráficos
				if (UtilJava.isColecaoDiferenteDeVazia(this.listaSaldoHFPDevolucaoDTO)) {
					this.preencherInformacoesGraficas(this.listaSaldoHFPDevolucaoDTO, this.devolucaoCalculoCompleto.getListaContaDevolucao());
				}

				// Demanda 35552 - Daniel Martins - 20/12/2017
				if (devolucaoCalculoCompleto.getDevolucao().getPercentualDevolucao() == 100l) {

					Double qtdCotaContas = 0d;
					Double qtdCotaHFP = 0d;

					if (devolucaoCalculoCompleto.getListaContaDevolucao().size() > 0 && this.listaSaldoHFPDevolucaoDTO.size() > 0) {
						
						qtdCotaHFP = this.listaSaldoHFPDevolucaoDTO
								.stream()
								.mapToDouble(e -> e.getQtdCotaContribuicao()
										+ (e.getIndicadorCorrecao().equals("S") ? e.getQtdCotaCorrecao() : 0D)
										+ (e.getIndicadorJuros().equals("S") ? e.getQtdCotaJuros() : 0D)
										+ (e.getIndicadorMulta().equals("S") ? e.getQtdCotaMulta() : 0D))
								.sum();
						/*
						for (SaldoHFPDevolucaoDTO saldoHFPDevolucaoDTO : this.listaSaldoHFPDevolucaoDTO) {
							qtdCotaHFP = qtdCotaHFP + saldoHFPDevolucaoDTO.getQtdCotaContribuicao()
									+ (saldoHFPDevolucaoDTO.getIndicadorCorrecao().equals("S") ? saldoHFPDevolucaoDTO.getQtdCotaCorrecao() : 0D)
									+ (saldoHFPDevolucaoDTO.getIndicadorJuros().equals("S") ? saldoHFPDevolucaoDTO.getQtdCotaJuros() : 0D)
									+ (saldoHFPDevolucaoDTO.getIndicadorMulta().equals("S") ? saldoHFPDevolucaoDTO.getQtdCotaMulta() : 0D);

						}
						*/
						
						qtdCotaContas =  devolucaoCalculoCompleto.getListaContaDevolucao()
								.stream()
								.mapToDouble(e -> e.getQtdTotalCotasContribuicao()
										+ e.getQtdTotalCotasCorrecao() 
										+ e.getQtdTotalCotasJuros()
										+ e.getQtdTotalCotasMulta())
								.sum();
						/*
						for (ContaDevolucao contaDevolucao : devolucaoCalculoCompleto.getListaContaDevolucao()) {
							qtdCotaContas = qtdCotaContas + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
									+ contaDevolucao.getQtdTotalCotasMulta();
						}
						*/

					}

					double ValorTolerancia = 0.00000001;

					// Comparação de quantidade de tolerancia acima
					if (Math.abs(qtdCotaContas - qtdCotaHFP) > ValorTolerancia) {
						String mensagem = "Quantidade de cotas diferentes: ficha de ativo e contas devolução.<br /><br />" + "Quantidade Ficha: " + qtdCotaHFP + "<br />" + "Quantidade Contas: "
								+ qtdCotaContas + "<br />";

						context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagem));
						this.setPermiteSalvarProcessoCalculado(false);
					}

				}

				// Demanda 36122 - Yanisley Mora Ritchie 06/03/2018
				if (historicoFinanceiroSpParticipanteBO.verificarPassivoIntegralizar(this.devolucaoCalculoCompleto.getDevolucao().getParticipantePlano())) {
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Participante possui passivo em Ficha Financeira"));
				}

				// Demanda 36395 - Yanisley Mora Ritchie 05/04/2018
				String recebeMensagemRetorno = this.historicoFinanceiroPagoBO.buscarSaldoEmPlanosBDGeral(this.devolucaoCalculoCompleto.getDevolucao().getParticipantePlano().getParticipante()
						.getCodigo());
				if (!UtilJava.isStringVazia(recebeMensagemRetorno)) {
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", recebeMensagemRetorno));

					AnotacaoDevolucao anotacaoDevolucao = this.anotacaoDevolucaoBO.gerarAnotacaoDevolucao(this.devolucaoCalculoCompleto.getDevolucao(), recebeMensagemRetorno, new Date(new Timestamp(
							System.currentTimeMillis()).getTime()), this.loginTemporariaDTO);
					this.devolucaoCalculoCompleto.getListaAnotacaoDevolucao().add(anotacaoDevolucao);
				}

			}
		} catch (DevolucaoException e) {
			log.error(e);
			// Mensagens.addMsgErro(pEx.getMessage());

			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", e.getMessage()));

		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			// Mensagens.addMsgErro(pEx.getMessage());

			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", pEx.getMessage()));

		}

		return FW_CALCULO_DEVOLUCAO;
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/06/2017
	 * @param saldoHistoricoFinanceiroPagoDTO
	 * @return
	 */
	private List<SaldoHFPDevolucaoDTO> montarListaSaldoHFPDevolucaoDTO(SaldoHistoricoFinanceiroPagoDTO saldoHistoricoFinanceiroPagoDTO) {
		List<SaldoHFPDevolucaoDTO> listaRetorno = new ArrayList<SaldoHFPDevolucaoDTO>();

		listaRetorno.add(new SaldoHFPDevolucaoDTO("Participante", saldoHistoricoFinanceiroPagoDTO.getQtdCotaContribuicaoPartic(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaJurosParticipante(),
				saldoHistoricoFinanceiroPagoDTO.getQtdCotaCorrecaoParticipante(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaMultaParticipante(), saldoHistoricoFinanceiroPagoDTO.getIndicadorMulta(),
				saldoHistoricoFinanceiroPagoDTO.getIndicadorJuros(), saldoHistoricoFinanceiroPagoDTO.getIndicadorCorrecao()));

		listaRetorno.add(new SaldoHFPDevolucaoDTO("Patrocinadora", saldoHistoricoFinanceiroPagoDTO.getQtdCotaContribuicaoPatronal(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaJurosPatronal(),
				saldoHistoricoFinanceiroPagoDTO.getQtdCotaCorrecaoPatronal(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaMultaPatronal(), saldoHistoricoFinanceiroPagoDTO.getIndicadorMulta(),
				saldoHistoricoFinanceiroPagoDTO.getIndicadorJuros(), saldoHistoricoFinanceiroPagoDTO.getIndicadorCorrecao()));

		listaRetorno.add(new SaldoHFPDevolucaoDTO("Autopatrocinado", saldoHistoricoFinanceiroPagoDTO.getQtdCotaContribuicaoPatronalParticipante(), saldoHistoricoFinanceiroPagoDTO
				.getQtdCotaJurosPatronalParticipante(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaCorrecaoPatronalParticipante(),
				saldoHistoricoFinanceiroPagoDTO.getQtdCotaMultaPatronalParticipante(), saldoHistoricoFinanceiroPagoDTO.getIndicadorMulta(), saldoHistoricoFinanceiroPagoDTO.getIndicadorJuros(),
				saldoHistoricoFinanceiroPagoDTO.getIndicadorCorrecao()));

		return listaRetorno;
	}

	/**
	 * Método para retornar a descrição do indicador do mantenedor
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param indicadorMantenedor
	 * @since 01/02/2017
	 * @return {@link String}
	 */
	public String buscarDescricaoMantenedor(String codigo) {
		return MantenedorEnum.getMantenedorEnum(codigo).getDescricao();
	}

	/**
	 * Método responsável de calacular os totais do DataTable da Contas de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * 
	 */
	public void calcularTotaisContas(Object o) {
		if (this.colunaOrdenadaContasDevolucao != 0) {
			this.calculoDevolucaoTela.calcularTotaisContasDevolucao(this.devolucaoCalculoCompleto.getListaContaDevolucao(), this.devolucaoCalculoCompleto.getDevolucao().getValorIndiceAjustado(), o
					.toString(), this.getColunaOrdenadaContasDevolucao());
		}

	}

	/**
	 * Método encarregado de calcular os totais que são mostrados no Datatable das
	 * parcelas de devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param o
	 */
	public void calcularTotaisParcelasContas(Object o) {
		if (this.colunaOrdenadaParcelasContasDevolucao != 0) {
			this.calculoDevolucaoTela.calcularTotaisContasParcelas(this.devolucaoCalculoCompleto.getListaParcelaContaDevolucaoDetalheImposto(), this.devolucaoCalculoCompleto
					.getListaParcelaContaDevolucao(), this.devolucaoCalculoCompleto.getDevolucao().getValorCota(), o.toString(), this.colunaOrdenadaParcelasContasDevolucao);
		}
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/06/2017
	 */
	public void calcularTotaisSaldo(Object o) {
		if (this.processoCalculoConcluido) {
			this.calculoDevolucaoTela.calcularTotaisSaldoAtual(this.listaSaldoHFPDevolucaoDTO, this.devolucaoCalculoCompleto.getDevolucao().getValorIndiceAjustado());
		}
	}

	/**
	 * @author BBPF0170 - MAGSON
	 * @since 07/06/2017
	 */
	public void calcularTotaisParcelasContasPgto(Object o) {
		List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevoluacoDetalheImposto = new ArrayList<ParcelaContaDevolucaoDetalheImposto>();
		for (ParcelaContaDevolucaoPagto parcelaContaDevolucaoPagto : this.devolucaoCalculoCompleto.getListaParcelaContaDevolucaoPagto()) {
			for (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto : this.parcelaContaDevolucaoDetalheImpostoBO
					.pesquisarParcelaContaDevolucaoDetalheImpostoPorParcelaContaDevolucaoECronograma(parcelaContaDevolucaoPagto.getParcelaContaDevolucao(), parcelaContaDevolucaoPagto
							.getCronogramaDevolucao())) {
				listaParcelaContaDevoluacoDetalheImposto.add(parcelaContaDevolucaoDetalheImposto);
			}
		}
		this.calculoDevolucaoTela.calcularTotaisContasParcelasPgto(listaParcelaContaDevoluacoDetalheImposto, this.devolucaoCalculoCompleto.getListaParcelaContaDevolucaoPagto(), o.toString());
	}

	/**
	 * Método encarregado de salvar a coluna que foi selecionada para ordenar o
	 * datatable das Contas de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param {@link SortEvent}
	 */
	public void onSortContasDevolucao(SortEvent event) {
		if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Tipo"))
			colunaOrdenadaContasDevolucao = 1;
		else if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Mantenedor"))
			colunaOrdenadaContasDevolucao = 2;
		else if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Automantenedor"))
			colunaOrdenadaContasDevolucao = 3;

	}

	/**
	 * Método encarregado de pegar a coluna que foi clicada no datatable das
	 * Parcelas de Contas de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link SortEvent}
	 */
	public void onSortParcelasContasDevolucao(SortEvent event) {
		if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Tipo"))
			colunaOrdenadaParcelasContasDevolucao = 1;
		else if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Parcela Paga"))
			colunaOrdenadaParcelasContasDevolucao = 2;
	}

	/**
	 * Método para pesuisar o Valor Cota Plano quando a data é selecionada na UI do
	 * Calendar
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link SelectEvent}R
	 */
	public void dataPosicaoCotaSelecionada(SelectEvent event) {
		if (event.getObject() instanceof Date) {
			pesquisarValorCotaPlano((Date) event.getObject());
		} else {
			System.out.println("Chegou outra Coisa");
		}
	}

	/**
	 * Método para pesuisar o Valor Cota Plano quando a data é digitada
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link AjaxBehaviorEvent}
	 */
	public void dataPosicaoCotaAltecaoManual(AjaxBehaviorEvent event) {
		Date dataManual = (Date) ((UIOutput) event.getSource()).getValue();

		pesquisarValorCotaPlano(dataManual);

	}

	/**
	 * Método encarregado de salvar o processo de devolução após o processo de
	 * cálculo
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/02/2017
	 * 
	 */
	public String salvarProcessoDevolucao() {
		if (this.getDevolucaoCalculoCompleto() != null) {
			try {
				this.calculoDevolucao.salvarDevolucao(getDevolucaoCalculoCompleto());
				Mensagens.addMsgInfo("Processo de devolução salvo com Sucesso!");
				this.setProcessoSalvo(true);

				if (documentoDevolucaoVisaoItemBO.verificarDocumentosPorDevolucao(getDevolucaoCalculoCompleto().getDevolucao(), loginTemporariaDTO)) {

					Mensagens.addMsgInfo("Favor verificar documento de devolução!");

					verificarDocumentosDevolucao(getDevolucaoCalculoCompleto().getDevolucao());

				}

			} catch (PrevidenciaException pEx) {
				Mensagens.addMsgErro(pEx.getMessage());
				this.setProcessoSalvo(false);
			} catch (Exception ex) {
				Mensagens.addMsgErro("Erro ao salvar o processo de Devolução.");
				this.setProcessoSalvo(false);
			}
		}

		return FW_CALCULO_DEVOLUCAO;
	}

	/**
	 * Método encarregado de retornar ao modo pesquisa inicial mantendo a lista de
	 * Planos
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/02/2017
	 */
	public String retornarPaginaPesquisa() {
		this.setProcessoCalculoConcluido(false);
		this.setProcessoSalvo(false);
		this.setDevolucaoCalculoCompleto(null);
		this.setCadastrarNovaDevolucao(false);
		this.calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();
		this.setValorCotaPlano(null);
		this.setColunaOrdenadaParcelasContasDevolucao(1);
		this.setColunaOrdenadaContasDevolucao(1);

		this.setParticipante(new Participante());
		this.setTipoDevolucao(null);

		return getUrlRetorno();
	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */

	public void expandirDetalheParcelaDevolucao(ToggleEvent event) {
		/*
		 * ParcelaContaDevolucao parcelaContaDevolucao = (ParcelaContaDevolucao)
		 * event.getData();
		 * 
		 * this.listaParcelaContaDevolucaoDetalheImpostoDTO.clear();
		 * this.listaParcelaContaDevolucaoDetalheImposto.clear();
		 * 
		 * if (this.processoSalvo) { this.listaParcelaContaDevolucaoDetalheImposto = new
		 * ArrayList<ParcelaContaDevolucaoDetalheImposto>(
		 * parcelaContaDevolucaoDetalheImpostoBO
		 * .pesquisarParcelaContaDevolucaoDetalheImpostoPorParcelaContaDevolucaoECronograma
		 * (parcelaContaDevolucao, null)); } else { for
		 * (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto :
		 * this.devolucaoCalculoCompleto. getListaParcelaContaDevolucaoDetalheImposto())
		 * {
		 * 
		 * if (parcelaContaDevolucao.equals(parcelaContaDevolucaoDetalheImposto.
		 * getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao())){
		 * this.listaParcelaContaDevolucaoDetalheImposto.add(
		 * parcelaContaDevolucaoDetalheImposto); } } }
		 * 
		 * listaParcelaContaDevolucaoDetalheImpostoDTO.addAll(
		 * parcelaContaDevolucaoDetalheImpostoBO.agruparDataETipoImposto(this.
		 * listaParcelaContaDevolucaoDetalheImposto));
		 */
	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */
	public void expandirDetalheParcelaDevolucao(List<ParcelaContaDevolucao> listaParcelaContaDevolucao) {

		for (ParcelaContaDevolucao parcelaContaDevolucao : listaParcelaContaDevolucao) {

			// this.listaParcelaContaDevolucaoDetalheImpostoDTO.clear();
			// this.listaParcelaContaDevolucaoDetalheImposto.clear();

			List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevolucaoDetalheImposto = new ArrayList<>();

			if (this.processoSalvo) {
				listaParcelaContaDevolucaoDetalheImposto = new ArrayList<ParcelaContaDevolucaoDetalheImposto>(
						parcelaContaDevolucaoDetalheImpostoBO
								.pesquisarParcelaContaDevolucaoDetalheImpostoPorParcelaContaDevolucaoECronograma(
										parcelaContaDevolucao, null));
			} else {
				for (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto : this.devolucaoCalculoCompleto
						.getListaParcelaContaDevolucaoDetalheImposto()) {

					if (parcelaContaDevolucao.equals(parcelaContaDevolucaoDetalheImposto
							.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao())) {
						listaParcelaContaDevolucaoDetalheImposto.add(parcelaContaDevolucaoDetalheImposto);
					}
				}
			}

			parcelaContaDevolucao.setListaParcelaContaDevolucaoDetalheImpostoDTO(parcelaContaDevolucaoDetalheImpostoBO
					.agruparDataETipoImposto(listaParcelaContaDevolucaoDetalheImposto));

		}

	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */
	public void expandirDetalheParcelaDevolucaoImpostoDTO(List<ParcelaContaDevolucaoDetalheImpostoDTO> listaParcelaContaDevolucaoDetalheImpostoDTO) {

		for (ParcelaContaDevolucaoDetalheImpostoDTO parcelaContaDevolucaoDetalheImpostoDTO : listaParcelaContaDevolucaoDetalheImpostoDTO) {
			parcelaContaDevolucaoDetalheImpostoDTO.setListaParcelaContaDevolucaoDetalheImposto(parcelaContaDevolucaoDetalheImpostoDTO.getListaParcelaContaDevolucaoDetalheImposto());
		}
	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */

	public void expandirDetalheParcelaDevolucaoImpostoDTO(ToggleEvent event) {
		/*
		 * ParcelaContaDevolucaoDetalheImpostoDTO parcelaContaDevolucaoDetalheImpostoDTO
		 * = (ParcelaContaDevolucaoDetalheImpostoDTO) event.getData();
		 * 
		 * 
		 * listaParcelaContaDevolucaoDetalheImpostoFiltro.addAll(
		 * parcelaContaDevolucaoDetalheImpostoDTO.
		 * getListaParcelaContaDevolucaoDetalheImposto());
		 */
	}

	/**
	 * Método encarregado de Calculo o total de impostos a pagar por parcela conta
	 * devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * 
	 * @param {@link ParcelaContaDevolucao}
	 */
	public double calcularImpostosParcela(ParcelaContaDevolucao parcelaContaDevolucao) {
		double totalImpostoParcela = 0D;

		for (ParcelaContaDevolucaoDetalheImposto detalheImposto : devolucaoCalculoCompleto.getListaParcelaContaDevolucaoDetalheImposto()) {
			if (detalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().equals(parcelaContaDevolucao) && detalheImposto.getCronogramaDevolucao() == null) {
				totalImpostoParcela += detalheImposto.getValorIrrf();
			}
		}

		return totalImpostoParcela;

	}

	public double calcularIsencaoParcela(ParcelaContaDevolucao parcelaContaDevolucao) {
		double totalIsensaoParcela = 0D;

		for (ParcelaContaDevolucaoDetalheImposto detalheImposto : devolucaoCalculoCompleto.getListaParcelaContaDevolucaoDetalheImposto()) {
			if (detalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().equals(parcelaContaDevolucao)) {
				totalIsensaoParcela += detalheImposto.getSaldoIsento();
			}
		}

		return totalIsensaoParcela;

	}

	public double calcularImpostosPago(ParcelaContaDevolucao parcelaContaDevolucao) {
		double totalImpostoParcela = 0D;
		for (ParcelaContaDevolucaoDetalheImposto detalheImposto : devolucaoCalculoCompleto.getListaParcelaContaDevolucaoDetalheImposto()) {
			if (detalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().equals(parcelaContaDevolucao) && detalheImposto.getCronogramaDevolucao() != null) {
				totalImpostoParcela += detalheImposto.getValorIrrf();
			}
		}

		return totalImpostoParcela;
	}

	/**
	 * Metodo responsável pelo cancelamento da inclusão de uma nova Anotação de
	 * Devoluçao
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 */
	public void cancelarInclusaoAnotacaoDevolucao() {
		this.anotacaoDevolucao = new AnotacaoDevolucao();
	}

	/**
	 * Método responsável de incluir novas Anotações de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * 
	 */
	public void incluirAnotacaoDevolucao(Devolucao devolucao) {

		this.anotacaoDevolucao.setDevolucao(devolucao);

		if (this.anotacaoDevolucao.getDataAnotacao() == null) {
			this.anotacaoDevolucao.setDataAnotacao(new Date());
		}

		if (this.anotacaoDevolucao.getDescricaoAnotacao() != null) {
			anotacaoDevolucaoBO.salvarAnotacaoDevolucao(this.anotacaoDevolucao);
		}

		this.devolucaoCalculoCompleto.setListaAnotacaoDevolucao(anotacaoDevolucaoBO.listaTodasPorDevolucao(this.devolucaoCalculoCompleto.getDevolucao()));

		cancelarInclusaoAnotacaoDevolucao();
	}

	public void limparObjetosTemporarios() {

	}

	public String salvarListaDocumentoDevolucaoVisaoItem() {

		for (DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItem : this.listaDocumentoDevolucaoVisaoItem) {

			DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItemPesq = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorCodigo(documentoDevolucaoVisaoItem.getCodigo());

			if (!documentoDevolucaoVisaoItemPesq.getIndicativoMarcado().equals(documentoDevolucaoVisaoItem.getIndicativoMarcado())) {

				// Marcando a data de marcação do documento.
				if (documentoDevolucaoVisaoItem.getIndicativoMarcado().equals("S")) {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(new Date());
				} else {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(null);
				}

				documentoDevolucaoVisaoItemPesq.setIndicativoMarcado(documentoDevolucaoVisaoItem.getIndicativoMarcado());
				documentoDevolucaoVisaoItemPesq.setNomeUsuarioAlteracao(loginTemporariaDTO.getIdentificacaoUsuario());
				documentoDevolucaoVisaoItemBO.salvarDocumentoDevolucaoVisaoItem(documentoDevolucaoVisaoItemPesq);
			}

		}

		Devolucao devolucaoInterno = new Devolucao();

		if (this.listaDocumentoDevolucaoVisaoItem.size() > 0) {
			devolucaoInterno = this.listaDocumentoDevolucaoVisaoItem.get(0).getDocumentoDevolucaoVisao().getDevolucao();
		}

		verificarDocumentosDevolucao(devolucaoInterno);

		fecharPopupDocumentosPendentes();

		return FW_CALCULO_DEVOLUCAO;

	}

	public void fecharPopupDocumentosPendentes() {
		PrimeFaces.current().dialog().closeDynamic("documentosDevolucaoDialog");
	}

	public void verificarDocumentosDevolucao(Devolucao devolucao) {

		String descricaoPendenciasLocal = new String();

		descricaoPendenciasLocal = "Não existe(m) documento(s)";

		if (devolucao == null) {
			this.setPossuiDocumentoDevolucao(false);
			this.setPossuiDocumentoDevolucaoPendente(false);
			this.setChamaPendenciasAberturaTela(false);
		} else {

			this.listaDocumentoDevolucaoVisaoItem = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorDevolucao(devolucao);

			this.setPossuiDocumentoDevolucaoPendente(false);
			this.setChamaPendenciasAberturaTela(false);

			if (this.listaDocumentoDevolucaoVisaoItem.size() > 0) {

				descricaoPendenciasLocal = "Não existe(m) documento(s) pendente(s)";

				this.setPossuiDocumentoDevolucao(true);

				if (documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemPendentePorDevolucao(devolucao)) {
					this.setPossuiDocumentoDevolucaoPendente(true);
					descricaoPendenciasLocal = "Existe(m) documento(s) Pendende(s)";
				}

			} else {
				descricaoPendenciasLocal = "Não existe(m) documento(s)";
				this.setPossuiDocumentoDevolucao(false);

			}

			// Somente chamar pendencia de forma automática se vier da tela de
			// pesquisa.
			if (this.getVariavelRetorno().equals("pesquisa")) {

				if (this.isPossuiDocumentoDevolucaoPendente()) {
					this.setChamaPendenciasAberturaTela(true);
				}

			}

		}

		this.setDescricaoPendencias(descricaoPendenciasLocal);

	}

	/**
	 * Método encarregado de mostrar o relatório de Processo de Retenção em PDF
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/04/2017
	 * @param {@link Devolucao}
	 */
	public void mostrarRelatorioProcessoRetencao(Devolucao devolucao) {
		try {
			ProcessoRetencaoDTO processoRetencaoDTO = new ProcessoRetencaoDTO();

			processoRetencaoDTO = this.devolucaoBO.montarRelatorioProcessoRetencao(devolucao);

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = UtilSession.getRealPath("imagens/logoBBPrevidencia.jpg");

			parametros.put("logo", logo);

			List<ProcessoRetencaoDTO> relatorioProcessoRetencao = new ArrayList<ProcessoRetencaoDTO>();
			relatorioProcessoRetencao.add(processoRetencaoDTO);
			String nomeArquivo = relatorioUtil.gerarRelatorio("processoRetencao", relatorioProcessoRetencao, parametros);
			log.info("Relatório Gerado: " + nomeArquivo);

			relatorioUtil.abrirPoupUp(nomeArquivo);

			// JRBeanCollectionDataSource dataSource = new
			// JRBeanCollectionDataSource(relatorioProcessoRetencao);
			// GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "processoRetencao",
			// dataSource);

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}
	}

	/**
	 * Método encarregado de mostrar o relatório da Súmula em PDF
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/11/2017
	 * @param {@link Devolucao}
	 */
	public void mostrarRelatorioSumula(Devolucao devolucao) {
		try {
			SumulaDevolucaoDTO sumulaDevolucaoDTO = new SumulaDevolucaoDTO();
			sumulaDevolucaoDTO = this.devolucaoBO.montarRelatorioSumulaDevolucao(devolucao);

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = UtilSession.getRealPath("imagens/logoBBPrevidencia.jpg");

			parametros.put("logo", logo);

			// parametros.put("listaDocumentos",
			// sumulaDevolucaoDTO.getRecebedoresResgateSumula() );
			parametros.put("recebedoresResgateSumula", sumulaDevolucaoDTO.getRecebedoresResgateSumula());

			List<SumulaDevolucaoDTO> relatorioSumulaDevolucao = new ArrayList<SumulaDevolucaoDTO>();
			relatorioSumulaDevolucao.add(sumulaDevolucaoDTO);
			String nomeArquivo = relatorioUtil.gerarRelatorio("sumulaDevolucao", relatorioSumulaDevolucao, parametros);
			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	public String mostrarResumoDevolucaoMigracao(DevolucaoAntigoDTO devolucaoAntigoDTO) {

		if (loginTemporariaDTO == null) {
			this.loginTemporariaDTO = UtilSession.getLoginAtualBBPrevWeb(OrigemAcesso.GESTAO_PARTICIPANTE);
		}

		this.setPossuiAcessoConsulta(true);
		this.setPermiteSalvarProcessoCalculado(true);
		this.setPossuiAcessoTotal(true);

		carregarUrlPesquisa();

		this.setCalculoDevolucaoTela(null);
		this.setCadastrarNovaDevolucao(false);
		this.setProcessoCalculoConcluido(true);
		this.setProcessoSalvo(false);
		this.setTipoDevolucao(null);
		this.setIndicadorFormaPagamentoContribCarencia(null);
		this.setParticipante(new Participante());
		this.setDevolucaoManual(false);

		String indicadoCarencia = "V";
		Long codigoTipoDevolucao = 0L;
		String tipoDevolucao = null;

		if (devolucaoAntigoDTO.getIndicadorCarenciaInstituidor() != null) {
			indicadoCarencia = devolucaoAntigoDTO.getIndicadorCarenciaInstituidor().equals("M") ? "V" : "F";
		}

		int qtdParcela = devolucaoAntigoDTO.getQtdParcela();

		// Migração Valores Mutua
		if (devolucaoAntigoDTO.getQtdParcela() >= 2 && devolucaoAntigoDTO.getParticipantePlano().getParticipante().getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante() == 34) {
			qtdParcela = 1;
		}

		if (devolucaoAntigoDTO.getIndicadorPortabilidade().equals("S")) {
			codigoTipoDevolucao = devolucaoAntigoDTO.getParticipantePlano().getPlanoPrevidencia().getTipoPortabilidadePadrao();
			tipoDevolucao = "P";
		} else {
			codigoTipoDevolucao = devolucaoAntigoDTO.getParticipantePlano().getPlanoPrevidencia().getTipoResgatePadrao();
			tipoDevolucao = "R";
		}

		String opcaoTributacao = devolucaoAntigoDTO.getParticipantePlano().getTipoRegimeTributacao().getCodigo();

		this.devolucaoCalculoCompleto = new DevolucaoCompletoDTO();

		this.devolucaoCalculoCompleto = this.calculoDevolucao.calcularDevolucaoMigracao(devolucaoAntigoDTO.getParticipantePlano().getParticipante().getCodigo(), devolucaoAntigoDTO
				.getParticipantePlano().getPlanoPrevidencia().getCodigo(), codigoTipoDevolucao, devolucaoAntigoDTO, UtilData.formataDataPorPadrao(
				devolucaoAntigoDTO.getDataRequerimento(),
				"dd/MM/yyyy"), tipoDevolucao, "S", qtdParcela, UtilData.formataDataPorPadrao(devolucaoAntigoDTO.getDataCota(), "dd/MM/yyyy"), indicadoCarencia, null, 100D, devolucaoAntigoDTO
				.getValorEmprestimo(), opcaoTributacao);

		if (devolucaoCalculoCompleto.getDevolucao() != null) {
			this.setParticipante(devolucaoCalculoCompleto.getDevolucao().getParticipantePlano().getParticipante());
			// this.devolucaoCalculoCompleto.getDevolucao().setCodigo(devolucaoAntigoDTO.getCodigo());
		}

		if (this.entidadeParticipante == null) {
			this.setEntidadeParticipante(devolucaoCalculoCompleto.getDevolucao().getParticipantePlano().getParticipante().getEntidadeParticipante());
		}

		if (this.planoPrevidencia == null) {
			this.setPlanoPrevidencia(devolucaoCalculoCompleto.getDevolucao().getParticipantePlano().getPlanoPrevidencia());
		}

		if (this.getRegraCalculoDevolucao() == null) {
			this.setRegraCalculoDevolucao(devolucaoCalculoCompleto.getDevolucao().getRegraCalculoDevolucao());
		}

		if (this.getTipoDevolucao() == null) {
			this.setTipoDevolucao(devolucaoCalculoCompleto.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao());
		}

		if (this.indicadorFormaPagamentoContribCarencia == null) {
			this.setIndicadorFormaPagamentoContribCarencia(devolucaoCalculoCompleto.getDevolucao().getIndicadorFormaPagtoContribCarencia());
		}

		if (!UtilJava.isNumeroNuloOuZero(devolucaoCalculoCompleto.getDevolucao().getPercentualDevolucao())) {
			this.setPercentualOpcao(devolucaoCalculoCompleto.getDevolucao().getPercentualDevolucao());
		}

		if (devolucaoCalculoCompleto.getDevolucao().getDataRequerimento() == null) {
			this.calculoDevolucaoTela.setDataRequerimento(devolucaoCalculoCompleto.getDevolucao().getDataRequerimento());
		}

		if (!UtilJava.isNumeroNuloOuZero(devolucaoCalculoCompleto.getDevolucao().getNumeroTotalParcelas())) {
			this.setNumTotalParcelas(devolucaoCalculoCompleto.getDevolucao().getNumeroTotalParcelas());
		}

		this.devolucaoManual = devolucaoCalculoCompleto.getDevolucao().getIndicadorDevManual().equalsIgnoreCase("S");

		pesquisarValorCotaPlano(devolucaoCalculoCompleto.getDevolucao().getDataCota());

		calcularTotalSaldoResgatavel(this.devolucaoCalculoCompleto.getListaContaDevolucao());

		expandirDetalheParcelaDevolucao(this.devolucaoCalculoCompleto.getListaParcelaContaDevolucao());

		// Montar lista de saldos de Ficha
		if (this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO() == null || this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO().getParticipantePlano() == null) {
			this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>();
		} else {
			this.listaSaldoHFPDevolucaoDTO = new ArrayList<SaldoHFPDevolucaoDTO>(montarListaSaldoHFPDevolucaoDTO(this.devolucaoCalculoCompleto.getSaldoHistoricoFinanceiroPagoDTO()));
		}

		// Montar informações dos gráficos
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaSaldoHFPDevolucaoDTO)) {
			this.preencherInformacoesGraficas(this.listaSaldoHFPDevolucaoDTO, this.devolucaoCalculoCompleto.getListaContaDevolucao());
		}

		this.devolucaoManual = true;

		return FW_CALCULO_DEVOLUCAO;
	}

	/**
	 * Método encarregado de retorna msn de acordo com a tela de retorno.
	 * 
	 * @author BBPF0170 - Magson DiAS
	 * @since 17/05/2017
	 * @param {@link String}
	 */

	public void paginaRetornoMessage(String msn) {
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, new FacesMessage("Consultar", "Tela de consulta: " + msn));
		PrimeFaces.current().ajax().update(":pgPesquisa");
	}

	public boolean mostrarBotaoSumula(Devolucao devolucao) {
		if (devolucao.getSituacaoDevolucao().getCodigo() == 1L) {
			if (devolucao.getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorTipoDevolucao()
					.equalsIgnoreCase("R")) {
				List<GrupoRecebimentoDevolucao> listaGrupo = new ArrayList<>();
				listaGrupo = this.grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorDevolucao(devolucao);

				if (listaGrupo.size() > 0) {
					return true;
				} else {
					return false;
				}
			} else {
				List<DetalhePortabilidadeDevolucao> listaDetalhePortabilidade = new ArrayList<>();
				listaDetalhePortabilidade = detalhePortabilidadeDevolucaoBO
						.pesquisarDetalhePortabilidadeDevolucaoPorDevolucao(devolucao);

				if (listaDetalhePortabilidade.size() > 0) {
					return true;
				} else {
					return false;
				}
			}
		}

		return true;
	}

	public double buscarValorEmprestimo(Participante participante, Date data) {
		try {
			String token = this.autenticarViaToken();

			if (token != null) {
				ParticipanteEmprestimoDTO participanteEmprestimoDTO = new ParticipanteEmprestimoDTO().builder().codigoParticipante(participante.getCodigo()).dataCalculo(
						UtilJava.formataDataPorPadrao(data, "dd/MM/yyyy")).build();

				System.setProperty("jsse.enableSNIExtension", "false");
				RestTemplate restTemplate = new RestTemplate();
				List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
				interceptors.add(new HeaderRequestInterceptor("AuthToken", token));
				restTemplate.setInterceptors(interceptors);

				String url = this.urlAmbiente + "emprestimo-service/emprestimo/consultarSaldoDevedorEmprestimo/";

				RetornoSaldoDevedorEmprestimoDTO saldoDevedor = restTemplate.postForObject(url, participanteEmprestimoDTO, RetornoSaldoDevedorEmprestimoDTO.class);

				if (saldoDevedor.getSaldoDevedor() != 0D) {
					this.setValorEmprestimoRecuperado(true);
					return saldoDevedor.getSaldoDevedor();
				} else
					return 0D;
			} else {
				return 0D;
			}
		} catch (Exception e) {
			log.error("Erro ao recuperar Saldo Devedor:" + e);
			return 0D;
		}
	}

	private String autenticarViaToken() {
		try {
			UsuarioLoginDTO usuarioLoginDTO = UsuarioLoginDTO.builder().login("BBPENGRENAGEM").senha("12345678").build();

			System.setProperty("jsse.enableSNIExtension", "false");
			RestTemplate restTemplate = new RestTemplate();
			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();

			restTemplate.setInterceptors(interceptors);
			String url = this.urlAmbiente + "login-service/login/autenticarApi/";

			RetornoLoginDTO retorno = restTemplate.postForObject(url, usuarioLoginDTO, RetornoLoginDTO.class);

			if (retorno.isUsuarioAutenticado())
				return retorno.getToken();
			else
				return null;

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Erro ao efetuar login.");
		}
	}

	public void buscarValorEmprestimo() {
		if (this.participante != null && this.dataFuturaPagamento != null) {
			this.valorEmprestimo = this.buscarValorEmprestimo(this.participante, this.dataFuturaPagamento);
		}
	}

	public void mostrarPesquisaValorEmprestimo() {
		this.dataFuturaPagamento = null;
		PrimeFaces.current().ajax().update(":frmPesquisaValorEmprestimo:dataFuturaPagamento");
		PrimeFaces.current().executeScript("PF('dlgValorEmprestimo').show()");
	}

	public void alterarIndicadorFormaPagamento() {
		if (!cadastrarNovaDevolucao && this.indicadorFormaPagamentoContribCarencia != null) {
			if (!this.devolucaoCalculoCompleto.getDevolucao().getIndicadorFormaPagtoContribCarencia().equalsIgnoreCase(this.indicadorFormaPagamentoContribCarencia)) {
				PrimeFaces.current().executeScript("PF('dlgIndicadorPagamento').show()");
			}
		}
	}

	public String salvarIndicadorPagamentoDevolucao() {
		try {
			Devolucao devObj = this.devolucaoBO.pesquisarDevolucaoPorCodigo(this.devolucaoCalculoCompleto.getDevolucao().getCodigo());
			devObj.setIndicadorFormaPagtoContribCarencia(this.indicadorFormaPagamentoContribCarencia);

			AnotacaoDevolucao anotacaoDevolucao = new AnotacaoDevolucao(devObj, new Date(), "Alterado o Indicador de Pagamento para "
					+ (this.indicadorFormaPagamentoContribCarencia.equalsIgnoreCase("F") ? "Final" : "Vencimento"), new Date(), this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

			this.devolucaoBO.salvarDevolucao(devObj);
			this.anotacaoDevolucaoBO.salvarAnotacaoDevolucao(anotacaoDevolucao);

			Mensagens.addMsgInfo("Indicador de pagamento alterado com sucesso!");
			return mostrarResumoDevolucao(devObj);
		} catch (Exception e) {
			Mensagens.addMsgErro("Erro ao Salvar processo de devolução.");
			return null;
		}
	}

	public void relatorioFichaFinanceira() {
		try {
			GregorianCalendar gegorianCalendar = new GregorianCalendar();
			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date dataInicio = (Date) formatter.parse("01/01/1900");
			Date dataFim = gegorianCalendar.getTime();

			ParticipantePlano participantePlano = this.participantePlanoBO.consultparPorParticipanteEPlano(this.participante, this.planoPrevidencia);

			List<ValorCotaPlano> listaCotas = this.valorCotaPlanoBO.listarCotaPlanoPorEmpresaPlanoPerfil(this.participante.getEntidadeParticipante(), this.planoPrevidencia, participantePlano
					.getListaModalidadePerfil().get(0).getChavePrimaria().getPerfilInvestimento(), dataInicio, dataFim);

			ParmSistem parmSistem = this.parmSistemBO.retornoParmSistem();

			SimpleDateFormat dataFormatada = new SimpleDateFormat("dd/MM/yyyy");

			String p_num_seq_fundo_prevd = participante.getEntidadeParticipante().getChavePrimaria().getCodigoFundoPrevidencia().toString();
			String p_num_seq_entid_partic = participante.getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante().toString();
			String p_num_seq_partic = participante.getCodigo().toString();
			String p_dt_posic_cartei = dataFormatada.format(listaCotas.get(0).getChavePrimaria().getDataPosicaoCota());
			String p_dt_incial = dataFormatada.format(dataInicio);
			String p_dt_final = dataFormatada.format(dataFim);

			String url = "http://" + parmSistem.getNomSrvApl() + ":" + parmSistem.getNumPortSrvApl() + "/reports/rwservlet?report=CCOPR554.rep" + "&userid=" + parmSistem.getNomeUsuarioRelatoriRep()
					+ "/" + Criptografia.descriptografar(parmSistem.getPassUsuarioRelatorioRep()) + "&server=" + parmSistem.getNomServdoRelat() + "&desformat=pdf&destype=cache&p_num_seq_fundo_prevd="
					+ p_num_seq_fundo_prevd + "&p_num_seq_entid_partic=" + p_num_seq_entid_partic + "&p_num_seq_partic=" + p_num_seq_partic + "&p_dt_posic_cartei=" + p_dt_posic_cartei
					+ "&p_dt_incial=" + p_dt_incial + "&p_dt_final=" + p_dt_final;

			System.out.println(url);

			relatorioUtil.baixarArquivo(url, "Ficha Financeira.pdf", "pdf");

		} catch (Exception e) {
			Mensagens.addMsgErro("Erro ao recuperar a ficha financeira do participante");
		}

	}

	public void onColumnToggle(ToggleEvent e) {
		this.listaControl.set((Integer) e.getData(), e.getVisibility() == Visibility.VISIBLE);
	}

	// Getters And Setters

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public boolean isPatrocinadoraEditavel() {
		return patrocinadoraEditavel;
	}

	public void setPatrocinadoraEditavel(boolean patrocinadoraEditavel) {
		this.patrocinadoraEditavel = patrocinadoraEditavel;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public boolean isCadastrarNovaDevolucao() {
		return cadastrarNovaDevolucao;
	}

	public void setCadastrarNovaDevolucao(boolean cadastrarNovaDevolucao) {
		this.cadastrarNovaDevolucao = cadastrarNovaDevolucao;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public Integer getNumTotalParcelas() {
		return numTotalParcelas;
	}

	public void setNumTotalParcelas(Integer numTotalParcelas) {
		this.numTotalParcelas = numTotalParcelas;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public ValorCotaPlano getValorCotaPlano() {
		return valorCotaPlano;
	}

	public void setValorCotaPlano(ValorCotaPlano valorCotaPlano) {
		this.valorCotaPlano = valorCotaPlano;
	}

	public List<SelectItem> getListaIndicadorFormaPagamentoContribCarencia() {
		return listaIndicadorFormaPagamentoContribCarencia;
	}

	public void setListaIndicadorFormaPagamentoContribCarencia(List<SelectItem> listaIndicadorFormaPagamentoContribCarencia) {
		this.listaIndicadorFormaPagamentoContribCarencia = listaIndicadorFormaPagamentoContribCarencia;
	}

	public String getIndicadorFormaPagamentoContribCarencia() {
		return indicadorFormaPagamentoContribCarencia;
	}

	public void setIndicadorFormaPagamentoContribCarencia(String indicadorFormaPagamentoContribCarencia) {
		this.indicadorFormaPagamentoContribCarencia = indicadorFormaPagamentoContribCarencia;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public DevolucaoCompletoDTO getDevolucaoCalculoCompleto() {
		return devolucaoCalculoCompleto;
	}

	public void setDevolucaoCalculoCompleto(DevolucaoCompletoDTO devolucaoCalculoCompleto) {
		this.devolucaoCalculoCompleto = devolucaoCalculoCompleto;
	}

	public boolean isProcessoCalculoConcluido() {
		return processoCalculoConcluido;
	}

	public void setProcessoCalculoConcluido(boolean processoCalculoConcluido) {
		this.processoCalculoConcluido = processoCalculoConcluido;
	}

	public CalculoDevolucaoBaseVisao getCalculoDevolucaoTela() {
		if (calculoDevolucaoTela == null) {
			calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();
		}

		return calculoDevolucaoTela;
	}

	public void setCalculoDevolucaoTela(CalculoDevolucaoBaseVisao calculoDevolucaoTela) {
		this.calculoDevolucaoTela = calculoDevolucaoTela;
	}

	public int getColunaOrdenadaContasDevolucao() {
		return colunaOrdenadaContasDevolucao;
	}

	public void setColunaOrdenadaContasDevolucao(int colunaOrdenadaContasDevolucao) {
		this.colunaOrdenadaContasDevolucao = colunaOrdenadaContasDevolucao;
	}

	public int getColunaOrdenadaParcelasContasDevolucao() {
		return colunaOrdenadaParcelasContasDevolucao;
	}

	public void setColunaOrdenadaParcelasContasDevolucao(int colunaOrdenadaParcelasContasDevolucao) {
		this.colunaOrdenadaParcelasContasDevolucao = colunaOrdenadaParcelasContasDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isProcessoSalvo() {
		return processoSalvo;
	}

	public void setProcessoSalvo(boolean processoSalvo) {
		this.processoSalvo = processoSalvo;
	}

	/*
	 * public List<ParcelaContaDevolucaoDetalheImposto>
	 * getListaParcelaContaDevolucaoDetalheImposto() { return
	 * listaParcelaContaDevolucaoDetalheImposto; }
	 * 
	 * public void setListaParcelaContaDevolucaoDetalheImposto(List<
	 * ParcelaContaDevolucaoDetalheImposto>
	 * listaParcelaContaDevolucaoDetalheImposto) {
	 * this.listaParcelaContaDevolucaoDetalheImposto =
	 * listaParcelaContaDevolucaoDetalheImposto; }
	 */
	public AnotacaoDevolucao getAnotacaoDevolucao() {
		if (this.anotacaoDevolucao == null) {
			this.anotacaoDevolucao = new AnotacaoDevolucao();
		}
		return anotacaoDevolucao;
	}

	public void abrirPopupDocumentosPendentes() {
		//PrimeFaces.current().executeScript("PF('documentosDevolucaoDialog').show();");
		Map<String, Object> options = new HashMap<String, Object>();
		options.put("resizable", false);
		options.put("draggable", false);
		options.put("modal", true);
		PrimeFaces.current().dialog().openDynamic("documentosDevolucaoDialog", options, null);
	}

	public void setAnotacaoDevolucao(AnotacaoDevolucao anotacaoDevolucao) {
		this.anotacaoDevolucao = anotacaoDevolucao;
	}

	public String getUrlRetorno() {
		return urlRetorno;
	}

	public void setUrlRetorno(String urlRetorno) {
		this.urlRetorno = urlRetorno;
	}

	public String getVariavelRetorno() {
		return variavelRetorno;
	}

	public void setVariavelRetorno(String variavelRetorno) {
		this.variavelRetorno = variavelRetorno;
	}

	public double getPercentualOpcao() {
		return percentualOpcao;
	}

	public void setPercentualOpcao(double percentualOpcao) {
		this.percentualOpcao = percentualOpcao;
	}

	public boolean isAlteraPercentual() {
		return alteraPercentual;
	}

	public void setAlteraPercentual(boolean alteraPercentual) {
		this.alteraPercentual = alteraPercentual;
	}

	public boolean isPermiteSalvarProcessoCalculado() {
		return permiteSalvarProcessoCalculado;
	}

	public void setPermiteSalvarProcessoCalculado(boolean permiteSalvarProcessoCalculado) {
		this.permiteSalvarProcessoCalculado = permiteSalvarProcessoCalculado;
	}

	public String getMensagemAntesSalvar() {
		return mensagemAntesSalvar;
	}

	public void setMensagemAntesSalvar(String mensagemAntesSalvar) {
		this.mensagemAntesSalvar = mensagemAntesSalvar;
	}

	public boolean isPossueEmprestimo() {
		return possueEmprestimo;
	}

	public void setPossueEmprestimo(boolean possueEmprestimo) {
		this.possueEmprestimo = possueEmprestimo;
	}

	public double getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(double valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public List<DocumentoDevolucaoVisaoItem> getListaDocumentoDevolucaoVisaoItem() {
		return listaDocumentoDevolucaoVisaoItem;
	}

	public void setListaDocumentoDevolucaoVisaoItem(List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem) {
		this.listaDocumentoDevolucaoVisaoItem = listaDocumentoDevolucaoVisaoItem;
	}

	public boolean isPossuiDocumentoDevolucao() {
		return possuiDocumentoDevolucao;
	}

	public void setPossuiDocumentoDevolucao(boolean possuiDocumentoDevolucao) {
		this.possuiDocumentoDevolucao = possuiDocumentoDevolucao;
	}

	public boolean isPossuiDocumentoDevolucaoPendente() {
		return possuiDocumentoDevolucaoPendente;
	}

	public void setPossuiDocumentoDevolucaoPendente(boolean possuiDocumentoDevolucaoPendente) {
		this.possuiDocumentoDevolucaoPendente = possuiDocumentoDevolucaoPendente;
	}

	public boolean isChamaPendenciasAberturaTela() {
		return chamaPendenciasAberturaTela;
	}

	public void setChamaPendenciasAberturaTela(boolean chamaPendenciasAberturaTela) {
		this.chamaPendenciasAberturaTela = chamaPendenciasAberturaTela;
	}

	public String getDescricaoPendencias() {
		return descricaoPendencias;
	}

	public void setDescricaoPendencias(String descricaoPendencias) {
		this.descricaoPendencias = descricaoPendencias;
	}

	public Double getTotalSaldoReserva() {
		return totalSaldoReserva;
	}

	public void setTotalSaldoReserva(Double totalSaldoReserva) {
		this.totalSaldoReserva = totalSaldoReserva;
	}

	public boolean isPossuiAcessoConsulta() {
		return possuiAcessoConsulta;
	}

	public void setPossuiAcessoConsulta(boolean possuiAcessoConsulta) {
		this.possuiAcessoConsulta = possuiAcessoConsulta;
	}

	public boolean isDevolucaoManual() {
		return devolucaoManual;
	}

	public void setDevolucaoManual(boolean devolucaoManual) {
		this.devolucaoManual = devolucaoManual;
	}

	public List<SituacaoDevolucao> getListaSituacaoDevolucao() {
		return listaSituacaoDevolucao;
	}

	public void setListaSituacaoDevolucao(List<SituacaoDevolucao> listaSituacaoDevolucao) {
		this.listaSituacaoDevolucao = listaSituacaoDevolucao;
	}

	public SituacaoDevolucao getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public Date getDataRequerimentoAte() {
		return dataRequerimentoAte;
	}

	public void setDataRequerimentoAte(Date dataRequerimentoAte) {
		this.dataRequerimentoAte = dataRequerimentoAte;
	}

	public Date getDataRequerimentoDesde() {
		return dataRequerimentoDesde;
	}

	public void setDataRequerimentoDesde(Date dataRequerimentoDesde) {
		this.dataRequerimentoDesde = dataRequerimentoDesde;
	}

	public boolean isPesquisaTotal() {
		if (this.entidadeParticipante != null || this.planoPrevidencia != null || this.participante.getCodigo() != null || this.tipoDevolucao != null || this.situacaoDevolucao != null
				|| this.dataRequerimentoDesde != null || this.dataRequerimentoAte != null || this.cpfPesquisa != null || this.matriculaPesquisa != null) {
			this.setPesquisaTotal(false);
		}

		return pesquisaTotal;
	}

	public void setPesquisaTotal(boolean pesquisaTotal) {
		this.pesquisaTotal = pesquisaTotal;
	}

	public List<SaldoHFPDevolucaoDTO> getListaSaldoHFPDevolucaoDTO() {
		return listaSaldoHFPDevolucaoDTO;
	}

	public void setListaSaldoHFPDevolucaoDTO(List<SaldoHFPDevolucaoDTO> listaSaldoHFPDevolucaoDTO) {
		this.listaSaldoHFPDevolucaoDTO = listaSaldoHFPDevolucaoDTO;
	}

	public boolean isMostrarGraficos() {
		return mostrarGraficos;
	}

	public void setMostrarGraficos(boolean mostrarGraficos) {
		this.mostrarGraficos = mostrarGraficos;
	}

	public PieChartModel getGraficoParticipante() {
		return graficoParticipante;
	}

	public void setGraficoParticipante(PieChartModel graficoParticipante) {
		this.graficoParticipante = graficoParticipante;
	}

	public PieChartModel getGraficoPatrocinadora() {
		return graficoPatrocinadora;
	}

	public void setGraficoPatrocinadora(PieChartModel graficoPatrocinadora) {
		this.graficoPatrocinadora = graficoPatrocinadora;
	}

	public PieChartModel getGraficoTotal() {
		return graficoTotal;
	}

	public void setGraficoTotal(PieChartModel graficoTotal) {
		this.graficoTotal = graficoTotal;
	}

	public boolean isProcessoCalculoConcluidoPago() {
		return processoCalculoConcluidoPago;
	}

	public void setProcessoCalculoConcluidoPago(boolean processoCalculoConcluidoPago) {
		this.processoCalculoConcluidoPago = processoCalculoConcluidoPago;
	}

	public String getCpfPesquisa() {
		return cpfPesquisa;
	}

	public void setCpfPesquisa(String cpfPesquisa) {
		this.cpfPesquisa = cpfPesquisa;
	}

	public String getMatriculaPesquisa() {
		return matriculaPesquisa;
	}

	public void setMatriculaPesquisa(String matriculaPesquisa) {
		this.matriculaPesquisa = matriculaPesquisa;
	}

	public List<Participante> getListaParticipantePesquisa() {
		return listaParticipantePesquisa;
	}

	public void setListaParticipantePesquisa(List<Participante> listaParticipantePesquisa) {
		this.listaParticipantePesquisa = listaParticipantePesquisa;
	}

	public String getUrlCloudDocs() {
		return urlCloudDocs;
	}

	public boolean isValorEmprestimoRecuperado() {
		return valorEmprestimoRecuperado;
	}

	public void setValorEmprestimoRecuperado(boolean valorEmprestimoRecuperado) {
		this.valorEmprestimoRecuperado = valorEmprestimoRecuperado;
	}

	public Date getDataFuturaPagamento() {
		return dataFuturaPagamento;
	}

	public void setDataFuturaPagamento(Date dataFuturaPagamento) {
		this.dataFuturaPagamento = dataFuturaPagamento;
	}

	public boolean isIndicadorPagamentoEditavel() {
		if (this.cadastrarNovaDevolucao) {
			indicadorPagamentoEditavel = true;
		} else {
			if (SituacaoDevolucaoEnum.EM_PARCELAMENTO.getCodigo() == devolucaoCalculoCompleto.getDevolucao().getSituacaoDevolucao().getCodigo()) {
				indicadorPagamentoEditavel = true;
			} else {
				indicadorPagamentoEditavel = false;
			}

		}

		return indicadorPagamentoEditavel;
	}

	public void setIndicadorPagamentoEditavel(boolean indicadorPagamentoEditavel) {
		this.indicadorPagamentoEditavel = indicadorPagamentoEditavel;
	}

	public List<Boolean> getListaControl() {
		return listaControl;
	}

	public void setListaControl(List<Boolean> listaControl) {
		this.listaControl = listaControl;
	}

	public Devolucao getDevolucaoBuscarDeferimento() {
		return devolucaoBuscarDeferimento;
	}

	public void setDevolucaoBuscarDeferimento(Devolucao devolucaoBuscarDeferimento) {

		if (devolucaoBuscarDeferimento != null) {
			this.listaDeferimentoDevolucao = new ArrayList<AprovacaoAlcadaDTO>(this.movimentoAlcadaBO.listarAprovacaoDeferimentoSolicitacao(devolucaoBuscarDeferimento.getMovimentoAlcada()));
		}

		this.devolucaoBuscarDeferimento = devolucaoBuscarDeferimento;
	}

	public List<AprovacaoAlcadaDTO> getListaDeferimentoDevolucao() {
		return listaDeferimentoDevolucao;
	}

	public void setListaDeferimentoDevolucao(List<AprovacaoAlcadaDTO> listaDeferimentoDevolucao) {
		this.listaDeferimentoDevolucao = listaDeferimentoDevolucao;
	}

	public boolean isPatronicinadoraBasa() {
		return patronicinadoraBasa;
	}

	public void setPatronicinadoraBasa(boolean patronicinadoraBasa) {
		this.patronicinadoraBasa = patronicinadoraBasa;
	}

	public SaldoParticipanteIsento getSaldoParticipanteIsento() {
		return saldoParticipanteIsento;
	}

	public void setSaldoParticipanteIsento(SaldoParticipanteIsento saldoParticipanteIsento) {
		this.saldoParticipanteIsento = saldoParticipanteIsento;
	}

	public String relatorioProcessoFichaFinanceira(CalcularProcessoDevolucaoRequest request, DevolucaoCompletoDTO devolucaoCalculoCompleto) {
		String fichaFinanceiraBase64 = "";
		String url = "";
		try {
			GregorianCalendar gegorianCalendar = new GregorianCalendar();
			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date dataInicio = (Date) formatter.parse("01/01/1900");
			Date dataFim = gegorianCalendar.getTime();
			String dataCotaPlanoString = request.getListaValorCotaPlano().get(0).getMonthValue() + "/" + request.getListaValorCotaPlano().get(0).getDayOfMonth() + "/"
					+ request.getListaValorCotaPlano().get(0).getYear();
			Date dataCota = (Date) formatter.parse(dataCotaPlanoString);

			this.participante = new Participante(request.getCodigoParticipante());
			this.planoPrevidencia = new PlanoPrevidencia(request.getCodigoPlanoPrevidencia());
			ParticipantePlanoProcessoDAO participantePlanoProcessoDAO = new ParticipantePlanoProcessoDAO();

			SimpleDateFormat dataFormatada = new SimpleDateFormat("dd/MM/yyyy");

			String p_num_seq_fundo_prevd = request.getCodFundPrev().toString();//participante.getEntidadeParticipante().getChavePrimaria().getCodigoFundoPrevidencia().toString();
			String p_num_seq_entid_partic = request.getCodigoEntidadeParticipante().toString();
			String p_num_seq_partic = request.getCodigoParticipante().toString();

			String p_dt_incial = dataFormatada.format(dataInicio);
			String p_dt_final = dataFormatada.format(dataFim);
			String p_dt_posic_cartei = dataFormatada.format(dataCota);

			url = "http://" + request.getParamSistema().getNomeServAplBBP() + ":" + request.getParamSistema().getNumPortaServAplBBP() + "/reports/rwservlet?report=CCOPR554.rep" + "&userid="
					+ request.getParamSistema().getNomeUsuarioRelRep() + "/" + Criptografia.descriptografar(request.getParamSistema().getPassUsuarioRelRep()) + "&server="
					+ request.getParamSistema().getNomeServRelat() + "&desformat=pdf&destype=cache&p_num_seq_fundo_prevd=" + p_num_seq_fundo_prevd + "&p_num_seq_entid_partic="
					+ p_num_seq_entid_partic + "&p_num_seq_partic=" + p_num_seq_partic + "&p_dt_posic_cartei=" + p_dt_posic_cartei + "&p_dt_incial=" + p_dt_incial + "&p_dt_final=" + p_dt_final;

		} catch (Exception e) {
			System.out.println("=========    ERRO: " + e.getMessage());
		}
		return url;
	}

	public SumulaDevolucaoDTO mostrarRelatorioSumulaPortal(DevolucaoCompletoDTO devolucaoCalculoCompleto, Devolucao devolucao, CalcularProcessoDevolucaoRequest request,
			List<DetalhePortabilidadeDevolucao> detalhePortabilidadeDevolucaoPortal) {
		try {
			SumulaDevolucaoDTO sumulaDevolucaoDTO = new SumulaDevolucaoDTO();

			ProcessoSumulaDevolucaoBO processoSumulaDevolucaoBO1 = new ProcessoSumulaDevolucaoBO();

			sumulaDevolucaoDTO = processoSumulaDevolucaoBO1.montarSumulaDevolucao(devolucaoCalculoCompleto, devolucao, request, detalhePortabilidadeDevolucaoPortal);
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			parametros.put("listaDocumentos", sumulaDevolucaoDTO.getRecebedoresResgateSumula());
			parametros.put("recebedoresResgateSumula", sumulaDevolucaoDTO.getRecebedoresResgateSumula());

			List<SumulaDevolucaoDTO> relatorioSumulaDevolucao = new ArrayList<SumulaDevolucaoDTO>();
			relatorioSumulaDevolucao.add(sumulaDevolucaoDTO);
			RelatorioUtil relatorioUtil1 = new RelatorioUtil();

			return sumulaDevolucaoDTO;
		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			return null;
		} catch (Exception ex) {
			log.error(ex.getMessage());
			//			Mensagens.addMsgErro(ex.getMessage());
			return null;
		}
	}
}
