package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.SituacaoParticipantePlano;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   28/11/2016
 * Classe de persistência para tabela TIPO_DEVOLUCAO.
 */
@Entity
@Table(name = "TIPO_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "TipoDevolucao.findAll", query = "SELECT q FROM TipoDevolucao q")
public class TipoDevolucao implements BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TIPO_DEVOLUCAO_GER", sequenceName = "S_TD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TIPO_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_TIP_DEV")
	private Long codigo;

	@Column(name = "NOM_TIP_DEV")
	private String nome;

	@Column(name = "NUM_MES_CAR_PRO_DEV")
	private int mesesCarenciaProxDevolucao;

	@Column(name = "PER_MIN_TIP_DEV")
	private Double minimoPercentualDevolucao;

	@Column(name = "PER_MAX_TIP_DEV")
	private Double maximoPercentualDevolucao;

	@Column(name = "IND_NES_DES")
	private String indicadorNecessidadeDesligamento;

	@Column(name = "IND_TIP_DEV")
	private String indicadorTipoDevolucao;

	@Column(name = "IND_FORMA_DEV")
	private String indicadorFormaDevolucao;

	@Column(name = "IND_REC")
	private String indicadorTipoRecebedor;

	@Transient
	private String descricaoIndicadorNecessidadeDesligamento;

	@Transient
	private String descricaoIndicadorTipoDevolucao;

	@Transient
	private String descricaoIndicadorFormaDevolucao;

	@Transient
	private String descricaoIndicadorTipoRecebedor;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV_PRO")
	private RubricaDevolucao rubricaDevolucaoProgressivo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV_REG")
	private RubricaDevolucao rubricaDevolucaoRegressivo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV_POR_FEC_PRO")
	private RubricaDevolucao rubricaDevolucaoPortabilidadeFecProgressivo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV_POR_ABE_PRO")
	private RubricaDevolucao rubricaDevolucaoPortabilidadeAbertaProgressivo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV_POR_FEC_REG")
	private RubricaDevolucao rubricaDevolucaoPortabilidadeFecRegressivo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV_POR_ABE_REG")
	private RubricaDevolucao rubricaDevolucaoPortabilidadeAbertaRegressivo;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_REV")
	private OperacaoInterna operacaoInternaReversao;

	@ManyToOne
	@JoinColumn(name = "COD_SITUAC_PAR")
	private SituacaoParticipantePlano situacaoParticipantePlanoParcelamento;

	@ManyToOne
	@JoinColumn(name = "COD_SITUAC_ENC")
	private SituacaoParticipantePlano situacaoParticipantePlanoEncerramento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Fetch(FetchMode.SUBSELECT)
	@ManyToMany(mappedBy = "tipoDevolucao", targetEntity = TipoDevolucaoMotDesligamento.class, fetch = FetchType.EAGER)
	private List<TipoDevolucaoMotDesligamento> listaTipoDevolucaoMotDesligamento;

	@Transient
	private boolean proprioParticipante;

	@Transient
	private boolean recebedorTerceiro;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getMesesCarenciaProxDevolucao() {
		return mesesCarenciaProxDevolucao;
	}

	public void setMesesCarenciaProxDevolucao(int mesesCarenciaProxDevolucao) {
		this.mesesCarenciaProxDevolucao = mesesCarenciaProxDevolucao;
	}

	public Double getMaximoPercentualDevolucao() {
		return maximoPercentualDevolucao;
	}

	public void setMaximoPercentualDevolucao(Double maximoPercentualDevolucao) {
		this.maximoPercentualDevolucao = maximoPercentualDevolucao;
	}

	public Double getMinimoPercentualDevolucao() {
		return minimoPercentualDevolucao;
	}

	public void setMinimoPercentualDevolucao(Double minimoPercentualDevolucao) {
		this.minimoPercentualDevolucao = minimoPercentualDevolucao;
	}

	public String getIndicadorNecessidadeDesligamento() {
		return indicadorNecessidadeDesligamento;
	}

	public void setIndicadorNecessidadeDesligamento(String indicadorNecessidadeDesligamento) {
		this.indicadorNecessidadeDesligamento = indicadorNecessidadeDesligamento;
	}

	public String getIndicadorTipoDevolucao() {
		return indicadorTipoDevolucao;
	}

	public void setIndicadorTipoDevolucao(String indicadorTipoDevolucao) {
		this.indicadorTipoDevolucao = indicadorTipoDevolucao;
	}

	public String getIndicadorFormaDevolucao() {
		return indicadorFormaDevolucao;
	}

	public void setIndicadorFormaDevolucao(String indicadorFormaDevolucao) {
		this.indicadorFormaDevolucao = indicadorFormaDevolucao;
	}

	public String getIndicadorTipoRecebedor() {
		return indicadorTipoRecebedor;
	}

	public void setIndicadorTipoRecebedor(String indicadorTipoRecebedor) {
		this.indicadorTipoRecebedor = indicadorTipoRecebedor;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public List<TipoDevolucaoMotDesligamento> getListaTipoDevolucaoMotDesligamento() {
		return listaTipoDevolucaoMotDesligamento;
	}

	public void setListaTipoDevolucaoMotDesligamento(List<TipoDevolucaoMotDesligamento> listaTipoDevolucaoMotDesligamento) {
		this.listaTipoDevolucaoMotDesligamento = listaTipoDevolucaoMotDesligamento;
	}

	public RubricaDevolucao getRubricaDevolucaoProgressivo() {
		return rubricaDevolucaoProgressivo;
	}

	public void setRubricaDevolucaoProgressivo(RubricaDevolucao rubricaDevolucaoProgressivo) {
		this.rubricaDevolucaoProgressivo = rubricaDevolucaoProgressivo;
	}

	public RubricaDevolucao getRubricaDevolucaoRegressivo() {
		return rubricaDevolucaoRegressivo;
	}

	public void setRubricaDevolucaoRegressivo(RubricaDevolucao rubricaDevolucaoRegressivo) {
		this.rubricaDevolucaoRegressivo = rubricaDevolucaoRegressivo;
	}

	public RubricaDevolucao getRubricaDevolucaoPortabilidadeFecProgressivo() {
		return rubricaDevolucaoPortabilidadeFecProgressivo;
	}

	public void setRubricaDevolucaoPortabilidadeFecProgressivo(RubricaDevolucao rubricaDevolucaoPortabilidadeFecProgressivo) {
		this.rubricaDevolucaoPortabilidadeFecProgressivo = rubricaDevolucaoPortabilidadeFecProgressivo;
	}

	public RubricaDevolucao getRubricaDevolucaoPortabilidadeAbertaProgressivo() {
		return rubricaDevolucaoPortabilidadeAbertaProgressivo;
	}

	public void setRubricaDevolucaoPortabilidadeAbertaProgressivo(RubricaDevolucao rubricaDevolucaoPortabilidadeAbertaProgressivo) {
		this.rubricaDevolucaoPortabilidadeAbertaProgressivo = rubricaDevolucaoPortabilidadeAbertaProgressivo;
	}

	public RubricaDevolucao getRubricaDevolucaoPortabilidadeFecRegressivo() {
		return rubricaDevolucaoPortabilidadeFecRegressivo;
	}

	public void setRubricaDevolucaoPortabilidadeFecRegressivo(RubricaDevolucao rubricaDevolucaoPortabilidadeFecRegressivo) {
		this.rubricaDevolucaoPortabilidadeFecRegressivo = rubricaDevolucaoPortabilidadeFecRegressivo;
	}

	public RubricaDevolucao getRubricaDevolucaoPortabilidadeAbertaRegressivo() {
		return rubricaDevolucaoPortabilidadeAbertaRegressivo;
	}

	public void setRubricaDevolucaoPortabilidadeAbertaRegressivo(RubricaDevolucao rubricaDevolucaoPortabilidadeAbertaRegressivo) {
		this.rubricaDevolucaoPortabilidadeAbertaRegressivo = rubricaDevolucaoPortabilidadeAbertaRegressivo;
	}

	public OperacaoInterna getOperacaoInternaReversao() {
		return operacaoInternaReversao;
	}

	public void setOperacaoInternaReversao(OperacaoInterna operacaoInternaReversao) {
		this.operacaoInternaReversao = operacaoInternaReversao;
	}

	public boolean isProprioParticipante() {
		return this.indicadorTipoRecebedor.equals("P");
	}

	public void setProprioParticipante(boolean proprioParticipante) {
		this.proprioParticipante = proprioParticipante;
	}

	public boolean isRecebedorTerceiro() {
		return this.indicadorTipoRecebedor.equals("T");
	}

	public void setRecebedorTerceiro(boolean recebedorTerceiro) {
		this.recebedorTerceiro = recebedorTerceiro;
	}

	public void setMinimoPercentualDevolucao(double minimoPercentualDevolucao) {
		this.minimoPercentualDevolucao = minimoPercentualDevolucao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoDevolucao other = (TipoDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TipoDevolucao [codigo=" + codigo + ", nome=" + nome + ", mesesCarenciaProxDevolucao=" + mesesCarenciaProxDevolucao + ", minimoPercentualDevolucao=" + minimoPercentualDevolucao
				+ ", maximoPercentualDevolucao=" + maximoPercentualDevolucao + ", indicadorNecessidadeDesligamento=" + indicadorNecessidadeDesligamento + ", indicadorTipoDevolucao="
				+ indicadorTipoDevolucao + ", indicadorFormaDevolucao=" + indicadorFormaDevolucao + ", indicadorTipoRecebedor=" + indicadorTipoRecebedor
				+ ", descricaoIndicadorNecessidadeDesligamento=" + descricaoIndicadorNecessidadeDesligamento + ", descricaoIndicadorTipoDevolucao=" + descricaoIndicadorTipoDevolucao
				+ ", descricaoIndicadorFormaDevolucao=" + descricaoIndicadorFormaDevolucao + ", descricaoIndicadorTipoRecebedor=" + descricaoIndicadorTipoRecebedor + ", rubricaDevolucaoProgressivo="
				+ rubricaDevolucaoProgressivo + ", rubricaDevolucaoRegressivo=" + rubricaDevolucaoRegressivo + ", rubricaDevolucaoPortabilidadeFecProgressivo="
				+ rubricaDevolucaoPortabilidadeFecProgressivo + ", rubricaDevolucaoPortabilidadeAbertaProgressivo=" + rubricaDevolucaoPortabilidadeAbertaProgressivo
				+ ", rubricaDevolucaoPortabilidadeFecRegressivo=" + rubricaDevolucaoPortabilidadeFecRegressivo + ", rubricaDevolucaoPortabilidadeAbertaRegressivo="
				+ rubricaDevolucaoPortabilidadeAbertaRegressivo + ", operacaoInternaReversao=" + operacaoInternaReversao + ", situacaoParticipantePlanoParcelamento="
				+ situacaoParticipantePlanoParcelamento + ", situacaoParticipantePlanoEncerramento=" + situacaoParticipantePlanoEncerramento + ", dataAlteracao=" + dataAlteracao + ", dataInclusao="
				+ dataInclusao + ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + ", listaTipoDevolucaoMotDesligamento="
				+ listaTipoDevolucaoMotDesligamento + ", proprioParticipante=" + proprioParticipante + ", recebedorTerceiro=" + recebedorTerceiro + "]";
	}

	public String getDescricaoIndicadorNecessidadeDesligamento() {

		if (indicadorNecessidadeDesligamento.equals("S")) {
			descricaoIndicadorNecessidadeDesligamento = "SIM";
		} else {
			descricaoIndicadorNecessidadeDesligamento = "NÃO";
		}

		return descricaoIndicadorNecessidadeDesligamento;

	}

	public void setDescricaoIndicadorNecessidadeDesligamento(String descricaoIndicadorNecessidadeDesligamento) {
		this.descricaoIndicadorNecessidadeDesligamento = descricaoIndicadorNecessidadeDesligamento;
	}

	public String getDescricaoIndicadorTipoDevolucao() {

		if (indicadorTipoDevolucao.equals("R")) {
			descricaoIndicadorTipoDevolucao = "RESGATE";
		} else {
			descricaoIndicadorTipoDevolucao = "PORTABILIDADE";
		}

		return descricaoIndicadorTipoDevolucao;
	}

	public void setDescricaoIndicadorTipoDevolucao(String descricaoIndicadorTipoDevolucao) {
		this.descricaoIndicadorTipoDevolucao = descricaoIndicadorTipoDevolucao;
	}

	public String getDescricaoIndicadorFormaDevolucao() {

		if (indicadorFormaDevolucao.equals("T")) {
			descricaoIndicadorFormaDevolucao = "TOTAL";
		} else {
			descricaoIndicadorFormaDevolucao = "PARCIAL";
		}

		return descricaoIndicadorFormaDevolucao;
	}

	public void setDescricaoIndicadorFormaDevolucao(String descricaoIndicadorFormaDevolucao) {
		this.descricaoIndicadorFormaDevolucao = descricaoIndicadorFormaDevolucao;
	}

	public String getDescricaoIndicadorTipoRecebedor() {

		if (indicadorTipoRecebedor.equals("P")) {
			descricaoIndicadorTipoRecebedor = "PARTICIPANTE";
		} else {
			descricaoIndicadorTipoRecebedor = "TERCEIRO";
		}

		return descricaoIndicadorTipoRecebedor;
	}

	public void setDescricaoIndicadorTipoRecebedor(String descricaoIndicadorTipoRecebedor) {
		this.descricaoIndicadorTipoRecebedor = descricaoIndicadorTipoRecebedor;
	}

	public SituacaoParticipantePlano getSituacaoParticipantePlanoParcelamento() {
		return situacaoParticipantePlanoParcelamento;
	}

	public void setSituacaoParticipantePlanoParcelamento(SituacaoParticipantePlano situacaoParticipantePlanoParcelamento) {
		this.situacaoParticipantePlanoParcelamento = situacaoParticipantePlanoParcelamento;
	}

	public SituacaoParticipantePlano getSituacaoParticipantePlanoEncerramento() {
		return situacaoParticipantePlanoEncerramento;
	}

	public void setSituacaoParticipantePlanoEncerramento(SituacaoParticipantePlano situacaoParticipantePlanoEncerramento) {
		this.situacaoParticipantePlanoEncerramento = situacaoParticipantePlanoEncerramento;
	}

	public boolean isResgate() {
		return this.indicadorTipoDevolucao.equals("R");
	}

	public boolean isPortabilidade() {
		return this.indicadorTipoDevolucao.equals("P");
	}

}