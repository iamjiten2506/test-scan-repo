package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@JsonIdentityInfo(generator = ObjectIdGenerators.UUIDGenerator.class, property = "@id", scope = DevolucaoPosicionadoDTO.class)
public class DevolucaoPosicionadoDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String codigoPt;
	private String codigoPn;
	private String codigoTDev;
	private String dataReq;
	private String indTDev;
	private String simulacao;
	private String qtdParcela;
	private String dataCota;
	private String indFormaPagRem;
	private String codigoUsuario;
	private Long codigoReferenciaCalculo;
	private Long codigoLoteReferencia;
	private Long codigoParticipantePlano;

	public DevolucaoPosicionadoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DevolucaoPosicionadoDTO(String codigoPt, String codigoPn, String codigoTDev, String dataReq, String indTDev, String simulacao, String qtdParcela, String dataCota, String indFormaPagRem,
			String codigoUsuario, Long codigoReferenciaCalculo, Long codigoLoteReferencia, Long codigoParticipantePlano) {
		super();
		this.codigoPt = codigoPt;
		this.codigoPn = codigoPn;
		this.codigoTDev = codigoTDev;
		this.dataReq = dataReq;
		this.indTDev = indTDev;
		this.simulacao = simulacao;
		this.qtdParcela = qtdParcela;
		this.dataCota = dataCota;
		this.indFormaPagRem = indFormaPagRem;
		this.codigoUsuario = codigoUsuario;
		this.codigoReferenciaCalculo = codigoReferenciaCalculo;
		this.codigoLoteReferencia = codigoLoteReferencia;
		this.codigoParticipantePlano = codigoParticipantePlano;
	}

	public String getCodigoPt() {
		return codigoPt;
	}

	public void setCodigoPt(String codigoPt) {
		this.codigoPt = codigoPt;
	}

	public String getCodigoPn() {
		return codigoPn;
	}

	public void setCodigoPn(String codigoPn) {
		this.codigoPn = codigoPn;
	}

	public String getCodigoTDev() {
		return codigoTDev;
	}

	public void setCodigoTDev(String codigoTDev) {
		this.codigoTDev = codigoTDev;
	}

	public String getDataReq() {
		return dataReq;
	}

	public void setDataReq(String dataReq) {
		this.dataReq = dataReq;
	}

	public String getIndTDev() {
		return indTDev;
	}

	public void setIndTDev(String indTDev) {
		this.indTDev = indTDev;
	}

	public String getSimulacao() {
		return simulacao;
	}

	public void setSimulacao(String simulacao) {
		this.simulacao = simulacao;
	}

	public String getQtdParcela() {
		return qtdParcela;
	}

	public void setQtdParcela(String qtdParcela) {
		this.qtdParcela = qtdParcela;
	}

	public String getDataCota() {
		return dataCota;
	}

	public void setDataCota(String dataCota) {
		this.dataCota = dataCota;
	}

	public String getIndFormaPagRem() {
		return indFormaPagRem;
	}

	public void setIndFormaPagRem(String indFormaPagRem) {
		this.indFormaPagRem = indFormaPagRem;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public Long getCodigoReferenciaCalculo() {
		return codigoReferenciaCalculo;
	}

	public void setCodigoReferenciaCalculo(Long codigoReferenciaCalculo) {
		this.codigoReferenciaCalculo = codigoReferenciaCalculo;
	}

	public Long getCodigoLoteReferencia() {
		return codigoLoteReferencia;
	}

	public void setCodigoLoteReferencia(Long codigoLoteReferencia) {
		this.codigoLoteReferencia = codigoLoteReferencia;
	}

	public Long getCodigoParticipantePlano() {
		return codigoParticipantePlano;
	}

	public void setCodigoParticipantePlano(Long codigoParticipantePlano) {
		this.codigoParticipantePlano = codigoParticipantePlano;
	}

	public String toString() {
		JSONObject jsonInfo = new JSONObject();

		try {
			jsonInfo.put("codigoPt", this.codigoPt);
			jsonInfo.put("codigoPn", this.codigoPn);
			jsonInfo.put("codigoTDev", this.codigoTDev);
			jsonInfo.put("dataReq", this.dataReq);
			jsonInfo.put("indTDev", this.indTDev);
			jsonInfo.put("simulacao", this.simulacao);
			jsonInfo.put("qtdParcela", this.qtdParcela);
			jsonInfo.put("dataCota", this.dataCota);
			jsonInfo.put("indFormaPagRem", this.indFormaPagRem);
			jsonInfo.put("codigoUsuario", this.codigoUsuario);
			jsonInfo.put("codigoReferenciaCalculo", this.codigoReferenciaCalculo);
			jsonInfo.put("codigoLoteReferencia", this.codigoLoteReferencia);
			jsonInfo.put("codigoParticipantePlano", this.codigoParticipantePlano);

		} catch (JSONException e1) {
		}
		return jsonInfo.toString();
	}
}
