package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   14/03/2017
 * Classe de persistência para tabela DOC_PLA_TIP_DEV.
 */
@Entity
@Table(name = "DOC_PLA_TIP_DEV", schema = "OWN_DCR")
@NamedQuery(name = "DocumentoPlanoTipoDevolucao.findAll", query = "SELECT q FROM DocumentoPlanoTipoDevolucao q")
public class DocumentoPlanoTipoDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DOC_PLA_TIP_DEV_GER", sequenceName = "S_DPTD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOC_PLA_TIP_DEV_GER")
	@Column(name = "NUM_SEQ_DOC_PLA_TIP_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLANO")
	private PlanoPrevidencia planoPrevidencia;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_DEV")
	private TipoDevolucao tipoDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DOC_DEV")
	private DocumentoDevolucao documentoDevolucao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INI")
	private Date DataInicio;

	@Column(name = "IND_VALIDO")
	private String indicativoValido;

	@Column(name = "IND_OBR")
	private String indicativoObrigatorio;

	@Column(name = "IND_VIS_REL")
	private String indicaVisualizacaoRelacionamento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public DocumentoDevolucao getDocumentoDevolucao() {
		return documentoDevolucao;
	}

	public void setDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		this.documentoDevolucao = documentoDevolucao;
	}

	public Date getDataInicio() {
		return DataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		DataInicio = dataInicio;
	}

	public String getIndicativoValido() {
		return indicativoValido;
	}

	public void setIndicativoValido(String indicativoValido) {
		this.indicativoValido = indicativoValido;
	}

	public String getIndicativoObrigatorio() {
		return indicativoObrigatorio;
	}

	public void setIndicativoObrigatorio(String indicativoObrigatorio) {
		this.indicativoObrigatorio = indicativoObrigatorio;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getIndicaVisualizacaoRelacionamento() {
		return indicaVisualizacaoRelacionamento;
	}

	public void setIndicaVisualizacaoRelacionamento(String indicaVisualizacaoRelacionamento) {
		this.indicaVisualizacaoRelacionamento = indicaVisualizacaoRelacionamento;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentoPlanoTipoDevolucao other = (DocumentoPlanoTipoDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}