package br.com.bbprevidencia.devolucao.controle;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.activation.MimetypesFileTypeMap;
import javax.faces.component.UIOutput;
import javax.faces.event.AjaxBehaviorEvent;
import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.primefaces.PrimeFaces;
import org.primefaces.component.export.ExcelOptions;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.Extenso;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.bbpcomum.util.UtilXls;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ExtratoPrevAutoPatrocinioBO;
import br.com.bbprevidencia.cadastroweb.bo.ExtratoPrevBO;
import br.com.bbprevidencia.cadastroweb.bo.ExtratoPrevBpdBO;
import br.com.bbprevidencia.cadastroweb.bo.ExtratoPrevPortabilidadeBO;
import br.com.bbprevidencia.cadastroweb.bo.ExtratoPrevResgateBO;
import br.com.bbprevidencia.cadastroweb.bo.ExtratoPrevUltimasContribuicoesBO;
import br.com.bbprevidencia.cadastroweb.bo.FundoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.HistoricoFinanceiroPagoBO;
import br.com.bbprevidencia.cadastroweb.bo.MotivoExtratoPrevBO;
import br.com.bbprevidencia.cadastroweb.bo.ObservacaoProcessoExtratoPrevBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoGuardaChuvaBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.ProcessoExtratoPrevBO;
import br.com.bbprevidencia.cadastroweb.bo.RegraBpdBO;
import br.com.bbprevidencia.cadastroweb.bo.RegraGeralBO;
import br.com.bbprevidencia.cadastroweb.bo.SituacaoExtratoPrevBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoCompletoDTO;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoImprimirExtracaoDTO;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoPrev;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoPrevAutoPatrocinio;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoPrevBpd;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoPrevPortabilidade;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoPrevResgate;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.MotivoExtratoPrev;
import br.com.bbprevidencia.cadastroweb.dto.ObservacaoProcessoExtratoPrev;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.ProcessoExtratoPrev;
import br.com.bbprevidencia.cadastroweb.dto.ProcessoExtratoPrevDTO;
import br.com.bbprevidencia.cadastroweb.dto.ProcessoExtratoPrevDesligadosDTO;
import br.com.bbprevidencia.cadastroweb.dto.ProcessoExtratoPrevIndevidoDTO;
import br.com.bbprevidencia.cadastroweb.dto.RegraBpd;
import br.com.bbprevidencia.cadastroweb.dto.RegraGeral;
import br.com.bbprevidencia.cadastroweb.dto.SituacaoExtratoPrev;
import br.com.bbprevidencia.cadastroweb.dto.TelefoneParticipante;
import br.com.bbprevidencia.cadastroweb.enumerador.TipoPlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.cotas.bo.ValorCotaPlanoBO;
import br.com.bbprevidencia.cotas.dto.ValorCotaPlano;
import br.com.bbprevidencia.devolucao.dto.ApresentacaoExtratoPrevDTO;
import br.com.bbprevidencia.devolucao.dto.CorpoExtratoPrevDTO;
import br.com.bbprevidencia.devolucao.dto.DadosAutoPatrocinioDTO;
import br.com.bbprevidencia.devolucao.dto.DadosBpdDTO;
import br.com.bbprevidencia.devolucao.dto.DadosPortabilidadeAnteriorDTO;
import br.com.bbprevidencia.devolucao.dto.DadosPortabilidadeDTO;
import br.com.bbprevidencia.devolucao.dto.DadosResgateDTO;
import br.com.bbprevidencia.devolucao.dto.ExtratoPrevRequestDTO;
import br.com.bbprevidencia.devolucao.dto.TermoExtratoPrevDTO;
import br.com.bbprevidencia.devolucao.dto.ValoresComunRelatorioExtratoPrevDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.interno.bo.ArquivoAnexoBO;
import br.com.bbprevidencia.interno.bo.ArquivoAnexoItemBO;
import br.com.bbprevidencia.interno.dto.ArquivoAnexo;
import br.com.bbprevidencia.interno.dto.ArquivoAnexoItem;
import br.com.bbprevidencia.seguranca.bo.ParmSistemBO;
import br.com.bbprevidencia.seguranca.dto.ParmSistem;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since   08/11/2018
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("processoExtratoPrevidenciarioVisao")
public class ProcessoExtratoPrevidenciarioVisao {

	private static String FW_PROCESSO_EXTRATO_PREVIDENCIARIO = "/paginas/processoExtratoPrevidenciario.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(ProcessoExtratoPrevidenciarioVisao.class);

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoGuardaChuvaBO planoGuardaChuvaBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private ExtratoPrevBO extratoPrevBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ValorCotaPlanoBO valorCotaPlanoBO;

	@Autowired
	private ParmSistemBO parmSistemBO;

	@Autowired
	private AmbienteServico ambienteServico;

	@Autowired
	private ArquivoAnexoBO arquivoAnexoBO;

	@Autowired
	private ArquivoAnexoItemBO arquivoAnexoItemBO;

	@Autowired
	private ProcessoExtratoPrevBO processoExtratoPrevBO;

	@Autowired
	private SituacaoExtratoPrevBO situacaoExtratoPrevBO;

	@Autowired
	private MotivoExtratoPrevBO motivoExtratoPrevBO;

	@Autowired
	private ObservacaoProcessoExtratoPrevBO observacaoProcessoExtratoPrevBO;

	@Autowired
	private FundoPrevidenciaBO fundoPrevidenciaBO;

	@Autowired
	private RelatorioUtil relatorioUtil;

	@Autowired
	private RegraGeralBO regraGeralBO;

	@Autowired
	private ExtratoPrevAutoPatrocinioBO extratoPrevAutoPatrocinioBO;

	@Autowired
	private RegraBpdBO regraBpdBO;

	@Autowired
	private ExtratoPrevBpdBO extratoPrevBpdBO;

	@Autowired
	private ExtratoPrevResgateBO extratoPrevResgateBO;

	@Autowired
	private HistoricoFinanceiroPagoBO historicoFinaceiroPagoBO;

	@Autowired
	private ExtratoPrevPortabilidadeBO extratoPrevPortabilidadeBO;

	@Autowired
	private ExtratoPrevUltimasContribuicoesBO extratoPrevUltimasContribuicoesBO;

	@Autowired
	private ServletContext context;

	private ParmSistem parmSistem;
	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean listarStatus;
	private Participante participante;
	private PlanoPrevidencia planoPrevidencia;
	private EntidadeParticipante entidadeParticipante;
	private ExtratoPrev extratoPrev;
	private ValorCotaPlano valorCotaPlano;
	private Date dataCota;
	private Date dataAtual;
	private List<Participante> listaParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private String url;
	private boolean btImprimir;
	private ArquivoAnexo arquivoAnexo;
	private StreamedContent arquivoAnexoStreamed;
	private List<StreamedContent> listaArquivoAnexo;
	private List<ProcessoExtratoPrevDTO> listaTodosExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaManuaisExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaDisponivelExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaVistoWebExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaImprimirExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaEnviadoExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaArNaoRecExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaArRecExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaEncerradoExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaAcimaPrazoExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaNaoGeradoExtratoPrev;
	private List<ProcessoExtratoPrevDTO> listaFinalizadoExtratoPrev;
	private List<ProcessoExtratoPrevDesligadosDTO> listaDesligadosExtratoPrev;
	private List<ProcessoExtratoPrevIndevidoDTO> listaIndevidosExtratoPrev;

	private List<ProcessoExtratoPrevDTO> listaManualExtratoPrevSelect;
	private List<ProcessoExtratoPrevDTO> listaDisponivelExtratoPrevSelect;
	private List<ProcessoExtratoPrevDTO> listaVistoWebExtratoPrevSelect;
	private List<ProcessoExtratoPrevDTO> listaImprimirExtratoPrevSelect;
	private List<ProcessoExtratoPrevDTO> listaEnviadoExtratoPrevSelect;
	private List<ProcessoExtratoPrevDTO> listaArNaoRecExtratoSelect;
	private List<ProcessoExtratoPrevDTO> listaArRecExtratoSelect;
	private List<ProcessoExtratoPrevDTO> listaEncerradoExtratoSelect;

	private List<ProcessoExtratoPrev> listaProcessoExtratoPrev;

	private List<ExtratoCompletoDTO> listaExtratoCompleto;

	private List<ObservacaoProcessoExtratoPrev> listaObservacoes;

	@Value("#{propriedades['sistema.caminhoSalvarExtrato']}")
	private String caminhoSalvarArquivos;

	StreamedContent arquivoRecuperado;

	File file;

	FileInputStream streamRetorno;

	String nomeArquivo;

	private int activeIndex = 0;
	private boolean limparForm = true;

	private String observacaoManual;
	private String observacaoDisponivel;
	private String observacaoVistoWeb;
	private String observacaoImprimir;
	private String observacaoEnviado;
	private String observacaoNaoRecebido;
	private String observacaoRecebido;

	private boolean checkImprimir;

	private Date dataEnviado;
	private Date dataArNaoRecebido;
	private Date dataArRecebido;

	private ExcelOptions xlsOptions;

	private ProcessoExtratoPrevDTO resumoProcessoExtrato;

	private SituacaoExtratoPrev situacaoExtratoPrev;

	private MotivoExtratoPrev motivoExtratoPrev;

	private Extenso extenso = new Extenso();

	private ValoresComunRelatorioExtratoPrevDTO valoresComuns;

	/**
	 * Método para iniciar a tela Emissão Extrato Previdenciário.
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since   08/11/2018
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.url = null;
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.extratoPrev = new ExtratoPrev();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("emissaoExtratoPrevidenciario");
		} else {
			this.possuiAcessoTotal = false;
		}

		limpar();

		preencherOpcoesExcel();

		this.listaEntidadeParticipante = entidadeParticipanteBO.listarEntidadeParticipante();
		listarProcessoExtratoCompleto();
		return FW_PROCESSO_EXTRATO_PREVIDENCIARIO;
	}

	private void preencherOpcoesExcel() {
		xlsOptions = new ExcelOptions();
		xlsOptions.setFacetBgColor("#195F8E");
		xlsOptions.setFacetFontSize("10");
		xlsOptions.setFacetFontColor("#F7F7F7");
		xlsOptions.setFacetFontStyle("BOLD");
		xlsOptions.setCellFontSize("10");

	}

	public void mudarAba() {
		System.out.println("Aba ativa: " + activeIndex);
	}

	public void listarProcessoExtratoCompleto() {
		if (UtilJava.isColecaoVazia(this.listaExtratoCompleto)) {
			this.listaExtratoCompleto = this.processoExtratoPrevBO.listarExtratoCompleto();
		}
	}

	/**
	 * Método para listar os planos por patrocinadora.
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since   08/11/2018
	 * @return {@link String}
	 * @param {@link AjaxBehaviorEvent}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {
		if (this.entidadeParticipante == null) {
			this.setListaPlanoPrevidencia(new ArrayList<PlanoPrevidencia>());
		} else {
			try {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante()));
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}
		return FW_PROCESSO_EXTRATO_PREVIDENCIARIO;
	}

	/**
	 * Método para carregar um plano de previdencia. 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since   08/11/2018
	 * @param {@link AjaxBehaviorEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Método para carregar um participante.
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since   08/11/2018
	 * @param {@link AjaxBehaviorEvent}
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (!UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("participante", getParticipante());
		} else {
			setParticipante(new Participante());
		}

		this.valorCotaPlano = this.valorCotaPlanoBO.pesquisarCotaParticipantePlano(this.getDataAtual(), participantePlanoBO.consultparPorParticipanteEPlano(this.participante, this.planoPrevidencia));
		this.dataCota = this.valorCotaPlano.getChavePrimaria().getDataPosicaoCota();

	}

	/**
	 * Método para listar os participante por nome que estaja na situação para emitir extrato Previdenciário.
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since   08/11/2018
	 * @param {@link String}
	 * @return {@link List<Participante>}
	 */
	public List<Participante> listarParticipantes(String nome) {
		List<Participante> listaParticipante = new ArrayList<Participante>();
		if (this.entidadeParticipante.getChavePrimaria() != null) {
			listaParticipante = this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			Mensagens.addMsgErro("Favor selecionar uma patrocinadora.");
		}
		return listaParticipante;
	}

	/**
	 * Método para limpar os objetos. 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since   08/11/2018
	 */
	public void limpar() {
		this.limparForm = true;
		this.listarStatus = true;
		this.entidadeParticipante = new EntidadeParticipante();
		this.listaPlanoPrevidencia = new ArrayList<>();
		this.planoPrevidencia = new PlanoPrevidencia();
		this.participante = new Participante();
		this.dataCota = null;
		this.listaTodosExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();
		setActiveIndex(0);
		this.resumoProcessoExtrato = new ProcessoExtratoPrevDTO();
	}

	/**
	 * Método para salva o arquivo em pdf do extrato.  
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since   08/11/2018
	 */
	public void sendPostRequest() {
		try {
			InputStream inputStream = new URL(this.url).openStream();
			this.file = File.createTempFile("extrato_revidenciario", ".pdf");
			FileOutputStream outputStream = new FileOutputStream(this.file);

			byte[] buffer = new byte[1024];
			int length;

			while (true) {
				length = inputStream.read(buffer);
				if (length < 0) {
					break;
				}

				outputStream.write(buffer, 0, length);
				outputStream.flush();
			}

			outputStream.close();
			inputStream.close();

		} catch (MalformedURLException e) {
			log.error(e);
			throw new PrevidenciaException(e.getMessage());
		} catch (IOException e) {
			log.error(e);
			throw new PrevidenciaException(e.getMessage());
		}

	}

	/**
	 * @author  
	 * @throws FileNotFoundException 
	 * @since   08/11/2018
	 */
	public void preencheArquivoAnexo() {
		try {
			this.arquivoAnexo = new ArquivoAnexo();
			this.arquivoAnexo.setCodigoChaveOrigem("EXTR");
			this.arquivoAnexo.setCodigoUsuInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			this.arquivoAnexo.setDataInclusao(new Date());
			// itens
			ArquivoAnexoItem item = new ArquivoAnexoItem();
			item.setArquivoAnexo(this.arquivoAnexo);
			item.setCodigoUsuInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			item.setDataInclusao(new Date());
			item.setNomeArquivo("extrato_previdenciario.pdf");
			item.setDescricaoArquivo("Extrato Previdenciário");
			item.setNomeArquivoSerie(arquivoAnexoBO.geraHashArquivo(item.getNomeArquivo()) + item.getNomeArquivo().substring(item.getNomeArquivo().lastIndexOf('.')));
			this.arquivoAnexo.getListaArquivoAnexoItem().add(item);
			this.nomeArquivo = item.getNomeArquivo();
			this.arquivoAnexoBO.salvarArquivoAnexo(this.arquivoAnexo);

			this.arquivoRecuperado = new DefaultStreamedContent(new FileInputStream(this.file), new MimetypesFileTypeMap().getContentType(this.file), item.getNomeArquivo());
			List<StreamedContent> listaArquivos = new ArrayList<StreamedContent>();
			listaArquivos.add(this.arquivoRecuperado);
			this.arquivoAnexoItemBO.salvarListaArquivoAnexoItem(this.arquivoAnexo.getListaArquivoAnexoItem(), listaArquivos, this.getCaminhoSalvarArquivos());
		} catch (FileNotFoundException e) {
			throw new PrevidenciaException(e.getMessage());
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}

	public void pesquisarProcessoExtrato(boolean pesquisaNormal) {
		this.listaTodosExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>(this.processoExtratoPrevBO.listarAtualProcessoExtratoPrev(this.entidadeParticipante != null ? this.entidadeParticipante
				.getChavePrimaria().getCodigoEntidadeParticipante() : null, this.participante != null ? this.participante.getCodigo() : null, this.planoPrevidencia != null ? this.planoPrevidencia
				.getPlanoGuardaChuva().getCodigo() : null));

		if (pesquisaNormal) {
			setActiveIndex(0);
			this.limparForm = false;
		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * 
	 * Enviar o processo de extrato previedenciario de manual para enviado
	 * 
	 */
	public void extratoManualParaEnviadoOuDisponivel(String situacao) {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaManualExtratoPrevSelect)) {
			try {
				List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
				List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

				for (ProcessoExtratoPrevDTO item : this.listaManualExtratoPrevSelect) {
					ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

					processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));

					if (situacao.equalsIgnoreCase("E")) {
						processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(3L));
						processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(4L));
					} else {
						processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(1L));
						processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(81L));
					}

					processoExtratoPrev.setDataInclusao(new Date());
					processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

					listaProcessoExtratoPrev.add(processoExtratoPrev);
				}

				if (!UtilJava.isStringVazia(this.observacaoManual, true)) {

					for (ProcessoExtratoPrevDTO item : this.listaManualExtratoPrevSelect) {
						ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
						observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
						observacao.setObservacao(this.observacaoManual);
						observacao.setDataInclusao(new Date());
						observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaObservacaoProcesso.add(observacao);
					}
				}

				if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
					this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

					if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
						this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
					}
				}
				pesquisarProcessoExtrato(false);
				this.observacaoDisponivel = null;

				Mensagens.addMsgInfo("Processo(s) enviado(s) com sucesso!");

			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao inserir situação de processo de extrato!");
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}
	}

	public void extratoDisponivelParaEnviado() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaDisponivelExtratoPrevSelect)) {
			try {
				List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
				List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

				for (ProcessoExtratoPrevDTO item : this.listaDisponivelExtratoPrevSelect) {
					ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

					processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
					processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(3L));
					processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(3L));
					processoExtratoPrev.setDataInclusao(new Date());
					processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

					listaProcessoExtratoPrev.add(processoExtratoPrev);
				}

				if (!UtilJava.isStringVazia(this.observacaoDisponivel, true)) {

					for (ProcessoExtratoPrevDTO item : this.listaDisponivelExtratoPrevSelect) {
						ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
						observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
						observacao.setObservacao(this.observacaoDisponivel);
						observacao.setDataInclusao(new Date());
						observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaObservacaoProcesso.add(observacao);
					}
				}

				if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
					this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

					if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
						this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
					}
				}

				pesquisarProcessoExtrato(false);
				this.observacaoDisponivel = null;

				Mensagens.addMsgInfo("Processo(s) enviado(s) com sucesso!");
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao inserir situação de processo de extrato!");
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}
	}

	public void extratoVistoWebParaFinalizado() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaVistoWebExtratoPrevSelect)) {
			try {
				List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
				List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

				for (ProcessoExtratoPrevDTO item : this.listaVistoWebExtratoPrevSelect) {
					ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

					processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
					processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(7L));
					processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(9L));
					processoExtratoPrev.setDataInclusao(new Date());
					processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

					listaProcessoExtratoPrev.add(processoExtratoPrev);
				}

				if (!UtilJava.isStringVazia(this.observacaoVistoWeb, true)) {

					for (ProcessoExtratoPrevDTO item : this.listaVistoWebExtratoPrevSelect) {
						ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
						observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
						observacao.setObservacao(this.observacaoVistoWeb);
						observacao.setDataInclusao(new Date());
						observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaObservacaoProcesso.add(observacao);
					}
				}

				if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
					this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

					if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
						this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
					}
				}

				pesquisarProcessoExtrato(false);
				this.observacaoDisponivel = null;

				Mensagens.addMsgInfo("Processo(s) finalizado(s) com sucesso!");
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao inserir situação de processo de extrato!");
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}
	}

	public void extratoImpressoParaEnviado() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaImprimirExtratoPrevSelect)) {
			try {
				List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
				List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

				if (this.checkImprimir) {
					this.imprimirExtratoPrevidenciario(this.listaImprimirExtratoPrevSelect);
				}

				for (ProcessoExtratoPrevDTO item : this.listaImprimirExtratoPrevSelect) {
					ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

					processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
					processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(3L));
					processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(3L));
					processoExtratoPrev.setDataInclusao(new Date());
					processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

					listaProcessoExtratoPrev.add(processoExtratoPrev);
				}

				if (!UtilJava.isStringVazia(this.observacaoImprimir, true)) {

					for (ProcessoExtratoPrevDTO item : this.listaImprimirExtratoPrevSelect) {
						ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
						observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
						observacao.setObservacao(this.observacaoImprimir);
						observacao.setDataInclusao(new Date());
						observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaObservacaoProcesso.add(observacao);
					}
				}

				if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
					this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

					if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
						this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
					}
				}

				pesquisarProcessoExtrato(false);
				this.observacaoImprimir = null;
				this.checkImprimir = false;

				Mensagens.addMsgInfo("Processo(s) finalizado(s) com sucesso!");
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao inserir situação de processo de extrato!");
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}
	}

	private void imprimirExtratoPrevidenciario(List<ProcessoExtratoPrevDTO> listaImprimirExtratoPrevSelect) {
		// TODO Auto-generated method stub

	}

	public void extratoPrevParaEncerrado(String tipoSituacao) {
		try {
			if (tipoSituacao.equalsIgnoreCase("I")) {
				if (UtilJava.isColecaoDiferenteDeVazia(this.listaImprimirExtratoPrevSelect)) {
					StringBuilder retorno = excerrarExtrato(this.listaImprimirExtratoPrevSelect);

					if (retorno != null) {
						throw new PrevidenciaException(retorno.toString());
					}

					this.observacaoImprimir = null;

					this.checkImprimir = false;
				} else {
					throw new PrevidenciaException("Favor selecionar algum processo antes de continuar!");
				}
			} else if (tipoSituacao.equalsIgnoreCase("E")) {
				if (UtilJava.isColecaoDiferenteDeVazia(this.listaEncerradoExtratoSelect)) {
					StringBuilder retorno = new StringBuilder(excerrarExtrato(this.listaEncerradoExtratoSelect));

					if (retorno != null) {
						throw new PrevidenciaException(retorno.toString());
					}
				} else {
					throw new PrevidenciaException("Favor selecionar algum processo antes de continuar!");
				}
			}

			Mensagens.addMsgInfo("Processo(s) encerrados(s) com sucesso!");
			pesquisarProcessoExtrato(false);
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro(e.getMessage());
		}
	}

	/**
	 * Encerra processos de estrato que estão em impresso
	 * @see OWN_DR.sdrsp_encerra_extrato_previd
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 28/12/2018
	 */
	public StringBuilder excerrarExtrato(List<ProcessoExtratoPrevDTO> listaExtratoParaEncerrar) {
		try {
			StringBuilder listaErro = new StringBuilder();

			for (ProcessoExtratoPrevDTO item : listaExtratoParaEncerrar) {
				listaErro.append(this.processoExtratoPrevBO.encerrarProcessoExtratoPrevidenciario(item.getNumeroExtratoPrev()));
			}

			return listaErro;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Erro ao encerrar processo de extrato: " + e.getMessage());
		}
	}

	/**
	 * Extração em formato Excel dos extratos no status de Imprimir
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 02/01/2019
	 * 
	 */
	public void extraerListaProcessoExtrato(Long situacao) {
		try {
			List<ExtratoImprimirExtracaoDTO> listaRetorno = new ArrayList<ExtratoImprimirExtracaoDTO>(this.processoExtratoPrevBO.listarExtratoImprimirExtracaoDTO(
					this.entidadeParticipante != null ? this.entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante() : null,
					this.planoPrevidencia != null ? this.planoPrevidencia.getPlanoGuardaChuva().getCodigo() : null,
					this.participante != null ? this.participante.getCodigo() : null,
					"S",
					situacao));

			if (UtilJava.isColecaoVazia(listaRetorno)) {
				throw new PrevidenciaException("Não foram encontradas informações para exportar!");
			} else {
				Workbook wb = new HSSFWorkbook();
				Sheet sheet = wb.createSheet("Planilha1");

				int rownum = 0;
				int cellnum = 0;
				Cell cell;
				Row row;

				// Configurando Header
				row = sheet.createRow(rownum++);

				cell = row.createCell(cellnum++);
				cell.setCellValue("NUMERO_EXTRATO_PREV");

				cell = row.createCell(cellnum++);
				cell.setCellValue("PATROCINADORA");

				cell = row.createCell(cellnum++);
				cell.setCellValue("PLANO_GUARDA_CHUVA");

				cell = row.createCell(cellnum++);
				cell.setCellValue("NUM_SEQ_PARTIC");

				cell = row.createCell(cellnum++);
				cell.setCellValue("MATRICULA");

				cell = row.createCell(cellnum++);
				cell.setCellValue("PARTICIPANTE");

				cell = row.createCell(cellnum++);
				cell.setCellValue("DATA");

				cell = row.createCell(cellnum++);
				cell.setCellValue("NUM_DIAS");

				cell = row.createCell(cellnum++);
				cell.setCellValue("SOMENTE_GERAL");

				cell = row.createCell(cellnum++);
				cell.setCellValue("CPF");

				cell = row.createCell(cellnum++);
				cell.setCellValue("LOGRADOURO");

				cell = row.createCell(cellnum++);
				cell.setCellValue("Nº");

				cell = row.createCell(cellnum++);
				cell.setCellValue("COMPLEMENTO");

				cell = row.createCell(cellnum++);
				cell.setCellValue("BAIRRO");

				cell = row.createCell(cellnum++);
				cell.setCellValue("CIDADE");

				cell = row.createCell(cellnum++);
				cell.setCellValue("UF");

				cell = row.createCell(cellnum++);
				cell.setCellValue("CEP");

				cell = row.createCell(cellnum++);
				cell.setCellValue("E-MAIL");

				cell = row.createCell(cellnum++);
				cell.setCellValue("TEL_CEL");

				cell = row.createCell(cellnum++);
				cell.setCellValue("TEL_RES");

				cell = row.createCell(cellnum++);
				cell.setCellValue("TEL_COM");

				for (ExtratoImprimirExtracaoDTO rs : listaRetorno) {
					row = sheet.createRow(rownum++);
					cellnum = 0;

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getCodigo());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getNomeEntidadeparticipante());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getNomePlanoGuardaChuva());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getNumeroParticipante());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getMatriculaParticipante());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getNomeParticipante());

					cell = row.createCell(cellnum++);
					cell.setCellValue(UtilJava.formataDataPorPadrao(rs.getDataInclusao(), "dd/MM/yyyy"));

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getNumeroDias());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getSomenteGeral());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getCpf());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getEndLogradouro() != null ? rs.getEndLogradouro().toUpperCase() : null);

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getNumLogradouro() != null ? rs.getNumLogradouro().toString() : null);

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getComplementoLogradouro());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getBairro() != null ? rs.getBairro().toUpperCase() : rs.getBairro());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getCidade() != null ? rs.getCidade().toUpperCase() : rs.getCidade());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getuF());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getCep());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getEmail() != null ? rs.getEmail().toLowerCase() : rs.getEmail());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getTelefoneCelular());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getTelefoneResdencial());

					cell = row.createCell(cellnum++);
					cell.setCellValue(rs.getTelefoneComercial());
				}

				ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();

				wb.write(outByteStream);
				byte[] outArray = outByteStream.toByteArray();
				UtilXls.imprimeXLS(outArray, "EXT_LST_IMP_" + UtilJava.formataDataPorPadrao(new Date(), "ddMMyyyyHHmmss"));
			}

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro(e.getMessage());
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 02/01/2019
	 */
	public void extratoEnviadoParaArNaoRecebidoOuConfirmaAr(String tipoAr) {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaEnviadoExtratoPrevSelect)) {
			try {
				if (this.dataEnviado == null) {
					Mensagens.addMsgErro("Favor informar a data do evento.");
				} else {
					List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
					List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

					for (ProcessoExtratoPrevDTO item : this.listaEnviadoExtratoPrevSelect) {
						ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

						processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
						processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(tipoAr.equalsIgnoreCase("ARN") ? 21L : 4L));
						processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(tipoAr.equalsIgnoreCase("ARN") ? 21L : 5L));
						processoExtratoPrev.setDataInclusao(this.dataEnviado);
						processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaProcessoExtratoPrev.add(processoExtratoPrev);
					}

					if (!UtilJava.isStringVazia(this.observacaoEnviado, true)) {

						for (ProcessoExtratoPrevDTO item : this.listaEnviadoExtratoPrevSelect) {
							ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
							observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
							observacao.setObservacao(this.observacaoEnviado);
							observacao.setDataInclusao(new Date());
							observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

							listaObservacaoProcesso.add(observacao);
						}
					}

					if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
						this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

						if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
							this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
						}
					}

					pesquisarProcessoExtrato(false);
					this.observacaoEnviado = null;

					Mensagens.addMsgInfo("Recebimento de A.R.(s) " + listaEnviadoExtratoPrevSelect.size() + " processo(s) com sucesso!");
				}
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao processar extratos: " + e.getMessage());
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 02/01/2019
	 */
	public void extratoArNaoRecebidoParaRecebido() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaArNaoRecExtratoSelect)) {
			try {
				if (this.dataArNaoRecebido == null) {
					Mensagens.addMsgErro("Favor informar a data do evento.");
				} else {
					List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
					List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

					for (ProcessoExtratoPrevDTO item : this.listaArNaoRecExtratoSelect) {
						ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

						processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
						processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(4L));
						processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(161L));
						processoExtratoPrev.setDataInclusao(this.dataArNaoRecebido);
						processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaProcessoExtratoPrev.add(processoExtratoPrev);
					}

					if (!UtilJava.isStringVazia(this.observacaoNaoRecebido, true)) {

						for (ProcessoExtratoPrevDTO item : this.listaArNaoRecExtratoSelect) {
							ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
							observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
							observacao.setObservacao(this.observacaoNaoRecebido);
							observacao.setDataInclusao(new Date());
							observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

							listaObservacaoProcesso.add(observacao);
						}
					}

					if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
						this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

						if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
							this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
						}
					}

					pesquisarProcessoExtrato(false);
					this.observacaoNaoRecebido = null;
					this.dataArNaoRecebido = null;

					Mensagens.addMsgInfo("Recebimento de A.R.(s) " + listaArNaoRecExtratoSelect.size() + " processo(s) com sucesso!");
				}
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao processar extratos: " + e.getMessage());
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 02/01/2019
	 */
	public void extratoArNaoRecebidoParaEnviado() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaArNaoRecExtratoSelect)) {
			try {
				List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
				List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

				for (ProcessoExtratoPrevDTO item : this.listaArNaoRecExtratoSelect) {
					ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

					processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
					processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(3L));
					processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(4L));
					processoExtratoPrev.setDataInclusao(new Date());
					processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

					listaProcessoExtratoPrev.add(processoExtratoPrev);
				}

				if (!UtilJava.isStringVazia(this.observacaoNaoRecebido, true)) {

					for (ProcessoExtratoPrevDTO item : this.listaArNaoRecExtratoSelect) {
						ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
						observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
						observacao.setObservacao(this.observacaoNaoRecebido);
						observacao.setDataInclusao(new Date());
						observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaObservacaoProcesso.add(observacao);
					}
				}

				if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
					this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

					if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
						this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
					}
				}

				pesquisarProcessoExtrato(false);
				this.observacaoNaoRecebido = null;
				this.dataArNaoRecebido = null;

				Mensagens.addMsgInfo("Processado(s) " + listaArNaoRecExtratoSelect.size() + " processo(s) com sucesso!");
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao processar extratos: " + e.getMessage());
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}

	}

	public void extratoArRecebidoParaNaoRecebido() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaArRecExtratoSelect)) {
			try {
				if (this.dataArRecebido == null) {
					Mensagens.addMsgErro("Favor informar a data do evento.");
				} else {
					List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
					List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

					for (ProcessoExtratoPrevDTO item : this.listaArRecExtratoSelect) {
						ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

						processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
						processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(21L));
						processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(141L));
						processoExtratoPrev.setDataInclusao(this.dataArRecebido);
						processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaProcessoExtratoPrev.add(processoExtratoPrev);
					}

					if (!UtilJava.isStringVazia(this.observacaoRecebido, true)) {

						for (ProcessoExtratoPrevDTO item : this.listaArRecExtratoSelect) {
							ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
							observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
							observacao.setObservacao(this.observacaoRecebido);
							observacao.setDataInclusao(new Date());
							observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

							listaObservacaoProcesso.add(observacao);
						}
					}

					if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
						this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

						if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
							this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
						}
					}

					pesquisarProcessoExtrato(false);
					this.observacaoRecebido = null;
					this.dataArRecebido = null;

					Mensagens.addMsgInfo("Recebimento de A.R.(s) " + listaArRecExtratoSelect.size() + " processo(s) com sucesso!");
				}
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao processar extratos: " + e.getMessage());
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}
	}

	public void extratoArRecebidoParaEncerrar() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaArRecExtratoSelect)) {
			try {
				List<ProcessoExtratoPrev> listaProcessoExtratoPrev = new ArrayList<ProcessoExtratoPrev>();
				List<ObservacaoProcessoExtratoPrev> listaObservacaoProcesso = new ArrayList<ObservacaoProcessoExtratoPrev>();

				for (ProcessoExtratoPrevDTO item : this.listaArRecExtratoSelect) {
					ProcessoExtratoPrev processoExtratoPrev = new ProcessoExtratoPrev();

					processoExtratoPrev.setExtratoPrev(this.extratoPrevBO.buscarExtratoPrevPorCodigo(item.getNumeroExtratoPrev()));
					processoExtratoPrev.setSituacaoExtratoPrev(this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(62L));
					processoExtratoPrev.setMotivoExtratoPrev(motivoExtratoPrevBO.buscarMotivoPorCodigo(103L));
					processoExtratoPrev.setDataInclusao(new Date());
					processoExtratoPrev.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

					listaProcessoExtratoPrev.add(processoExtratoPrev);
				}

				if (!UtilJava.isStringVazia(this.observacaoRecebido, true)) {

					for (ProcessoExtratoPrevDTO item : this.listaArRecExtratoSelect) {
						ObservacaoProcessoExtratoPrev observacao = new ObservacaoProcessoExtratoPrev();
						observacao.setProcessoExtratoprev(this.processoExtratoPrevBO.buscarProcessoExtratoPorExtratoPrevPorCodigo(item.getCodigo()));
						observacao.setObservacao(this.observacaoRecebido);
						observacao.setDataInclusao(new Date());
						observacao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

						listaObservacaoProcesso.add(observacao);
					}
				}

				if (UtilJava.isColecaoDiferenteDeVazia(listaProcessoExtratoPrev)) {
					this.processoExtratoPrevBO.salvarListaProcessoExtratoPrev(listaProcessoExtratoPrev);

					if (UtilJava.isColecaoDiferenteDeVazia(listaObservacaoProcesso)) {
						this.observacaoProcessoExtratoPrevBO.salvarListaObservacoes(listaObservacaoProcesso);
					}
				}

				pesquisarProcessoExtrato(false);
				this.observacaoRecebido = null;
				this.dataArRecebido = null;

				Mensagens.addMsgInfo("Recebimento de A.R.(s) " + listaArRecExtratoSelect.size() + " processo(s) com sucesso!");
			} catch (Exception e) {
				log.error(e);
				Mensagens.addMsgErro("Erro ao processar extratos: " + e.getMessage());
			}
		} else {
			Mensagens.addMsgWarn("Favor selecionar algum processo antes de continuar!");
		}
	}

	public void mostrarResumoExtrato(ProcessoExtratoPrevDTO extrato) {
		this.resumoProcessoExtrato = extrato;

		this.situacaoExtratoPrev = this.situacaoExtratoPrevBO.buscarSituacaoPorCodigo(this.resumoProcessoExtrato.getNumeroSituacao());
		this.motivoExtratoPrev = this.motivoExtratoPrevBO.buscarMotivoPorCodigo(this.resumoProcessoExtrato.getNumeroMotivo());

		this.listaProcessoExtratoPrev = this.processoExtratoPrevBO.listarProcessoExtratoPrevPorCodigoExtratoPrev(extrato.getNumeroExtratoPrev());
		this.listaObservacoes = this.observacaoProcessoExtratoPrevBO.listarObservacaoProcessoExtratoPrev(extrato.getNumeroExtratoPrev());
		PrimeFaces.current().executeScript("PF('resumoExtratoPrev').show()");
	}

	public Date getDataAtual() {
		if (dataAtual == null)
			dataAtual = new Date();
		return dataAtual;
	}

	public void carregarDesligados() {
		if (UtilJava.isColecaoVazia(listaDesligadosExtratoPrev) && !this.limparForm) {
			listaDesligadosExtratoPrev = new ArrayList<ProcessoExtratoPrevDesligadosDTO>(this.processoExtratoPrevBO.listarDesligadosSemProcessoExtratoPrev(
					this.entidadeParticipante != null ? this.entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante() : null,
					this.participante != null ? this.participante.getCodigo() : null,
					this.planoPrevidencia != null ? this.planoPrevidencia.getPlanoGuardaChuva().getCodigo() : null));
		} else {
			listaDesligadosExtratoPrev = new ArrayList<ProcessoExtratoPrevDesligadosDTO>();
		}
	}

	public void exportarRelatorioExtrato(ProcessoExtratoPrevDTO extrato) {
		try {
			this.valoresComuns = new ValoresComunRelatorioExtratoPrevDTO();

			ExtratoPrev extratoPrev = this.extratoPrevBO.buscarExtratoPrevPorCodigo(extrato.getNumeroExtratoPrev());

			List<ApresentacaoExtratoPrevDTO> listaApresentacaoExtratoPrev = this.montarRelatorioApresentacao(extratoPrev);
			List<CorpoExtratoPrevDTO> listaDadosGeraisExtratoPrev = this.montarRelatorioExtratoPrev(extratoPrev);
			List<TermoExtratoPrevDTO> listaTermoOpcaoExtratoPrev = this.montarRelatorioTermoExtratoPrev(extratoPrev, listaDadosGeraisExtratoPrev);

			boolean mostrarTermo = extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") && extratoPrev.getIndValido().equalsIgnoreCase("S");

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

			parametros.put("logo", logo);
			parametros.put("mostrarTermo", mostrarTermo);
			parametros.put("listaApresentacaoExtratoPrev", listaApresentacaoExtratoPrev);
			parametros.put("listaDadosGeraisExtratoPrev", listaDadosGeraisExtratoPrev);
			parametros.put("listaTermoOpcaoExtratoPrev", listaTermoOpcaoExtratoPrev);

			imprimirRelatorio("extratoPrevidenciario", new ArrayList<>(), parametros);
			
			/*
			if (this.activeIndex == 1) {
				imprimirRelatorio("subreportExtratoPrevApresentacao", listaApresentacaoExtratoPrev, parametros);
			} else {
				imprimirRelatorio("subreportExtratoPrevTermoOpcao", listaTermoOpcaoExtratoPrev, parametros);
			}
			*/

		} catch (Exception e) {
			Mensagens.addError(e.getMessage());
		}
	}

	public List<TermoExtratoPrevDTO> montarRelatorioTermoExtratoPrev (ExtratoPrev extratoPrev, List<CorpoExtratoPrevDTO> listaCorpoExtratoPrev) {
		List<TermoExtratoPrevDTO> listaRetorno = new ArrayList<>();
		
		TermoExtratoPrevDTO itemRetorno = new TermoExtratoPrevDTO();
		
		itemRetorno.setCnpb(extratoPrev.getPlanoGuardaChuva().getCnpb());
		itemRetorno.setNomeParticipante(extratoPrev.getParticipante().getNomeParticipante());
		itemRetorno.setNomePatrocinadora(extratoPrev.getParticipante().getEntidadeParticipante().getNomeEntidadeParticipante());
		itemRetorno.setDataNascimento(UtilJava.formataDataPorPadrao(extratoPrev.getParticipante().getDataNascimento(), "dd/MM/yyyy"));
		itemRetorno.setCpf(UtilJava.formataCPF(extratoPrev.getParticipante().getCpf()));
		itemRetorno.setEmail(extratoPrev.getParticipante().getEnderecoEmail() != null ? extratoPrev.getParticipante().getEnderecoEmail().toLowerCase() : "");
		itemRetorno.setEndereco(extratoPrev.getParticipante().getEnderecoCompleto());
		itemRetorno.setBairro(extratoPrev.getParticipante().getEnderecoBairro());
		itemRetorno.setCidade(extratoPrev.getParticipante().getNomeCidade());
		itemRetorno.setCep(UtilJava.formatarCep(extratoPrev.getParticipante().getCepFormatado()));
		itemRetorno.setUf(extratoPrev.getParticipante().getEnderecoUnidadeFederativa().getCodigo());
		
		if (extratoPrev.getParticipante().getListaTelefoneParticipante().size() > 0) {
			for (TelefoneParticipante telefone : extratoPrev.getParticipante().getListaTelefoneParticipante()) {
				if (telefone.getTipoTelefone().getCodigo().equalsIgnoreCase("1")) {
					itemRetorno.setTelefoneResidencial(telefone.getTelefoneFormatado());
				} else if (telefone.getTipoTelefone().getCodigo().equalsIgnoreCase("2")) {
					itemRetorno.setTelefoneComercial(telefone.getTelefoneFormatado());
				} else if (telefone.getTipoTelefone().getCodigo().equalsIgnoreCase("3")) {
					itemRetorno.setTelefoneCelular(telefone.getTelefoneFormatado());
				} else  {
					itemRetorno.setTelefoneOutros(telefone.getTelefoneFormatado());
				}
			}
		}
		
		itemRetorno.setNumMaxPacelaResgate(listaCorpoExtratoPrev.get(0).getQtdMaxParcelasResgate());
		
		itemRetorno.setCodigoPlanoGC(extratoPrev.getPlanoGuardaChuva().getCodigo().intValue());
		
		itemRetorno.setDscTipoEmpresa(extratoPrev.getParticipante().getEntidadeParticipante().isInstituidora() ? "Instituidora" : "Patrocinadora");
		
		itemRetorno.setDscTextoInformativo(extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") ? "" : " (E envio do documento comprobatório da rescisão contratual em casos de resgate e portabilidade).");
		
		itemRetorno.setPossuiResgate(!listaCorpoExtratoPrev.get(0).getListaResgate().isEmpty());
		
		itemRetorno.setPossuiAutopatrocinio(!listaCorpoExtratoPrev.get(0).getListaAutoPatrocinio().isEmpty());
		
		itemRetorno.setPossuiBpd(!listaCorpoExtratoPrev.get(0).getListaBpd().isEmpty());
		
		itemRetorno.setPossuiPortabilidade(!listaCorpoExtratoPrev.get(0).getListaPortabilidade().isEmpty());
		
		itemRetorno.setMostrarOpcaoContribuicao(this.valoresComuns.isMostrarOpcaoContribuicao());
		
		itemRetorno.setPossuiRisco(this.valoresComuns.isPossuiRisco());
		
		listaRetorno.add(itemRetorno);
		
		return listaRetorno;
		
	}

	public List<ApresentacaoExtratoPrevDTO> montarRelatorioApresentacao(ExtratoPrev extratoPrev) {
		List<ApresentacaoExtratoPrevDTO> listaApresentacao = new ArrayList<ApresentacaoExtratoPrevDTO>();

		Map<String, String> fundoEndereco = new HashMap<String, String>(this.fundoPrevidenciaBO.consultaEnderecoFundoPrevidencia(1L));

		ApresentacaoExtratoPrevDTO infoApresentacao = new ApresentacaoExtratoPrevDTO();

		infoApresentacao.setNomeParticipante(extratoPrev.getParticipante().getNomeParticipante());
		infoApresentacao.setSexo(extratoPrev.getParticipante().getIndicadorSexo());

		infoApresentacao.setLogradouro(extratoPrev.getParticipante().getEnderecoCompleto());
		infoApresentacao.setBairro(StringUtils.isNotBlank(extratoPrev.getParticipante().getEnderecoBairro()) ? extratoPrev.getParticipante().getEnderecoBairro() : "");
		infoApresentacao.setCep(StringUtils.isNotBlank(extratoPrev.getParticipante().getCepFormatado()) ? extratoPrev.getParticipante().getCepFormatado() : "");
		infoApresentacao.setCidade(StringUtils.isNotBlank(extratoPrev.getParticipante().getNomeCidade()) ? extratoPrev.getParticipante().getNomeCidade() : "");
		infoApresentacao.setUf(StringUtils.isNotBlank(extratoPrev.getParticipante().getEnderecoUnidadeFederativa().getCodigo()) ? extratoPrev.getParticipante().getEnderecoUnidadeFederativa()
				.getCodigo() : "");
		infoApresentacao.setEnderecoBbp(fundoEndereco.get("BBPREV"));
		infoApresentacao.setNomeEmpresaBbp(fundoEndereco.get("ENDERECO_BBPREV"));
		infoApresentacao.setCidadeBbp("CEP: " + UtilJava.formatarCep(fundoEndereco.get("CEP")) + "   " + fundoEndereco.get("CIDADE_BBPREV"));

		String textoMotivo = "";
		String texoOrientacao = "";
		String ultimoParagrafo = "";

		if (extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09")) {
			textoMotivo = "a transferência para empresa do mesmo grupo econômico";
			ultimoParagrafo = "4. ";
		} else {
			textoMotivo = "o término do vínculo empregatício com a " + extratoPrev.getParticipante().getEntidadeParticipante().getNomeAbreviadoEntidadeParticipante();
			texoOrientacao = "4. Orientamos analisar os impactos que o regime de tributação - Progressivo ou Regressivo - pode acarretar em sua opção, especialmente em caso de resgate.";
			ultimoParagrafo = "5. ";
		}

		infoApresentacao.setParagrafoUm("1. Tendo em vista " + textoMotivo + ", disponibilizamos o seu extrato previdenciário em conformidade com o Regulamento do "
				+ WordUtils.capitalize(extratoPrev.getPlanoGuardaChuva().getNomePlanoGuardaChuva().toLowerCase()).replace("De", "de"));

		infoApresentacao.setParagrafoDois(texoOrientacao + (StringUtils.isNotBlank(texoOrientacao) ? "\n\n" : "") + ultimoParagrafo
				+ "Colocamo-nos à disposição para prestar quaisquer esclarecimentos.");

		listaApresentacao.add(infoApresentacao);

		return listaApresentacao;
	}

	/**
	 * Monta o corpo do extrato previdenciario
	 * @param extratoPrev
	 * @return
	 */
	public List<CorpoExtratoPrevDTO> montarRelatorioExtratoPrev(ExtratoPrev extratoPrev) {
		List<CorpoExtratoPrevDTO> listaCorpo = new ArrayList<CorpoExtratoPrevDTO>();

		CorpoExtratoPrevDTO infoCorpo = new CorpoExtratoPrevDTO();

		int diasIdade;
		int diasPlano;
		int diasEmpresa;
		boolean indParteGeral = false;
		boolean indPlanoBD = false;
		boolean indPossuiResgate = false;
		String textoBaseObsGeral = "";

		ValorCotaPlano valorCotaPlano = new ValorCotaPlano();

		String dscTipoEntidade = extratoPrev.getParticipante().getEntidadeParticipante().isInstituidora() ? "Instituidora" : "Patrocinadora";

		if (extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09")) {
			infoCorpo.setMotivoOcorrencia("transferência para a empresa do mesmo grupo econômico");
			infoCorpo.setIndicaDataDesligamento("T");
			infoCorpo.setDataDesligamento(extratoPrev.getParticipante().getDataSituacaoParticipante());
			diasEmpresa = UtilJava.dataDiff(extratoPrev.getParticipante().getDataAdmissao(), extratoPrev.getParticipante().getDataSituacaoParticipante());
			indPossuiResgate = false;
		} else {
			infoCorpo.setMotivoOcorrencia("perda do vínculo empregatício com a empresa patrocinadora");
			infoCorpo.setIndicaDataDesligamento("D");
			infoCorpo.setDataDesligamento(extratoPrev.getParticipante().getDataDesligamento());
			diasEmpresa = UtilJava.dataDiff(extratoPrev.getParticipante().getDataAdmissao(), extratoPrev.getParticipante().getDataDesligamento());
			indPossuiResgate = true;
			textoBaseObsGeral = " e cópia da homologação de rescisão do contrato de trabalho do participante";
		}

		infoCorpo.setPrazoMaximoOpcao("60 (" + this.extenso.escreverPorExtensoMoeda(60D).replace(" Real", "").replace(" Reais", "") + ")");
		infoCorpo.setNomeParticipante(extratoPrev.getParticipante().getNomeParticipante());
		infoCorpo.setMatriculaParticipante(extratoPrev.getParticipante().getNumeroMatriculaPatrocinadora());
		infoCorpo.setCpfParticipante(UtilJava.formataCPF(extratoPrev.getParticipante().getCpf()));
		infoCorpo.setSexoParticipante(extratoPrev.getParticipante().getDescricaoSexo().toUpperCase());
		infoCorpo.setDataNascParticipante(extratoPrev.getParticipante().getDataNascimento());
		infoCorpo.setNomePlanoGuardaChuva(extratoPrev.getPlanoGuardaChuva().getNomePlanoGuardaChuva().toUpperCase());
		infoCorpo.setDataAdmissao(extratoPrev.getParticipante().getDataAdmissao());

		infoCorpo.setDataBase(extratoPrev.getDatBase());

		Date dataInscricao = this.extratoPrevBO.buscarDataInscricao(extratoPrev.getParticipante().getCodigo());
		Date dataMigracao = this.extratoPrevBO.buscarDataMigracao(extratoPrev.getParticipante().getCodigo());

		if (dataMigracao != null) {
			infoCorpo.setDataInscricao(UtilJava.formataDataPorPadrao(dataMigracao, "dd/MM/yyyy") + "   Migrado em: " + UtilJava.formataDataPorPadrao(dataInscricao, "dd/MM/yyyy"));
			diasPlano = UtilJava.dataDiff(dataMigracao, extratoPrev.getDatBase());
		} else {
			infoCorpo.setDataInscricao(UtilJava.formataDataPorPadrao(dataInscricao, "dd/MM/yyyy"));
			diasPlano = UtilJava.dataDiff(dataInscricao, extratoPrev.getDatBase());
		}

		diasIdade = UtilJava.dataDiff(extratoPrev.getParticipante().getDataNascimento(), extratoPrev.getDatBase());

		infoCorpo.setIdadeParticipante((int) (diasIdade / 365.24) + " Ano(s) " + (int) ((diasIdade % 365.24) / 30.4167) + " Mês(es) " + (int) ((diasIdade % 365.24) % 30.4167) + " Dia(s)");

		infoCorpo.setTempoEmpresa((int) (diasEmpresa / 365.24) + " Ano(s) " + (int) ((diasEmpresa % 365.24) / 30.4167) + " Mês(es) " + (int) ((diasEmpresa % 365.24) % 30.4167) + " Dia(s)");

		infoCorpo.setTempoPlano((int) (diasPlano / 365.24) + " Ano(s) " + (int) ((diasPlano % 365.24) / 30.4167) + " Mês(es) " + (int) ((diasPlano % 365.24) % 30.4167) + " Dia(s)");

		infoCorpo.setSalarioBase(extratoPrev.getValSalarioParticipacao() != null ? extratoPrev.getValSalarioParticipacao().doubleValue() : null);

		List<RegraGeral> listaRegraGeral = new ArrayList<RegraGeral>(this.regraGeralBO.buscarPorPlanoGuardaChuva(extratoPrev.getPlanoGuardaChuva().getCodigo()));

		ParticipantePlano participantePlano = null;

		for (RegraGeral rG : listaRegraGeral) {
			if ((rG.getIndicadorParticipantePlano().equalsIgnoreCase("O") || rG.getIndicadorParticipantePlano().equalsIgnoreCase("P")) && rG.getDataInicioVigencia().before(new Date())
					&& (rG.getDataFimVigencia() == null || rG.getDataFimVigencia().after(new Date()))) {

				for (ParticipantePlano pP : extratoPrev.getParticipante().getListaParticipantePlano()) {
					if (pP.getPlanoPrevidencia().getCodigo() == rG.getChavePrimaria().getPlanoPrevidencia().getCodigo()) {
						participantePlano = pP;
						break;
					}
				}
				break;
			} else {
				continue;
			}
		}

		try {
			valorCotaPlano = this.valorCotaPlanoBO.pesquisarCotaParticipantePlano(new Date(), participantePlano);
			infoCorpo.setValorUltimaCota(valorCotaPlano.getValorCota().doubleValue());
		} catch (Exception e) {
			log.error(e);
			infoCorpo.setValorUltimaCota(null);
		}

		if (extratoPrev.getNomeEspecieElegivelSimulacao() != null) {
			infoCorpo.setNomeEspececieElegibilidade(extratoPrev.getNomeEspecieElegivelSimulacao());
		} else {
			infoCorpo.setNomeEspececieElegibilidade("aposentadoria");
		}

		infoCorpo.setElegivelParaBeneficio(extratoPrev.getIndElegivelBenef().equalsIgnoreCase("S"));

		/*************************************************
				Parte do corpo AUTOPATROCINIO
		 ***************************************************/
		List<ExtratoPrevAutoPatrocinio> listaAutoPatrocinio = new ArrayList<ExtratoPrevAutoPatrocinio>(this.extratoPrevAutoPatrocinioBO.listarExtratoPrevAutoPatrocinioComDireito(extratoPrev));

		String obsAutoPatroc = null;
		List<Long> planosGc = Arrays.asList(12L, 41L, 13L, 9L, 44L, 40L, 7L, 48L);
		if (UtilJava.isColecaoDiferenteDeVazia(listaAutoPatrocinio)) {
			obsAutoPatroc = "Observações:\n\n" + "- os valores iniciais acima demonstrados , incluída a taxa de administração, estão sujeitos a alterações periódicas;";

			if (planosGc.contains(extratoPrev.getPlanoGuardaChuva().getCodigo())) {
				obsAutoPatroc += "\n- é de livre escolha do participante autopatrocinado rever o percentual de sua contribuição na data da respectiva opção por este instituto;";
			}

			obsAutoPatroc += "\n- a opção pelo autopatrocínio não impede, posteriormente, a opção pelo instituto do resgate ou da portabilidade, desde que sejam preenchidos os requisitos para tanto.";
			obsAutoPatroc += "\n- os valores acima apresentados devem ser custeados a partir da data "
					+ (extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") ? "da sua transferência para a empresa do mesmo grupo econômico"
							: "de seu desligamento na ") + dscTipoEntidade;

			for (ExtratoPrevAutoPatrocinio aP : listaAutoPatrocinio) {
				DadosAutoPatrocinioDTO item = new DadosAutoPatrocinioDTO();
				item.setPartePlano(TipoPlanoPrevidencia.getTipoPlanoPrevidencia(aP.getPlanoPrevidencia().getRegraGeralVigente().getIndicadorParticipantePlano()).getDescricao());
				item.setTipoContribuicao(aP.getTipoContribuicao().getDescricaoTipoContribuicao());
				item.setValorParticipante(aP.getValorContribuicaoParticipante());
				item.setValorPatrocinadora(aP.getValorContribuicaoPatrocinadora());

				infoCorpo.getListaAutoPatrocinio().add(item);

				this.valoresComuns.setMostrarOpcaoContribuicao(aP.getPlanoPrevidencia().getRegraArracadacaoVigente().getIndicadorTipoCalculoParticipante().equalsIgnoreCase("I")
						|| aP.getPlanoPrevidencia().getRegraArracadacaoVigente().getIndicadorTipoCalculoPatrocinadora().equalsIgnoreCase("I"));

				this.valoresComuns.setPossuiRisco(aP.getPlanoPrevidencia().getRegraGeralVigente().getIndicadorParticipantePlano().equalsIgnoreCase("R"));

				if (UtilJava.isColecaoDiferenteDeVazia(listaRegraGeral)) {
					for (RegraGeral rG : listaRegraGeral) {
						if (rG.getChavePrimaria().getPlanoPrevidencia().getCodigo() == aP.getPlanoPrevidencia().getCodigo() && rG.getCodigoModalidadePlano().equalsIgnoreCase("BD")) {
							indPlanoBD = true;
						}
					}
				}

			}
			infoCorpo.setPossuiAP("S");
		} else {
			obsAutoPatroc = "O(a) Senhor (a), não possui direito a auto patrocínio.";
			infoCorpo.setPossuiAP("N");
		}

		infoCorpo.setObsExtratoAutoPatrocinio(obsAutoPatroc);

		/*************************************************
				Parte do corpo BPD
		 ***************************************************/

		List<RegraBpd> listaRegraBpd = new ArrayList<RegraBpd>(this.regraBpdBO.buscarRegraBpdPorPlanoGuardaChuva(extratoPrev.getPlanoGuardaChuva()));

		Integer qtdMeses = 36;

		if (UtilJava.isColecaoDiferenteDeVazia(listaRegraBpd)) {
			for (RegraBpd bpd : listaRegraBpd) {
				qtdMeses = bpd.getQtdeMesesBpd() != null && bpd.getQtdeMesesBpd() != qtdMeses ? bpd.getQtdeMesesBpd() : qtdMeses;
			}
		}

		infoCorpo.setInfoInicioBpd("Oferecido ao participante, em razão da "
				+ (extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") ? "sua transferência para a empresa do mesmo grupo econômico"
						: "cessação de vínculo empregatício com a " + dscTipoEntidade)
				+ ", antes da aquisição do direito ao benefício de Aposentadoria, optar por deixar de contribuir para receber, em tempo futuro, o benefício pleno programado decorrente dessa opção"
				+ ", desde que cumprida a carência de " + qtdMeses + " (" + this.extenso.escreverPorExtensoMoeda(qtdMeses).replace(" Real", "").replace(" Reais", "")
				+ ") meses de vinculação ao plano de benefícios.");

		List<ExtratoPrevBpd> listaExtratoPrevBpd = new ArrayList<ExtratoPrevBpd>(this.extratoPrevBpdBO.listarExtratoPrevBpdComDireito(extratoPrev));

		Double valorTaxaAdminBpd = 0D;
		Double valorValorIncapacidade = 0D;
		String obsBpd;

		if (UtilJava.isColecaoDiferenteDeVazia(listaExtratoPrevBpd)) {
			for (ExtratoPrevBpd bpd : listaExtratoPrevBpd) {
				DadosBpdDTO dados = new DadosBpdDTO();
				dados.setNomePlano(TipoPlanoPrevidencia.getTipoPlanoPrevidencia(bpd.getPlanoPrevidencia().getRegraGeralVigente().getIndicadorParticipantePlano()).getDescricao());
				dados.setValorMontanteGarantidor(bpd.getValorGarantidor());
				dados.setValorTaxaAdmin(bpd.getValorTaxaAdministracao());
				dados.setValorIncapacidadeMorte(bpd.getValorIncapacidadeMorte());
				infoCorpo.getListaBpd().add(dados);

				valorTaxaAdminBpd += bpd.getValorTaxaAdministracao() != null ? bpd.getValorTaxaAdministracao() : 0D;
				valorValorIncapacidade += bpd.getValorIncapacidadeMorte() != null ? bpd.getValorIncapacidadeMorte() : 0D;

				if (UtilJava.isColecaoDiferenteDeVazia(listaRegraGeral)) {
					for (RegraGeral rG : listaRegraGeral) {
						if (rG.getChavePrimaria().getPlanoPrevidencia().getCodigo() == bpd.getPlanoPrevidencia().getCodigo() && rG.getIndicadorParticipantePlano().equalsIgnoreCase("G")) {
							indParteGeral = true;
						}
					}
				}
			}

			obsBpd = "Observações:\n\n"
					+ (indParteGeral || indPlanoBD ? "- é facultativo a opção por contribuir para os benefícios de risco previstos no regulamento do plano.\n" : "")
					+ "- opção pelo BPD não impede, posteriormente, a opção pelo instituto do resgate ou da portabilidade deste que sejam preenchidos os requisitos para tanto;\n"
					+ "- vale destacar que lhe é facultado efetuar contribuições especiais/extraordinárias para o plano com o objetivo de acrescer o saldo de conta.\n"
					+ (extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") ? "- No caso de transferência de patrocinadora a data de cessação de vínculo empregatício com  a patrocinadora será a considerado a data desta transferência.\n"
							: "")
					+ (indParteGeral ? "- Quando da concessão do benefício deverá ser observada a metodologia de cálculo da renda mensal.\n" : "")
					+ (extratoPrev.getPlanoGuardaChuva().getCodigo() == 6L ? "- Durante a fase de diferimento, o participante que optar pela a cobertura dos benefícios de que trata a Parte Geral "
							+ "deverá suportar o respectivo custeio, calculado atuarialmente, bem como a taxa de administração prevista no artigo 85, observando os ditames dos artigos 82 e 84 deste Regulamento.\n"
							: "")
					+ (extratoPrev.getPlanoGuardaChuva().getCodigo() == 44L ? "- O Participante Vinculado (em BPD) assumirá o custeio das despesas administrativas decorrentes "
							+ "da sua manutenção no Plano, cuja taxa será estabelecida pela Entidade Gestora e registrada no plano de custeio anual. "
							+ "O valor assim calculado será descontado do saldo retido no Plano, inicialmente, do saldo de Conta de Contribuição de Participante, "
							+ "havendo o esgotamento do saldo sua inscrição será cancelada automaticamente.\n" : "")
					+ (extratoPrev.getPlanoGuardaChuva().getCodigo() == 22L ? "- De acordo com regulamento vigente, para o cálculo da Renda Mensal de Aposentadoria Antecipada não serão consideradas as contribuições extraordinárias da Patrocinadora "
							+ "referentes ao compromisso especial de tempo de serviço passado (TSP PATROCINADORA A INTEGRALIZAR).\n"
							: "") + (valorTaxaAdminBpd > 0D ? "* Valor a ser pago, obrigatoriamente, caso opte por este instituto.\n" : "")
					+ (valorValorIncapacidade > 0D ? "** Valor a ser pago para cobertura de benefícios de risco , não obrigatório." : "");

			infoCorpo.setPossuiBpd("S");
		} else {
			obsBpd = "O(a) Senhor (a), não possui direito ao benefício proporcional diferido.";
			infoCorpo.setPossuiBpd("N");
		}

		infoCorpo.setInfoFinalBpd(obsBpd);

		/*************************************************
				Parte do corpo RESGATE
		 ***************************************************/

		if (indPossuiResgate) {
			List<ExtratoPrevResgate> listaExtratoResgate = this.extratoPrevResgateBO.listarExtratoPrevResgate(extratoPrev);

			if (UtilJava.isColecaoDiferenteDeVazia(listaExtratoResgate)) {
				Double valorResgatavel = 0D;
				Integer qtdeMaxParcelas = 0;
				Integer qtdeContribAm = 0;
				Integer direitoResgate = 0;

				for (ExtratoPrevResgate r : listaExtratoResgate) {
					valorResgatavel += (r.getValorSaldoParticipante() != null ? r.getValorSaldoParticipante() : 0D) + (r.getValorSaldoPatrocinadora() != null ? r.getValorSaldoPatrocinadora() : 0D);
					DadosResgateDTO resgate = new DadosResgateDTO();
					resgate.setNomePlano(TipoPlanoPrevidencia.getTipoPlanoPrevidencia(r.getPlanoPrevidencia().getRegraGeralVigente().getIndicadorParticipantePlano()).getDescricao());
					resgate.setValorResgatavel(valorResgatavel);

					qtdeMaxParcelas = r.getQtdeMaximaParcelas() != null ? r.getQtdeMaximaParcelas() : 1;
					qtdeContribAm = r.getPlanoPrevidencia().getCodigo() == 12L ? r.getQuantidadeContribuicoes() : 0;
					direitoResgate += r.getIndicadorDireitoResgate().equalsIgnoreCase("S") ? 1 : 0;

					if (valorResgatavel > 0D) {
						infoCorpo.getListaResgate().add(resgate);
					}
				}

				infoCorpo.setQtdMaxParcelasResgate(qtdeMaxParcelas);

				indPossuiResgate = valorResgatavel > 0D;
				String obsResgate = null;

				Map<String, Double> portabildadeAnterior = new HashMap<String, Double>(this.historicoFinaceiroPagoBO.buscarPortabilidadeAnterior(extratoPrev.getParticipante().getCodigo()));

				if (portabildadeAnterior.size() > 0) {
					for (String chave : portabildadeAnterior.keySet()) {
						DadosPortabilidadeAnteriorDTO portAnt = new DadosPortabilidadeAnteriorDTO();
						portAnt.setTipoEntidade(chave);
						portAnt.setValor(portabildadeAnterior.get(chave) * (valorCotaPlano.getValorCota() != null ? valorCotaPlano.getValorCota().doubleValue() : 1));
						infoCorpo.getListaPortabilidadeAnterior().add(portAnt);
					}
				}

				if (indPossuiResgate) {
					infoCorpo.setInfoInicioResgate("É assegurado o resgate do valor decorrente de seu desligamento da " + dscTipoEntidade
							+ ", de acordo com as regras estabelecidas no regulamento do seu plano de benefícios.");

					if (direitoResgate > 0) {
						obsResgate = "Observações:\n\n"
								+ "- o saldo resgatável bruto está sujeito à incidência de Imposto de Renda na fonte, aplicável sobre cada parcela, se for o caso de parcelamento, ou sobre o valor total, "
								+ "calculado de acordo com a opção de tributação feita pelo participante, quando da inscrição no plano;\n" + "- a seu critério, o resgate poderá ser pago em até "
								+ qtdeMaxParcelas + " (" + this.extenso.escreverPorExtensoMoeda(qtdeMaxParcelas).replace(" Real", "").replace(" Reais", "") + ") "
								+ "parcelas mensais iguais e sucessivas, sendo as parcelas vincendas atualizadas com base na rentabilidade "
								+ "líquida do patrimônio do plano. Sobre estas parcelas haverá o desconto do Imposto de Renda com base na legislação em vigor.\n";

						if (qtdeContribAm != 0 && qtdeContribAm < 24 && dataMigracao != null) {
							obsResgate += "-os valores apresentados não incluem a reserva de migração, tendo em vista V.Sª. possuir menos de 24 contribuições para o plano Unisantos 2, conforme § 1° do artigo 21 do regulamento do plano.\n";
						}

						obsResgate += "- os recursos de portabilidade oriundos de entidade fechada, não compõe o saldo resgatável.";
					} else {
						obsResgate = "O(a) Senhor (a), não possui direito a resgatar.";
					}
				}

				infoCorpo.setInfoFimResgate(obsResgate);
			}
		} else {
			infoCorpo.setInfoFimResgate("O(a) Senhor (a), não possui direito a resgatar.");
		}

		infoCorpo.setPossuiResgate(indPossuiResgate);

		/*************************************************
				Parte do corpo PORTABILIDADE
		 ***************************************************/
		List<ExtratoPrevPortabilidade> listaExtratoPortabilidade = this.extratoPrevPortabilidadeBO.listarExtratoPrevPortabilidade(extratoPrev);

		if (UtilJava.isColecaoDiferenteDeVazia(listaExtratoPortabilidade)) {
			infoCorpo.setPossuiPortabilidade(true);

			Integer tempoCarencia = 0;
			Integer direitoPortar = 0;
			for (ExtratoPrevPortabilidade eP : listaExtratoPortabilidade) {
				DadosPortabilidadeDTO dados = new DadosPortabilidadeDTO();
				dados.setNomePlano(TipoPlanoPrevidencia.getTipoPlanoPrevidencia(eP.getPlanoPrevidencia().getRegraGeralVigente().getIndicadorParticipantePlano()).getDescricao());
				dados.setValorPortavel((eP.getValorSaldoParticipante() != null ? eP.getValorSaldoParticipante() : 0D)
						+ (eP.getValorSaldoPatrocinadora() != null ? eP.getValorSaldoPatrocinadora() : 0D));
				tempoCarencia = eP.getQuantidadeMesesCarenciaPlano() != null ? eP.getQuantidadeMesesCarenciaPlano() : 0;
				direitoPortar += eP.getIndicadorDireitoPortabilidade().equalsIgnoreCase("S") ? 1 : 0;

				if (dados.getValorPortavel() > 0D) {
					infoCorpo.getListaPortabilidade().add(dados);
				}

			}

			infoCorpo
					.setInfoInicioPortabilidade("Oferecido ao participante que optar por transferir seus recursos financeiros para outro plano de previdência complementar autorizado a operar o referido plano "
							+ "desde que simultaneamente: tenha "
							+ (extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") ? "sido transferido para a empresa do mesmo grupo econômico"
									: "rescindido o vínculo empregatício com a " + dscTipoEntidade)
							+ " e cumprido a carência de "
							+ tempoCarencia
							+ " ("
							+ this.extenso.escreverPorExtensoMoeda(tempoCarencia).replace(" Real", "").replace(" Reais", "") + ") meses de vinculação ao plano.");

			if (direitoPortar > 0) {
				infoCorpo
						.setInfoFimPortabilidade("Observações:\n\n"
								+ "- os valores portáveis serão atualizados pela rentabilidade líquida do plano até a data da efetiva transferência para o plano receptor indicado pelo participante, isentos de imposto de renda;\n"
								+ "- é vedado o resgate de recursos oriundos de Portabilidade, constituídos em plano de benefícios administrado por entidade fechada de previdência complementar.\n"
								+ (extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") ? "- No caso de transferência de patrocinadora a data de cessação de vínculo empregatício com a patrocinadora será a considerado a data desta transferência."
										: ""));
				infoCorpo.setDireitoPortar(true);
			} else {
				infoCorpo.setInfoFimPortabilidade("O(a) Senhor(a), não possui direito a portar.");
				infoCorpo.setDireitoPortar(false);
			}
		} else {
			infoCorpo.setPossuiPortabilidade(false);
		}

		/*************************************************
			Parte do corpo EMPRÉSTIMO
		 ***************************************************/
		if (extratoPrev.getDataPosicaoEmprestimo() == null) {
			infoCorpo.setTxtValorEmprestimo(extratoPrev.getValEmprestimo() != null ? "Valor de Empréstimo R$ " + UtilJava.formataNumero(extratoPrev.getValEmprestimo().doubleValue(), 2)
					: "Valor de Empréstimo R$ " + UtilJava.formataNumero(0D, 2));
		} else {
			infoCorpo.setTxtValorEmprestimo("Valor de Empréstimo R$ " + UtilJava.formataNumero(extratoPrev.getValEmprestimo().doubleValue(), 2) + " posicionado em "
					+ UtilJava.formataDataPorPadrao(extratoPrev.getDataPosicaoEmprestimo(), "dd/MM/yyyy"));
		}

		Date dataReferencia = this.extratoPrevUltimasContribuicoesBO.buscarDataReferenciaMaxima(extratoPrev);

		if (dataReferencia == null)
			dataReferencia = this.extratoPrevUltimasContribuicoesBO.buscarDataReferenciaMaximaFromFicha(extratoPrev);

		infoCorpo
				.setObservacoesGerais("Observações Gerais:\n\n"
						+ "- deverão ser encaminhadas juntamente com o Termo de Opção, cópia dos documentos pessoais (RG e CPF)"
						+ textoBaseObsGeral
						+ ";\n"
						+ "- o valor estimado das simulações referem-se às contribuições até "
						+ UtilJava.formataDataPorPadrao(dataReferencia, "dd/MM/yyyy")
						+ ";\n"
						+ "- os valores estão sujeitos a alterações, tendo em vista que, de acordo com o estabelecido no regulamento, as contribuições são atualizadas com base na rentabilidade do plano, sujeitas, assim, a variações positivas "
						+ "ou negativas, além de não estarem considerando possíveis valores a deduzir referentes a empréstimos consignados com a BB Previdência.\n"
						+ "- O Termo de Opção deverá ter reconhecimento em cartório no caso de resgate.");

		listaCorpo.add(infoCorpo);

		return listaCorpo;
	}

	public void imprimirRelatorio(String relatorio, List<?> dados, Map<String, Object> parametros) {
		String nomeArquivo = "";
		try {

			nomeArquivo = relatorioUtil.gerarRelatorio(relatorio, dados, parametros);

			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (Exception e) {
			log.error("Erro ao exportar relatório.", e);
			throw new PrevidenciaException(e);
		}
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public ExtratoPrev getExtratoPrev() {
		return extratoPrev;
	}

	public void setExtratoPrev(ExtratoPrev extratoPrev) {
		this.extratoPrev = extratoPrev;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public ValorCotaPlano getValorCotaPlano() {
		return valorCotaPlano;
	}

	public void setValorCotaPlano(ValorCotaPlano valorCotaPlano) {
		this.valorCotaPlano = valorCotaPlano;
	}

	public ParmSistem getParmSistem() {
		return parmSistem;
	}

	public void setParmSistem(ParmSistem parmSistem) {
		this.parmSistem = parmSistem;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean isBtImprimir() {
		return btImprimir;
	}

	public void setBtImprimir(boolean btImprimir) {
		this.btImprimir = btImprimir;
	}

	public String getCaminhoSalvarArquivos() {
		return caminhoSalvarArquivos;
	}

	public void setCaminhoSalvarArquivos(String caminhoSalvarArquivos) {
		this.caminhoSalvarArquivos = caminhoSalvarArquivos;
	}

	public StreamedContent getArquivoRecuperado() {
		return arquivoRecuperado;
	}

	public void setArquivoRecuperado(StreamedContent arquivoRecuperado) {
		this.arquivoRecuperado = arquivoRecuperado;
	}

	public ArquivoAnexo getArquivoAnexo() {
		return arquivoAnexo;
	}

	public void setArquivoAnexo(ArquivoAnexo arquivoAnexo) {
		this.arquivoAnexo = arquivoAnexo;
	}

	public StreamedContent getArquivoAnexoStreamed() {
		return arquivoAnexoStreamed;
	}

	public void setArquivoAnexoStreamed(StreamedContent arquivoAnexoStreamed) {
		this.arquivoAnexoStreamed = arquivoAnexoStreamed;
	}

	public List<StreamedContent> getListaArquivoAnexo() {
		return listaArquivoAnexo;
	}

	public void setListaArquivoAnexo(List<StreamedContent> listaArquivoAnexo) {
		this.listaArquivoAnexo = listaArquivoAnexo;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

	public List<ProcessoExtratoPrevDTO> getListaTodosExtratoPrev() {
		return listaTodosExtratoPrev;
	}

	public void setListaTodosExtratoPrev(List<ProcessoExtratoPrevDTO> listaTodosExtratoPrev) {
		this.listaTodosExtratoPrev = listaTodosExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaManuaisExtratoPrev() {
		this.listaManuaisExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			this.listaManuaisExtratoPrev = this.processoExtratoPrevBO.filtrarListaManualExtraoPrev(this.listaTodosExtratoPrev);
		}

		return listaManuaisExtratoPrev;
	}

	public void setListaManuaisExtratoPrev(List<ProcessoExtratoPrevDTO> listaManuaisExtratoPrev) {
		this.listaManuaisExtratoPrev = listaManuaisExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaDisponivelExtratoPrev() {
		listaDisponivelExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaDisponivelExtratoPrev = this.processoExtratoPrevBO.filtrarListaDisponivelExtraoPrev(listaTodosExtratoPrev);

			for (ProcessoExtratoPrevDTO disponivel : listaDisponivelExtratoPrev) {
				this.processoExtratoPrevBO.verificaExtratoCompleto(disponivel, this.listaExtratoCompleto);
			}
		}

		return listaDisponivelExtratoPrev;
	}

	public void setListaDisponivelExtratoPrev(List<ProcessoExtratoPrevDTO> listaDisponivelExtratoPrev) {
		this.listaDisponivelExtratoPrev = listaDisponivelExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaVistoWebExtratoPrev() {
		listaVistoWebExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaVistoWebExtratoPrev = this.processoExtratoPrevBO.filtrarListaVistoWebExtraoPrev(listaTodosExtratoPrev);
		}

		return listaVistoWebExtratoPrev;
	}

	public void setListaVistoWebExtratoPrev(List<ProcessoExtratoPrevDTO> listaVistoWebExtratoPrev) {
		this.listaVistoWebExtratoPrev = listaVistoWebExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaImprimirExtratoPrev() {
		listaImprimirExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaImprimirExtratoPrev = this.processoExtratoPrevBO.filtrarListaImprimirExtraoPrev(listaTodosExtratoPrev);

			for (ProcessoExtratoPrevDTO imprimir : listaImprimirExtratoPrev) {
				this.processoExtratoPrevBO.verificaExtratoCompleto(imprimir, this.listaExtratoCompleto);
			}
		}

		return listaImprimirExtratoPrev;
	}

	public void setListaImprimirExtratoPrev(List<ProcessoExtratoPrevDTO> listaImprimirExtratoPrev) {
		this.listaImprimirExtratoPrev = listaImprimirExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaEnviadoExtratoPrev() {
		listaEnviadoExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaEnviadoExtratoPrev = this.processoExtratoPrevBO.filtrarListaEnviadoExtraoPrev(listaTodosExtratoPrev);
			this.observacaoImprimir = null;
			this.checkImprimir = false;
		}

		return listaEnviadoExtratoPrev;
	}

	public void setListaEnviadoExtratoPrev(List<ProcessoExtratoPrevDTO> listaEnviadoExtratoPrev) {
		this.listaEnviadoExtratoPrev = listaEnviadoExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaArNaoRecExtratoPrev() {
		listaArNaoRecExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaArNaoRecExtratoPrev = this.processoExtratoPrevBO.filtrarListaArNaoRecExtraoPrev(listaTodosExtratoPrev);
		}

		return listaArNaoRecExtratoPrev;
	}

	public void setListaArNaoRecExtratoPrev(List<ProcessoExtratoPrevDTO> listaArNaoRecExtratoPrev) {
		this.listaArNaoRecExtratoPrev = listaArNaoRecExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaArRecExtratoPrev() {
		listaArRecExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaArRecExtratoPrev = this.processoExtratoPrevBO.filtrarListaArRecExtraoPrev(listaTodosExtratoPrev);
		}

		return listaArRecExtratoPrev;
	}

	public void setListaArRecExtratoPrev(List<ProcessoExtratoPrevDTO> listaArRecExtratoPrev) {
		this.listaArRecExtratoPrev = listaArRecExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaEncerradoExtratoPrev() {
		listaEncerradoExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaEncerradoExtratoPrev = this.processoExtratoPrevBO.filtrarListaEncerradoRecExtraoPrev(listaTodosExtratoPrev);
		}

		return listaEncerradoExtratoPrev;
	}

	public void setListaEncerradoExtratoPrev(List<ProcessoExtratoPrevDTO> listaEncerradoExtratoPrev) {
		this.listaEncerradoExtratoPrev = listaEncerradoExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaAcimaPrazoExtratoPrev() {
		listaAcimaPrazoExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaAcimaPrazoExtratoPrev = this.processoExtratoPrevBO.filtrarListaAcimaPrazoExtraoPrev(listaTodosExtratoPrev);
		}

		return listaAcimaPrazoExtratoPrev;
	}

	public void setListaAcimaPrazoExtratoPrev(List<ProcessoExtratoPrevDTO> listaAcimaPrazoExtratoPrev) {
		this.listaAcimaPrazoExtratoPrev = listaAcimaPrazoExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaNaoGeradoExtratoPrev() {
		listaNaoGeradoExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaNaoGeradoExtratoPrev = this.processoExtratoPrevBO.filtrarListaNaoGeradoExtraoPrev(listaTodosExtratoPrev);
		}

		return listaNaoGeradoExtratoPrev;
	}

	public void setListaNaoGeradoExtratoPrev(List<ProcessoExtratoPrevDTO> listaNaoGeradoExtratoPrev) {
		this.listaNaoGeradoExtratoPrev = listaNaoGeradoExtratoPrev;
	}

	public List<ProcessoExtratoPrevDTO> getListaFinalizadoExtratoPrev() {
		listaFinalizadoExtratoPrev = new ArrayList<ProcessoExtratoPrevDTO>();

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaTodosExtratoPrev)) {
			listaFinalizadoExtratoPrev = this.processoExtratoPrevBO.filtrarListaFinalizadoExtraoPrev(listaTodosExtratoPrev);
		} else {

		}

		return listaFinalizadoExtratoPrev;
	}

	public void setListaFinalizadoExtratoPrev(List<ProcessoExtratoPrevDTO> listaFinalizadoExtratoPrev) {
		this.listaFinalizadoExtratoPrev = listaFinalizadoExtratoPrev;
	}

	public List<ProcessoExtratoPrevDesligadosDTO> getListaDesligadosExtratoPrev() {
		return listaDesligadosExtratoPrev;
	}

	public void setListaDesligadosExtratoPrev(List<ProcessoExtratoPrevDesligadosDTO> listaDesligadosExtratoPrev) {
		this.listaDesligadosExtratoPrev = listaDesligadosExtratoPrev;
	}

	public List<ProcessoExtratoPrevIndevidoDTO> getListaIndevidosExtratoPrev() {
		if (UtilJava.isColecaoVazia(listaIndevidosExtratoPrev) && !this.limparForm) {
			listaIndevidosExtratoPrev = new ArrayList<ProcessoExtratoPrevIndevidoDTO>(this.processoExtratoPrevBO.listarProcessoExtratoIndevidos(
					this.entidadeParticipante != null ? this.entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante() : null,
					this.participante != null ? this.participante.getCodigo() : null,
					this.planoPrevidencia != null ? this.planoPrevidencia.getPlanoGuardaChuva().getCodigo() : null));
		} else {
			listaIndevidosExtratoPrev = new ArrayList<ProcessoExtratoPrevIndevidoDTO>();
		}

		return listaIndevidosExtratoPrev;
	}

	public String exportarRelatorioExtratoToApi(ExtratoPrevRequestDTO request) {
		try {
			ProcessoExtratoPrevDTO extrato = this.processoExtratoPrevBO.listarAtualProcessoExtratoPrev(null, request.getCodigoEntidade(), request.getCodigoPlano())
					.stream()
					.filter(e -> e.getValido().equals("S"))
					.findFirst().get();
			
			this.valoresComuns = new ValoresComunRelatorioExtratoPrevDTO();

			ExtratoPrev extratoPrev = this.extratoPrevBO.buscarExtratoPrevPorCodigo(extrato.getNumeroExtratoPrev());

			List<ApresentacaoExtratoPrevDTO> listaApresentacaoExtratoPrev = this.montarRelatorioApresentacao(extratoPrev);
			List<CorpoExtratoPrevDTO> listaDadosGeraisExtratoPrev = this.montarRelatorioExtratoPrev(extratoPrev);
			List<TermoExtratoPrevDTO> listaTermoOpcaoExtratoPrev = this.montarRelatorioTermoExtratoPrev(extratoPrev, listaDadosGeraisExtratoPrev);

			boolean mostrarTermo = extratoPrev.getParticipante().getSituacaoParticipante().getCodigo().equalsIgnoreCase("09") && extratoPrev.getIndValido().equalsIgnoreCase("S");

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = context.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

			parametros.put("logo", logo);
			parametros.put("mostrarTermo", mostrarTermo);
			parametros.put("listaApresentacaoExtratoPrev", listaApresentacaoExtratoPrev);
			parametros.put("listaDadosGeraisExtratoPrev", listaDadosGeraisExtratoPrev);
			parametros.put("listaTermoOpcaoExtratoPrev", listaTermoOpcaoExtratoPrev);
			
			
			return relatorioUtil.gerarRelatorio("extratoPrevidenciario", new ArrayList<>(), parametros);

		} catch (Exception e) {
			throw new PrevidenciaException(e);
		}
	}

	public void setListaIndevidosExtratoPrev(List<ProcessoExtratoPrevIndevidoDTO> listaIndevidosExtratoPrev) {
		this.listaIndevidosExtratoPrev = listaIndevidosExtratoPrev;
	}

	public int getActiveIndex() {
		return activeIndex;
	}

	public void setActiveIndex(int activeIndex) {
		this.activeIndex = activeIndex;
	}

	public List<ProcessoExtratoPrevDTO> getListaManualExtratoPrevSelect() {
		return listaManualExtratoPrevSelect;
	}

	public void setListaManualExtratoPrevSelect(List<ProcessoExtratoPrevDTO> listaManualExtratoPrevSelect) {
		this.listaManualExtratoPrevSelect = listaManualExtratoPrevSelect;
	}

	public String getObservacaoManual() {
		return observacaoManual;
	}

	public void setObservacaoManual(String observacaoManual) {
		this.observacaoManual = observacaoManual;
	}

	public List<ProcessoExtratoPrevDTO> getListaDisponivelExtratoPrevSelect() {
		return listaDisponivelExtratoPrevSelect;
	}

	public void setListaDisponivelExtratoPrevSelect(List<ProcessoExtratoPrevDTO> listaDisponivelExtratoPrevSelect) {
		this.listaDisponivelExtratoPrevSelect = listaDisponivelExtratoPrevSelect;
	}

	public String getObservacaoDisponivel() {
		return observacaoDisponivel;
	}

	public void setObservacaoDisponivel(String observacaoDisponivel) {
		this.observacaoDisponivel = observacaoDisponivel;
	}

	public List<ProcessoExtratoPrevDTO> getListaVistoWebExtratoPrevSelect() {
		return listaVistoWebExtratoPrevSelect;
	}

	public void setListaVistoWebExtratoPrevSelect(List<ProcessoExtratoPrevDTO> listaVistoWebExtratoPrevSelect) {
		this.listaVistoWebExtratoPrevSelect = listaVistoWebExtratoPrevSelect;
	}

	public String getObservacaoVistoWeb() {
		return observacaoVistoWeb;
	}

	public void setObservacaoVistoWeb(String observacaoVistoWeb) {
		this.observacaoVistoWeb = observacaoVistoWeb;
	}

	public List<ProcessoExtratoPrevDTO> getListaImprimirExtratoPrevSelect() {
		return listaImprimirExtratoPrevSelect;
	}

	public void setListaImprimirExtratoPrevSelect(List<ProcessoExtratoPrevDTO> listaImprimirExtratoPrevSelect) {
		this.listaImprimirExtratoPrevSelect = listaImprimirExtratoPrevSelect;
	}

	public String getObservacaoImprimir() {
		return observacaoImprimir;
	}

	public void setObservacaoImprimir(String observacaoImprimir) {
		this.observacaoImprimir = observacaoImprimir;
	}

	public List<ProcessoExtratoPrevDTO> getListaEnviadoExtratoPrevSelect() {
		return listaEnviadoExtratoPrevSelect;
	}

	public void setListaEnviadoExtratoPrevSelect(List<ProcessoExtratoPrevDTO> listaEnviadoExtratoPrevSelect) {
		this.listaEnviadoExtratoPrevSelect = listaEnviadoExtratoPrevSelect;
	}

	public String getObservacaoEnviado() {
		return observacaoEnviado;
	}

	public void setObservacaoEnviado(String observacaoEnviado) {
		this.observacaoEnviado = observacaoEnviado;
	}

	public Date getDataEnviado() {
		return dataEnviado;
	}

	public void setDataEnviado(Date dataEnviado) {
		this.dataEnviado = dataEnviado;
	}

	public boolean isCheckImprimir() {
		return checkImprimir;
	}

	public void setCheckImprimir(boolean checkImprimir) {
		this.checkImprimir = checkImprimir;
	}

	public ExcelOptions getXlsOptions() {
		return xlsOptions;
	}

	public void setXlsOptions(ExcelOptions xlsOptions) {
		this.xlsOptions = xlsOptions;
	}

	public List<ProcessoExtratoPrevDTO> getListaArNaoRecExtratoSelect() {
		return listaArNaoRecExtratoSelect;
	}

	public void setListaArNaoRecExtratoSelect(List<ProcessoExtratoPrevDTO> listaArNaoRecExtratoSelect) {
		this.listaArNaoRecExtratoSelect = listaArNaoRecExtratoSelect;
	}

	public String getObservacaoNaoRecebido() {
		return observacaoNaoRecebido;
	}

	public void setObservacaoNaoRecebido(String observacaoNaoRecebido) {
		this.observacaoNaoRecebido = observacaoNaoRecebido;
	}

	public Date getDataArNaoRecebido() {
		return dataArNaoRecebido;
	}

	public void setDataArNaoRecebido(Date dataArNaoRecebido) {
		this.dataArNaoRecebido = dataArNaoRecebido;
	}

	public List<ProcessoExtratoPrevDTO> getListaArRecExtratoSelect() {
		return listaArRecExtratoSelect;
	}

	public void setListaArRecExtratoSelect(List<ProcessoExtratoPrevDTO> listaArRecExtratoSelect) {
		this.listaArRecExtratoSelect = listaArRecExtratoSelect;
	}

	public String getObservacaoRecebido() {
		return observacaoRecebido;
	}

	public void setObservacaoRecebido(String observacaoRecebido) {
		this.observacaoRecebido = observacaoRecebido;
	}

	public Date getDataArRecebido() {
		return dataArRecebido;
	}

	public void setDataArRecebido(Date dataArRecebido) {
		this.dataArRecebido = dataArRecebido;
	}

	public List<ProcessoExtratoPrevDTO> getListaEncerradoExtratoSelect() {
		return listaEncerradoExtratoSelect;
	}

	public void setListaEncerradoExtratoSelect(List<ProcessoExtratoPrevDTO> listaEncerradoExtratoSelect) {
		this.listaEncerradoExtratoSelect = listaEncerradoExtratoSelect;
	}

	public ProcessoExtratoPrevDTO getResumoProcessoExtrato() {
		return resumoProcessoExtrato;
	}

	public void setResumoProcessoExtrato(ProcessoExtratoPrevDTO resumoProcessoExtrato) {
		this.resumoProcessoExtrato = resumoProcessoExtrato;
	}

	public boolean isLimparForm() {
		return limparForm;
	}

	public void setLimparForm(boolean limparForm) {
		this.limparForm = limparForm;
	}

	public List<ExtratoCompletoDTO> getListaExtratoCompleto() {
		return listaExtratoCompleto;
	}

	public void setListaExtratoCompleto(List<ExtratoCompletoDTO> listaExtratoCompleto) {
		this.listaExtratoCompleto = listaExtratoCompleto;
	}

	public SituacaoExtratoPrev getSituacaoExtratoPrev() {
		return situacaoExtratoPrev;
	}

	public void setSituacaoExtratoPrev(SituacaoExtratoPrev situacaoExtratoPrev) {
		this.situacaoExtratoPrev = situacaoExtratoPrev;
	}

	public MotivoExtratoPrev getMotivoExtratoPrev() {
		return motivoExtratoPrev;
	}

	public void setMotivoExtratoPrev(MotivoExtratoPrev motivoExtratoPrev) {
		this.motivoExtratoPrev = motivoExtratoPrev;
	}

	public List<ProcessoExtratoPrev> getListaProcessoExtratoPrev() {
		return listaProcessoExtratoPrev;
	}

	public void setListaProcessoExtratoPrev(List<ProcessoExtratoPrev> listaProcessoExtratoPrev) {
		this.listaProcessoExtratoPrev = listaProcessoExtratoPrev;
	}

	public List<ObservacaoProcessoExtratoPrev> getListaObservacoes() {
		return listaObservacoes;
	}

	public void setListaObservacoes(List<ObservacaoProcessoExtratoPrev> listaObservacoes) {
		this.listaObservacoes = listaObservacoes;
	}

}
