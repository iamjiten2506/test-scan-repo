package br.com.bbprevidencia.devolucao.enumerador;

public enum LayoutEnum {

	COAF("COAF", layoutCoaf());

	private String codigo;
	private String descricao;

	private LayoutEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	private static String layoutCoaf() {

		StringBuilder sb = new StringBuilder();
		sb.append("<OCORRENCIA>\n");
		sb.append("<NumOcorrencia>${numeroOcorrencia}</NumOcorrencia>\n");
		sb.append("<CPFCNPJCom>${cnpj}</CPFCNPJCom>\n");
		sb.append("<DtInicio>${dataInicio}</DtInicio>\n");
		sb.append("<DtFim>${dataFim}</DtFim>\n");
		sb.append("<AgNum></AgNum>\n");
		sb.append("<AgNome></AgNome>\n");
		sb.append("<AgMun>${municipio}</AgMun>\n");
		sb.append("<AgUF>${uf}</AgUF>\n");
		sb.append("<Det>${descricao}</Det>\n");
		sb.append("<VlCred>${credito}</VlCred>\n");
		sb.append("<VlDeb>${debito}</VlDeb>\n");
		sb.append("<VlProv>${valorProv}</VlProv>\n");
		sb.append("<VlProp>${valorProp}</VlProp>\n");
		sb.append("<ENQUADRAMENTOS>\n");
		sb.append("<CodEnq>${codigoEnquadramento}</CodEnq>\n");
		sb.append("</ENQUADRAMENTOS>\n");
		sb.append("<ENVOLVIDOS>\n");
		sb.append("<ENVOLVIDO>\n");
		sb.append("<CPFCNPJEnv>${cpf}</CPFCNPJEnv>\n");
		sb.append("<NmEnv>${nome}</NmEnv>\n");
		sb.append("<TpEnv>1</TpEnv>\n");
		sb.append("<AgNumEnv></AgNumEnv>\n");
		sb.append("<AgNomeEnv></AgNomeEnv>\n");
		sb.append("<NumConta></NumConta>\n");
		sb.append("<DtAbConta></DtAbConta>\n");
		sb.append("<DtAtuaCad></DtAtuaCad>\n");
		sb.append("<PObrigada>0</PObrigada>\n");
		sb.append("<PEP>0</PEP>\n");
		sb.append("<ServPub>0</ServPub>\n");
		sb.append("</ENVOLVIDO>\n");
		sb.append("</ENVOLVIDOS>\n");
		sb.append("</OCORRENCIA>\n");

		return sb.toString();
	}
}