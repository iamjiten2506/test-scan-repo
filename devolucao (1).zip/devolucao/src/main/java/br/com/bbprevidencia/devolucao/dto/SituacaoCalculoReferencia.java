package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   02/05/2018
 * Classe de persistência para tabela SITUACAO_REF_CALC_DR.
 */
@Entity
@Table(name = "SITUACAO_REF_CALC_DR")
@NamedQuery(name = "SituacaoCalculoReferencia.findAll", query = "SELECT q FROM SituacaoCalculoReferencia q")
public class SituacaoCalculoReferencia implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SITUACAO_REF_CALC_DR_GER", sequenceName = "S_SITUACAO_FOLHA_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SITUACAO_REF_CALC_DR_GER")
	@Column(name = "NUM_SEQ_SIT_REF_CALC_DR")
	private Long codigo;

	@Column(name = "NOM_SIT_REF_CALC_DR")
	private String nome;

	@Column(name = "IND_PERMITE_CALCULO")
	private String indicadorPermiteCalculo;

	@Column(name = "NUM_APRESENTACAO")
	private Long ordemApresentacao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTER")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCL")
	private Date dataInclusao;

	@Column(name = "NOM_USU_ALTER")
	private String nomeUsuarioAlteracao;

	@Column(name = "NOM_USU_INCL")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIndicadorPermiteCalculo() {
		return indicadorPermiteCalculo;
	}

	public void setIndicadorPermiteCalculo(String indicadorPermiteCalculo) {
		this.indicadorPermiteCalculo = indicadorPermiteCalculo;
	}

	public Long getOrdemApresentacao() {
		return ordemApresentacao;
	}

	public void setOrdemApresentacao(Long ordemApresentacao) {
		this.ordemApresentacao = ordemApresentacao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SituacaoCalculoReferencia other = (SituacaoCalculoReferencia) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SituacaoCalculoReferencia [codigo=");
		builder.append(codigo);
		builder.append(", nome=");
		builder.append(nome);
		builder.append(", indicadorPermiteCalculo=");
		builder.append(indicadorPermiteCalculo);
		builder.append(", ordemApresentacao=");
		builder.append(ordemApresentacao);
		builder.append(", dataAlteracao=");
		builder.append(dataAlteracao);
		builder.append(", dataInclusao=");
		builder.append(dataInclusao);
		builder.append(", nomeUsuarioAlteracao=");
		builder.append(nomeUsuarioAlteracao);
		builder.append(", nomeUsuarioInclusao=");
		builder.append(nomeUsuarioInclusao);
		builder.append("]");
		return builder.toString();
	}

}