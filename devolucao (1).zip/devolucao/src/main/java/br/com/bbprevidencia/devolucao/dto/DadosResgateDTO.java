package br.com.bbprevidencia.devolucao.dto;

public class DadosResgateDTO {

	private String nomePlano;
	private Double valorResgatavel;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public Double getValorResgatavel() {
		return valorResgatavel;
	}

	public void setValorResgatavel(Double valorResgatavel) {
		this.valorResgatavel = valorResgatavel;
	}

}
