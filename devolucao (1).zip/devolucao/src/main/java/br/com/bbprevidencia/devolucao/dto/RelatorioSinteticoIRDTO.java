package br.com.bbprevidencia.devolucao.dto;

public class RelatorioSinteticoIRDTO {
	private String codigoRetencao;

	private String tipoRetencao;

	private String dataRetencao;

	private Double valorRetencao;

	private String codigoNaturezaRendimento;

	public String getCodigoRetencao() {
		return codigoRetencao;
	}

	public void setCodigoRetencao(String codigoRetencao) {
		this.codigoRetencao = codigoRetencao;
	}

	public String getTipoRetencao() {
		return tipoRetencao;
	}

	public void setTipoRetencao(String tipoRetencao) {
		this.tipoRetencao = tipoRetencao;
	}

	public String getDataRetencao() {
		return dataRetencao;
	}

	public void setDataRetencao(String dataRetencao) {
		this.dataRetencao = dataRetencao;
	}

	public Double getValorRetencao() {
		return valorRetencao;
	}

	public void setValorRetencao(Double valorRetencao) {
		this.valorRetencao = valorRetencao;
	}

	public String getCodigoNaturezaRendimento() {
		return codigoNaturezaRendimento;
	}

	public void setCodigoNaturezaRendimento(String codigoNaturezaRendimento) {
		this.codigoNaturezaRendimento = codigoNaturezaRendimento;
	}

}
