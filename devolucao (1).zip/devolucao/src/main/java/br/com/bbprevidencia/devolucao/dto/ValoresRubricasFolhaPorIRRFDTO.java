package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   03/01/2017
 * Classe para utilização em filtragem de objetos de ParcelaContaDevolucao.
 */
public class ValoresRubricasFolhaPorIRRFDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double valorTotalDevolucaoProgressivo;
	private Double valorTotalDevolucaoRegressivo;
	private Double valorTotalIRRFDevolucaoProgressivo;
	private Double valorTotalIRRFDevolucaoRegressivo;
	private Double qtdTotalDevolucaoProgressivo;
	private Double qtdTotalDevolucaoRegressivo;

	public Double getValorTotalDevolucaoProgressivo() {
		return valorTotalDevolucaoProgressivo;
	}

	public void setValorTotalDevolucaoProgressivo(Double valorTotalDevolucaoProgressivo) {
		this.valorTotalDevolucaoProgressivo = valorTotalDevolucaoProgressivo;
	}

	public Double getValorTotalDevolucaoRegressivo() {
		return valorTotalDevolucaoRegressivo;
	}

	public void setValorTotalDevolucaoRegressivo(Double valorTotalDevolucaoRegressivo) {
		this.valorTotalDevolucaoRegressivo = valorTotalDevolucaoRegressivo;
	}

	public Double getValorTotalIRRFDevolucaoProgressivo() {
		return valorTotalIRRFDevolucaoProgressivo;
	}

	public void setValorTotalIRRFDevolucaoProgressivo(Double valorTotalIRRFDevolucaoProgressivo) {
		this.valorTotalIRRFDevolucaoProgressivo = valorTotalIRRFDevolucaoProgressivo;
	}

	public Double getValorTotalIRRFDevolucaoRegressivo() {
		return valorTotalIRRFDevolucaoRegressivo;
	}

	public void setValorTotalIRRFDevolucaoRegressivo(Double valorTotalIRRFDevolucaoRegressivo) {
		this.valorTotalIRRFDevolucaoRegressivo = valorTotalIRRFDevolucaoRegressivo;
	}

	public Double getQtdTotalDevolucaoProgressivo() {
		return qtdTotalDevolucaoProgressivo;
	}

	public void setQtdTotalDevolucaoProgressivo(Double qtdTotalDevolucaoProgressivo) {
		this.qtdTotalDevolucaoProgressivo = qtdTotalDevolucaoProgressivo;
	}

	public Double getQtdTotalDevolucaoRegressivo() {
		return qtdTotalDevolucaoRegressivo;
	}

	public void setQtdTotalDevolucaoRegressivo(Double qtdTotalDevolucaoRegressivo) {
		this.qtdTotalDevolucaoRegressivo = qtdTotalDevolucaoRegressivo;
	}

}