package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;

/**
 * Classe de persistência para tabela PAR_INT_CON_FIN_DEV.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   24/01/2017
 * 
 */
@Entity
@Table(name = "PAR_INT_CON_FIN_DEV", schema = "OWN_DCR")
@NamedQuery(name = "ParametroIntegracaoContabilFinanceiraDevolucao.findAll", query = "SELECT q FROM ParametroIntegracaoContabilFinanceiraDevolucao q")
public class ParametroIntegracaoContabilFinanceiraDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PAR_INT_CON_FIN_DEV_GER", sequenceName = "S_PICID_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PAR_INT_CON_FIN_DEV_GER")
	@Column(name = "NUM_SEQ_PAR_INT_CON_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV")
	private RubricaDevolucao rubricaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLANO")
	private PlanoPrevidencia planoPrevidencia;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_CON")
	private OperacaoInterna operacaoInternaContabil;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_TES")
	private OperacaoInterna operacaoInternaTesouraria;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public OperacaoInterna getOperacaoInternaContabil() {
		return operacaoInternaContabil;
	}

	public void setOperacaoInternaContabil(OperacaoInterna operacaoInternaContabil) {
		this.operacaoInternaContabil = operacaoInternaContabil;
	}

	public OperacaoInterna getOperacaoInternaTesouraria() {
		return operacaoInternaTesouraria;
	}

	public void setOperacaoInternaTesouraria(OperacaoInterna operacaoInternaTesouraria) {
		this.operacaoInternaTesouraria = operacaoInternaTesouraria;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

}
