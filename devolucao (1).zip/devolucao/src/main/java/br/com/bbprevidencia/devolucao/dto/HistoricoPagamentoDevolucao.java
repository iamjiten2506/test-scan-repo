package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * Classe de persistência para tabela HST_PGT_DEV.
 */
@Entity
@Table(name = "HST_PGT_DEV", schema = "OWN_DCR")
@NamedQuery(name = "HistoricoPagamentoDevolucao.findAll", query = "SELECT q FROM HistoricoPagamentoDevolucao q")
public class HistoricoPagamentoDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "HST_PGT_DEV_GER", sequenceName = "S_HPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "HST_PGT_DEV_GER")
	@Column(name = "NUM_SEQ_HIS_PAG_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CRO_DEV")
	private CronogramaDevolucao cronogramaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RECEBEDOR")
	private Recebedor recebedor;

	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "COD_PESSOA"), @JoinColumn(name = "COD_AREA_ATUA") })
	private AtuacaoPessoa atuacaoPessoa;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV")
	private RubricaDevolucao rubricaDevolucao;

	//@ManyToOne
	@Column(name = "NUM_SEQ_PERFIL_INVEST")
	private Long codigoPerfilInvest;// PerfilInvestimento perfilInvestimento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_COT")
	private Date dataCota;

	@Column(name = "QTD_COT_RUB")
	private Double qtdCotaRubrica;

	@Column(name = "VAL_RUB")
	private double valorRubrica;

	@Column(name = "VAL_COT")
	private double valorCota;

	@Column(name = "VAL_IND_AJU")
	private double valorIndiceAjusta;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private int totalParcelas;

	public HistoricoPagamentoDevolucao(Devolucao devolucao, CronogramaDevolucao cronogramaDevolucao, Recebedor recebedor, AtuacaoPessoa atuacaoPessoa, RubricaDevolucao rubricaDevolucao,
	/*PerfilInvestimento perfilInvestimento*/Long codigoPerfilInvest, Date dataCota, Double qtdCotaRubrica, double valorRubrica, double valorCota, double valorIndiceAjusta, Date dataInclusao,
			String nomeUsuarioInclusao) {
		super();
		this.devolucao = devolucao;
		this.cronogramaDevolucao = cronogramaDevolucao;
		this.recebedor = recebedor;
		this.atuacaoPessoa = atuacaoPessoa;
		this.rubricaDevolucao = rubricaDevolucao;
		this.codigoPerfilInvest = codigoPerfilInvest;
		this.dataCota = dataCota;
		this.qtdCotaRubrica = qtdCotaRubrica;
		this.valorRubrica = valorRubrica;
		this.valorCota = valorCota;
		this.valorIndiceAjusta = valorIndiceAjusta;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public HistoricoPagamentoDevolucao() {
		super();
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	/*public PerfilInvestimento getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(PerfilInvestimento perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}*/

	public Date getDataCota() {
		return dataCota;
	}

	public Long getCodigoPerfilInvest() {
		return codigoPerfilInvest;
	}

	public void setCodigoPerfilInvest(Long codigoPerfilInvest) {
		this.codigoPerfilInvest = codigoPerfilInvest;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Double getQtdCotaRubrica() {
		return qtdCotaRubrica;
	}

	public void setQtdCotaRubrica(Double qtdCotaRubrica) {
		this.qtdCotaRubrica = qtdCotaRubrica;
	}

	public double getValorRubrica() {
		return valorRubrica;
	}

	public void setValorRubrica(double valorRubrica) {
		this.valorRubrica = valorRubrica;
	}

	public double getValorCota() {
		return valorCota;
	}

	public void setValorCota(double valorCota) {
		this.valorCota = valorCota;
	}

	public double getValorIndiceAjusta() {
		return valorIndiceAjusta;
	}

	public void setValorIndiceAjusta(double valorIndiceAjusta) {
		this.valorIndiceAjusta = valorIndiceAjusta;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public int getTotalParcelas() {
		return totalParcelas;
	}

	public void setTotalParcelas(int totalParcelas) {
		this.totalParcelas = totalParcelas;
	}

}
