package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
public class RelatorioHistoricoPagamentosFichaDevolucaoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "NUM_SEQ_CRONOGRAMA_FOLHA")
	private Long codigo;

	@Column(name = "NOM_TIPO_FOLHA")
	private String tipoFolha;

	@Column(name = "DAT_REFCIA")
	@Temporal(TemporalType.DATE)
	private Date dataReferencia;

	@Column(name = "DAT_COTA")
	@Temporal(TemporalType.DATE)
	private Date dataCota;

	@Column(name = "NUM_SEQ_PARTIC_PLANO")
	private Long codigoParticipantePlano;

	@Column(name = "NUM_SEQ_TIPO_FOLHA")
	private Long codigoTipoFolha;

	@Column(name = "NUM_MATRIC_PATROC")
	private String matricula;

	@Column(name = "NOM_PARTIC")
	private String participante;

	@Column(name = "QTD_COTA_UTIL")
	private Double qtdCotaUtil;

	@Column(name = "QTD_TOTAL_RESTANTE")
	private Double qtdTotalRestante;

	@Column(name = "QTD_TOTAL")
	private Double qtdTotal;

	@Column(name = "NOM_ABREV_ENTID_PARTIC")
	private String patrocinadora;

	@Column(name = "NOM_PLANO")
	private String plano;

	@Column(name = "NUM_SEQ_ENTID_PARTIC")
	private Long codigoPatrocinadora;

	@Column(name = "NUM_SEQ_PLANO")
	private Long codigoPlano;

	@Column(name = "NUM_SEQ_FUNDO_PREVD")
	private Long codigoFundo;

	@Column(name = "NUM_SEQ_PERFIL_INVEST")
	private Long codigoPerfilInvestimento;

	@Column(name = "QTD_TOTAL_AMAIOR")
	private Double qtdTotalAmaior;

	@Transient
	private Double valorCota;

	@Transient
	private Double valorReais;

	@Transient
	private Double saldoAtualCotas;

	@Transient
	private Double valorUltimoPgto;

	@Column(name = "dat_credito_bancario")
	@Temporal(TemporalType.DATE)
	private Date dataCreditoBancario;

	@Column(name = "val_cota_concessao")
	private Double valorCotaConcessao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getTipoFolha() {
		return tipoFolha;
	}

	public void setTipoFolha(String tipoFolha) {
		this.tipoFolha = tipoFolha;
	}

	public Date getDataReferencia() {
		return dataReferencia;
	}

	public void setDataReferencia(Date dataReferencia) {
		this.dataReferencia = dataReferencia;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Long getCodigoParticipantePlano() {
		return codigoParticipantePlano;
	}

	public void setCodigoParticipantePlano(Long codigoParticipantePlano) {
		this.codigoParticipantePlano = codigoParticipantePlano;
	}

	public Long getCodigoTipoFolha() {
		return codigoTipoFolha;
	}

	public void setCodigoTipoFolha(Long codigoTipoFolha) {
		this.codigoTipoFolha = codigoTipoFolha;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getParticipante() {
		return participante;
	}

	public void setParticipante(String participante) {
		this.participante = participante;
	}

	public Double getQtdCotaUtil() {
		return qtdCotaUtil;
	}

	public void setQtdCotaUtil(Double qtdCotaUtil) {
		this.qtdCotaUtil = qtdCotaUtil;
	}

	public Double getQtdTotalRestante() {
		return qtdTotalRestante;
	}

	public void setQtdTotalRestante(Double qtdTotalRestante) {
		this.qtdTotalRestante = qtdTotalRestante;
	}

	public Double getQtdTotal() {
		return qtdTotal;
	}

	public void setQtdTotal(Double qtdTotal) {
		this.qtdTotal = qtdTotal;
	}

	public String getPatrocinadora() {
		return patrocinadora;
	}

	public void setPatrocinadora(String patrocinadora) {
		this.patrocinadora = patrocinadora;
	}

	public String getPlano() {
		return plano;
	}

	public void setPlano(String plano) {
		this.plano = plano;
	}

	public Long getCodigoPatrocinadora() {
		return codigoPatrocinadora;
	}

	public void setCodigoPatrocinadora(Long codigoPatrocinadora) {
		this.codigoPatrocinadora = codigoPatrocinadora;
	}

	public Long getCodigoPlano() {
		return codigoPlano;
	}

	public void setCodigoPlano(Long codigoPlano) {
		this.codigoPlano = codigoPlano;
	}

	public Long getCodigoFundo() {
		return codigoFundo;
	}

	public void setCodigoFundo(Long codigoFundo) {
		this.codigoFundo = codigoFundo;
	}

	public Long getCodigoPerfilInvestimento() {
		return codigoPerfilInvestimento;
	}

	public void setCodigoPerfilInvestimento(Long codigoPerfilInvestimento) {
		this.codigoPerfilInvestimento = codigoPerfilInvestimento;
	}

	public Double getQtdTotalAmaior() {
		return qtdTotalAmaior;
	}

	public void setQtdTotalAmaior(Double qtdTotalAmaior) {
		this.qtdTotalAmaior = qtdTotalAmaior;
	}

	public Double getValorCota() {
		return valorCota;
	}

	public void setValorCota(Double valorCota) {
		this.valorCota = valorCota;
	}

	public Double getValorReais() {
		return valorReais;
	}

	public void setValorReais(Double valorReais) {
		this.valorReais = valorReais;
	}

	public Double getSaldoAtualCotas() {
		return saldoAtualCotas;
	}

	public void setSaldoAtualCotas(Double saldoAtualCotas) {
		this.saldoAtualCotas = saldoAtualCotas;
	}

	public Date getDataCreditoBancario() {
		return dataCreditoBancario;
	}

	public void setDataCreditoBancario(Date dataCreditoBancario) {
		this.dataCreditoBancario = dataCreditoBancario;
	}

	public Double getValorCotaConcessao() {
		return valorCotaConcessao;
	}

	public void setValorCotaConcessao(Double valorCotaConcessao) {
		this.valorCotaConcessao = valorCotaConcessao;
	}

	public Double getValorUltimoPgto() {
		return valorUltimoPgto;
	}

	public void setValorUltimoPgto(Double valorUltimoPgto) {
		this.valorUltimoPgto = valorUltimoPgto;
	}

}
