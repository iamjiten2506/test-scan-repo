package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   01/12/2016
 * Classe de persistência para tabela PLA_VIG_DEV.
 */
@Entity
@Table(name = "PLANO_VIGENCIA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "PlanoVigenciaDevolucao.findAll", query = "SELECT q FROM PlanoVigenciaDevolucao q")
public class PlanoVigenciaDevolucao implements Serializable, BaseEntity, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PLA_VIG_DEV_GER", sequenceName = "S_PVD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PLA_VIG_DEV_GER")
	@Column(name = "NUM_SEQ_PLA_VIG_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLANO")
	private PlanoPrevidencia planoPrevidencia;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INI")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FIM")
	private Date dataFim;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@OneToMany(mappedBy = "planoVigenciaDevolucao", fetch = FetchType.EAGER, targetEntity = RegraDevolucao.class)
	private List<RegraDevolucao> listaRegraDevolucao = new ArrayList<RegraDevolucao>();

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public List<RegraDevolucao> getListaRegraDevolucao() {
		return listaRegraDevolucao;
	}

	public void setListaRegraDevolucao(List<RegraDevolucao> listaRegraDevolucao) {
		this.listaRegraDevolucao = listaRegraDevolucao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlanoVigenciaDevolucao other = (PlanoVigenciaDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public PlanoVigenciaDevolucao clone() throws CloneNotSupportedException {
		return (PlanoVigenciaDevolucao) super.clone();
	}

}