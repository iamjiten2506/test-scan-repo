package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoContribuicaoBO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoContribuicao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter as Regras de Cálculo de Contribuicao
 * 
 * @author  BBPF0415 - Yanisley Mora  Ritchie
 * @since 08/08/2018
 * 
 *        Copyright notice (c) 2018 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("regraCalculoTempoContribuicaoVisao")
public class RegraCalculoTempoContribuicaoVisao {

	private static final String FW_REGRA_CALC_TEMPO_CON = "/paginas/regraCalculoTempoContribuicao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private RegraCalculoTempoContribuicaoBO regraCalculoTempoContribuicaoBO;

	private List<RegraCalculoTempoContribuicao> listaRegraCalculoTempoContribuicao;

	private RegraCalculoTempoContribuicao regraCalculoTempoContribuicao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página das Regras de Cálculo Tempo Contribuicao
	 * @author  BBPF0415 - Yanisley Mora  Ritchie
	 * @since 26/01/2017
	 * @return {@link String}
	 */
	public String inciciarRegraCalculoTempoContribuicao() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("regraCalculoTempoContribuicao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.regraCalculoTempoContribuicao = null;

		this.listarStatus = true;

		listaRegraCalculoTempoContribuicao = new ArrayList<RegraCalculoTempoContribuicao>(regraCalculoTempoContribuicaoBO.listarRegraCalculoTempoContribuicao());

		return FW_REGRA_CALC_TEMPO_CON;
	}

	public List<RegraCalculoTempoContribuicao> getListaRegraCalculoTempoContribuicao() {
		return listaRegraCalculoTempoContribuicao;
	}

	public void setListaRegraCalculoTempoContribuicao(List<RegraCalculoTempoContribuicao> listaRegraCalculoTempoContribuicao) {
		this.listaRegraCalculoTempoContribuicao = listaRegraCalculoTempoContribuicao;
	}

	public RegraCalculoTempoContribuicao getRegraCalculoTempoContribuicao() {
		return regraCalculoTempoContribuicao;
	}

	public void setRegraCalculoTempoContribuicao(RegraCalculoTempoContribuicao regraCalculoTempoContribuicao) {
		this.regraCalculoTempoContribuicao = regraCalculoTempoContribuicao;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

}
