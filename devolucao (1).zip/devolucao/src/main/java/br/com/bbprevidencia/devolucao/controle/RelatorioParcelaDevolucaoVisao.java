package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioParcelaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório de parcelas de devolução
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 30/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioParcelaDevolucaoVisao")
public class RelatorioParcelaDevolucaoVisao {

	private static final String FW_RELATORIO_PARCELA_DEVOLUCAO = "/paginas/relatorioParcelaDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioPagamentoFolhaVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;
	@Autowired
	RelatorioUtil relatorioUtil;

	private boolean selecionarParticipante;

	private boolean selecionarPlano;

	private EntidadeParticipante entidadeParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;
	private List<TipoDevolucao> listaTipoDevolucao;
	private List<TipoDevolucao> listaTipoDevolucaoSelecionados;

	private PlanoPrevidencia planoPrevidencia;
	private Participante participante;

	private String tipoParcelamento;
	private List<String> listaStatusPagamento = new ArrayList<String>();

	/**
	 * Método encarregado de chamar a página de preenchimento de parâmetros
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 * @return
	 */
	public String iniciarRelatorioParcelaDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_PARCELA_DEVOLUCAO;
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 */
	private void setarValoresIniciais() {
		this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBO.listarTodosTipoDevolucao());
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.entidadeParticipanteBO.listarEntidadeParticipanteOrderByNome());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();

		this.selecionarParticipante = false;
		this.selecionarPlano = false;
		this.tipoParcelamento = "P";
		this.listaStatusPagamento.clear();
		this.listaStatusPagamento.add("S");

		setarVisaoMultiEmpresa();

	}

	private void setarVisaoMultiEmpresa() {
		this.selecionarPlano = false;
		this.selecionarParticipante = false;
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
		this.entidadeParticipante = new EntidadeParticipante();
		this.planoPrevidencia = new PlanoPrevidencia();
		this.participante = new Participante();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 */
	public void verificaListaPatrocinadora() {
		try {
			if (UtilJava.isColecaoVazia(this.listaEntidadeParticipanteSelecionadas)) {
				setarVisaoMultiEmpresa();
			} else {
				if (this.listaEntidadeParticipanteSelecionadas.size() == 1) {
					this.selecionarPlano = true;

					this.entidadeParticipante = this.listaEntidadeParticipanteSelecionadas.get(0);
					this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante);
				} else {
					setarVisaoMultiEmpresa();
				}
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 */
	public void verificaListaPlano() {
		try {
			if (UtilJava.isColecaoVazia(this.listaPlanoPrevidenciaSelecionados)) {
				this.selecionarParticipante = false;
			} else {
				if (this.listaPlanoPrevidenciaSelecionados.size() == 1) {
					this.selecionarParticipante = true;

					this.planoPrevidencia = this.listaPlanoPrevidenciaSelecionados.get(0);
				} else {
					this.selecionarParticipante = false;
				}
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo digitado no autocomplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() == null) {
			setParticipante(new Participante());
		}
	}

	public void limparPesquisa() {
		setarValoresIniciais();
	}

	public void exportarRelatorio(ActionEvent event) {
		try {
			String idEnviado = event.getComponent().getId();

			List<RelatorioParcelaDevolucaoDTO> relatorioParcelaDevolucao = new ArrayList<RelatorioParcelaDevolucaoDTO>();

			relatorioParcelaDevolucao.addAll(this.parcelaContaDevolucaoBO.relatorioParcelaDevolucao(
					this.listaEntidadeParticipanteSelecionadas,
					this.listaPlanoPrevidenciaSelecionados,
					this.participante,
					this.listaTipoDevolucaoSelecionados,
					this.tipoParcelamento,
					this.listaStatusPagamento));

			if (UtilJava.isColecaoVazia(relatorioParcelaDevolucao)) {
				Mensagens.addMsgInfo("Não foram encontradas informações para estes parâmetros!");
			} else {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);

				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(relatorioParcelaDevolucao);
				//GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "relatorioParcelaDevolucao", dataSource);

				String nomeArquivo = relatorioUtil.gerarRelatorio("relatorioParcelaDevolucao", relatorioParcelaDevolucao, parametros);
				relatorioUtil.abrirPoupUp(nomeArquivo);
			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro("Erro ao exportar relatório.");
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	public boolean isSelecionarParticipante() {
		return selecionarParticipante;
	}

	public void setSelecionarParticipante(boolean selecionarPatrocinadora) {
		this.selecionarParticipante = selecionarPatrocinadora;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public List<TipoDevolucao> getListaTipoDevolucaoSelecionados() {
		return listaTipoDevolucaoSelecionados;
	}

	public void setListaTipoDevolucaoSelecionados(List<TipoDevolucao> listaTipoDevolucaoSelecionados) {
		this.listaTipoDevolucaoSelecionados = listaTipoDevolucaoSelecionados;
	}

	public String getTipoParcelamento() {
		return tipoParcelamento;
	}

	public void setTipoParcelamento(String tipoParcelamento) {
		this.tipoParcelamento = tipoParcelamento;
	}

	public List<String> getListaStatusPagamento() {
		return listaStatusPagamento;
	}

	public void setListaStatusPagamento(List<String> listaStatusPagamento) {
		this.listaStatusPagamento = listaStatusPagamento;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

}
