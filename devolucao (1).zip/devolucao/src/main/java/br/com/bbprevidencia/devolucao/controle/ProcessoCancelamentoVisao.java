package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.adminsistemas.bo.FuncionalidadeUnidadeFuncionarioBO;
import br.com.bbprevidencia.adminsistemas.dto.FuncionalidadeUnidadeFuncionario;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipantePK;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoAlcadaBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.MovimentoAlcada;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author BBPF0333 - Daniel Martins
 * @since 24/01/2017
 *
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("processoCancelamentoVisao")
public class ProcessoCancelamentoVisao {

	private static String FW_PROCESSO_CANCELAMENTO = "/paginas/processoCancelamento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(ProcessoCancelamentoVisao.class);

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private MovimentoAlcadaBO movimentoAlcadaBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;

	@Autowired
	private FuncionalidadeUnidadeFuncionarioBO funcionalidadeUnidadeFuncionarioBO;

	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	private Long codigoEntidadeParticipante;

	private List<Devolucao> listaDevolucao;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<SelectItem> listaEntidadeParticipante;

	private List<SelectItem> listaTipoDevolucao;

	private List<Participante> listaParticipante;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private Participante participante;

	private CronogramaDevolucao cronogramaDevolucao;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private TipoDevolucao tipoDevolucao;

	private String indicadorTipoDevolucao;

	private String numeroMatriculaPatrocinadora;

	private boolean patrocinadoraEditavel;

	private Long codigoTipoDevolucao;

	private AnotacaoDevolucao anotacaoDevolucao;

	private DevolucaoCompletoDTO devolucaoCalculoCompleto;

	private Devolucao devolucao;

	private SituacaoDevolucaoEnum situacaoDevolucaoEnum;

	private HistoricoSituacaoDevolucao historicoSituacaoDevolucao;

	/**
	 * Método encarredado por iniciar a página
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 24/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		} else {
			this.possuiAcessoTotal = false;
		}

		limparFormularioPesquisa();
		this.listaEntidadeParticipante = listarEntidadeParticipante();
		this.listaTipoDevolucao = listarTipoDevolucao();
		return FW_PROCESSO_CANCELAMENTO;
	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo inicial
	 * de pesquisa
	 * 
	 * @author BBPF0170 - Magson Dias
	 * @since 26/01/2017
	 */
	public void limparFormularioPesquisa() {
		this.patrocinadoraEditavel = true;
		this.listarStatus = true;

		this.planoPrevidencia = new PlanoPrevidencia();
		this.listaPlanoPrevidencia = null;
		this.codigoEntidadeParticipante = null;
		this.entidadeParticipante = null;
		this.listaEntidadeParticipante = null;
		this.setParticipante(new Participante());
		this.participante = new Participante();
		this.listaParticipante = null;

		this.listaDevolucao = null;
		this.indicadorTipoDevolucao = null;
		this.tipoDevolucao = null;
		this.codigoTipoDevolucao = null;

	}

	/**
	 * Retorna o estado inicial da página
	 * 
	 * @author BBPF0170 - Magson
	 * @since 17/02/2017
	 * @return {@link String}
	 */
	public String limparPesquisa() {
		// this.setParticipante(null);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove(participante);
		PrimeFaces.current().resetInputs("formProcessoDevCanc");
		limparFormularioPesquisa();
		return iniciarTela();
	}

	/**
	 * Adiciona a mensage de erro no faces.
	 * 
	 * @param mensagem
	 */
	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

	/**
	 * Método responsável por listar todos os tipos de devoluções
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2017
	 * @return
	 */
	public List<SelectItem> listarTipoDevolucao() {
		List<SelectItem> itens = new ArrayList<SelectItem>();

		List<TipoDevolucao> listaTipoDevolucaoTemp = tipoDevolucaoBO.listarTodosTipoDevolucao();
		if (!UtilJava.isColecaoVazia(listaTipoDevolucaoTemp)) {
			for (TipoDevolucao tipoDev : listaTipoDevolucaoTemp) {
				itens.add(new SelectItem(tipoDev.getCodigo(), tipoDev.getNome()));
			}
		}

		return itens;
	}

	// Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 26/01/2017
	 */
	public void limpaSelecao() {
		this.setCronogramaDevolucao(null);
		this.setEntidadeParticipante(null);
		this.setPlanoPrevidencia(null);
		this.setTipoDevolucao(null);
		this.setNumeroMatriculaPatrocinadora(null);
	}

	/**
	 * Método responsável por retornar a lista de Planos associados à patrocionadora
	 * selecionada.
	 * 
	 * @author BBPF00170
	 * @since 20/02/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return {@link String}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {

		// Limapdo os valores antigos à pesquisa
		setPlanoPrevidencia(null);
		setListaPlanoPrevidencia(null);
		setParticipante(new Participante());
		setListaParticipante(null);
		// setIndicadorTipoDevolucao(null);

		if (this.getCodigoEntidadeParticipante() == null) {
			this.setListaPlanoPrevidencia(new ArrayList<PlanoPrevidencia>());
		} else {
			try {
				EntidadeParticipantePK chavePrimaria = new EntidadeParticipantePK();
				chavePrimaria.setCodigoEntidadeParticipante(getCodigoEntidadeParticipante());
				chavePrimaria.setCodigoFundoPrevidencia(1L);

				EntidadeParticipante entidadeParticipante = new EntidadeParticipante();
				entidadeParticipante.setChavePrimaria(chavePrimaria);

				this.setEntidadeParticipante(entidadeParticipante);

				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante()));

				if (!UtilJava.isColecaoVazia(this.listaPlanoPrevidencia)) {
					if (this.devolucaoBO.consultarDevolucaoPorPlanoPrevidenciaNaoCancelados(this.listaPlanoPrevidencia) == null) {
						addMsgErro("Lista de Devolução estar Vazia..");
						return "";
					}
					this.listaDevolucao = new ArrayList<Devolucao>(this.devolucaoBO.consultarDevolucaoPorPlanoPrevidenciaNaoCancelados(this.listaPlanoPrevidencia));
				}

			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}

		return FW_PROCESSO_CANCELAMENTO;
	}

	/**
	 * Método responsável por setar o Plano escolhido no select do plano
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link SelectEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Cria uma lista de itens da entidade participante.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return
	 */
	public List<SelectItem> listarEntidadeParticipante() {
		List<SelectItem> itens = new ArrayList<SelectItem>();

		List<EntidadeParticipante> listaPatrocinadora = entidadeParticipanteBO.listarEntidadeParticipante();
		if (!UtilJava.isColecaoVazia(listaPatrocinadora)) {
			for (EntidadeParticipante entidadeParticipante : listaPatrocinadora) {
				itens.add(new SelectItem(entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante(), entidadeParticipante.getNomeAbreviadoEntidadeParticipante()));
			}
		}

		return itens;
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo
	 * digitado no autocomplete
	 * 
	 * @author BBPF0170 - MAGSON
	 * @param {@link String nome }
	 * @return {@link List<Participante>}
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link event}
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (!UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("participante", getParticipante());
		} else {
			setParticipante(new Participante());
		}
	}

	/**
	 * Método para retornar o processo de devolução
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 20/02/2017
	 * @param {@link event}
	 * @return {@link String}
	 */
	public String pesquisarDevolucaoParticipante() {
		if (this.getEntidadeParticipante() != null && this.getPlanoPrevidencia() != null && this.getParticipante() != null) {
			ParticipantePlano participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(), this.getPlanoPrevidencia());
			// TipoDevolucao tipoDevolucao =
			// tipoDevolucaoBO.pesquisarTipoDevolucaoPorCodigo(this.getCodigoTipoDevolucao());

			this.listaDevolucao = this.devolucaoBO.pesquisarDevolucaoPorParticipanteSituacaoMenorPago(participantePlano);
		}
		return FW_PROCESSO_CANCELAMENTO;
	}

	/**
	 * Método para retornar o processo de devolução
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 21/02/2017
	 * @param {@link event}
	 * @return {@link String}
	 */
	public String pesquisarDevolucaoParticipante(AjaxBehaviorEvent event) {

		if (this.getEntidadeParticipante() != null && this.getPlanoPrevidencia() != null && this.getParticipante() != null) {

			ParticipantePlano participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(), this.getPlanoPrevidencia());
			TipoDevolucao tipoDevolucao = tipoDevolucaoBO.pesquisarTipoDevolucaoPorCodigo(this.getCodigoTipoDevolucao());
			// this.listaDevolucao =
			// this.devolucaoBO.pesquisarDevolucaoPorParticipantePlanoPorSituacao(participantePlano,
			// tipoDevolucao);
		}
		return FW_PROCESSO_CANCELAMENTO;
	}

	/**
	 * Método responsável de incluir novas Anotações de Devolução
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 21/02/2017
	 * @param {@link Devolucao}
	 */
	public void incluirAnotacaoDevolucao(Devolucao devolucao) {
		if (this.anotacaoDevolucao.getDataAnotacao() == null) {
			this.anotacaoDevolucao.setDataAnotacao(new Date());
		}

		if (this.anotacaoDevolucao.getDescricaoAnotacao() != null) {
			this.anotacaoDevolucao = anotacaoDevolucaoBO.gerarAnotacaoDevolucao(devolucao, this.anotacaoDevolucao.getDescricaoAnotacao(), this.anotacaoDevolucao.getDataAnotacao(), loginTemporariaDTO);

			/*
			 * Metodo para atualizar na base alterando a situação para cancelado.
			 */
			cancelamentoDevolucao(devolucao);

			/*
			 * Faz anotação referente a alteração da situaçaõ de uma devolução.
			 */
			anotacaoDevolucaoBO.salvarAnotacaoDevolucao(this.anotacaoDevolucao);
			Mensagens.addMsgInfo("Porcesso de cancelamento realizado com sucesso!");
			PrimeFaces.current().executeScript("PF('cadastrarAnotacao').hide()");
		}
		this.anotacaoDevolucao = null;
		this.devolucao = null;

		if (!UtilJava.isColecaoVazia(this.devolucaoBO.consultarDevolucaoPorPlanoPrevidenciaNaoCancelados(this.listaPlanoPrevidencia))) {
			this.listaDevolucao = new ArrayList<Devolucao>(this.devolucaoBO.consultarDevolucaoPorPlanoPrevidenciaNaoCancelados(this.listaPlanoPrevidencia));
		} else {
			this.listaDevolucao = new ArrayList<Devolucao>();
		}

		// oncomplete="PF('cadastrarAnotacao').hide()"
	}

	/**
	 * Método responsável para fazer o cancelamento da devolução.
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 21/02/2017
	 * @param {@link Devolucao}
	 */
	public void cancelamentoDevolucao(Devolucao devolucao) {
		SituacaoDevolucao situacao = new SituacaoDevolucao();
		situacao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(situacaoDevolucaoEnum.CANCELADO.getCodigo());

		Devolucao devolucaoNovo = this.devolucaoBO.pesquisarDevolucaoPorCodigo(devolucao.getCodigo());

		if (devolucaoNovo.getCodigo() != null) {
			devolucaoNovo.setSituacaoDevolucao(situacao);
			devolucaoNovo.setDataAlteracao(new Date());
			devolucaoNovo.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			List<FuncionalidadeUnidadeFuncionario> funcionalidade = funcionalidadeUnidadeFuncionarioBO.pesquisarFuncionalidadeUnidadeFuncionarioPorMatricula(Long.valueOf(loginTemporariaDTO
					.getUsuarioSessao().getDescricaoLogin().replaceAll("[^0-9]", "")));

			Long codigoFuncionalidade = funcionalidade.size() > 0 ? funcionalidade.get(0).getFuncionalidade().getCodigo() : 1L;
			/*
			 * Atualiza a entidade devolucao com a nova situação (CANCELADO.)
			 */
			devolucaoBO.salvarDevolucao(devolucaoNovo);
			if (devolucao.getMovimentoAlcada() != null)
				movimentoAlcadaBO.salvarCancelamentoMovimentoAlcada(consultarMovimentoAlcada(devolucao.getMovimentoAlcada()), this.anotacaoDevolucao.getDescricaoAnotacao(), codigoFuncionalidade);
			/*
			 * Inclui historico de alteração da situação, passa o Objeto devolucao antigo,
			 * salvando histórico.
			 */
			incluiiHistoricoSituacaoDevoluca(devolucao);

			pesquisarDevolucaoParticipante();
		}

	}

	private MovimentoAlcada consultarMovimentoAlcada(Long codigoMovimento) {
		return movimentoAlcadaBO.buscarMovimento(codigoMovimento);
	}

	/**
	 * Método responsável de incluir novo histórico situação devolução.
	 * 
	 * @author BBPF0170 - MAGSON
	 * @since 21/02/2017
	 * @param {@link Devolucao}
	 */
	public void incluiiHistoricoSituacaoDevoluca(Devolucao devolucao) {
		this.historicoSituacaoDevolucao = historicoSituacaoDevolucaoBO.gerarHistoricoSituacaoDevolucao(devolucao);
		historicoSituacaoDevolucaoBO.salvarHistoricoSituacaoDevolucao(historicoSituacaoDevolucao);

	}

	/**
	 * Método responsável pro carregas o Obejto devolução no modal de Anotações
	 * 
	 * @author BBPF0170 - MAGSON
	 * @since 21/02/2017
	 * @param {@link Devolucao}
	 * @return {@link String}
	 */

	public String modalAnotacao(Devolucao devolucao) {
		this.devolucao = devolucao;
		return "";
	}

	public CronogramaDevolucaoBO getCronogramaDevolucaoBO() {
		return cronogramaDevolucaoBO;
	}

	public void setCronogramaDevolucaoBO(CronogramaDevolucaoBO cronogramaDevolucaoBO) {
		this.cronogramaDevolucaoBO = cronogramaDevolucaoBO;
	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public TipoDevolucaoBO getTipoDevolucaoBO() {
		return tipoDevolucaoBO;
	}

	public void setTipoDevolucaoBO(TipoDevolucaoBO tipoDevolucaoBO) {
		this.tipoDevolucaoBO = tipoDevolucaoBO;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	// public List<EntidadeParticipante> getListaEntidadeParticipante() {
	// return listaEntidadeParticipante;
	// }

	// public void setListaEntidadeParticipante(List<EntidadeParticipante>
	// listaEntidadeParticipante) {
	// this.listaEntidadeParticipante = listaEntidadeParticipante;
	// }

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<SelectItem> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<SelectItem> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public String getNumeroMatriculaPatrocinadora() {
		return numeroMatriculaPatrocinadora;
	}

	public void setNumeroMatriculaPatrocinadora(String numeroMatriculaPatrocinadora) {
		this.numeroMatriculaPatrocinadora = numeroMatriculaPatrocinadora;
	}

	public Long getCodigoEntidadeParticipante() {
		return codigoEntidadeParticipante;
	}

	public void setCodigoEntidadeParticipante(Long codigoEntidadeParticipante) {
		this.codigoEntidadeParticipante = codigoEntidadeParticipante;
	}

	public ParticipanteBO getParticipanteBO() {
		return participanteBO;
	}

	public void setParticipanteBO(ParticipanteBO participanteBO) {
		this.participanteBO = participanteBO;
	}

	public ParticipantePlanoBO getParticipantePlanoBO() {
		return participantePlanoBO;
	}

	public void setParticipantePlanoBO(ParticipantePlanoBO participantePlanoBO) {
		this.participantePlanoBO = participantePlanoBO;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public String getIndicadorTipoDevolucao() {
		return indicadorTipoDevolucao;
	}

	public void setIndicadorTipoDevolucao(String indicadorTipoDevolucao) {
		this.indicadorTipoDevolucao = indicadorTipoDevolucao;
	}

	public boolean isPatrocinadoraEditavel() {
		return patrocinadoraEditavel;
	}

	public void setPatrocinadoraEditavel(boolean patrocinadoraEditavel) {
		this.patrocinadoraEditavel = patrocinadoraEditavel;
	}

	public List<SelectItem> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<SelectItem> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	public DevolucaoBO getDevolucaoBO() {
		return devolucaoBO;
	}

	public void setDevolucaoBO(DevolucaoBO devolucaoBO) {
		this.devolucaoBO = devolucaoBO;
	}

	public Long getCodigoTipoDevolucao() {
		return codigoTipoDevolucao;
	}

	public void setCodigoTipoDevolucao(Long codigoTipoDevolucao) {
		this.codigoTipoDevolucao = codigoTipoDevolucao;
	}

	public AnotacaoDevolucao getAnotacaoDevolucao() {
		if (this.anotacaoDevolucao == null) {
			this.anotacaoDevolucao = new AnotacaoDevolucao();
		}
		return anotacaoDevolucao;
	}

	public void setAnotacaoDevolucao(AnotacaoDevolucao anotacaoDevolucao) {
		this.anotacaoDevolucao = anotacaoDevolucao;
	}

	public DevolucaoCompletoDTO getDevolucaoCalculoCompleto() {
		return devolucaoCalculoCompleto;
	}

	public void setDevolucaoCalculoCompleto(DevolucaoCompletoDTO devolucaoCalculoCompleto) {
		this.devolucaoCalculoCompleto = devolucaoCalculoCompleto;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public SituacaoDevolucaoBO getSituacaoDevolucaoBO() {
		return situacaoDevolucaoBO;
	}

	public void setSituacaoDevolucaoBO(SituacaoDevolucaoBO situacaoDevolucaoBO) {
		this.situacaoDevolucaoBO = situacaoDevolucaoBO;
	}

	public SituacaoDevolucaoEnum getSituacaoDevolucaoEnum() {
		return situacaoDevolucaoEnum;
	}

	public void setSituacaoDevolucaoEnum(SituacaoDevolucaoEnum situacaoDevolucaoEnum) {
		this.situacaoDevolucaoEnum = situacaoDevolucaoEnum;
	}

	public HistoricoSituacaoDevolucaoBO getHistoricoSituacaoDevolucaoBO() {
		return historicoSituacaoDevolucaoBO;
	}

	public void setHistoricoSituacaoDevolucaoBO(HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO) {
		this.historicoSituacaoDevolucaoBO = historicoSituacaoDevolucaoBO;
	}

	public HistoricoSituacaoDevolucao getHistoricoSituacaoDevolucao() {
		return historicoSituacaoDevolucao;
	}

	public void setHistoricoSituacaoDevolucao(HistoricoSituacaoDevolucao historicoSituacaoDevolucao) {
		this.historicoSituacaoDevolucao = historicoSituacaoDevolucao;
	}

}
