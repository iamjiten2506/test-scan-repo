package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;

/**
 * Classe de persistência para tabela ENT_PAR_TIP_FOL_DEV.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * 
 */
@Entity
@Table(name = "ENT_PAR_TIP_FOL_DEV", schema = "OWN_DCR")
@NamedQuery(name = "EntidadeParticipanteTipoFolhaDevolucao.findAll", query = "SELECT q FROM EntidadeParticipanteTipoFolhaDevolucao q")
public class EntidadeParticipanteTipoFolhaDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "ENT_PAR_TIP_FOL_DEV_GER", sequenceName = "S_EPTFD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ENT_PAR_TIP_FOL_DEV_GER")
	@Column(name = "NUM_SEQ_ENT_PAR_TIP_FOL_DEV")
	private Long codigo;

	//@NotNull(message = "Tipo de Folha: Favor selecionar um tipo de Folha.")
	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_FOLHA_DEV")
	private TipoFolhaDevolucao tipoFolhaDevolucao;

	//@NotNull(message = "Patrocinadora: Favor selecionar uma Patrocinadora.")
	@JoinColumns( { @JoinColumn(name = "NUM_SEQ_ENTID_PARTIC"), @JoinColumn(name = "NUM_SEQ_FUNDO_PREVD") })
	@ManyToOne
	private EntidadeParticipante entidadeParticipante;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public TipoFolhaDevolucao getTipoFolhaDevolucao() {
		return tipoFolhaDevolucao;
	}

	public void setTipoFolhaDevolucao(TipoFolhaDevolucao tipoFolhaDevolucao) {
		this.tipoFolhaDevolucao = tipoFolhaDevolucao;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((dataAlteracao == null) ? 0 : dataAlteracao.hashCode());
		result = prime * result + ((dataInclusao == null) ? 0 : dataInclusao.hashCode());
		result = prime * result + ((entidadeParticipante == null) ? 0 : entidadeParticipante.hashCode());
		result = prime * result + ((nomeUsuarioAlteracao == null) ? 0 : nomeUsuarioAlteracao.hashCode());
		result = prime * result + ((nomeUsuarioInclusao == null) ? 0 : nomeUsuarioInclusao.hashCode());
		result = prime * result + ((tipoFolhaDevolucao == null) ? 0 : tipoFolhaDevolucao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EntidadeParticipanteTipoFolhaDevolucao other = (EntidadeParticipanteTipoFolhaDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (dataAlteracao == null) {
			if (other.dataAlteracao != null)
				return false;
		} else if (!dataAlteracao.equals(other.dataAlteracao))
			return false;
		if (dataInclusao == null) {
			if (other.dataInclusao != null)
				return false;
		} else if (!dataInclusao.equals(other.dataInclusao))
			return false;
		if (entidadeParticipante == null) {
			if (other.entidadeParticipante != null)
				return false;
		} else if (!entidadeParticipante.equals(other.entidadeParticipante))
			return false;
		if (nomeUsuarioAlteracao == null) {
			if (other.nomeUsuarioAlteracao != null)
				return false;
		} else if (!nomeUsuarioAlteracao.equals(other.nomeUsuarioAlteracao))
			return false;
		if (nomeUsuarioInclusao == null) {
			if (other.nomeUsuarioInclusao != null)
				return false;
		} else if (!nomeUsuarioInclusao.equals(other.nomeUsuarioInclusao))
			return false;
		if (tipoFolhaDevolucao == null) {
			if (other.tipoFolhaDevolucao != null)
				return false;
		} else if (!tipoFolhaDevolucao.equals(other.tipoFolhaDevolucao))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EntidadeParticipanteTipoFolhaDevolucao [codigo=" + codigo + ", tipoFolhaDevolucao=" + tipoFolhaDevolucao + ", entidadeParticipante=" + entidadeParticipante + ", dataAlteracao="
				+ dataAlteracao + ", dataInclusao=" + dataInclusao + ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + "]";
	}

}