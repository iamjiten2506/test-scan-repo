package br.com.bbprevidencia.devolucao.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import br.com.bbprevidencia.bbpcomum.util.FabricaManagedBean;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.indice.bo.IndiceEconomicoBO;
import br.com.bbprevidencia.indice.dto.IndiceEconomico;

@FacesConverter(value = "indiceEconomicoConverter")
public class IndiceEconomicoConverter implements Converter {

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
	 */
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String valor) {
		try {

			if (!UtilJava.isStringVazia(valor)) {
				return consultarPorChavePrimaria(valor);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public String getAsString(FacesContext context, UIComponent component, Object obj) {
		if (obj != null && obj instanceof IndiceEconomico) {

			IndiceEconomico indiceEconomico = (IndiceEconomico) obj;

			if (indiceEconomico.getCodigoIndiceEconomico() != null) {
				return indiceEconomico.getCodigoIndiceEconomico().toString();
			}
		}
		return null;
	}

	/**
	 * Consulta pessoa através da chave passada como argumento.
	 *
	 * @author  BBPF0333 - Daniel Martins
	 * @since   28/03/2017
	 * @param   codigoIndiceEconomico
	 * @return  IndiceEconomico
	 */
	public IndiceEconomico consultarPorChavePrimaria(String codigoIndiceEconomico) {

		IndiceEconomico indiceEconomicoRetorno = null;

		if (codigoIndiceEconomico != null) {

			IndiceEconomicoBO IndiceEconomicoBO = (IndiceEconomicoBO) FabricaManagedBean.getManagedBean(IndiceEconomicoBO.class);

			try {
				indiceEconomicoRetorno = IndiceEconomicoBO.consultarPorCodigoIndiceEconomico(codigoIndiceEconomico);
			} catch (Exception e) {
			}
		}
		return indiceEconomicoRetorno;
	}

}
