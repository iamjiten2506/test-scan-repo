package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
public class RecebedorDepDTO {
	private Long codigo;
	private Long codigoParticipante;
	private String nomeRecebedor;
	//    private String grauParentesco;
	private Long codigoGrauParentesco;
	//    private String dataNascimentoRecebedor;
	private String sexoRecebedor;
	//    private String invalidezDependente;
	//    private String dependenteIR;
	private BigDecimal percentualRateioIndividual;
	private Long valorPercentual;
	private String cpf;
	//    private String dataFimDependente;
	private Double percentualDependente;
	private Date dataNascimento;
	private String tipoConta;
	private Long codBanco;
	private String nomeBanco;
	private Long codAgencia;
	private Long codConta;
	private String digConta;

	public RecebedorDepDTO() {
		this.codigo = 0L;
		this.codigoParticipante = 0L;
		this.nomeRecebedor = "";
		this.codigoGrauParentesco = 0L;
		this.sexoRecebedor = "";
		this.percentualRateioIndividual = BigDecimal.ZERO;
		this.valorPercentual = 0L;
		this.cpf = "";
		this.percentualDependente = 0D;
		this.dataNascimento = null;
		this.tipoConta = "";
		this.codBanco = 0L;
		this.nomeBanco = "";
		this.codAgencia = 0L;
		this.codConta = 0L;
		//this.digConta = 0L;
	}

	public boolean isPercentualIndividual() {
		return this.percentualRateioIndividual != null && this.percentualRateioIndividual.intValue() > 0;
	}
}
