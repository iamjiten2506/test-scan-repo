package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

@Entity
@Table(name = "MOVIMENTO_ALCADA", schema = "OWN_SAD")
//@NamedQuery(name = "MovimentoAlcada.findAll", query = "SELECT q FROM MovimentoAlcada q")
public class MovimentoAlcada implements Serializable, BaseEntity {

	private static final long serialVersionUID = 5559006800512894667L;

	@Id
	@Column(name = "NUM_SEQ_MOV_ALC")
	private Long codigo;

	@Column(name = "NUM_SEQ_LOT_PRO_ALC")
	private Long codigoProcessamentoLote;

	@Column(name = "NUM_SEQ_TP_PRO_ALC")
	private Long codigoTipoProcessoAlcada;

	@Column(name = "COD_UNID_ORGANZ")
	private Long codigoUnidadeOrganizacional;

	@Column(name = "COD_CON_01")
	private String controle1;

	@Column(name = "COD_CON_02")
	private String controle2;

	@Column(name = "COD_CON_03")
	private String controle3;

	@Column(name = "COD_CHAVE_ORI")
	private String chaveOrigem;

	@Column(name = "VLR_MOV_ALC")
	private BigDecimal valorMovimentoAlcada;

	@Column(name = "IND_AUT_COM")
	private String autorizacaoCompleta;

	// Número sequencial de funcionalidade unidade funcionario BBP de indeferimento
	@Column(name = "NUM_SEQ_FUN_UNI_ORG_FUN_BBP")
	private Long funcionalidadeUnidadeFuncionarioIndeferimento;

	@Column(name = "DSC_IND")
	private String descricaoIndeferimento;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusaoRegistro;

	@Column(name = "COD_USU_INC_REG")
	private String codigoUsuarioInclusaoRegistro;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracaoRegistro;

	@Column(name = "COD_USU_ALT_REG")
	private String codigoUsuarioAlteracaoRegistro;

	@Column(name = "NUM_SEQ_ARQ_ANE")
	private Long codigoArquivoAnexo;

	@Column(name = "DSC_MOV")
	private String descricaoMovimento;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Long getCodigoProcessamentoLote() {
		return codigoProcessamentoLote;
	}

	public void setCodigoProcessamentoLote(Long codigoProcessamentoLote) {
		this.codigoProcessamentoLote = codigoProcessamentoLote;
	}

	public Long getCodigoTipoProcessoAlcada() {
		return codigoTipoProcessoAlcada;
	}

	public void setCodigoTipoProcessoAlcada(Long codigoTipoProcessoAlcada) {
		this.codigoTipoProcessoAlcada = codigoTipoProcessoAlcada;
	}

	public Long getCodigoUnidadeOrganizacional() {
		return codigoUnidadeOrganizacional;
	}

	public void setCodigoUnidadeOrganizacional(Long codigoUnidadeOrganizacional) {
		this.codigoUnidadeOrganizacional = codigoUnidadeOrganizacional;
	}

	public String getControle1() {
		return controle1;
	}

	public void setControle1(String controle1) {
		this.controle1 = controle1;
	}

	public String getControle2() {
		return controle2;
	}

	public void setControle2(String controle2) {
		this.controle2 = controle2;
	}

	public String getControle3() {
		return controle3;
	}

	public void setControle3(String controle3) {
		this.controle3 = controle3;
	}

	public String getChaveOrigem() {
		return chaveOrigem;
	}

	public void setChaveOrigem(String chaveOrigem) {
		this.chaveOrigem = chaveOrigem;
	}

	public BigDecimal getValorMovimentoAlcada() {
		return valorMovimentoAlcada;
	}

	public void setValorMovimentoAlcada(BigDecimal valorMovimentoAlcada) {
		this.valorMovimentoAlcada = valorMovimentoAlcada;
	}

	public String getAutorizacaoCompleta() {
		return autorizacaoCompleta;
	}

	public void setAutorizacaoCompleta(String autorizacaoCompleta) {
		this.autorizacaoCompleta = autorizacaoCompleta;
	}

	public Long getFuncionalidadeUnidadeFuncionarioIndeferimento() {
		return funcionalidadeUnidadeFuncionarioIndeferimento;
	}

	public void setFuncionalidadeUnidadeFuncionarioIndeferimento(Long funcionalidadeUnidadeFuncionarioIndeferimento) {
		this.funcionalidadeUnidadeFuncionarioIndeferimento = funcionalidadeUnidadeFuncionarioIndeferimento;
	}

	public String getDescricaoIndeferimento() {
		return descricaoIndeferimento;
	}

	public void setDescricaoIndeferimento(String descricaoIndeferimento) {
		this.descricaoIndeferimento = descricaoIndeferimento;
	}

	public Date getDataInclusaoRegistro() {
		return dataInclusaoRegistro;
	}

	public void setDataInclusaoRegistro(Date dataInclusaoRegistro) {
		this.dataInclusaoRegistro = dataInclusaoRegistro;
	}

	public String getCodigoUsuarioInclusaoRegistro() {
		return codigoUsuarioInclusaoRegistro;
	}

	public void setCodigoUsuarioInclusaoRegistro(String codigoUsuarioInclusaoRegistro) {
		this.codigoUsuarioInclusaoRegistro = codigoUsuarioInclusaoRegistro;
	}

	public Date getDataAlteracaoRegistro() {
		return dataAlteracaoRegistro;
	}

	public void setDataAlteracaoRegistro(Date dataAlteracaoRegistro) {
		this.dataAlteracaoRegistro = dataAlteracaoRegistro;
	}

	public String getCodigoUsuarioAlteracaoRegistro() {
		return codigoUsuarioAlteracaoRegistro;
	}

	public void setCodigoUsuarioAlteracaoRegistro(String codigoUsuarioAlteracaoRegistro) {
		this.codigoUsuarioAlteracaoRegistro = codigoUsuarioAlteracaoRegistro;
	}

	public Long getCodigoArquivoAnexo() {
		return codigoArquivoAnexo;
	}

	public void setCodigoArquivoAnexo(Long codigoArquivoAnexo) {
		this.codigoArquivoAnexo = codigoArquivoAnexo;
	}

	public String getDescricaoMovimento() {
		return descricaoMovimento;
	}

	public void setDescricaoMovimento(String descricaoMovimento) {
		this.descricaoMovimento = descricaoMovimento;
	}

}
