package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

import br.com.bbprevidencia.cadastroweb.dto.HistoricoFinanceiroPago;

public class DevolucaoContribRegraValorDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double qtdContribPartic;
	private Double qtdContribJurosPartic;
	private Double qtdContribMultaPartic;
	private Double qtdContribCorrecaoPartic;
	private Double percentualDevolucaoPartic;

	private Double qtdContribEmp;
	private Double qtdContribJurosEmp;
	private Double qtdContribMultaEmp;
	private Double qtdContribCorrecaoEmp;
	private Double percentualDevolucaoEmp;

	private Double qtdContribParticEmp;
	private Double qtdContribJurosParticEmp;
	private Double qtdContribMultaParticEmp;
	private Double qtdContribCorrecaoParticEmp;
	private Double percentualDevolucaoParticEmp;

	private Double qtdTotalDevolucaoPartic;
	private Double qtdTotalDevolucaoEmp;
	private Double qtdTotalDevolucaoParticEmp;

	private Double qtdContribParticReversao;
	private Double qtdContribJurosParticReversao;
	private Double qtdContribMultaParticReversao;
	private Double qtdContribCorrecaoParticReversao;
	private Double percentualDevolucaoParticReversao;

	private Double qtdContribEmpReversao;
	private Double qtdContribJurosEmpReversao;
	private Double qtdContribMultaEmpReversao;
	private Double qtdContribCorrecaoEmpReversao;
	private Double percentualDevolucaoEmpReversao;

	private Double qtdContribParticEmpReversao;
	private Double qtdContribJurosParticEmpReversao;
	private Double qtdContribMultaParticEmpReversao;
	private Double qtdContribCorrecaoParticEmpReversao;
	private Double percentualDevolucaoParticEmpReversao;

	private Double qtdTotalDevolucaoParticReversao;
	private Double qtdTotalDevolucaoEmpReversao;
	private Double qtdTotalDevolucaoParticEmpReversao;

	private Double qtdContribParticNaoResgatavel;
	private Double qtdContribJurosParticNaoResgatavel;
	private Double qtdContribMultaParticNaoResgatavel;
	private Double qtdContribCorrecaoParticNaoResgatavel;
	private Double percentualDevolucaoParticNaoResgatavel;

	private Double qtdContribEmpNaoResgatavel;
	private Double qtdContribJurosEmpNaoResgatavel;
	private Double qtdContribMultaEmpNaoResgatavel;
	private Double qtdContribCorrecaoEmpNaoResgatavel;
	private Double percentualDevolucaoEmpNaoResgatavel;

	private Double qtdContribParticEmpNaoResgatavel;
	private Double qtdContribJurosParticEmpNaoResgatavel;
	private Double qtdContribMultaParticEmpNaoResgatavel;
	private Double qtdContribCorrecaoParticEmpNaoResgatavel;
	private Double percentualDevolucaoParticEmpNaoResgatavel;

	private Double qtdTotalDevolucaoParticNaoResgatavel;
	private Double qtdTotalDevolucaoEmpNaoResgatavel;
	private Double qtdTotalDevolucaoParticEmpNaoResgatavel;

	private RegraDevolucaoContribFaixas regraDevolucaoContribFaixas;

	private HistoricoFinanceiroPago historicoFinanceiroPago;

	private Long codigoHistFinanPago;

	private Double fatorConversaoPlanoCota;

	private int numeroOrdem;

	public Double getQtdContribPartic() {
		return qtdContribPartic;
	}

	public void setQtdContribPartic(Double qtdContribPartic) {
		this.qtdContribPartic = qtdContribPartic;
	}

	public Double getQtdContribJurosPartic() {
		return qtdContribJurosPartic;
	}

	public void setQtdContribJurosPartic(Double qtdContribJurosPartic) {
		this.qtdContribJurosPartic = qtdContribJurosPartic;
	}

	public Double getQtdContribMultaPartic() {
		return qtdContribMultaPartic;
	}

	public void setQtdContribMultaPartic(Double qtdContribMultaPartic) {
		this.qtdContribMultaPartic = qtdContribMultaPartic;
	}

	public Double getQtdContribCorrecaoPartic() {
		return qtdContribCorrecaoPartic;
	}

	public void setQtdContribCorrecaoPartic(Double qtdContribCorrecaoPartic) {
		this.qtdContribCorrecaoPartic = qtdContribCorrecaoPartic;
	}

	public Double getPercentualDevolucaoPartic() {
		return percentualDevolucaoPartic;
	}

	public void setPercentualDevolucaoPartic(Double percentualDevolucaoPartic) {
		this.percentualDevolucaoPartic = percentualDevolucaoPartic;
	}

	public Double getQtdContribEmp() {
		return qtdContribEmp;
	}

	public void setQtdContribEmp(Double qtdContribEmp) {
		this.qtdContribEmp = qtdContribEmp;
	}

	public Double getQtdContribJurosEmp() {
		return qtdContribJurosEmp;
	}

	public void setQtdContribJurosEmp(Double qtdContribJurosEmp) {
		this.qtdContribJurosEmp = qtdContribJurosEmp;
	}

	public Double getQtdContribMultaEmp() {
		return qtdContribMultaEmp;
	}

	public void setQtdContribMultaEmp(Double qtdContribMultaEmp) {
		this.qtdContribMultaEmp = qtdContribMultaEmp;
	}

	public Double getQtdContribCorrecaoEmp() {
		return qtdContribCorrecaoEmp;
	}

	public void setQtdContribCorrecaoEmp(Double qtdContribCorrecaoEmp) {
		this.qtdContribCorrecaoEmp = qtdContribCorrecaoEmp;
	}

	public Double getPercentualDevolucaoEmp() {
		return percentualDevolucaoEmp;
	}

	public void setPercentualDevolucaoEmp(Double percentualDevolucaoEmp) {
		this.percentualDevolucaoEmp = percentualDevolucaoEmp;
	}

	public Double getQtdContribParticEmp() {
		return qtdContribParticEmp;
	}

	public void setQtdContribParticEmp(Double qtdContribParticEmp) {
		this.qtdContribParticEmp = qtdContribParticEmp;
	}

	public Double getQtdContribJurosParticEmp() {
		return qtdContribJurosParticEmp;
	}

	public void setQtdContribJurosParticEmp(Double qtdContribJurosParticEmp) {
		this.qtdContribJurosParticEmp = qtdContribJurosParticEmp;
	}

	public Double getQtdContribMultaParticEmp() {
		return qtdContribMultaParticEmp;
	}

	public void setQtdContribMultaParticEmp(Double qtdContribMultaParticEmp) {
		this.qtdContribMultaParticEmp = qtdContribMultaParticEmp;
	}

	public Double getQtdContribCorrecaoParticEmp() {
		return qtdContribCorrecaoParticEmp;
	}

	public void setQtdContribCorrecaoParticEmp(Double qtdContribCorrecaoParticEmp) {
		this.qtdContribCorrecaoParticEmp = qtdContribCorrecaoParticEmp;
	}

	public Double getPercentualDevolucaoParticEmp() {
		return percentualDevolucaoParticEmp;
	}

	public void setPercentualDevolucaoParticEmp(Double percentualDevolucaoParticEmp) {
		this.percentualDevolucaoParticEmp = percentualDevolucaoParticEmp;
	}

	public Double getQtdTotalDevolucaoPartic() {
		return qtdTotalDevolucaoPartic;
	}

	public void setQtdTotalDevolucaoPartic(Double qtdTotalDevolucaoPartic) {
		this.qtdTotalDevolucaoPartic = qtdTotalDevolucaoPartic;
	}

	public Double getQtdTotalDevolucaoEmp() {
		return qtdTotalDevolucaoEmp;
	}

	public void setQtdTotalDevolucaoEmp(Double qtdTotalDevolucaoEmp) {
		this.qtdTotalDevolucaoEmp = qtdTotalDevolucaoEmp;
	}

	public Double getQtdTotalDevolucaoParticEmp() {
		return qtdTotalDevolucaoParticEmp;
	}

	public void setQtdTotalDevolucaoParticEmp(Double qtdTotalDevolucaoParticEmp) {
		this.qtdTotalDevolucaoParticEmp = qtdTotalDevolucaoParticEmp;
	}

	public RegraDevolucaoContribFaixas getRegraDevolucaoContribFaixas() {
		return regraDevolucaoContribFaixas;
	}

	public void setRegraDevolucaoContribFaixas(RegraDevolucaoContribFaixas regraDevolucaoContribFaixas) {
		this.regraDevolucaoContribFaixas = regraDevolucaoContribFaixas;
	}

	public Double getQtdContribParticReversao() {
		return qtdContribParticReversao;
	}

	public void setQtdContribParticReversao(Double qtdContribParticReversao) {
		this.qtdContribParticReversao = qtdContribParticReversao;
	}

	public Double getQtdContribJurosParticReversao() {
		return qtdContribJurosParticReversao;
	}

	public void setQtdContribJurosParticReversao(Double qtdContribJurosParticReversao) {
		this.qtdContribJurosParticReversao = qtdContribJurosParticReversao;
	}

	public Double getQtdContribMultaParticReversao() {
		return qtdContribMultaParticReversao;
	}

	public void setQtdContribMultaParticReversao(Double qtdContribMultaParticReversao) {
		this.qtdContribMultaParticReversao = qtdContribMultaParticReversao;
	}

	public Double getQtdContribCorrecaoParticReversao() {
		return qtdContribCorrecaoParticReversao;
	}

	public void setQtdContribCorrecaoParticReversao(Double qtdContribCorrecaoParticReversao) {
		this.qtdContribCorrecaoParticReversao = qtdContribCorrecaoParticReversao;
	}

	public Double getPercentualDevolucaoParticReversao() {
		return percentualDevolucaoParticReversao;
	}

	public void setPercentualDevolucaoParticReversao(Double percentualDevolucaoParticReversao) {
		this.percentualDevolucaoParticReversao = percentualDevolucaoParticReversao;
	}

	public Double getQtdContribEmpReversao() {
		return qtdContribEmpReversao;
	}

	public void setQtdContribEmpReversao(Double qtdContribEmpReversao) {
		this.qtdContribEmpReversao = qtdContribEmpReversao;
	}

	public Double getQtdContribJurosEmpReversao() {
		return qtdContribJurosEmpReversao;
	}

	public void setQtdContribJurosEmpReversao(Double qtdContribJurosEmpReversao) {
		this.qtdContribJurosEmpReversao = qtdContribJurosEmpReversao;
	}

	public Double getQtdContribMultaEmpReversao() {
		return qtdContribMultaEmpReversao;
	}

	public void setQtdContribMultaEmpReversao(Double qtdContribMultaEmpReversao) {
		this.qtdContribMultaEmpReversao = qtdContribMultaEmpReversao;
	}

	public Double getQtdContribCorrecaoEmpReversao() {
		return qtdContribCorrecaoEmpReversao;
	}

	public void setQtdContribCorrecaoEmpReversao(Double qtdContribCorrecaoEmpReversao) {
		this.qtdContribCorrecaoEmpReversao = qtdContribCorrecaoEmpReversao;
	}

	public Double getPercentualDevolucaoEmpReversao() {
		return percentualDevolucaoEmpReversao;
	}

	public void setPercentualDevolucaoEmpReversao(Double percentualDevolucaoEmpReversao) {
		this.percentualDevolucaoEmpReversao = percentualDevolucaoEmpReversao;
	}

	public Double getQtdContribParticEmpReversao() {
		return qtdContribParticEmpReversao;
	}

	public void setQtdContribParticEmpReversao(Double qtdContribParticEmpReversao) {
		this.qtdContribParticEmpReversao = qtdContribParticEmpReversao;
	}

	public Double getQtdContribJurosParticEmpReversao() {
		return qtdContribJurosParticEmpReversao;
	}

	public void setQtdContribJurosParticEmpReversao(Double qtdContribJurosParticEmpReversao) {
		this.qtdContribJurosParticEmpReversao = qtdContribJurosParticEmpReversao;
	}

	public Double getQtdContribMultaParticEmpReversao() {
		return qtdContribMultaParticEmpReversao;
	}

	public void setQtdContribMultaParticEmpReversao(Double qtdContribMultaParticEmpReversao) {
		this.qtdContribMultaParticEmpReversao = qtdContribMultaParticEmpReversao;
	}

	public Double getQtdContribCorrecaoParticEmpReversao() {
		return qtdContribCorrecaoParticEmpReversao;
	}

	public void setQtdContribCorrecaoParticEmpReversao(Double qtdContribCorrecaoParticEmpReversao) {
		this.qtdContribCorrecaoParticEmpReversao = qtdContribCorrecaoParticEmpReversao;
	}

	public Double getPercentualDevolucaoParticEmpReversao() {
		return percentualDevolucaoParticEmpReversao;
	}

	public void setPercentualDevolucaoParticEmpReversao(Double percentualDevolucaoParticEmpReversao) {
		this.percentualDevolucaoParticEmpReversao = percentualDevolucaoParticEmpReversao;
	}

	public Double getQtdTotalDevolucaoParticReversao() {
		return qtdTotalDevolucaoParticReversao;
	}

	public void setQtdTotalDevolucaoParticReversao(Double qtdTotalDevolucaoParticReversao) {
		this.qtdTotalDevolucaoParticReversao = qtdTotalDevolucaoParticReversao;
	}

	public Double getQtdTotalDevolucaoEmpReversao() {
		return qtdTotalDevolucaoEmpReversao;
	}

	public void setQtdTotalDevolucaoEmpReversao(Double qtdTotalDevolucaoEmpReversao) {
		this.qtdTotalDevolucaoEmpReversao = qtdTotalDevolucaoEmpReversao;
	}

	public Double getQtdTotalDevolucaoParticEmpReversao() {
		return qtdTotalDevolucaoParticEmpReversao;
	}

	public void setQtdTotalDevolucaoParticEmpReversao(Double qtdTotalDevolucaoParticEmpReversao) {
		this.qtdTotalDevolucaoParticEmpReversao = qtdTotalDevolucaoParticEmpReversao;
	}

	public Long getCodigoHistFinanPago() {
		return codigoHistFinanPago;
	}

	public void setCodigoHistFinanPago(Long codigoHistFinanPago) {
		this.codigoHistFinanPago = codigoHistFinanPago;
	}

	public HistoricoFinanceiroPago getHistoricoFinanceiroPago() {
		return historicoFinanceiroPago;
	}

	public void setHistoricoFinanceiroPago(HistoricoFinanceiroPago historicoFinanceiroPago) {
		this.historicoFinanceiroPago = historicoFinanceiroPago;
	}

	public Double getFatorConversaoPlanoCota() {
		return fatorConversaoPlanoCota;
	}

	public void setFatorConversaoPlanoCota(Double fatorConversaoPlanoCota) {
		this.fatorConversaoPlanoCota = fatorConversaoPlanoCota;
	}

	public int getNumeroOrdem() {
		return numeroOrdem;
	}

	public void setNumeroOrdem(int numeroOrdem) {
		this.numeroOrdem = numeroOrdem;
	}

	public Double getQtdContribParticNaoResgatavel() {
		return qtdContribParticNaoResgatavel;
	}

	public void setQtdContribParticNaoResgatavel(Double qtdContribParticNaoResgatavel) {
		this.qtdContribParticNaoResgatavel = qtdContribParticNaoResgatavel;
	}

	public Double getQtdContribJurosParticNaoResgatavel() {
		return qtdContribJurosParticNaoResgatavel;
	}

	public void setQtdContribJurosParticNaoResgatavel(Double qtdContribJurosParticNaoResgatavel) {
		this.qtdContribJurosParticNaoResgatavel = qtdContribJurosParticNaoResgatavel;
	}

	public Double getQtdContribMultaParticNaoResgatavel() {
		return qtdContribMultaParticNaoResgatavel;
	}

	public void setQtdContribMultaParticNaoResgatavel(Double qtdContribMultaParticNaoResgatavel) {
		this.qtdContribMultaParticNaoResgatavel = qtdContribMultaParticNaoResgatavel;
	}

	public Double getQtdContribCorrecaoParticNaoResgatavel() {
		return qtdContribCorrecaoParticNaoResgatavel;
	}

	public void setQtdContribCorrecaoParticNaoResgatavel(Double qtdContribCorrecaoParticNaoResgatavel) {
		this.qtdContribCorrecaoParticNaoResgatavel = qtdContribCorrecaoParticNaoResgatavel;
	}

	public Double getPercentualDevolucaoParticNaoResgatavel() {
		return percentualDevolucaoParticNaoResgatavel;
	}

	public void setPercentualDevolucaoParticNaoResgatavel(Double percentualDevolucaoParticNaoResgatavel) {
		this.percentualDevolucaoParticNaoResgatavel = percentualDevolucaoParticNaoResgatavel;
	}

	public Double getQtdContribEmpNaoResgatavel() {
		return qtdContribEmpNaoResgatavel;
	}

	public void setQtdContribEmpNaoResgatavel(Double qtdContribEmpNaoResgatavel) {
		this.qtdContribEmpNaoResgatavel = qtdContribEmpNaoResgatavel;
	}

	public Double getQtdContribJurosEmpNaoResgatavel() {
		return qtdContribJurosEmpNaoResgatavel;
	}

	public void setQtdContribJurosEmpNaoResgatavel(Double qtdContribJurosEmpNaoResgatavel) {
		this.qtdContribJurosEmpNaoResgatavel = qtdContribJurosEmpNaoResgatavel;
	}

	public Double getQtdContribMultaEmpNaoResgatavel() {
		return qtdContribMultaEmpNaoResgatavel;
	}

	public void setQtdContribMultaEmpNaoResgatavel(Double qtdContribMultaEmpNaoResgatavel) {
		this.qtdContribMultaEmpNaoResgatavel = qtdContribMultaEmpNaoResgatavel;
	}

	public Double getQtdContribCorrecaoEmpNaoResgatavel() {
		return qtdContribCorrecaoEmpNaoResgatavel;
	}

	public void setQtdContribCorrecaoEmpNaoResgatavel(Double qtdContribCorrecaoEmpNaoResgatavel) {
		this.qtdContribCorrecaoEmpNaoResgatavel = qtdContribCorrecaoEmpNaoResgatavel;
	}

	public Double getPercentualDevolucaoEmpNaoResgatavel() {
		return percentualDevolucaoEmpNaoResgatavel;
	}

	public void setPercentualDevolucaoEmpNaoResgatavel(Double percentualDevolucaoEmpNaoResgatavel) {
		this.percentualDevolucaoEmpNaoResgatavel = percentualDevolucaoEmpNaoResgatavel;
	}

	public Double getQtdContribParticEmpNaoResgatavel() {
		return qtdContribParticEmpNaoResgatavel;
	}

	public void setQtdContribParticEmpNaoResgatavel(Double qtdContribParticEmpNaoResgatavel) {
		this.qtdContribParticEmpNaoResgatavel = qtdContribParticEmpNaoResgatavel;
	}

	public Double getQtdContribJurosParticEmpNaoResgatavel() {
		return qtdContribJurosParticEmpNaoResgatavel;
	}

	public void setQtdContribJurosParticEmpNaoResgatavel(Double qtdContribJurosParticEmpNaoResgatavel) {
		this.qtdContribJurosParticEmpNaoResgatavel = qtdContribJurosParticEmpNaoResgatavel;
	}

	public Double getQtdContribMultaParticEmpNaoResgatavel() {
		return qtdContribMultaParticEmpNaoResgatavel;
	}

	public void setQtdContribMultaParticEmpNaoResgatavel(Double qtdContribMultaParticEmpNaoResgatavel) {
		this.qtdContribMultaParticEmpNaoResgatavel = qtdContribMultaParticEmpNaoResgatavel;
	}

	public Double getQtdContribCorrecaoParticEmpNaoResgatavel() {
		return qtdContribCorrecaoParticEmpNaoResgatavel;
	}

	public void setQtdContribCorrecaoParticEmpNaoResgatavel(Double qtdContribCorrecaoParticEmpNaoResgatavel) {
		this.qtdContribCorrecaoParticEmpNaoResgatavel = qtdContribCorrecaoParticEmpNaoResgatavel;
	}

	public Double getPercentualDevolucaoParticEmpNaoResgatavel() {
		return percentualDevolucaoParticEmpNaoResgatavel;
	}

	public void setPercentualDevolucaoParticEmpNaoResgatavel(Double percentualDevolucaoParticEmpNaoResgatavel) {
		this.percentualDevolucaoParticEmpNaoResgatavel = percentualDevolucaoParticEmpNaoResgatavel;
	}

	public Double getQtdTotalDevolucaoParticNaoResgatavel() {
		return qtdTotalDevolucaoParticNaoResgatavel;
	}

	public void setQtdTotalDevolucaoParticNaoResgatavel(Double qtdTotalDevolucaoParticNaoResgatavel) {
		this.qtdTotalDevolucaoParticNaoResgatavel = qtdTotalDevolucaoParticNaoResgatavel;
	}

	public Double getQtdTotalDevolucaoEmpNaoResgatavel() {
		return qtdTotalDevolucaoEmpNaoResgatavel;
	}

	public void setQtdTotalDevolucaoEmpNaoResgatavel(Double qtdTotalDevolucaoEmpNaoResgatavel) {
		this.qtdTotalDevolucaoEmpNaoResgatavel = qtdTotalDevolucaoEmpNaoResgatavel;
	}

	public Double getQtdTotalDevolucaoParticEmpNaoResgatavel() {
		return qtdTotalDevolucaoParticEmpNaoResgatavel;
	}

	public void setQtdTotalDevolucaoParticEmpNaoResgatavel(Double qtdTotalDevolucaoParticEmpNaoResgatavel) {
		this.qtdTotalDevolucaoParticEmpNaoResgatavel = qtdTotalDevolucaoParticEmpNaoResgatavel;
	}

}
