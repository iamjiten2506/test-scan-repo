package br.com.bbprevidencia.devolucao.validator;

import java.text.ParseException;
import java.util.Date;

import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.apache.commons.lang.StringUtils;

import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.utils.data.UtilData;

/**
 * Classe encarregada de validadar datas de Início e Fim
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 30/01/2017
 *
 */
@FacesValidator(value = "DataInicioFimValidator")
public class DataInicioFimValidator implements Validator {

	Date dataInicio = null;
	Date dataFim = null;

	@Override
	public void validate(FacesContext arg0, UIComponent arg1, Object arg2) throws ValidatorException {

		UIInput datInicial = (UIInput) arg0.getViewRoot().findComponent((String) arg1.getAttributes().get("input1"));

		UIInput datFinal = (UIInput) arg0.getViewRoot().findComponent((String) arg1.getAttributes().get("input2"));

		Object datIni = datInicial.getSubmittedValue();

		Object datFim = datFinal.getSubmittedValue();

		this.validaDataInicioFim(datIni, datFim);

	}

	/**
	 * Método responsável por validar a data do requerimento
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 14/02/2017
	 * @param datIni
	 * @param datFim
	 * @throws ValidatorException
	 */
	private void validaDataInicioFim(Object datIni, Object datFim) throws ValidatorException {
		this.dataInicio = null;
		this.dataFim = null;

		String strDtIni = (datIni == null) ? null : datIni.toString().trim();

		String strDtFim = (datFim == null) ? null : datFim.toString().trim();

		if (StringUtils.isBlank(strDtIni)) {
			throw new ValidatorException(Mensagens.getFacesMessageErro("DEV_VMSG023"));
		}

		try {
			this.dataInicio = UtilData.getDataValida(strDtIni);
		} catch (ParseException e) {
			return;
		}

		//if (this.dataFim == null) {
		//	return;
		//} else {

		try {
			this.dataFim = UtilData.getDataValida(strDtFim);
			if (this.dataFim == null) {
				return;
			}
		} catch (ParseException e) {
			return;
		}
		//}

		if (UtilData.isDataMaior(this.dataInicio, this.dataFim)) {
			throw new ValidatorException(Mensagens.getFacesMessageErro("DEV_VMSG020"));
		}

		if (UtilData.isDataIgual(this.dataInicio, this.dataFim)) {
			throw new ValidatorException(Mensagens.getFacesMessageErro("DEV_VMSG021"));
		}
	}

}
