package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.devolucao.enumerador.TipoEntidadePortabilidadeEnum;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   23/01/2017
 * Classe de persistência para tabela TIP_PLA_DES_POR_DEV.
 */
@Entity
@Table(name = "TIP_PLA_DES_POR_DEV", schema = "OWN_DCR")
@NamedQuery(name = "TipoPlanoDestinoPortabilidadeDevolucao.findAll", query = "SELECT q FROM TipoPlanoDestinoPortabilidadeDevolucao q")
public class TipoPlanoDestinoPortabilidadeDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TIP_PLA_DES_POR_DEV_GER", sequenceName = "S_TEDPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TIP_PLA_DES_POR_DEV_GER")
	@Column(name = "NUM_SEQ_TIP_PLA_DES_POR_DEV")
	private Long codigo;

	@Column(name = "NOM_TIP_PLA_DES_POR_DEV")
	private String nome;

	@Column(name = "DES_TIP_PLA_DES_POR_DEV")
	private String descricao;

	@Enumerated(value = EnumType.STRING)
	@Column(name = "IND_TIP_ENT", nullable = false, length = 1, columnDefinition = "char(1)")
	private TipoEntidadePortabilidadeEnum tipoEntidadePortabilidadeEnum;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public TipoEntidadePortabilidadeEnum getTipoEntidadePortabilidadeEnum() {
		return tipoEntidadePortabilidadeEnum;
	}

	public void setTipoEntidadePortabilidadeEnum(TipoEntidadePortabilidadeEnum tipoEntidadePortabilidadeEnum) {
		this.tipoEntidadePortabilidadeEnum = tipoEntidadePortabilidadeEnum;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoPlanoDestinoPortabilidadeDevolucao other = (TipoPlanoDestinoPortabilidadeDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}