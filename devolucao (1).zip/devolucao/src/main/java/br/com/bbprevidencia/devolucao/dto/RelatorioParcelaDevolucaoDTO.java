package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

public class RelatorioParcelaDevolucaoDTO {

	private String parcela;

	private String totalParcelas;

	private String nomeEntidadeParticipante;

	private String nomePlano;

	private String matriculaParticipante;

	private String nomeParticipante;

	private Date dataPagamento;

	private Double quantidadeCotas;

	private String nomeContaDevolucao;

	public String getNomeEntidadeParticipante() {
		return nomeEntidadeParticipante;
	}

	public void setNomeEntidadeParticipante(String nomeEntidadeParticipante) {
		this.nomeEntidadeParticipante = nomeEntidadeParticipante;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getParcela() {
		return parcela;
	}

	public void setParcela(String parcela) {
		this.parcela = parcela;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Double getQuantidadeCotas() {
		return quantidadeCotas;
	}

	public void setQuantidadeCotas(Double quantidadeCotas) {
		this.quantidadeCotas = quantidadeCotas;
	}

	public String getNomeContaDevolucao() {
		return nomeContaDevolucao;
	}

	public void setNomeContaDevolucao(String nomeContaDevolucao) {
		this.nomeContaDevolucao = nomeContaDevolucao;
	}

	public String getTotalParcelas() {
		return totalParcelas;
	}

	public void setTotalParcelas(String totalParcelas) {
		this.totalParcelas = totalParcelas;
	}

}
