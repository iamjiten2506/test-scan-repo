package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoEntidadePortabilidadeEnum {

	A("A", "Entidade Aberta de Previdência Complementar"),
	F("F", "Entidade Fechada de Previdência Complementar");

	private String codigo;
	private String descricao;

	private TipoEntidadePortabilidadeEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return TipoEntidadePortabilidadeEnum
	 */
	public static TipoEntidadePortabilidadeEnum getTipoEntidadePortabilidadeEnum(String codigo) {
		if (codigo != null) {
			for (TipoEntidadePortabilidadeEnum tipoEntidadePortabilidadeEnum : values()) {
				if (tipoEntidadePortabilidadeEnum.getCodigo().equals(codigo)) {
					return tipoEntidadePortabilidadeEnum;
				}
			}
		}
		return null;
	}

}