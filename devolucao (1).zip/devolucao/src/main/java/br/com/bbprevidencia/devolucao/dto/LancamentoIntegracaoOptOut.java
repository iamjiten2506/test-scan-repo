package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.folha.dto.Consignatario;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Classe de persistência para tabela LAN_INT_OPT_OUT.
 * 
 * @author  BBPF0468 - Carlos Wallace
 * @since   31/08/2020
 * 
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
@Entity
@Table(name = "LAN_INT_OPT_OUT", schema = "OWN_DCR")
@NamedQuery(name = "LancamentoIntegracaoOptOut.findAll", query = "SELECT l FROM LancamentoIntegracaoOptOut l")
public class LancamentoIntegracaoOptOut implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "LAN_INT_OPT_OUT_GER", sequenceName = "OWN_DCR.S_LAN_INT_OPT_OUT_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LAN_INT_OPT_OUT_GER")
	@Column(name = "NUM_SEQ_LAN_INT_OPT_OUT")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SOL_OPT_OUT")
	private SolicitacaoOptOut solicitacaoOptOut;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT")
	private OperacaoInterna operacaoInterna;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PERFIL_INVEST")
	private PerfilInvestimento perfilInvestimento;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RECEBEDOR")
	private Recebedor recebedor;

	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "COD_PESSOA"), @JoinColumn(name = "COD_AREA_ATUA") })
	private AtuacaoPessoa atuacaoPessoa;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_MOV_INT")
	private Date dataMovimentoIntegracao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CONSIGNATARIO")
	private Consignatario consignatario;

	@Column(name = "VAL_INT")
	private Double valorIntegracao;

	@Column(name = "COD_SEQ_MOV_LOTE")
	private long codigoSequencialMovimentoLote;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private boolean lancamentoIntegracaoInternaPlanos;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PAR_PLA_ENT_DEST")
	private ParticipantePlano participantePlanoDestino;

	public boolean isParticipantePlanoDestinoPreenchido() {
		return this.participantePlanoDestino != null && this.participantePlanoDestino.getCodigo() > 0;
	}

}
