package br.com.bbprevidencia.devolucao.controle;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIOutput;
import javax.faces.component.UISelectItem;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.EmailValidator;
import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bbprevidencia.bbpcomum.util.CpfCnpjValidator;
import br.com.bbprevidencia.bbpcomum.util.TipoMascara;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.AgenciaBancariaBO;
import br.com.bbprevidencia.cadastroweb.bo.BancoBO;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.EstadoCivilBO;
import br.com.bbprevidencia.cadastroweb.bo.GrauInstrucaoBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.TipoTelefoneBO;
import br.com.bbprevidencia.cadastroweb.bo.UnidadeFederativaBO;
import br.com.bbprevidencia.cadastroweb.dto.AgenciaBancaria;
import br.com.bbprevidencia.cadastroweb.dto.BancoDTO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipantePK;
import br.com.bbprevidencia.cadastroweb.dto.EstadoCivil;
import br.com.bbprevidencia.cadastroweb.dto.GrauInstrucao;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.TipoTelefone;
import br.com.bbprevidencia.cadastroweb.dto.UnidadeFederativa;
import br.com.bbprevidencia.cadastroweb.exception.RegistroNaoEncontradoException;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.GrupoRecebimentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.GrupoRecebimentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.ValidacaoUtil;
import br.com.bbprevidencia.folha.bo.QualidadeRecebedorBO;
import br.com.bbprevidencia.folha.bo.RecebedorBO;
import br.com.bbprevidencia.folha.bo.SituacaoRecebedorBO;
import br.com.bbprevidencia.folha.dto.QualidadeRecebedor;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.folha.dto.RepresentanteRecebedor;
import br.com.bbprevidencia.folha.dto.SituacaoRecebedor;
import br.com.bbprevidencia.folha.dto.TelefoneRecebedor;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0170 - MAGSON DIAS.
 * @since   17/03/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("recebedorVisao")
public class RecebedorVisao {

	private static String FW_RECEBEDOR = "/paginas/recebedor.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static String FW_ACESSO_NEGADO = "/template/erro401.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(RecebedorVisao.class);

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private GrupoRecebimentoDevolucaoBO grupoRecebimentoDevolucaoBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBo;
	@Autowired
	private RecebedorBO recebedorBO;
	@Autowired
	private QualidadeRecebedorBO qualidadeRecebedorBO;
	@Autowired
	private SituacaoRecebedorBO situacaoRecebedorBO;
	@Autowired
	private BancoBO bancoBO;
	@Autowired
	private AgenciaBancariaBO agenciaBancariaBO;
	@Autowired
	private ParticipantePlanoBO participantePlanoBO;
	@Autowired
	private UnidadeFederativaBO unidadeFederativaBO;
	@Autowired
	private ValidacaoUtil validacaoUtil;
	@Autowired
	private TipoTelefoneBO tipoTelefoneBO;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean listarStatus;
	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private GrupoRecebimentoDevolucao grupoRecebimentoDevolucao;
	private Participante participante;
	private TipoDevolucao tipoDevolucao;
	private Devolucao devolucao;
	private Recebedor recebedor;
	private EstadoCivilBO estadoCivilBO;
	private GrauInstrucaoBO grauInstrucaoBO;
	private BancoDTO bancoDTO;
	private Long codigoBanco;
	private Long codigoAgencia;
	//private AgenciaBancaria agenciaBancaria;
	private Date dataAtual;
	private Long codigoEntidadeParticipante;
	private ParticipantePlano participantePlano;
	private QualidadeRecebedor qualidadeRecebedor;

	private List<GrupoRecebimentoDevolucao> listaGrupoRecebimentoDevolucao;
	private List<Recebedor> listarRecebedor;
	private List<QualidadeRecebedor> listarQualidadeRecebedor;
	private List<SituacaoRecebedor> listarSituacaoRecebedor;
	private List<UISelectItem> listaItemGrauInstrucao;
	private List<EstadoCivil> listaEstadoCivil;
	private List<GrauInstrucao> listaGrauInstrucao;
	private List<BancoDTO> listaBanco;
	private List<AgenciaBancaria> listarAgenciaBancaria;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<Participante> listaParticipante;
	private List<SelectItem> listaEntidadeParticipante;
	private List<UnidadeFederativa> listaUnidadeFederativa;
	private List<TipoTelefone> listaTipoTelefone;
	private TelefoneRecebedor telefoneRecebedor;
	private List<RepresentanteRecebedor> listaRepresentanteRecebedor;
	private RepresentanteRecebedor representanteRecebedor;
	private List<Recebedor> listaRecebedor;
	private Recebedor recebedorParticipante;

	public void atualizarDataTerminoVigencia() {
		log.info("Atualizando data término de vigência");
		this.representanteRecebedor.setDataTerminoVigencia(this.representanteRecebedor.getDataInicioVigencia());
	}

	/**
	 * Método encarredado por iniciar a página manter recebedor.
	 *  
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since   16/02/2017
	 * @return {@link String}
	 * @throws Exception 
	 * @throws RegistroNaoEncontradoException 
	 */
	public String iniciarTela() throws RegistroNaoEncontradoException, Exception {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("cadastroRecebedor");
		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("cadastroRecebedor");
			if (this.possuiAcessoTotal) {
				this.listarStatus = true;
				limparFormularioPesquisa();
				this.listaEntidadeParticipante = listarEntidadeParticipante();
				this.listarQualidadeRecebedor = qualidadeRecebedorBO.listarTodasQualidadeRecebedor();
				this.listarSituacaoRecebedor = situacaoRecebedorBO.listarTodasSituacaoRecebedor();
				this.listaBanco = bancoBO.listarBanco();
				this.listaEstadoCivil = estadoCivilBO.listarEstadoCivil();
				this.listaGrauInstrucao = grauInstrucaoBO.listarGrauInstrucao();
				this.listaUnidadeFederativa = unidadeFederativaBO.listarUnidadeFederativa();
				this.listaTipoTelefone = tipoTelefoneBO.listarTipoTelefone();

				return FW_RECEBEDOR;
			}
		}
		return FW_ACESSO_NEGADO;
	}

	/**
	 * Método para salvar ou atualizar o registro de um recebedor.
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 17/03/2017
	 * @return {@link String}
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String salvarRecebedor() {
		this.recebedor.setAgenciaBancaria(this.agenciaBancariaBO.consultarPorCodigoEBanco(this.codigoAgencia, this.codigoBanco));
		try {

			if (this.recebedor.getCodigo() == null) {
				this.recebedor.setDataInclusao(new Date());
				this.recebedor.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				this.recebedor.setDataSituacaoRecebedor(new Date());
				this.recebedor.setParticipante(this.participante);
			}
			//if (this.recebedor.getEmailSecundario().equals("")) {
			//	this.recebedor.setEmailSecundario(this.recebedor.getEmail());
			//}
			configurarRecebedor(getRecebedor());
			if (validaCampos()) {
				return "";
			}
			if (this.recebedor.getCodigo() == null) {
				Mensagens.addMsgInfo("Recebedor salvo com sucesso!");
			} else {
				Mensagens.addMsgInfo("Recebedor atualizado com sucesso!");
			}
			recebedorBO.salvar(this.recebedor);
			controlarEdicaoVisualizacao();
			this.listarRecebedor = recebedorBO.listaReceborParticipante(this.participante);
			return FW_RECEBEDOR;
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar/atualizar o recebedor.");
			return "";
		}

	}

	/**
	 * Método responsável por retornar a lista de agencias de acordo com o código selecionado.
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 16/03/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return	{@link String}
	 */
	public String listarAgencias(AjaxBehaviorEvent event) {
		if (this.getCodigoBanco() == null) {
			addMsgErro("Selecione um Banco.");
		} else {
			try {
				this.listarAgenciaBancaria = new ArrayList<AgenciaBancaria>(this.agenciaBancariaBO.pequisarAgenciaPorCodigoBanco(codigoBanco));
				return "";
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}
		return "";
	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo inicial de pesquisa
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since  16/03/2017
	 */
	public void limparFormularioPesquisa() {
		this.setTelefoneRecebedor(new TelefoneRecebedor());
		this.setCodigoEntidadeParticipante(null);
		this.setParticipante(new Participante());
		this.setPlanoPrevidencia(null);
		this.setEntidadeParticipante(null);
		this.listarStatus = true;
		this.setCodigoAgencia(null);
		this.setCodigoBanco(null);
		this.setListarAgenciaBancaria(null);
		this.setListarRecebedor(null);
		this.setRepresentanteRecebedor(new RepresentanteRecebedor());
		this.setListaRepresentanteRecebedor(null);
	}

	/**
	 * Retorna o estado inicial da página
	 * 
	 * @author  BBPF0170 - Magson
	 * @since 17/03/2017
	 * @return {@link String}
	 */
	public String limparPesquisa() {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove(participante);
		PrimeFaces.current().resetInputs("formRECEBEDOR");
		limparFormularioPesquisa();
		return FW_RECEBEDOR;
	}

	/**
	 * Retorna a pagina mostrando a lista de recebedor.
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 * @return {@link String}
	 */
	public String retornar() {
		this.listarStatus = true;
		this.setCodigoAgencia(null);
		this.setCodigoBanco(null);
		this.setListarAgenciaBancaria(null);
		return "";
	}

	/**
	 * Método responsavel por editar um registro do recebedor.
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 * @param {@link Recebedor}
	 */
	public void editarRecebedor(Recebedor recebedor) {
		this.setRecebedor(recebedorBO.pesquisarRecebedorCodigo(recebedor.getCodigo()));
		this.recebedor.setDataAlteracao(new Date());
		this.recebedor.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
		this.telefoneRecebedor = new TelefoneRecebedor();
		this.representanteRecebedor = new RepresentanteRecebedor();
		//receber agencia e banco.
		if (this.recebedor.getAgenciaBancaria() != null) {
			setCodigoBanco(recebedor.getAgenciaBancaria().getChavePrimaria().getCodigoBanco());
			setCodigoAgencia(recebedor.getAgenciaBancaria().getChavePrimaria().getCodigoAgenciaBancaria());
			this.listarAgenciaBancaria = new ArrayList<AgenciaBancaria>(this.agenciaBancariaBO.pequisarAgenciaPorCodigoBanco(this.codigoBanco));
		}
		//Setar o receber selecionado
		//setRecebedor(recebedor);
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método que deleta um recebedor
	 * 
	 * @author  BBPF0170 - Magson
	 * @since 17/02/2017
	 * @param {@link Recebedor}
	 */
	public String deletarRecebedor(Recebedor recebedor) {
		try {
			recebedorBO.apagar(recebedor);
			this.listarRecebedor = recebedorBO.listaReceborParticipante(this.participante);
			Mensagens.addMsgInfo("Recebedor excluído com sucesso!");
			return FW_RECEBEDOR;
		} catch (PrevidenciaException pEx) {
			addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			addMsgErro(ex.getMessage());
			return "";
		}

	}

	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 16/03/2017
	 */
	public void controlarEdicaoVisualizacao() {
		if (isListarStatus()) {
			this.listarRecebedor = recebedorBO.listaReceborParticipante(this.participante);
		}
		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método que chama a tela para um novo cadastro de Recebedor.
	 * @author BBPF0170	- MAGSON 
	 * @since 15/03/2017
	 * @return String
	 */
	public String cadastrarNovoRecebedor() {
		if (this.participante != null) {
			recebedor = new Recebedor();
			this.telefoneRecebedor = new TelefoneRecebedor();
			this.representanteRecebedor = new RepresentanteRecebedor();
			controlarEdicaoVisualizacao();
			return FW_RECEBEDOR;
		}
		addMsgErro("Informe um participante!");
		return FW_RECEBEDOR;
	}

	/**
	 * Método para configurar o estado do recebedor para que o procedimento de salvar seja efetuado.
	 * 
	 * @author bbpf0170 - Magson Dias
	 * @param {@link Recebedor}
	 */
	private void configurarRecebedor(Recebedor recebedor) {
		configurarCPF(getRecebedor());
		configurarRepresentantes(getRecebedor());
		//configurarCep(getParticipante());
	}

	/**
	 * Método para retorna data Atual
	 * @author bbpf0170 - Magson Dias
	 * @return {@link Date}
	 */
	public Date getDataAtual() {
		if (dataAtual == null)
			dataAtual = new Date();
		return dataAtual;
	}

	/**
	 * Método para configurar CPF do recebedor 
	 * @author bbpf0170 - Magson Dias
	 * @param {@link Recebedor}
	 */
	private void configurarCPF(Recebedor recebedor) {
		String cpf = null;
		if (!UtilJava.isStringVazia(recebedor.getCpf())) {
			cpf = new String(TipoMascara.CPF.aplicarMascara(recebedor.getCpf()));
			cpf = cpf.replaceAll("\\.", "");

			if (cpf.split("-")[0] != null && !cpf.split("-")[0].equals(""))
				recebedor.setNumeroCpf(new BigDecimal(cpf.split("-")[0]));

			if (cpf.split("-")[1] != null && !cpf.split("-")[1].equals(""))
				recebedor.setNumeroComplCpf(new BigDecimal(cpf.split("-")[1]));
		}

	}

	/**
	 * Método para configurar Representantes  do recebedor 
	 * @author bbpf0468 - Carlos Wallace
	 * @param {@link Recebedor}
	 */
	private void configurarRepresentantes(Recebedor recebedor) {
		if (!recebedor.getListaRepresentanteRecebedor().isEmpty()) {

			for (RepresentanteRecebedor rep : recebedor.getListaRepresentanteRecebedor()) {
				rep.setIndicadorContraCheque(rep.isContraCheque() ? "S" : "N");
				rep.setIndicadorCreditoBancario(rep.isCreditoBancario() ? "S" : "N");
			}
		}
	}

	/**
	 * Método para validar campos
	 * @author bbpf0170 - Magson Dias
	 * @return {@link boolean}
	 */

	private boolean validaCampos() {
		boolean res = false;
		if (StringUtils.isNotBlank(this.recebedor.getEmail()) && !EmailValidator.getInstance().isValid(this.recebedor.getEmail())) {
			addMsgErro("O email digitado não é valido!");
			res = true;
		}
		if (!this.recebedor.getEmailSecundario().equals("")) {
			if (!EmailValidator.getInstance().isValid(this.recebedor.getEmailSecundario())) {
				addMsgErro("O e-mail secundário digitado não é valido!");
				res = true;
			}
		}
		if (this.recebedor.getNumeroCpf() == null || this.recebedor.getNumeroComplCpf() == null) {
			addMsgErro("O CPF digitado não é válido!");
			res = true;
		} else {
			if (!CpfCnpjValidator.isValidCPF(TipoMascara.CPF.aplicarMascara(this.recebedor.getCpf()))) {
				//Mensagens.addError("ME056", UtilJava.formataCPF(recebedor.getCpf()));
				addMsgErro("O CPF digitado não é válido!");
				res = true;
			}
		}

		List<Recebedor> listaRecebedor = this.recebedorBO.pesquisarRecebedorPorCodigoParticipante(recebedor.getParticipante());

		if (UtilJava.isColecaoDiferenteDeVazia(listaRecebedor)) {

			for (Recebedor recebedor : listaRecebedor) {

				if (this.recebedor.getCodigo() != null && (recebedor.getCodigo().equals(this.recebedor.getCodigo()))) {
					continue;
				}

				if (this.recebedor.isPercentualIndividual() && !recebedor.isPercentualIndividual()) {
					br.com.bbprevidencia.bbpcomum.util.Mensagens.addMsgInfo("Existe recebedor do grupo sem percentual cadastrado!");
				}
			}
		}
		return res;
	}

	/*
	 * 
	
	private void configurarCep(Recebedor recebedor) {
		String cep = null;
		if (!UtilJava.isStringVazia(participante.getCep())) {
			cep = new String(TipoMascara.CEP.aplicarMascara(participante.getCep()));
			if (cep.split("-")[0] != null && !cep.split("-")[0].equals(""))
				participante.setEnderecoCep(cep.split("-")[0]);
			if (cep.split("-")[1] != null && !cep.split("-")[1].equals(""))
				participante.setEnderecoComplementoCep(cep.split("-")[1]);
		}
	}
	 */

	/**
	 * Método para adiciona a mensage de erro no faces.
	 * @author  BBPF0170 - MAGSON 
	 * @param {@link String mensagem}
	 */
	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

	/**
	 * Método responsável por retornar o objeto recebedor carregado com as informações do participate.
	 * 
	 * @author BBPF0170 - Magson Dias 
	 * @since 16/02/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return	{@link String}
	 */
	public String retornaOproprio(AjaxBehaviorEvent event) {
		this.setQualidadeRecebedor(this.recebedor.getQualidadeRecebedor());
		try {
			if (this.recebedor.getQualidadeRecebedor().getCodigo() == 1 && this.recebedor.getCodigo() == null) {
				this.recebedor = validacaoUtil.retornaOproprioRecebedorParticipante(this.participante, this.loginTemporariaDTO);
				if (this.recebedor.getQualidadeRecebedor() == null) {
					this.recebedor.setQualidadeRecebedor(this.qualidadeRecebedor);
				}

				if (this.recebedor.getAgenciaBancaria() != null) {
					this.setCodigoBanco(this.recebedor.getAgenciaBancaria().getChavePrimaria().getCodigoBanco());
					this.setCodigoAgencia(this.recebedor.getAgenciaBancaria().getChavePrimaria().getCodigoAgenciaBancaria());
					this.listarAgenciaBancaria = new ArrayList<AgenciaBancaria>(this.agenciaBancariaBO.pequisarAgenciaPorCodigoBanco(this.codigoBanco));
				}

			}
			return "";
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}

	}

	/**
	 * Método responsável por setar o Plano escolhido no select do plano
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link SelectEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Método para adicinar um telefone na tela de cadastro receberdor. 
	 * @author  BBPF00170 - Magson
	 * @since   13/02/2017
	 */
	public String adicionarTelefoneRecebedor() {
		boolean res = false;
		if (this.telefoneRecebedor.getNumeroDDD().equals("")) {
			addMsgErro("Número DDD: campo obrigatório!");
			res = true;
		}
		if (this.telefoneRecebedor.getNumeroTelefone().equals("")) {
			addMsgErro("Número Telefone: campo obrigatório!");
			res = true;
		}
		if (this.telefoneRecebedor.getTipoTelefone() == null) {
			addMsgErro("Tipo: campo obrigatório!");
			res = true;
		}

		if (!res) {
			this.telefoneRecebedor.setRecebedor(this.recebedor);
			this.telefoneRecebedor.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			this.telefoneRecebedor.setDataInclusao(new Date());
			this.recebedor.getListaTelefoneRecebedor().add(this.telefoneRecebedor);
			this.setTelefoneRecebedor(new TelefoneRecebedor());
		}
		//PrimeFaces.current().executeScript("PF('tbViewRecebedor').select(3);");
		return FW_RECEBEDOR;
	}

	/**
	 * Método para remover um telefone na tela de cadastro receberdor. 
	 * @author  BBPF00170 - Magson
	 * @since   13/02/2017
	 */
	public String removerTelRecebedor(TelefoneRecebedor telefone) {
		try {
			for (int i = 0; i < this.recebedor.getListaTelefoneRecebedor().size(); i++) {
				if (this.recebedor.getListaTelefoneRecebedor().get(i) == telefone) {
					this.recebedor.getListaTelefoneRecebedor().remove(i);
				}
			}

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi possível realizar a operação", e);

		}

		//PrimeFaces.current().executeScript("PF('tbViewRecebedor').select(3);");
		return FW_RECEBEDOR;

	}

	/**
	 * Método para adicionar um representante na tela de cadastro recebedor. 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since   15/08/2018
	 */
	public String adicionarRepresentanteRecebedor() {
		boolean res = false;
		if (this.representanteRecebedor.getRecebedorRepresentante() == null) {
			addMsgErro("Representante: campo obrigatório!");
			res = true;
		}
		if (this.representanteRecebedor.getDataInicioVigencia() == null) {
			addMsgErro("Data Início Vigência: campo obrigatório!");
			res = true;
		}
		if (this.representanteRecebedor.getDataTerminoVigencia() == null) {
			addMsgErro("Data Término Vigência : campo obrigatório!");
			res = true;
		}

		if (!res) {
			this.representanteRecebedor.setIndicadorContraCheque(this.representanteRecebedor.isContraCheque() ? "S" : "N");
			this.representanteRecebedor.setIndicadorCreditoBancario(this.representanteRecebedor.isCreditoBancario() ? "S" : "N");
			this.representanteRecebedor.setRecebedor(this.recebedor);
			this.representanteRecebedor.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			this.representanteRecebedor.setDataInclusao(new Date());
			this.recebedor.getListaRepresentanteRecebedor().add(this.representanteRecebedor);
			this.setRepresentanteRecebedor(new RepresentanteRecebedor());
		}
		return "";
	}

	/**
	 * Método responsavel por editar um registro do representante
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since 17/08/2018
	 * @param {@link Recebedor}
	 */
	public void editarRepRecebedor(RepresentanteRecebedor repRecebedor) {
		this.setRepresentanteRecebedor(repRecebedor);
		this.removerRepRecebedor(repRecebedor);
	}

	/**
	 * Método para remover um representante na tela de cadastro receberdor. 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since   15/08/2018
	 */
	public String removerRepRecebedor(RepresentanteRecebedor representante) {
		try {
			for (int i = 0; i < this.recebedor.getListaRepresentanteRecebedor().size(); i++) {
				if (this.recebedor.getListaRepresentanteRecebedor().get(i) == representante) {
					this.recebedor.getListaRepresentanteRecebedor().remove(i);
				}
			}

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi possível realizar a operação", e);

		}

		return "";

	}

	/**
	 * Método responsável por retornar a lista de Planos associados à patrocionadora selecionada.
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return	{@link String}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {
		//Limapdo os valores antigos à pesquisa
		setPlanoPrevidencia(new PlanoPrevidencia());
		setListaPlanoPrevidencia(new ArrayList<PlanoPrevidencia>());
		setParticipante(new Participante());
		setListaParticipante(new ArrayList<Participante>());
		setListarRecebedor(new ArrayList<Recebedor>());
		this.listarStatus = true;

		if (this.getCodigoEntidadeParticipante() == null) {
			this.setListaPlanoPrevidencia(new ArrayList<PlanoPrevidencia>());
		} else {
			try {
				EntidadeParticipantePK chavePrimaria = new EntidadeParticipantePK();
				chavePrimaria.setCodigoEntidadeParticipante(getCodigoEntidadeParticipante());
				chavePrimaria.setCodigoFundoPrevidencia(1L);

				EntidadeParticipante entidadeParticipante = new EntidadeParticipante();
				entidadeParticipante.setChavePrimaria(chavePrimaria);

				this.setEntidadeParticipante(entidadeParticipante);
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante()));

			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}

		return FW_RECEBEDOR;
	}

	/**
	 * Método para retornar lista de participante por nome
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 20/03/2017
	 * @param {@link String nome}
	 * @return list<Participante>
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
	}

	/**
	 * Método para retornar lista de recebedores por participante
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since 15/08/2018
	 * @param {@link String nomeRecebedor}
	 * @return list<Recebedor>
	 */
	public List<Recebedor> listarRecebedoresPorNomeEParticipante(String nomeRecebedor) {
		log.info("NOME RECEBEDOR " + nomeRecebedor);
		log.info("PARTICIPANTE " + this.participante.getNomeParticipante());
		return this.recebedorBO.listaRecebedorPorNomeEParticipante(nomeRecebedor, this.participante);
	}

	/**
	 * Método para retornar o processo de devolução
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 17/03/2017
	 * @param {@link Participante}
	 * @return {@link  String}
	 */
	public String pesquisarRecebedorParticipante(Participante participante) {
		if (this.getParticipante() != null && this.getParticipante().getCodigo() != null) {
			this.listarRecebedor = recebedorBO.listaReceborParticipante(participante);
			listarStatus = true;
		} else {
			addMsgErro("Informe um participante!");
		}
		return FW_RECEBEDOR;
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0170 - MAGSON 
	 * @since 08/03/2017
	 * @param {@link event}
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());
		setParticipante(new Participante());
	}

	public void handleSelecionarRepresentante(SelectEvent event) {
		setRecebedorParticipante((Recebedor) event.getObject());
		setRecebedorParticipante(new Recebedor());
	}

	/**
	 * Cria uma lista de itens da entidade participante.
	 *  
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @return list<SelectiItem>
	 */
	public List<SelectItem> listarEntidadeParticipante() {
		List<SelectItem> itens = new ArrayList<SelectItem>();
		List<EntidadeParticipante> listaPatrocinadora = entidadeParticipanteBO.listarEntidadeParticipante();
		if (!UtilJava.isColecaoVazia(listaPatrocinadora)) {
			for (EntidadeParticipante entidadeParticipante : listaPatrocinadora) {
				itens.add(new SelectItem(entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante(), entidadeParticipante.getNomeAbreviadoEntidadeParticipante()));
			}
		}
		return itens;
	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public ParticipanteBO getParticipanteBO() {
		return participanteBO;
	}

	public void setParticipanteBO(ParticipanteBO participanteBO) {
		this.participanteBO = participanteBO;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public GrupoRecebimentoDevolucaoBO getGrupoRecebimentoDevolucaoBO() {
		return grupoRecebimentoDevolucaoBO;
	}

	public void setGrupoRecebimentoDevolucaoBO(GrupoRecebimentoDevolucaoBO grupoRecebimentoDevolucaoBO) {
		this.grupoRecebimentoDevolucaoBO = grupoRecebimentoDevolucaoBO;
	}

	public TipoDevolucaoBO getTipoDevolucaoBo() {
		return tipoDevolucaoBo;
	}

	public void setTipoDevolucaoBo(TipoDevolucaoBO tipoDevolucaoBo) {
		this.tipoDevolucaoBo = tipoDevolucaoBo;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public GrupoRecebimentoDevolucao getGrupoRecebimentoDevolucao() {
		return grupoRecebimentoDevolucao;
	}

	public void setGrupoRecebimentoDevolucao(GrupoRecebimentoDevolucao grupoRecebimentoDevolucao) {
		this.grupoRecebimentoDevolucao = grupoRecebimentoDevolucao;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public List<GrupoRecebimentoDevolucao> getListaGrupoRecebimentoDevolucao() {
		return listaGrupoRecebimentoDevolucao;
	}

	public void setListaGrupoRecebimentoDevolucao(List<GrupoRecebimentoDevolucao> listaGrupoRecebimentoDevolucao) {
		this.listaGrupoRecebimentoDevolucao = listaGrupoRecebimentoDevolucao;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public RecebedorBO getRecebedorBO() {
		return recebedorBO;
	}

	public void setRecebedorBO(RecebedorBO recebedorBO) {
		this.recebedorBO = recebedorBO;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public List<Recebedor> getListarRecebedor() {
		return listarRecebedor;
	}

	public void setListarRecebedor(List<Recebedor> listarRecebedor) {
		this.listarRecebedor = listarRecebedor;
	}

	public QualidadeRecebedorBO getQualidadeRecebedorBO() {
		return qualidadeRecebedorBO;
	}

	public void setQualidadeRecebedorBO(QualidadeRecebedorBO qualidadeRecebedorBO) {
		this.qualidadeRecebedorBO = qualidadeRecebedorBO;
	}

	public List<QualidadeRecebedor> getListarQualidadeRecebedor() {
		return listarQualidadeRecebedor;
	}

	public void setListarQualidadeRecebedor(List<QualidadeRecebedor> listarQualidadeRecebedor) {
		this.listarQualidadeRecebedor = listarQualidadeRecebedor;
	}

	public SituacaoRecebedorBO getSituacaoRecebedorBO() {
		return situacaoRecebedorBO;
	}

	public void setSituacaoRecebedorBO(SituacaoRecebedorBO situacaoRecebedorBO) {
		this.situacaoRecebedorBO = situacaoRecebedorBO;
	}

	public List<SituacaoRecebedor> getListarSituacaoRecebedor() {
		return listarSituacaoRecebedor;
	}

	public void setListarSituacaoRecebedor(List<SituacaoRecebedor> listarSituacaoRecebedor) {
		this.listarSituacaoRecebedor = listarSituacaoRecebedor;
	}

	public EstadoCivilBO getEstadoCivilBO() {
		return estadoCivilBO;
	}

	public void setEstadoCivilBO(EstadoCivilBO estadoCivilBO) {
		this.estadoCivilBO = estadoCivilBO;
	}

	public List<UISelectItem> getListaItemGrauInstrucao() {
		return listaItemGrauInstrucao;
	}

	public void setListaItemGrauInstrucao(List<UISelectItem> listaItemGrauInstrucao) {
		this.listaItemGrauInstrucao = listaItemGrauInstrucao;
	}

	public List<EstadoCivil> getListaEstadoCivil() {
		return listaEstadoCivil;
	}

	public void setListaEstadoCivil(List<EstadoCivil> listaEstadoCivil) {
		this.listaEstadoCivil = listaEstadoCivil;
	}

	public GrauInstrucaoBO getGrauInstrucaoBO() {
		return grauInstrucaoBO;
	}

	public void setGrauInstrucaoBO(GrauInstrucaoBO grauInstrucaoBO) {
		this.grauInstrucaoBO = grauInstrucaoBO;
	}

	public List<GrauInstrucao> getListaGrauInstrucao() {
		return listaGrauInstrucao;
	}

	public void setListaGrauInstrucao(List<GrauInstrucao> listaGrauInstrucao) {
		this.listaGrauInstrucao = listaGrauInstrucao;
	}

	public BancoBO getBancoBO() {
		return bancoBO;
	}

	public void setBancoBO(BancoBO bancoBO) {
		this.bancoBO = bancoBO;
	}

	public List<BancoDTO> getListaBanco() {
		return listaBanco;
	}

	public void setListaBanco(List<BancoDTO> listaBanco) {
		this.listaBanco = listaBanco;
	}

	public AgenciaBancariaBO getAgenciaBancariaBO() {
		return agenciaBancariaBO;
	}

	public void setAgenciaBancariaBO(AgenciaBancariaBO agenciaBancariaBO) {
		this.agenciaBancariaBO = agenciaBancariaBO;
	}

	public BancoDTO getBancoDTO() {
		return bancoDTO;
	}

	public void setBancoDTO(BancoDTO bancoDTO) {
		this.bancoDTO = bancoDTO;
	}

	public Long getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(Long codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public Long getCodigoAgencia() {
		return codigoAgencia;
	}

	public void setCodigoAgencia(Long codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	public List<AgenciaBancaria> getListarAgenciaBancaria() {
		return listarAgenciaBancaria;
	}

	public void setListarAgenciaBancaria(List<AgenciaBancaria> listarAgenciaBancaria) {
		this.listarAgenciaBancaria = listarAgenciaBancaria;
	}

	public void setDataAtual(Date dataAtual) {
		this.dataAtual = dataAtual;
	}

	public Long getCodigoEntidadeParticipante() {
		return codigoEntidadeParticipante;
	}

	public void setCodigoEntidadeParticipante(Long codigoEntidadeParticipante) {
		this.codigoEntidadeParticipante = codigoEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public ParticipantePlanoBO getParticipantePlanoBO() {
		return participantePlanoBO;
	}

	public void setParticipantePlanoBO(ParticipantePlanoBO participantePlanoBO) {
		this.participantePlanoBO = participantePlanoBO;
	}

	public ParticipantePlano getParticipantePlano() {
		return participantePlano;
	}

	public void setParticipantePlano(ParticipantePlano participantePlano) {
		this.participantePlano = participantePlano;
	}

	public List<SelectItem> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<SelectItem> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public UnidadeFederativaBO getUnidadeFederativaBO() {
		return unidadeFederativaBO;
	}

	public void setUnidadeFederativaBO(UnidadeFederativaBO unidadeFederativaBO) {
		this.unidadeFederativaBO = unidadeFederativaBO;
	}

	public List<UnidadeFederativa> getListaUnidadeFederativa() {
		return listaUnidadeFederativa;
	}

	public void setListaUnidadeFederativa(List<UnidadeFederativa> listaUnidadeFederativa) {
		this.listaUnidadeFederativa = listaUnidadeFederativa;
	}

	public QualidadeRecebedor getQualidadeRecebedor() {
		return qualidadeRecebedor;
	}

	public void setQualidadeRecebedor(QualidadeRecebedor qualidadeRecebedor) {
		this.qualidadeRecebedor = qualidadeRecebedor;
	}

	public List<TipoTelefone> getListaTipoTelefone() {
		return listaTipoTelefone;
	}

	public void setListaTipoTelefone(List<TipoTelefone> listaTipoTelefone) {
		this.listaTipoTelefone = listaTipoTelefone;
	}

	public TelefoneRecebedor getTelefoneRecebedor() {
		return telefoneRecebedor;
	}

	public void setTelefoneRecebedor(TelefoneRecebedor telefoneRecebedor) {
		this.telefoneRecebedor = telefoneRecebedor;
	}

	public List<RepresentanteRecebedor> getListaRepresentanteRecebedor() {
		return listaRepresentanteRecebedor;
	}

	public void setListaRepresentanteRecebedor(List<RepresentanteRecebedor> listaRepresentanteRecebedor) {
		this.listaRepresentanteRecebedor = listaRepresentanteRecebedor;
	}

	public RepresentanteRecebedor getRepresentanteRecebedor() {
		return representanteRecebedor;
	}

	public void setRepresentanteRecebedor(RepresentanteRecebedor representanteRecebedor) {
		this.representanteRecebedor = representanteRecebedor;
	}

	public Recebedor getRecebedorParticipante() {
		return recebedorParticipante;
	}

	public void setRecebedorParticipante(Recebedor recebedorParticipante) {
		this.recebedorParticipante = recebedorParticipante;
	}

}
