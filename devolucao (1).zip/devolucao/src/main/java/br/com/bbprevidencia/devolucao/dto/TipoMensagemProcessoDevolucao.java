package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   23/01/2017
 * Classe de persistência para tabela TIP_MSG_PRO_DEV.
 */
@Entity
@Table(name = "TIP_MSG_PRO_DEV", schema = "OWN_DCR")
@NamedQuery(name = "TipoMensagemProcessoDevolucao.findAll", query = "SELECT q FROM TipoMensagemProcessoDevolucao q")
public class TipoMensagemProcessoDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TIP_MSG_PRO_DEV_GER", sequenceName = "S_TMPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TIP_MSG_PRO_DEV_GER")
	@Column(name = "NUM_SEQ_TIP_MSG_PRO_DEV")
	private Long codigo;

	@Column(name = "NOM_TIP_MSG_PRO_DEV")
	private String nome;

	/*@Enumerated(value = EnumType.STRING)
	@Column(name = "IND_TIP_MSG", nullable = false, length = 1, columnDefinition = "char(1)")
	private TipoMensagemEnum tipoMensagemEnum;
	 */

	@Column(name = "IND_TIP_MSG")
	private String indicadorTipoMensamem;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private String descricaoIndicadorTipoMensamem;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	/*
	 public TipoMensagemEnum getTipoMensagemEnum() {
	 return tipoMensagemEnum;
	 }

	 public void setTipoMensagemEnum(TipoMensagemEnum tipoMensagemEnum) {
	 this.tipoMensagemEnum = tipoMensagemEnum;
	 }
	 */

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public String getIndicadorTipoMensamem() {
		return indicadorTipoMensamem;
	}

	public void setIndicadorTipoMensamem(String indicadorTipoMensamem) {
		this.indicadorTipoMensamem = indicadorTipoMensamem;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getDescricaoIndicadorTipoMensamem() {

		descricaoIndicadorTipoMensamem = "ERRO";

		if (this.indicadorTipoMensamem.equals("E")) {
			descricaoIndicadorTipoMensamem = "ERRO";
		}

		if (this.indicadorTipoMensamem.equals("A")) {
			descricaoIndicadorTipoMensamem = "AVISO";
		}

		if (this.indicadorTipoMensamem.equals("R")) {
			descricaoIndicadorTipoMensamem = "RESUMO";
		}

		return descricaoIndicadorTipoMensamem;
	}

	public void setDescricaoIndicadorTipoMensamem(String descricaoIndicadorTipoMensamem) {
		this.descricaoIndicadorTipoMensamem = descricaoIndicadorTipoMensamem;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoMensagemProcessoDevolucao other = (TipoMensagemProcessoDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}