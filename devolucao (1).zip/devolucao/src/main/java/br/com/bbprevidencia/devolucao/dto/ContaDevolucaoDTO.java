package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ContaDevolucaoDTO {
	private String indicadorMantenedor;
	private Long codTipoContaDevolucao;
	private Double qtdTotalCotasContribuicao;
	private Double qtdTotalCotasJuros;
	private Double qtdTotalCotasMulta;
	private Double qtdTotalCotasCorrecao;
}
