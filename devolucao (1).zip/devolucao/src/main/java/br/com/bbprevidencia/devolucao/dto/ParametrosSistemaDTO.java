package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ParametrosSistemaDTO {
	private String nomSrvApl;
	private String numPortSrvApl;
	private String nomeUsuarioRelatoriRep;
	private String passUsuarioRelatorioRep;
	private String nomServdoRelat;
}
