package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   08/12/2016
 * Classe de persistência para tabela CONTA_DEVOLUCAO.
 */
@Entity
@Table(name = "CONTA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "ContaDevolucao.findAll", query = "SELECT q FROM ContaDevolucao q")
public class ContaDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;
	private static final Double VALOR_ZERO = 0D;

	@Id
	@SequenceGenerator(name = "CONTA_DEVOLUCAO_GER", sequenceName = "S_CD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CONTA_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_CONTA_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_CON_DEV")
	private TipoContaDevolucao tipoContaDevolucao;

	@Column(name = "IND_MAN")
	private String indicadorMantenedor;

	@Column(name = "IND_AUT")
	private String indicadorAutoMantenedor;

	@Column(name = "QTD_TOT_COT_CON")
	private Double qtdTotalCotasContribuicao;

	@Column(name = "QTD_TOT_COT_JUROS")
	private Double qtdTotalCotasJuros;

	@Column(name = "QTD_TOT_COT_COR")
	private Double qtdTotalCotasCorrecao;

	@Column(name = "QTD_TOT_COT_MULTA")
	private Double qtdTotalCotasMulta;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public ContaDevolucao() {
		super();
	}

	public ContaDevolucao(Devolucao devolucao, TipoContaDevolucao tipoContaDevolucao, String indicadorMantenedor, String indicadorAutoMantenedor) {
		super();
		this.devolucao = devolucao;
		this.tipoContaDevolucao = tipoContaDevolucao;
		this.indicadorMantenedor = indicadorMantenedor;
		this.indicadorAutoMantenedor = indicadorAutoMantenedor;
		this.qtdTotalCotasContribuicao = VALOR_ZERO;
		this.qtdTotalCotasJuros = VALOR_ZERO;
		this.qtdTotalCotasMulta = VALOR_ZERO;
		this.qtdTotalCotasCorrecao = VALOR_ZERO;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public TipoContaDevolucao getTipoContaDevolucao() {
		return tipoContaDevolucao;
	}

	public void setTipoContaDevolucao(TipoContaDevolucao tipoContaDevolucao) {
		this.tipoContaDevolucao = tipoContaDevolucao;
	}

	public String getIndicadorMantenedor() {
		return indicadorMantenedor;
	}

	public void setIndicadorMantenedor(String indicadorMantenedor) {
		this.indicadorMantenedor = indicadorMantenedor;
	}

	public String getIndicadorAutoMantenedor() {
		return indicadorAutoMantenedor;
	}

	public void setIndicadorAutoMantenedor(String indicadorAutoMantenedor) {
		this.indicadorAutoMantenedor = indicadorAutoMantenedor;
	}

	public Double getQtdTotalCotasContribuicao() {
		return qtdTotalCotasContribuicao;
	}

	public void setQtdTotalCotasContribuicao(Double qtdTotalCotasContribuicao) {
		this.qtdTotalCotasContribuicao = qtdTotalCotasContribuicao;
	}

	public Double getQtdTotalCotasJuros() {
		return qtdTotalCotasJuros;
	}

	public void setQtdTotalCotasJuros(Double qtdTotalCotasJuros) {
		this.qtdTotalCotasJuros = qtdTotalCotasJuros;
	}

	public Double getQtdTotalCotasCorrecao() {
		return qtdTotalCotasCorrecao;
	}

	public void setQtdTotalCotasCorrecao(Double qtdTotalCotasCorrecao) {
		this.qtdTotalCotasCorrecao = qtdTotalCotasCorrecao;
	}

	public Double getQtdTotalCotasMulta() {
		return qtdTotalCotasMulta;
	}

	public void setQtdTotalCotasMulta(Double qtdTotalCotasMulta) {
		this.qtdTotalCotasMulta = qtdTotalCotasMulta;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public String toString() {
		return "ContaDevolucao [codigo=" + codigo + ", devolucao=" + devolucao + ", tipoContaDevolucao=" + tipoContaDevolucao + ", indicadorMantenedor=" + indicadorMantenedor
				+ ", indicadorAutoMantenedor=" + indicadorAutoMantenedor + ", qtdTotalCotasContribuicao=" + qtdTotalCotasContribuicao + ", qtdTotalCotasJuros=" + qtdTotalCotasJuros
				+ ", qtdTotalCotasCorrecao=" + qtdTotalCotasCorrecao + ", qtdTotalCotasMulta=" + qtdTotalCotasMulta + ", dataAlteracao=" + dataAlteracao + ", dataInclusao=" + dataInclusao
				+ ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + "]";
	}

}