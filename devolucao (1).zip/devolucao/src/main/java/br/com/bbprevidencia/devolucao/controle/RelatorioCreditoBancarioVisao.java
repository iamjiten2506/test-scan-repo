package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.LancamentoIntegracaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioCreditoBancarioDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório de Crédito Bancário
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 16/06/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioCreditoBancarioVisao")
public class RelatorioCreditoBancarioVisao {

	private static final String FW_RELATORIO_CREDITO_BANCARIO = "/paginas/relatorioCreditoBancario.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioPagamentoFolhaVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;
	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	RelatorioUtil relatorioUtil;
	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;
	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;
	@Autowired
	private LancamentoIntegracaoDevolucaoBO lancamentoIntegracaoDevolucaoBO;

	private Date dataInicial;

	private Date dataFinal;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private CronogramaDevolucao cronogramaDevolucao;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;

	private List<TipoDevolucao> listaTipoDevolucao;

	private List<TipoDevolucao> listaTipoDevolucaoSelecionados;

	private boolean selecionarPlano;

	/**
	 * Método encarregado de preencher os dados inciais e carregar página
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/06/2017
	 * @return
	 */
	public String iniciarRelatorioCreditoBancario() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_CREDITO_BANCARIO;
	}

	/**
	 * Método encarregado de prencher os dados iniciais do sistema.
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/06/2017
	 */
	private void setarValoresIniciais() {
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(this.cronogramaDevolucaoBO.listarCronogramaDescendente());
		this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBO.listarTodosTipoDevolucao());
		this.cronogramaDevolucao = new CronogramaDevolucao();
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>();
		this.listaEntidadeParticipanteSelecionadas = new ArrayList<EntidadeParticipante>();
		setarVisaoMultiEmpresa();
	}

	private void setarVisaoMultiEmpresa() {
		this.selecionarPlano = false;
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
	}

	/**
	 * Método encarregado de pesquisar as entidades participantes que participaram do cáculo de determinado cronograma
	 */
	public void listarPatrocinadoraPorCronograma() {
		//Situação do cronograma como fechado
		if (this.cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
			this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.historicoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
		} else {
			this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.movimentoCalculoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/16/2017
	 */
	public void verificaListaPatrocinadora() {
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipanteSelecionadas)) {
			setarVisaoMultiEmpresa();
		} else {
			if (this.listaEntidadeParticipanteSelecionadas.size() == 1) {
				this.selecionarPlano = true;

				EntidadeParticipante entidadeParticipante = this.listaEntidadeParticipanteSelecionadas.get(0);
				this.listaPlanoPrevidencia = listarPlanoPrevidencia(entidadeParticipante);

			} else {
				setarVisaoMultiEmpresa();
			}
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link EntidadeParticipante}
	 * @return
	 */
	public List<PlanoPrevidencia> listarPlanoPrevidencia(EntidadeParticipante entidadeParticipante) {

		try {
			List<PlanoPrevidencia> listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(entidadeParticipante);

			return listaPlanoPrevidencia;
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/06/2017
	 */
	public void limparPesquisa() {
		setarValoresIniciais();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/16/2017
	 */
	public void exportarRelatorio() {
		try {
			RelatorioCreditoBancarioDTO relatorioCreditoBancarioDTO = new RelatorioCreditoBancarioDTO();

			relatorioCreditoBancarioDTO = lancamentoIntegracaoDevolucaoBO.preencherRelatorioCreditoBancario(
					this.cronogramaDevolucao,
					this.listaTipoDevolucaoSelecionados,
					this.listaEntidadeParticipanteSelecionadas,
					this.listaPlanoPrevidenciaSelecionados);
			if (UtilJava.isColecaoVazia(relatorioCreditoBancarioDTO.getListaRelatorioCreditoBancarioAnalitico())) {
				Mensagens.addMsgInfo("Não foram encontradas informações para estes parâmetros!");
			} else {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);

				parametros.put("dataPagamento", relatorioCreditoBancarioDTO.getDataPagamento());
				parametros.put("totalFolha", relatorioCreditoBancarioDTO.getTotalFolha());
				parametros.put("listaRelatorioCreditoBancarioAnalitico", relatorioCreditoBancarioDTO.getListaRelatorioCreditoBancarioAnalitico());
				parametros.put("listaRelatorioCreditoBancarioSintetico", relatorioCreditoBancarioDTO.getListaRelatorioCreditoBancarioSintetico());

				RelatorioCreditoBancarioDTO dado = new RelatorioCreditoBancarioDTO();
				List<RelatorioCreditoBancarioDTO> minhaLista = new ArrayList<RelatorioCreditoBancarioDTO>();
				minhaLista.add(dado);

				imprimirRelatorio("creditoBancario", minhaLista, parametros);

			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro("Erro ao exportar relatório: " + ex.getMessage());
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param relatorio
	 * @param dados
	 * @param param
	 */
	public void imprimirRelatorio(String relatorio, List<RelatorioCreditoBancarioDTO> dados, Map<String, Object> parametros) {
		try {
			String nomeArquivo = relatorioUtil.gerarRelatorio(relatorio, dados, parametros);
			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (Exception e) {
			log.error("Erro ao exportar relatório.", e);
			throw new PrevidenciaException(e);
		}
	}

	/* Getters And Setters */

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public List<TipoDevolucao> getListaTipoDevolucaoSelecionados() {
		return listaTipoDevolucaoSelecionados;
	}

	public void setListaTipoDevolucaoSelecionados(List<TipoDevolucao> listaTipoDevolucaoSelecionados) {
		this.listaTipoDevolucaoSelecionados = listaTipoDevolucaoSelecionados;
	}

}
