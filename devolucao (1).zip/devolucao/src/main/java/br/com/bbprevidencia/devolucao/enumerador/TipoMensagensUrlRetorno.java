package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoMensagensUrlRetorno {

	PESQUISA("pesquisa", "Pesquisa."),
	ATUALIZ_RECEB("atualizacao", "Atualização para recebimento."),
	CONFERENCIA("conferencia", "Conferência."),
	ENVIO_DEFERIMENTO("deferimento", "Envio para deferimento."),
	VERIFICAR_DEFERIMENTO("verificarDeferimento", "Verificação de deferimento."),
	CANCELAMENTO("cancelamento", "Cancelamento."),
	CALCULO_DEVOLUCAO_MANUAL("devolucaoManual", "Cálculo Devolução Manual");

	private String codigo;
	private String descricao;

	private TipoMensagensUrlRetorno(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return TipoIntegracaoEnum
	 */
	public static TipoMensagensUrlRetorno getTipoMensagensUrlRetorno(String codigo) {
		if (codigo != null) {
			for (TipoMensagensUrlRetorno tipoMensagensUrlRetorno : values()) {
				if (tipoMensagensUrlRetorno.getCodigo().equals(codigo)) {
					return tipoMensagensUrlRetorno;
				}
			}
		}
		return null;
	}
}
