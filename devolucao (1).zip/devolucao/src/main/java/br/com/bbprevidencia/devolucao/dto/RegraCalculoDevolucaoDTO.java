package br.com.bbprevidencia.devolucao.dto;

import java.util.List;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.fasterxml.jackson.annotation.JsonProperty;

import br.com.bbprevidencia.devolucao.enumerador.TipoValorizacaoEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegraCalculoDevolucaoDTO {

	@JsonProperty("tipoDevolucao")
	private String tipoDevolucaoIndicadorTipoDevolucao;

	@JsonProperty("nomeTipoDevolucao")
	private String tipoDevolucaoNome;

	private Long numeroMaximoParcelas;

	private Double percentualJuros;

	private String indicadorTipoImpostoProgressivo;

	@Enumerated(value = EnumType.STRING)
	@JsonProperty("tipoValorizacao")
	private TipoValorizacaoEnum tipoValorizacaoEnum;

	@JsonProperty("indiceEnconomicoPagamento")
	private String indiceEnconomicoCodigoIndiceEconomico;

	private String indiceEconomicoMinimoParcela;

	@JsonProperty("regraElegibilidade")
	List<RegraElegibilidadeDevolucaoDTO> listaRegraElegibilidadeDevolucao;

}
