package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Transient;

import com.ibm.icu.math.BigDecimal;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;

@Entity
public class RelatorioPagamentoDevolucaoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RelatorioPagamentoDevolucaoDTOPK chavePrimaria;

	@Column(name = "NOM_ABREV_ENTID_PARTIC")
	private String nomePatrocinadora;

	@Column(name = "NOM_ABREV_PLANO")
	private String nomePlano;

	@Column(name = "NUM_MATRIC_PATROC")
	private String matriculaParticipante;

	@Column(name = "NOM_PARTIC")
	private String nomeParticipante;

	@Column(name = "CPF")
	private String cpf;

	@Column(name = "NUM_CNPJ")
	private String cnpj;

	@Column(name = "DAT_REQ")
	private Date dataRequerimento;

	@Column(name = "VALOR_PROVENTO")
	private Double valorBruto;

	@Column(name = "VALOR_IR")
	private Double valorIR;

	@Column(name = "VALOR_DESCONTO")
	private Double valorDescontoTotal;

	@Transient
	private Double valorDesconto;

	@Transient
	private Double valorLiquido;

	@Column(name = "DAT_COT")
	private Date dataCota;

	@Transient
	private String dataFormatada;

	@Transient
	private String dataRequerimentoFormatada;

	@Transient
	private String dataCotaFormatada;

	@Transient
	private String dataPagamentoFormatada;

	@Column(name = "QTD_PARTIC")
	private Double qtdPartic;

	@Column(name = "QTD_PATROC")
	private Double qtdPatroc;

	public RelatorioPagamentoDevolucaoDTOPK getChavePrimaria() {
		return chavePrimaria;
	}

	public void setChavePrimaria(RelatorioPagamentoDevolucaoDTOPK chavePrimaria) {
		this.chavePrimaria = chavePrimaria;
	}

	public String getNomePatrocinadora() {
		return nomePatrocinadora;
	}

	public void setNomePatrocinadora(String nomePatrocinadora) {
		this.nomePatrocinadora = nomePatrocinadora;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public Double getValorBruto() {
		return valorBruto;
	}

	public void setValorBruto(Double valorBruto) {
		this.valorBruto = valorBruto;
	}

	public Double getValorIR() {
		return valorIR;
	}

	public void setValorIR(Double valorIR) {
		this.valorIR = valorIR;
	}

	public Double getValorDesconto() {
		return valorDesconto();
	}

	public void setValorDesconto(Double valorDesconto) {
		this.valorDesconto = valorDesconto();
	}

	public Double getValorLiquido() {
		return valorLiquido();
	}

	public void setValorLiquido(Double valorLiquido) {
		this.valorLiquido = valorLiquido();
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public String getDataFormatada() {
		return UtilJava.formataDataPorPadrao(chavePrimaria.getDataPagamento(), "dd/MM/yyyy");
	}

	public void setDataFormatada(String dataFormatada) {
		this.dataFormatada = dataFormatada;
	}

	public Double getValorDescontoTotal() {
		return valorDescontoTotal;
	}

	public void setValorDescontoTotal(Double valorDescontoTotal) {
		this.valorDescontoTotal = valorDescontoTotal;
	}

	public Double valorLiquido() {
		return new BigDecimal(this.valorBruto - this.valorDescontoTotal).doubleValue();
	}

	public Double valorDesconto() {
		return new BigDecimal(this.valorDescontoTotal - this.valorIR).doubleValue();
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public Double getQtdPartic() {
		return qtdPartic;
	}

	public void setQtdPartic(Double qtdPartic) {
		this.qtdPartic = qtdPartic;
	}

	public Double getQtdPatroc() {
		return qtdPatroc;
	}

	public void setQtdPatroc(Double qtdPatroc) {
		this.qtdPatroc = qtdPatroc;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getDataRequerimentoFormatada() {
		return UtilJava.formataDataPorPadrao(this.getDataRequerimento(), "dd/MM/yyyy");
	}

	public String getDataCotaFormatada() {
		return UtilJava.formataDataPorPadrao(this.dataCota, "dd/MM/yyyy");
	}

	public String getDataPagamentoFormatada() {
		return UtilJava.formataDataPorPadrao(chavePrimaria.getDataPagamento(), "dd/MM/yyyy");
	}

}
