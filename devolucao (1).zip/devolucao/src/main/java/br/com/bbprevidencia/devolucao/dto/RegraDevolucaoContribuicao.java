package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.TipoContribuicao;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 28/11/2016 Classe de persistência para tabela REGRA_DEV_CONTRIB.
 */
@Entity
@Table(name = "REG_CON_DEV", schema = "OWN_DCR")
@NamedQuery(name = "RegraDevolucaoContribuicao.findAll", query = "SELECT q FROM RegraDevolucaoContribuicao q")
public class RegraDevolucaoContribuicao implements Serializable, BaseEntity, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REG_CON_DEV_GER", sequenceName = "S_RCD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REG_CON_DEV_GER")
	@Column(name = "NUM_SEQ_REG_CON_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CAL_DEV")
	private RegraCalculoDevolucao regraCalculoDevolucao;

	@ManyToOne
	@JoinColumn(name = "COD_TIPO_CONTRI")
	private TipoContribuicao tipoContribuicao;

	@Column(name = "NUM_CAR_TEM_ESP_EMP")
	private Long mesesTempoEsperaContriEmpresa;

	@Column(name = "NUM_CAR_TEM_ESP_PAR")
	private Long mesesTempoEsperaContriParticipante;

	@Column(name = "IND_CON_PAR")
	private String consideraContribParticipante;

	@Column(name = "IND_CON_EMP")
	private String consideraContribEmpresa;

	@Column(name = "IND_REV_PAR")
	private String geraReversaoContribParticipante;

	@Column(name = "IND_REV_EMP")
	private String geraReversaoContribEmpresa;

	@Column(name = "IND_REGRA_COM")
	private String indicadorVigenciaCompetContribuicao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private boolean consideraResevaEmpresa;

	@Transient
	private boolean consideraResevaParticipante;

	@Transient
	private boolean geraReversaoEmpresa;

	@Transient
	private boolean geraReversaoParticipante;

	@Transient
	private boolean resgateAplicadoPorCompetencia;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "regraDevolucaoContribuicao", fetch = FetchType.EAGER, targetEntity = RegraDevolucaoContribFaixas.class, orphanRemoval = true)
	private List<RegraDevolucaoContribFaixas> listaRegraDevolucaoContribFaixas = new ArrayList<RegraDevolucaoContribFaixas>();

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "regraDevolucaoContribuicao", fetch = FetchType.EAGER, targetEntity = PlanoContribFaixasDev.class, orphanRemoval = true)
	private List<PlanoContribFaixasDev> listaPlanoContrtibFaixasDev = new ArrayList<PlanoContribFaixasDev>();

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public TipoContribuicao getTipoContribuicao() {
		return tipoContribuicao;
	}

	public void setTipoContribuicao(TipoContribuicao tipoContribuicao) {
		this.tipoContribuicao = tipoContribuicao;
	}

	public Long getMesesTempoEsperaContriEmpresa() {
		return mesesTempoEsperaContriEmpresa;
	}

	public void setMesesTempoEsperaContriEmpresa(Long mesesTempoEsperaContriEmpresa) {
		this.mesesTempoEsperaContriEmpresa = mesesTempoEsperaContriEmpresa;
	}

	public Long getMesesTempoEsperaContriParticipante() {
		return mesesTempoEsperaContriParticipante;
	}

	public void setMesesTempoEsperaContriParticipante(Long mesesTempoEsperaContriParticipante) {
		this.mesesTempoEsperaContriParticipante = mesesTempoEsperaContriParticipante;
	}

	public String getConsideraContribParticipante() {
		this.consideraResevaParticipante = this.consideraContribParticipante == null ? false : this.consideraContribParticipante.equalsIgnoreCase("S") ? true : false;
		return consideraContribParticipante;
	}

	public void setConsideraContribParticipante(String consideraContribParticipante) {
		this.consideraContribParticipante = consideraContribParticipante;
	}

	public String getConsideraContribEmpresa() {
		this.consideraResevaEmpresa = this.consideraContribEmpresa == null ? false : this.consideraContribEmpresa.equalsIgnoreCase("S") ? true : false;
		return consideraContribEmpresa;
	}

	public void setConsideraContribEmpresa(String consideraContribEmpresa) {
		this.consideraContribEmpresa = consideraContribEmpresa;
	}

	public String getGeraReversaoContribParticipante() {
		this.geraReversaoParticipante = this.geraReversaoContribParticipante == null ? false : this.geraReversaoContribParticipante.equalsIgnoreCase("S") ? true : false;
		return geraReversaoContribParticipante;
	}

	public void setGeraReversaoContribParticipante(String geraReversaoContribParticipante) {
		this.geraReversaoContribParticipante = geraReversaoContribParticipante;
	}

	public String getGeraReversaoContribEmpresa() {
		this.geraReversaoEmpresa = this.geraReversaoContribEmpresa == null ? false : this.geraReversaoContribEmpresa.equalsIgnoreCase("S") ? true : false;
		return geraReversaoContribEmpresa;
	}

	public void setGeraReversaoContribEmpresa(String geraReversaoContribEmpresa) {
		this.geraReversaoContribEmpresa = geraReversaoContribEmpresa;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public List<RegraDevolucaoContribFaixas> getListaRegraDevolucaoContribFaixas() {
		return listaRegraDevolucaoContribFaixas;
	}

	public void setListaRegraDevolucaoContribFaixas(List<RegraDevolucaoContribFaixas> listaRegraDevolucaoContribFaixas) {
		this.listaRegraDevolucaoContribFaixas = listaRegraDevolucaoContribFaixas;
	}

	public String getIndicadorVigenciaCompetContribuicao() {
		this.resgateAplicadoPorCompetencia = this.indicadorVigenciaCompetContribuicao == null ? false : this.indicadorVigenciaCompetContribuicao.equalsIgnoreCase("S") ? true : false;
		return indicadorVigenciaCompetContribuicao;
	}

	public void setIndicadorVigenciaCompetContribuicao(String indicadorVigenciaCompetContribuicao) {
		this.indicadorVigenciaCompetContribuicao = indicadorVigenciaCompetContribuicao;
	}

	public List<PlanoContribFaixasDev> getListaPlanoContrtibFaixasDev() {
		return listaPlanoContrtibFaixasDev;
	}

	public void setListaPlanoContrtibFaixasDev(List<PlanoContribFaixasDev> listaPlanoContrtibFaixasDev) {
		this.listaPlanoContrtibFaixasDev = listaPlanoContrtibFaixasDev;
	}

	public boolean isConsideraResevaEmpresa() {
		return consideraResevaEmpresa;
	}

	public void setConsideraResevaEmpresa(boolean consideraResevaEmpresa) {
		this.consideraResevaEmpresa = consideraResevaEmpresa;
		this.setConsideraContribEmpresa(consideraResevaEmpresa ? "S" : "N");
	}

	public boolean isConsideraResevaParticipante() {
		return consideraResevaParticipante;
	}

	public void setConsideraResevaParticipante(boolean consideraResevaParticipante) {
		this.consideraResevaParticipante = consideraResevaParticipante;
		this.setConsideraContribParticipante(consideraResevaParticipante ? "S" : "N");
	}

	public boolean isGeraReversaoEmpresa() {
		return geraReversaoEmpresa;
	}

	public void setGeraReversaoEmpresa(boolean geraReversaoEmpresa) {
		this.geraReversaoEmpresa = geraReversaoEmpresa;
		this.setGeraReversaoContribEmpresa(geraReversaoEmpresa ? "S" : "N");
	}

	public boolean isGeraReversaoParticipante() {
		return geraReversaoParticipante;
	}

	public void setGeraReversaoParticipante(boolean geraReversaoParticipante) {
		this.geraReversaoParticipante = geraReversaoParticipante;
		this.setGeraReversaoContribParticipante(geraReversaoParticipante ? "S" : "N");
	}

	public boolean isResgateAplicadoPorCompetencia() {
		return resgateAplicadoPorCompetencia;
	}

	public void setResgateAplicadoPorCompetencia(boolean resgateAplicadoPorCompetencia) {
		this.resgateAplicadoPorCompetencia = resgateAplicadoPorCompetencia;
		this.setIndicadorVigenciaCompetContribuicao(resgateAplicadoPorCompetencia ? "S" : "N");
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegraDevolucaoContribuicao other = (RegraDevolucaoContribuicao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RegraDevolucaoContribuicao [codigo=" + codigo + ", regraCalculoDevolucao=" + regraCalculoDevolucao + ", tipoContribuicao=" + tipoContribuicao + ", mesesTempoEsperaContriEmpresa="
				+ mesesTempoEsperaContriEmpresa + ", mesesTempoEsperaContriParticipante=" + mesesTempoEsperaContriParticipante + ", consideraContribParticipante=" + consideraContribParticipante
				+ ", consideraContribEmpresa=" + consideraContribEmpresa + ", geraReversaoContribParticipante=" + geraReversaoContribParticipante + ", geraReversaoContribEmpresa="
				+ geraReversaoContribEmpresa + ", indicadorVigenciaCompetContribuicao=" + indicadorVigenciaCompetContribuicao + ", dataAlteracao=" + dataAlteracao + ", dataInclusao=" + dataInclusao
				+ ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + ", listaRegraDevolucaoContribFaixas=" + listaRegraDevolucaoContribFaixas
				+ ", listaPlanoContrtibFaixasDev=" + listaPlanoContrtibFaixasDev + "]";
	}

	@Override
	public RegraDevolucaoContribuicao clone() throws CloneNotSupportedException {
		RegraDevolucaoContribuicao regraDevolucaoContribuicao = (RegraDevolucaoContribuicao) super.clone();

		regraDevolucaoContribuicao.setCodigo(null);

		List<RegraDevolucaoContribFaixas> listaRegraDevolucaoContribFaixas = new ArrayList<RegraDevolucaoContribFaixas>();

		List<PlanoContribFaixasDev> listaPlanoContribFaixasDev = new ArrayList<PlanoContribFaixasDev>();

		for (RegraDevolucaoContribFaixas regraDevolucaoContribFaixas : regraDevolucaoContribuicao.getListaRegraDevolucaoContribFaixas()) {
			regraDevolucaoContribFaixas.setCodigo(null);
			listaRegraDevolucaoContribFaixas.add(regraDevolucaoContribFaixas.clone());
		}

		for (RegraDevolucaoContribFaixas regraDevolucaoContribFaixas : listaRegraDevolucaoContribFaixas) {
			regraDevolucaoContribFaixas.setCodigo(null);
		}

		for (PlanoContribFaixasDev planoContribFaixasDev : regraDevolucaoContribuicao.getListaPlanoContrtibFaixasDev()) {
			listaPlanoContribFaixasDev.add(planoContribFaixasDev.clone());
		}

		for (PlanoContribFaixasDev planoContribFaixasDev : listaPlanoContribFaixasDev) {
			planoContribFaixasDev.setCodigo(null);
		}

		regraDevolucaoContribuicao.setListaRegraDevolucaoContribFaixas(listaRegraDevolucaoContribFaixas);
		regraDevolucaoContribuicao.setListaPlanoContrtibFaixasDev(listaPlanoContribFaixasDev);

		return regraDevolucaoContribuicao;
	}

	public List<RegraDevolucaoContribFaixas> getListaRegraDevolucaoContribFaixasFiltradaPorEntidadeParticipante(
			EntidadeParticipante entidadeParticipante) {

		List<RegraDevolucaoContribFaixas> lista = this.listaRegraDevolucaoContribFaixas.stream()
				.filter(p ->  p.getEntidadeParticipante() != null && p.getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante()
						.equals(entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante())
						&& p.getEntidadeParticipante().getChavePrimaria().getCodigoFundoPrevidencia()
								.equals(entidadeParticipante.getChavePrimaria().getCodigoFundoPrevidencia()))
				.collect(Collectors.toList());
		
		if (UtilJava.isColecaoDiferenteDeVazia(lista)) {
			return lista;
		}
		
		return this.listaRegraDevolucaoContribFaixas.stream().filter(p -> p.getEntidadeParticipante() == null).collect(Collectors.toList());
	}
}