package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoItemBO;
import br.com.bbprevidencia.devolucao.bo.GrupoRecebimentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucaoVisaoItem;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraElegibilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioDocumentoPendenteDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.bo.AtuacaoPessoaBO;
import br.com.bbprevidencia.pessoa.bo.PessoaEntidadeBO;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;
import br.com.bbprevidencia.pessoa.dto.PessoaEntidade;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório do Processo de Retenção
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 12/04/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioDocumentoPendenteVisao")
public class RelatorioDocumentoPendenteVisao {

	private static final String FW_RELATORIO_DOCUMENTO_PENDENTE = "/paginas/relatorioDocumentoPendente.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioDocumentoPendenteVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;
	@Autowired
	private DevolucaoBO devolucaoBO;
	@Autowired
	private GrupoRecebimentoDevolucaoBO grupoRecebimentoDevolucaoBO;
	@Autowired
	private DocumentoDevolucaoVisaoBO documentoDevolucaoVisaoBO;
	@Autowired
	private DocumentoDevolucaoVisaoItemBO documentoDevolucaoVisaoItemBO;
	@Autowired
	private PessoaEntidadeBO pessoaEntidadeBO;
	@Autowired
	private AtuacaoPessoaBO atuacaoPessoaBO;
	@Autowired
	RelatorioUtil relatorioUtil;

	private boolean selecionarParticipante;
	private boolean selecionarPlano;

	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<TipoDevolucao> listaTipoDevolucao;
	private List<Recebedor> listaRecebedor;
	private List<Devolucao> listaDevolucoes;

	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private Participante participante;
	private TipoDevolucao tipoDevolucao;
	private RegraCalculoDevolucao regraCalculoDevolucao;
	private RegraElegibilidadeDevolucao regraElegibilidadeDevolucao;
	private Recebedor recebedor;
	private ParticipantePlano participantePlano;
	private boolean recebedorObrigatorio;
	private boolean pessoaObrigatoria;
	private List<PessoaEntidade> listaPessoa;
	private PessoaEntidade pessoa;

	public String iniciarRelatorioCartaDocumentoPendente() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_DOCUMENTO_PENDENTE;

	}

	/**
	 * Setar os valores iniciais da Tela
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/04/2017
	 */
	private void setarValoresIniciais() {
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipante)) {
			this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.entidadeParticipanteBO.listarEntidadeParticipanteOrderByNome());
		}

		this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBO.listarTodosTipoDevolucao());

		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaRecebedor = new ArrayList<Recebedor>();
		this.participante = new Participante();
		this.planoPrevidencia = new PlanoPrevidencia();
		this.recebedor = new Recebedor();
		this.entidadeParticipante = new EntidadeParticipante();
		this.listaDevolucoes = new ArrayList<Devolucao>();

		this.selecionarParticipante = false;
		this.selecionarPlano = false;
		this.regraCalculoDevolucao = null;
		this.tipoDevolucao = new TipoDevolucao();
		this.recebedorObrigatorio = false;
		this.pessoaObrigatoria = false;
		this.pessoa = new PessoaEntidade();
		this.listaPessoa = new ArrayList<PessoaEntidade>();
	}

	/**
	 * Método encarregado de listar os planos pela patrocinado selecionada
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/04/2017
	 */
	public void listarPlanoPrevidenciaPorPatrocinadora() {
		try {
			if (this.getEntidadeParticipante() != null) {
				this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante);
				this.selecionarPlano = true;
				this.selecionarParticipante = true;

				if (UtilJava.isColecaoDiferenteDeVazia(this.listaPlanoPrevidencia) && this.listaPlanoPrevidencia.size() == 1) {
					this.setPlanoPrevidencia(this.listaPlanoPrevidencia.get(0));
					listarTipoDevolucaoPorPlanoPrevidencia();
				}
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/04/2017
	 */
	public void listarTipoDevolucaoPorPlanoPrevidencia() {
		try {
			if (this.getPlanoPrevidencia() != null) {
				this.selecionarParticipante = true;
				List<TipoDevolucao> listaTipoDevolucaoTemp = this.tipoDevolucaoBO.listarTodosTipoDevolucaoPorPlanoPrevidencia(getPlanoPrevidencia());

				if (UtilJava.isColecaoDiferenteDeVazia(listaTipoDevolucaoTemp)) {
					this.listaTipoDevolucao = listaTipoDevolucaoTemp;
				}
			} else {
				this.selecionarParticipante = false;
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo digitado no autocomplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.getPlanoPrevidencia().getCodigo() != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.getEntidadeParticipante());
		}
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/04/2017
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() == null) {
			setParticipante(new Participante());
		}

		//Pesquisar devoluções para o participante
		this.listaDevolucoes = new ArrayList<Devolucao>();
		if (this.participante.getCodigo() != null && this.participante.getListaParticipantePlano().size() > 0) {
			if (this.participante.getListaParticipantePlano().size() == 1) {
				this.listaDevolucoes.addAll(this.devolucaoBO.pesquisarDevolucaoPorParticipantePlano(this.participante.getListaParticipantePlano().get(0)));
			} else {
				for (ParticipantePlano pp : this.participante.getListaParticipantePlano()) {
					this.listaDevolucoes.addAll(this.devolucaoBO.pesquisarDevolucaoPorParticipantePlano(pp));
				}
			}
		}

		if (this.listaDevolucoes.size() == 0) {
			Mensagens.addMsgInfo("Não existem devoluções para este Participante.");
		}
	}

	/**
	 * Método responsável por limpar a pesquisa.
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/04/2017
	 * @param event
	 */
	public void limparPesquisa() {
		setarValoresIniciais();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/03/2017
	 * @param event
	 */
	public void exportarRelatorio(ActionEvent event) {
		try {
			Object recebedorPessoa = new Object();
			List<DocumentoDevolucaoVisaoItem> listaDevolucaoVisaoItem = new ArrayList<DocumentoDevolucaoVisaoItem>();
			if (this.tipoDevolucao.getIndicadorTipoDevolucao().equalsIgnoreCase("R")) {
				if (this.recebedor.getCodigo() == null) {
					throw new PrevidenciaException("Não há recebedor selecionado para emitir o relatório.");
				} else {
					recebedorPessoa = this.recebedor;
					if (this.listaDevolucoes.size() != 0) {
						for (Devolucao de : this.listaDevolucoes) {
							List<DocumentoDevolucaoVisaoItem> lst = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorDevolucaoERecebedor(de, this.recebedor);
							if (UtilJava.isColecaoDiferenteDeVazia(lst)) {
								listaDevolucaoVisaoItem.addAll(lst);
							}
						}
					}
				}
			} else {
				if (this.pessoa.getCodigo() == null) {
					throw new PrevidenciaException("Não há pessoa selecionada para emitir o relatório.");
				} else {
					recebedorPessoa = this.pessoa;
					if (this.listaDevolucoes.size() != 0) {
						for (Devolucao de : this.listaDevolucoes) {
							List<DocumentoDevolucaoVisaoItem> lst = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorDevolucaoAtuacaoPessoa(de, atuacaoPessoaBO
									.pesquisarAtuacaoPessoaPorPessoa(this.pessoa));
							if (UtilJava.isColecaoDiferenteDeVazia(lst)) {
								listaDevolucaoVisaoItem.addAll(lst);
							}
						}
					}
				}
			}

			if (listaDevolucaoVisaoItem.size() == 0) {
				Mensagens.addMsgInfo("Não existem documentos pendentes para emitir o relatório.");
			} else {
				RelatorioDocumentoPendenteDTO relatorio = this.documentoDevolucaoVisaoItemBO.montarRelatorioDocumentoPendenteDevolucao(recebedorPessoa, this.planoPrevidencia, this.participante);

				if (UtilJava.isColecaoVazia(relatorio.getListaDocumentoPendente()) && UtilJava.isColecaoVazia(relatorio.getListaDocumentoSolicitado())) {
					Mensagens.addMsgInfo("Não existem documentos pendentes para emitir o relatório.");
				} else {
					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

					String logo = UtilSession.getRealPath("imagens/logoBBPrevidencia.jpg");
					parametros.put("logo", logo);
					parametros.put("listaPendentes", relatorio.getListaDocumentoPendente());
					parametros.put("listaSolicitados", relatorio.getListaDocumentoSolicitado());

					List<RelatorioDocumentoPendenteDTO> listaRelatorioSaida = new ArrayList<RelatorioDocumentoPendenteDTO>();
					listaRelatorioSaida.add(relatorio);
					//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(listaRelatorioSaida);
					//GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "cartaDocumentoPendente", dataSource);
					String nomeArquivo = relatorioUtil.gerarRelatorio("cartaDocumentoPendente", listaRelatorioSaida, parametros);
					relatorioUtil.abrirPoupUp(nomeArquivo);
				}
			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/04/2017
	 */
	public void listarRecebedorOuPessoaPorDevolucao() {
		this.recebedorObrigatorio = false;
		this.pessoaObrigatoria = false;

		if (this.tipoDevolucao != null) {

			if (this.tipoDevolucao.getIndicadorTipoDevolucao().equalsIgnoreCase("R")) {
				this.listaRecebedor.clear();
				this.recebedor = new Recebedor();

				List<Recebedor> listaTmpRecebedor = new ArrayList<Recebedor>(this.documentoDevolucaoVisaoItemBO.listarRecebedorComPendenciaPorParticipante(this.participante));
				if (listaTmpRecebedor.size() == 0) {
					Mensagens.addMsgErro("Não há recebedores associados a este Participante.");
				} else {
					this.listaRecebedor.addAll(listaTmpRecebedor);
					this.recebedorObrigatorio = true;
					this.pessoaObrigatoria = false;
				}

			} else {
				this.pessoa = new PessoaEntidade();
				this.listaPessoa.clear();

				List<AtuacaoPessoa> listaAtuacaoPessoa = new ArrayList<AtuacaoPessoa>(this.documentoDevolucaoVisaoItemBO.pesquisaPessoaComDocuemtosPendentesPorParticipante(this.participante));

				if (listaAtuacaoPessoa.size() == 0) {
					Mensagens.addMsgErro("Não há Pessoas associados às devoluções deste Participante.");
				} else {
					for (AtuacaoPessoa ap : listaAtuacaoPessoa) {
						this.listaPessoa.add(this.pessoaEntidadeBO.pesquisarPessoaEntidadePorCodigo(ap.getChavePrimaria().getCodigo()));
					}
					this.pessoaObrigatoria = true;
					this.recebedorObrigatorio = false;
				}
			}
		}
	}

	public boolean isSelecionarParticipante() {
		return selecionarParticipante;
	}

	public void setSelecionarParticipante(boolean selecionarParticipante) {
		this.selecionarParticipante = selecionarParticipante;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public RegraElegibilidadeDevolucao getRegraElegibilidadeDevolucao() {
		return regraElegibilidadeDevolucao;
	}

	public void setRegraElegibilidadeDevolucao(RegraElegibilidadeDevolucao regraElegibilidadeDevolucao) {
		this.regraElegibilidadeDevolucao = regraElegibilidadeDevolucao;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public ParticipantePlano getParticipantePlano() {
		return participantePlano;
	}

	public void setParticipantePlano(ParticipantePlano participantePlano) {
		this.participantePlano = participantePlano;
	}

	public List<Recebedor> getListaRecebedor() {
		return listaRecebedor;
	}

	public void setListaRecebedor(List<Recebedor> listaRecebedor) {
		this.listaRecebedor = listaRecebedor;
	}

	public boolean isRecebedorObrigatorio() {
		return recebedorObrigatorio;
	}

	public void setRecebedorObrigatorio(boolean recebedorObrigatorio) {
		this.recebedorObrigatorio = recebedorObrigatorio;
	}

	public boolean isPessoaObrigatoria() {
		return pessoaObrigatoria;
	}

	public void setPessoaObrigatoria(boolean pessoaObrigatoria) {
		this.pessoaObrigatoria = pessoaObrigatoria;
	}

	public PessoaEntidade getPessoa() {
		return pessoa;
	}

	public void setPessoa(PessoaEntidade pessoa) {
		this.pessoa = pessoa;
	}

	public List<Devolucao> getListaDevolucoes() {
		return listaDevolucoes;
	}

	public void setListaDevolucoes(List<Devolucao> listaDevolucoes) {
		this.listaDevolucoes = listaDevolucoes;
	}

	public List<PessoaEntidade> getListaPessoa() {
		return listaPessoa;
	}

	public void setListaPessoa(List<PessoaEntidade> listaPessoa) {
		this.listaPessoa = listaPessoa;
	}

}
