package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

public class DadosPlanoResgatePortabilidadeDTO {

	private String nomePlano;
	private Date dataSituacaoPlano;
	private Date dataInscricao;
	private String fundadorPlano;
	private String situacaoPlano;
	private String tipoTributacao;
	private String resumoResgate;
	private String resumoPortabilidade;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public Date getDataSituacaoPlano() {
		return dataSituacaoPlano;
	}

	public void setDataSituacaoPlano(Date dataSituacaoPlano) {
		this.dataSituacaoPlano = dataSituacaoPlano;
	}

	public Date getDataInscricao() {
		return dataInscricao;
	}

	public void setDataInscricao(Date dataInscricao) {
		this.dataInscricao = dataInscricao;
	}

	public String getFundadorPlano() {
		return fundadorPlano;
	}

	public void setFundadorPlano(String fundadorPlano) {
		this.fundadorPlano = fundadorPlano;
	}

	public String getSituacaoPlano() {
		return situacaoPlano;
	}

	public void setSituacaoPlano(String situacaoPlano) {
		this.situacaoPlano = situacaoPlano;
	}

	public String getTipoTributacao() {
		return tipoTributacao;
	}

	public void setTipoTributacao(String tipoTributacao) {
		this.tipoTributacao = tipoTributacao;
	}

	public String getResumoResgate() {
		return resumoResgate;
	}

	public void setResumoResgate(String resumoResgate) {
		this.resumoResgate = resumoResgate;
	}

	public String getResumoPortabilidade() {
		return resumoPortabilidade;
	}

	public void setResumoPortabilidade(String resumoPortabilidade) {
		this.resumoPortabilidade = resumoPortabilidade;
	}

}
