package br.com.bbprevidencia.devolucao.controle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.google.gson.Gson;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DevolucaoPortabilidadeDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioConclusaoPortabilidadeDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioTermoRegimeTributacaoDTO;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

@Controller
@EnableWebMvc
public class PortabilidadeWs {

	public static Logger logger = Logger.getLogger(PortabilidadeWs.class);

	@Autowired
	private ServletContext context;

	private List<Devolucao> listaDevolucao;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/retornarTermoPortabilidade", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> retornarTermoPortabilidade(HttpServletRequest req) throws IOException {

		Gson gson = new Gson();
		String relatorioBase64 = "";
		try {
			BufferedReader reader = req.getReader();
			DevolucaoPortabilidadeDTO devPortDTO = gson.fromJson(reader, DevolucaoPortabilidadeDTO.class);
			logger.info("JSON " + devPortDTO);

			//Retorna a lista de planos do participante
			try {

				//Carrega o participante
				Participante participante = this.participanteBO.consultarParticipantePorCodigo(devPortDTO.getCodigoParticipante());

				//Retorna todas as devoluções do Participante
				//this.listaDevolucao = new ArrayList<Devolucao>(devolucaoBO.pesquisarDevolucaoPagaPorParticipantePlano(participante.getListaParticipantePlano()));

				//Retorna a devolução para o Plano informado
				Devolucao devolucao = this.devolucaoBO.pesquisarDevolucaoPagaPortabilidadePorParticipantePlano(devPortDTO.getCodigoParticipantePlano());
				this.listaDevolucao = new ArrayList<Devolucao>();
				this.listaDevolucao.add(devolucao);

				if (UtilJava.isColecaoVazia(this.listaDevolucao)) {
					logger.info("Não foram encontradas devoluções para este participante!");

				} else {

					List<RelatorioConclusaoPortabilidadeDTO> relatorioConclusaoPortabilidade = new ArrayList<RelatorioConclusaoPortabilidadeDTO>();
					relatorioConclusaoPortabilidade = this.devolucaoBO.montarRelatorioDePortabilidade(this.listaDevolucao, "TP");

					//ERRO PROPOSITAL
					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

					//					String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

					String logo = context.getRealPath("/imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

					String assinaturaBBP = context.getRealPath("/imagens/LogotiposExterno/assinaturaAdriana.png");

					parametros.put("logo", logo);

					parametros.put("assinaturaBBP", assinaturaBBP);

					parametros.put("dataAdesao", new Date());

					String relatorio = (relatorioConclusaoPortabilidade.get(0).getPlanoGuardaChuvaDestino().equalsIgnoreCase("PLANO BBPREV FUTURO")) ? "termoPortabilidadeBBPrevFuturo"
							: "termoPortabilidade";

					String nomeRelatorio = relatorioUtil.gerarRelatorio(relatorio, relatorioConclusaoPortabilidade, parametros);

					//					String nomeRelatorio = relatorioUtil.gerarRelatorio("termoPortabilidade", relatorioConclusaoPortabilidade, parametros);

					relatorioBase64 = this.retornarRelatorioBase64(nomeRelatorio);
				}

			} catch (PrevidenciaException pEx) {
				logger.error("Erro ao exportar relatório.", pEx);
				logger.error(pEx.getMessage());

			} catch (Exception ex) {
				logger.error(ex.getMessage());

			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());

		}

		return ResponseEntity.status(HttpStatus.OK).body(relatorioBase64);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/retornarTermoTributacao", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> retornarTermoTributacaoRegressivo(HttpServletRequest req) throws IOException {

		Gson gson = new Gson();
		String relatorioBase64 = "";
		try {
			BufferedReader reader = req.getReader();
			DevolucaoPortabilidadeDTO devPortDTO = gson.fromJson(reader, DevolucaoPortabilidadeDTO.class);
			logger.info("JSON " + devPortDTO);

			String opcaoTributacao = (devPortDTO.getRegimeTributacao().equals("P")) ? "Progressivo" : "Regressivo";

			//Retorna a lista de planos do participante
			try {

				//Carrega o participante
				Participante participante = this.participanteBO.consultarParticipantePorCodigo(devPortDTO.getCodigoParticipante());

				List<RelatorioTermoRegimeTributacaoDTO> listaRelatorio = new ArrayList<RelatorioTermoRegimeTributacaoDTO>();

				RelatorioTermoRegimeTributacaoDTO relatorioTermoTribRegressivo = new RelatorioTermoRegimeTributacaoDTO();
				relatorioTermoTribRegressivo = this.devolucaoBO.montarRelatorioDeRegimeTributacao(participante, opcaoTributacao);

				if (relatorioTermoTribRegressivo.getNomeParticipante() != null) {
					listaRelatorio.add(relatorioTermoTribRegressivo);

					//ERRO PROPOSITAL
					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

					//					String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

					//BB Previdência
					String logo = context.getRealPath("/imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
					parametros.put("logo", logo);

					//BBPrevFuturo
					String logoBBPrevFuturo = context.getRealPath("/imagens/LogotiposExterno/Logomarca_BBPREVFUTURO.jpg");
					parametros.put("logoBBPrevFuturo", logoBBPrevFuturo);

					//						String assinaturaBBP = context.getRealPath("/imagens/LogotiposExterno/assinaturaAdriana.png");

					//					parametros.put("logo", logo);

					//						parametros.put("assinaturaBBP", assinaturaBBP);

					//						parametros.put("dataAdesao", new Date());

					//					String nomeRelatorio = relatorioUtil.gerarRelatorio("termoOpcaoTributacaoRegressivo", listaRelatorio, parametros);

					String nomeRelatorio = relatorioUtil.gerarRelatorio("termoOpcaoTributacao", listaRelatorio, parametros);

					//					String nomeRelatorio = (devPortDTO.getRegimeTributacao().equals("P")) ? relatorioUtil.gerarRelatorio("termoOpcaoTributacaoProgressivo", listaRelatorio, parametros) : relatorioUtil
					//							.gerarRelatorio("termoOpcaoTributacaoRegressivo", listaRelatorio, parametros);

					relatorioBase64 = this.retornarRelatorioBase64(nomeRelatorio);

				}

			} catch (PrevidenciaException pEx) {
				logger.error("Erro ao exportar relatório.", pEx);
				logger.error(pEx.getMessage());

			} catch (Exception ex) {
				logger.error(ex.getMessage());

			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());

		}

		return ResponseEntity.status(HttpStatus.OK).body(relatorioBase64);

	}

	public String retornarRelatorioBase64(String fileName) {
		String arquivoBase64 = "";
		try {
			File arquivo = new File(reportSourcePath() + fileName);
			InputStream finput = new FileInputStream(arquivo);
			byte[] imageBytes = new byte[(int) arquivo.length()];
			finput.read(imageBytes, 0, imageBytes.length);
			finput.close();
			arquivoBase64 = Base64.encodeBase64String(imageBytes);

		} catch (FileNotFoundException e) {
			logger.error(e);
			throw new PrevidenciaException(e);

		} catch (IOException ie) {
			logger.error(ie);
			throw new PrevidenciaException(ie);

		} catch (Exception e) {
			logger.error(e);
			throw new PrevidenciaException(e);

		}

		return arquivoBase64;

	}

	/**
	 * Retorna caminho onde os relatórios (.jasper e .jrxml e tmps) ficam
	 * armazenados
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * */
	private String reportSourcePath() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance().getExternalContext().getRealPath("/relatorios/") + "/";
		} else {
			return context.getRealPath("/relatorios/") + "/";
		}
	}

}
