package br.com.bbprevidencia.devolucao.controle;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.RelatorioUtil;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioValoresDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioValoresIntegracaoDTO;
import br.com.bbprevidencia.devolucao.enumerador.CabecalhoArquivosEnum;
import br.com.bbprevidencia.devolucao.enumerador.LayoutEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.utils.arquivo.UtilTemplates;
import br.com.bbprevidencia.utils.exception.InfraException;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * parar gerar informações DIRF
 * 
 * @author  BBPF0351 - Marco Figueiredo
 * @since 15/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("processamentoInfSistemasExtDevolucaoVisao")
public class ProcessamentoInfSistemasExtDevolucaoVisao {

	private static String FW_PROCESSAR_INFORMACAO = "/paginas/processarInformacoesSistExternos.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private String retornoProcessamento;

	private List<EntidadeParticipante> listaEntidadeParticipante = new ArrayList<EntidadeParticipante>();
	private List<PlanoPrevidencia> listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();

	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;

	private String numeroMatriculaPatrocinadora;

	private boolean indicativoNaoPodeGerar;

	private String tipoGeracao;

	private Date dataReferenciaInicial;
	private Date dataReferenciaFinal;

	List<RelatorioValoresDevolucaoDTO> listaRelatorioValoresDevolucaoDTO = new ArrayList<RelatorioValoresDevolucaoDTO>();
	List<RelatorioValoresIntegracaoDTO> listaRelatorioValoresIntegracaoDTO = new ArrayList<RelatorioValoresIntegracaoDTO>();

	/**
	 * Método encarregado por iniciar a página dos cronogramas de devolução
	 * @author  BBPF0351 - Marco Figueiredo
	 * @since 15/01/2018
	 * @return {@link String}
	 */
	public String iniciarTela() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processamentoDIRFDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		preencheListaCombosEValores();

		return FW_PROCESSAR_INFORMACAO;
	}

	private void preencheListaCombosEValores() {
		try {
			this.listaEntidadeParticipante.addAll(this.entidadeParticipanteBO.listarEntidadeParticipanteOrderByNome());

			this.listaPlanoPrevidencia.addAll(this.planoPrevidenciaBO.listarPlanoPrevidencia());

			this.tipoGeracao = "A";
		} catch (Exception e) {
			throw new PrevidenciaException("Erro ao carregar combos de filtros. Erro: ", e.getMessage());
		}

	}

	private void limpaSelecao() {
		this.tipoGeracao = "";
		this.dataReferenciaFinal.setDate(0);
		this.dataReferenciaFinal.setDate(0);
	}

	public void filtrarListaPlanos() {
		try {
			this.listaPlanoPrevidencia.clear();
			this.listaPlanoPrevidencia.addAll(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante));
		} catch (Exception e) {
			Mensagens.addMsgErro("Erro ao filtrar planos: " + e.getMessage());
		}
	}

	public void processar() {

		try {

			Calendar cal = Calendar.getInstance();
			cal.setTime(this.dataReferenciaInicial);
			int mesInicio = cal.get(Calendar.MONTH) + 1;
			int anoInicio = cal.get(Calendar.YEAR);

			cal.setTime(this.dataReferenciaFinal);
			int mesFinal = cal.get(Calendar.MONTH) + 1;
			int anoFinal = cal.get(Calendar.YEAR);

			if ((anoInicio - anoFinal != 0) && isIN1452()) {
				Mensagens.addMsgErro("As datas devem estar no mesmo ano.");
				return;
			} else {

				listaRelatorioValoresDevolucaoDTO = this.historicoPagamentoDevolucaoBO.pesquisarValoresRelatorioIN1452(this.dataReferenciaInicial, this.dataReferenciaFinal);
			}

			switch (this.tipoGeracao) {
			case "1":

				listaRelatorioValoresIntegracaoDTO = this.historicoPagamentoDevolucaoBO.pesquisarValoresRelatorioIntegracao(this.dataReferenciaInicial, this.dataReferenciaFinal);
				gerarArquivoCoaf();
				break;

			case "2":

				if (UtilJava.isColecaoVazia(this.listaRelatorioValoresDevolucaoDTO)) {
					Mensagens.addMsgWarn("Não encontrado registros para parâmetros solicitados.");
					return;
				}
				gerarArquivoIN1452(mesInicio, anoInicio, mesFinal, anoFinal);
				break;

			default:
				Mensagens.addMsgErro("Favor selecionar uma opção de Geração.");
			}

		} catch (InfraException e) {
			Mensagens.addMsgErro("Erro ao gerar layout. Erro: " + e.getMessage());
		} catch (PrevidenciaException pr) {
			Mensagens.addMsgErro(pr.getMessage());
		} catch (Exception e) {
			Mensagens.addMsgErro("Erro ao processar. Erro: " + e.getMessage());
		}

	}

	private void gerarArquivoCoaf() throws InfraException {

		List<RelatorioValoresIntegracaoDTO> listaFiltrada = filtrarListaRelatorioValoresIntegracao(listaRelatorioValoresIntegracaoDTO);
		StringBuilder sb = new StringBuilder();
		String nomeArquivo = "SICSCOAF_" + UtilJava.formataDataPorPadrao(new Date(), "ddMMyyyy");

		if (UtilJava.isColecaoVazia(listaFiltrada)) {
			Mensagens.addWarn("Não encontrado devoluções com valores acima de R$ 50.000,00.");
			return;
		}

		//Coloca parametros para alteração no template
		for (RelatorioValoresIntegracaoDTO relatorioValoresIntegracaoDTO : listaFiltrada) {

			Map<String, Object> contexto = new HashMap<String, Object>();
			contexto.put("numeroOcorrencia", relatorioValoresIntegracaoDTO.getChaveOcorrenciaCoaf());
			contexto.put("cnpj", String.format("%014d", Long.parseLong(relatorioValoresIntegracaoDTO.getCnpj())));

			contexto.put("dataInicio", relatorioValoresIntegracaoDTO.getDataFormatada());
			contexto.put("dataFim", relatorioValoresIntegracaoDTO.getDataFormatada());
			contexto.put("municipio", "BRASILIA");
			contexto.put("uf", "DF");
			contexto.put("descricao", relatorioValoresIntegracaoDTO.getDetalheCoaf());

			contexto.put("credito", String.format("%.0f", Math.floor(relatorioValoresIntegracaoDTO.getValorBruto())));
			contexto.put("debito", "0");
			contexto.put("valorProv", "0");
			contexto.put("valorProp", "0");
			contexto.put("codigoEnquadramento", "840");
			contexto.put("cpf", String.format("%011d", Long.parseLong(relatorioValoresIntegracaoDTO.getCpf())));
			contexto.put("nome", relatorioValoresIntegracaoDTO.getNomeParticipante());

			sb.append(UtilTemplates.executarTemplate(LayoutEnum.COAF.getDescricao(), contexto));
		}

		StringBuilder arquivo = new StringBuilder();
		//Adiciona cabeçalho
		arquivo.append(CabecalhoArquivosEnum.cabecalhoCOAF(sb.toString()));

		RelatorioUtil.gravaArquivo(arquivo.toString(), nomeArquivo, true, RelatorioUtil.tipo.XML);

	}

	private String gerarArquivoIN1452(int mesInicio, int anoInicio, int mesFinal, int anoFinal) {
		try {

			List<String> nomes = new ArrayList<String>();

			if (UtilJava.isColecaoDiferenteDeVazia(this.listaRelatorioValoresDevolucaoDTO)) {

				for (int i = mesInicio; i <= mesFinal; i++) {

					final int filtroMes = i;
					String anoMesReferencia = anoFinal + UtilJava.adicionaZeroEsquerda(2, (long) i);

					String nomeArquivo = "PAGTORESGATES_" + anoMesReferencia + "_" + UtilJava.formataCalendarPorPadrao(Calendar.getInstance(), "yyyyMMddHHmmss") + ".CSV";
					nomes.add(nomeArquivo);

					List<RelatorioValoresDevolucaoDTO> listaFiltrada = filtrarListaRelatorioValoresDevolucao(listaRelatorioValoresDevolucaoDTO, filtroMes);

					if (UtilJava.isColecaoDiferenteDeVazia(listaFiltrada)) {
						RelatorioUtil.gravaArquivoLista(listaFiltrada, CabecalhoArquivosEnum.CABECALHO_IN1452.getCabecalho(), nomeArquivo, false, RelatorioUtil.tipo.TXT);
					}

				}

				RelatorioUtil.ziparEFazerDownload(nomes, "IN1452.zip");

			} else {
				Mensagens.addMsgErro("Não encontrado registros para período referenciado.");
			}
		} catch (PrevidenciaException pr) {
			Mensagens.addMsgErro(pr.getMessage());
		} catch (Exception e) {
			Mensagens.addMsgErro("Erro ao processar arquivo IN1452. Erro: " + e.getMessage());
		}

		return "";
	}

	private List<RelatorioValoresDevolucaoDTO> filtrarListaRelatorioValoresDevolucao(List<RelatorioValoresDevolucaoDTO> listaRelatorioValoresDevolucaoDTO, final int filtroMes) {

		@SuppressWarnings("unchecked")
		List<RelatorioValoresDevolucaoDTO> listaFiltrada = (List<RelatorioValoresDevolucaoDTO>) CollectionUtils.select(listaRelatorioValoresDevolucaoDTO, new Predicate() {

			@Override
			public boolean evaluate(Object object) {
				RelatorioValoresDevolucaoDTO obj = (RelatorioValoresDevolucaoDTO) object;
				SimpleDateFormat sdf2 = new SimpleDateFormat("MM");

				return Integer.valueOf(sdf2.format(obj.getChavePrimaria().getDataPagamento())) == filtroMes;
			}
		});

		return listaFiltrada;
	}

	private List<RelatorioValoresIntegracaoDTO> filtrarListaRelatorioValoresIntegracao(List<RelatorioValoresIntegracaoDTO> listaRelatorioValoresDevolucaoDTO) {

		@SuppressWarnings("unchecked")
		List<RelatorioValoresIntegracaoDTO> listaFiltrada = (List<RelatorioValoresIntegracaoDTO>) CollectionUtils.select(listaRelatorioValoresDevolucaoDTO, new Predicate() {

			@Override
			public boolean evaluate(Object object) {
				RelatorioValoresIntegracaoDTO obj = (RelatorioValoresIntegracaoDTO) object;

				return obj.isValorAcimaCinquentaMil();
			}
		});

		return listaFiltrada;
	}

	public String limpar() {
		limpaSelecao();

		return FW_PROCESSAR_INFORMACAO;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public String getRetornoProcessamento() {
		return retornoProcessamento;
	}

	public void setRetornoProcessamento(String retornoProcessamento) {
		this.retornoProcessamento = retornoProcessamento;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public String getNumeroMatriculaPatrocinadora() {
		return numeroMatriculaPatrocinadora;
	}

	public void setNumeroMatriculaPatrocinadora(String numeroMatriculaPatrocinadora) {
		this.numeroMatriculaPatrocinadora = numeroMatriculaPatrocinadora;
	}

	public boolean isIndicativoNaoPodeGerar() {
		return indicativoNaoPodeGerar;
	}

	public void setIndicativoNaoPodeGerar(boolean indicativoNaoPodeGerar) {
		this.indicativoNaoPodeGerar = indicativoNaoPodeGerar;
	}

	public Date getDataReferenciaInicial() {
		return dataReferenciaInicial;
	}

	public void setDataReferenciaInicial(Date dataReferenciaInicial) {
		this.dataReferenciaInicial = dataReferenciaInicial;
	}

	public Date getDataReferenciaFinal() {
		return dataReferenciaFinal;
	}

	public void setDataReferenciaFinal(Date dataReferenciaFinal) {
		this.dataReferenciaFinal = dataReferenciaFinal;
	}

	public String getTipoGeracao() {
		return tipoGeracao;
	}

	public void setTipoGeracao(String tipoGeracao) {
		this.tipoGeracao = tipoGeracao;
	}

	public List<RelatorioValoresDevolucaoDTO> getListaRelatorioValoresDevolucaoDTO() {
		return listaRelatorioValoresDevolucaoDTO;
	}

	public void setListaRelatorioValoresDevolucaoDTO(List<RelatorioValoresDevolucaoDTO> listaRelatorioValoresDevolucaoDTO) {
		this.listaRelatorioValoresDevolucaoDTO = listaRelatorioValoresDevolucaoDTO;
	}

	private boolean isIN1452() {
		return this.tipoGeracao.equals("2");
	}

	public List<RelatorioValoresIntegracaoDTO> getListaRelatorioValoresIntegracaoDTO() {
		return listaRelatorioValoresIntegracaoDTO;
	}

	public void setListaRelatorioValoresIntegracaoDTO(List<RelatorioValoresIntegracaoDTO> listaRelatorioValoresIntegracaoDTO) {
		this.listaRelatorioValoresIntegracaoDTO = listaRelatorioValoresIntegracaoDTO;
	}

}
