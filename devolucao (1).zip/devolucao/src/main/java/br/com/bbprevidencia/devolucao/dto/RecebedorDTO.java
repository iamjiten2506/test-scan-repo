package br.com.bbprevidencia.devolucao.dto;

public class RecebedorDTO {
	private String nome;
	private String banco;
	private String codAgenciaBanco;
	private String numContaBanco;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getCodAgenciaBanco() {
		return codAgenciaBanco;
	}

	public void setCodAgenciaBanco(String codAgenciaBanco) {
		this.codAgenciaBanco = codAgenciaBanco;
	}

	public String getNumContaBanco() {
		return numContaBanco;
	}

	public void setNumContaBanco(String numContaBanco) {
		this.numContaBanco = numContaBanco;
	}
}
