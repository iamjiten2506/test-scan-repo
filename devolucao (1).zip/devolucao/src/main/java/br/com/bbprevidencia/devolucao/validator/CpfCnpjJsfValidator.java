package br.com.bbprevidencia.devolucao.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator(value = "cpfcnpjjsfvalidador")
public class CpfCnpjJsfValidator implements Validator {

	private static final String KEY_MENSAGEM_VALIDACAO_CPF = "O CPF digitado não é válido!";
	private static final String KEY_MENSAGEM_VALIDACAO_CNPJ = "O CNPJ digitado não é válido!";

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {

		if (value == null || value.toString().isEmpty()) {
			return;
		}

		if (value instanceof String) {
			String cpfCnpj = ((String) value).replaceAll("\\D", "");

			if (cpfCnpj.length() > 11) {
				if (!br.com.bbprevidencia.bbpcomum.util.CpfCnpjValidator.isValidCNPJ(cpfCnpj)) {
					addMsgErro(KEY_MENSAGEM_VALIDACAO_CNPJ);
				}
			} else if (!br.com.bbprevidencia.bbpcomum.util.CpfCnpjValidator.isValidCPF(cpfCnpj)) {

				addMsgErro(KEY_MENSAGEM_VALIDACAO_CPF);
			}
		}
	}

	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

}
