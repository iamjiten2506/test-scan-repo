package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InserirDevolucaoRequestDTO {

	private Long codigoParticipante;

	private Long codigoPlano;

	private Long codigoTipoDevolucao;

	private String dataRequerimento;

	private String indicadorTipoDevolucao;

	private Integer quantidadeParcelas;

	private String dataCota;

	private String formaPagamentoRemanescente;

	private boolean portabilidadePenseFuturo;

	private DetalhePortabilidadeRequestDTO detalhePortabilidade;

}
