package br.com.bbprevidencia.devolucao.dto.response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class ValorEmprestimoResponse {
	private Double valorEmprestimo;
}
