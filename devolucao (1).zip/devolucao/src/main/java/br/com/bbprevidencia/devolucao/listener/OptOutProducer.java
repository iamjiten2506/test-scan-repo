package br.com.bbprevidencia.devolucao.listener;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class OptOutProducer {

	@Autowired
	private AmqpTemplate amqpTemplate;

	@Value("optout.exchange")
	private String exchange;

	@Value("optout.routingkey")
	private String routingkey;

	public void produce(Long idPaticipante) {
		amqpTemplate.convertAndSend("optout.queue", idPaticipante);
		System.out.println("Send msg = " + idPaticipante);
	}

}