package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   28/11/2016
 * Classe de persistência para tabela REG_CON_FAI_DEV.
 */
@Entity
@Table(name = "REG_CON_FAI_DEV", schema = "OWN_DCR")
@NamedQuery(name = "RegraDevolucaoContribFaixas.findAll", query = "SELECT q FROM RegraDevolucaoContribFaixas q")
public class RegraDevolucaoContribFaixas implements Serializable, BaseEntity, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REG_CON_FAI_DEV_GER", sequenceName = "S_RCFD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REG_CON_FAI_DEV_GER")
	@Column(name = "NUM_SEQ_REG_CON_FAI_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CON_DEV")
	private RegraDevolucaoContribuicao regraDevolucaoContribuicao;

	@JoinColumns( { @JoinColumn(name = "NUM_SEQ_ENTID_PARTIC"), @JoinColumn(name = "NUM_SEQ_FUNDO_PREVD") })
	@ManyToOne
	private EntidadeParticipante entidadeParticipante;

	@Column(name = "PER_PAR")
	private Double percentualPartcipante;

	@Column(name = "PER_PAR_FUN")
	private Double percentualPartcipanteFundador;

	@Column(name = "PER_EMP")
	private Double percentualEmpresa;

	@Column(name = "PER_EMP_FUN")
	private Double percentualEmpresaFundador;

	@Column(name = "NUM_MES_EMP")
	private Long mesesEmpresa;

	@Column(name = "NUM_MES_PLA")
	private Long mesesPlano;

	@Column(name = "NUM_MES_CON")
	private Long mesesContribuicao;

	@Column(name = "NUM_QTD_CON")
	private Long quantidadeContribuicao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INI")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FIM")
	private Date dataFim;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public RegraDevolucaoContribuicao getRegraDevolucaoContribuicao() {
		return regraDevolucaoContribuicao;
	}

	public void setRegraDevolucaoContribuicao(RegraDevolucaoContribuicao regraDevolucaoContribuicao) {
		this.regraDevolucaoContribuicao = regraDevolucaoContribuicao;
	}

	public Double getPercentualPartcipante() {
		return percentualPartcipante;
	}

	public void setPercentualPartcipante(Double percentualPartcipante) {
		this.percentualPartcipante = percentualPartcipante;
	}

	public Double getPercentualPartcipanteFundador() {
		return percentualPartcipanteFundador;
	}

	public void setPercentualPartcipanteFundador(Double percentualPartcipanteFundador) {
		this.percentualPartcipanteFundador = percentualPartcipanteFundador;
	}

	public Double getPercentualEmpresa() {
		return percentualEmpresa;
	}

	public void setPercentualEmpresa(Double percentualEmpresa) {
		this.percentualEmpresa = percentualEmpresa;
	}

	public Double getPercentualEmpresaFundador() {
		return percentualEmpresaFundador;
	}

	public void setPercentualEmpresaFundador(Double percentualEmpresaFundador) {
		this.percentualEmpresaFundador = percentualEmpresaFundador;
	}

	public Long getMesesEmpresa() {
		return mesesEmpresa;
	}

	public void setMesesEmpresa(Long mesesEmpresa) {
		this.mesesEmpresa = mesesEmpresa;
	}

	public Long getMesesPlano() {
		return mesesPlano;
	}

	public void setMesesPlano(Long mesesPlano) {
		this.mesesPlano = mesesPlano;
	}

	public Long getMesesContribuicao() {
		return mesesContribuicao;
	}

	public void setMesesContribuicao(Long mesesContribuicao) {
		this.mesesContribuicao = mesesContribuicao;
	}

	public Long getQuantidadeContribuicao() {
		return quantidadeContribuicao;
	}

	public void setQuantidadeContribuicao(Long quantidadeContribuicao) {
		this.quantidadeContribuicao = quantidadeContribuicao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	@Override
	public RegraDevolucaoContribFaixas clone() throws CloneNotSupportedException {
		RegraDevolucaoContribFaixas regraDevolucaoContribFaixas = (RegraDevolucaoContribFaixas) super.clone();
		regraDevolucaoContribFaixas.setCodigo(null);

		return regraDevolucaoContribFaixas;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

}