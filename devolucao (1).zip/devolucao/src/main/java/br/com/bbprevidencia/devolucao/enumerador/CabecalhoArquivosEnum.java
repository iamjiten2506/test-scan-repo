package br.com.bbprevidencia.devolucao.enumerador;

import java.util.Date;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;

public enum CabecalhoArquivosEnum {

	CABECALHO_IN1452("Cabeçalho para geração de arquivo IN1452", CabecalhoIN1452()),
	CABECALHO_COAF("Cabeçalho para geração de arquivo COAF", cabecalhoCOAF());

	private String descricao;
	private String cabecalho;

	private CabecalhoArquivosEnum(String descricao, String cabecalho) {
		this.descricao = descricao;
		this.cabecalho = cabecalho;
	}

	public static String cabecalhoCOAF() {

		StringBuilder sb = new StringBuilder();

		sb.append(" <?xml version=" + "\"" + 1.0D + "\"" + " encoding=" + "\"" + "iso-8859-1" + "\"" + "?> \n");
		sb.append(" <LOTE> \n");
		sb.append(" <OCORRENCIAS ID=" + "\"" + "SICSCOAF22032018" + "\"" + ">" + "\n");
		sb.append(" </OCORRENCIAS>" + "\n");

		return sb.toString();

	}

	public static String cabecalhoCOAF(String layout) {

		StringBuilder sb = new StringBuilder();

		sb.append("<?xml version=" + "\"" + 1.0D + "\"" + " encoding=" + "\"" + "iso-8859-1" + "\"" + "?>\n");
		sb.append("<LOTE>" + "\n");
		sb.append("<OCORRENCIAS ID=" + "\"" + "SICSCOAF" + UtilJava.formataDataPorPadrao(new Date(), "ddMMyyyy") + "\"" + ">" + "\n");
		sb.append(layout);
		sb.append("</OCORRENCIAS>" + "\n");
		sb.append("</LOTE>" + "\n");

		return sb.toString();

	}

	private static String CabecalhoIN1452() {

		StringBuilder sb = new StringBuilder();

		sb.append("DT_SOLIC;");
		sb.append("NOM_PARTIC;");
		sb.append("CPF_PARTIC;");
		sb.append("CNPJ_CIA;");
		sb.append("DT_PAGTO;");
		sb.append("VR_BRUTO;");
		sb.append("IRRF;");
		sb.append("VR_LIQ");
		sb.append("\n");

		return sb.toString();

	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getCabecalho() {
		return cabecalho;
	}

	public void setCabecalho(String cabecalho) {
		this.cabecalho = cabecalho;
	}

}
