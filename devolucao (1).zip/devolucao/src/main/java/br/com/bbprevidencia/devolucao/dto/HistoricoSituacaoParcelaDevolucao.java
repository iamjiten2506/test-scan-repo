package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   08/12/2016
 * Classe de persistência para tabela HIS_SIT_DEV.
 */
@Entity
@Table(name = "HIST_SIT_DEV_PAR", schema = "OWN_DCR")
@NamedQuery(name = "HistoricoSituacaoParcelaDevolucao.findAll", query = "SELECT q FROM HistoricoSituacaoParcelaDevolucao q")
public class HistoricoSituacaoParcelaDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "HIST_SIT_DEV_PAR_GER", sequenceName = "S_QUALIDADE_RECEBEDOR_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "HIST_SIT_DEV_PAR_GER")
	@Column(name = "NUM_SEQ_HIS_SIT_PAR_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SIT_DEV_PAR")
	private SituacaoParcelaDevolucao situacaoParcelaDevolucao;

	@Column(name = "NUM_SEQ_DEV_PAR")
	private Long numeroDevolucaoParcela; //Alterar para objeto

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INI")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FIM")
	private Date dataFim;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public SituacaoParcelaDevolucao getSituacaoParcelaDevolucao() {
		return situacaoParcelaDevolucao;
	}

	public void setSituacaoParcelaDevolucao(SituacaoParcelaDevolucao situacaoParcelaDevolucao) {
		this.situacaoParcelaDevolucao = situacaoParcelaDevolucao;
	}

	public Long getNumeroDevolucaoParcela() {
		return numeroDevolucaoParcela;
	}

	public void setNumeroDevolucaoParcela(Long numeroDevolucaoParcela) {
		this.numeroDevolucaoParcela = numeroDevolucaoParcela;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

}