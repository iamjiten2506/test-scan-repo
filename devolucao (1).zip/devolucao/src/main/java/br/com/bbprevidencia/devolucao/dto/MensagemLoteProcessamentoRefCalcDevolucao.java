package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * Classe de persistência para tabela MSG_LOT_PRO_DEV.
 */
@Entity
@Table(name = "MENS_LT_PROC_REF_CALC_DR", schema = "OWN_DR")
@NamedQuery(name = "MensagemLoteProcessamentoRefCalcDevolucao.findAll", query = "SELECT q FROM MensagemLoteProcessamentoRefCalcDevolucao q")
@JsonIdentityInfo(generator = ObjectIdGenerators.UUIDGenerator.class, property = "@id", scope = DevolucaoPosicionadoDTO.class)
public class MensagemLoteProcessamentoRefCalcDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MENS_LT_PROC_REF_CALC_DR_GER", sequenceName = "S_MENS_LT_PROC_REF_CALC_DR_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MENS_LT_PROC_REF_CALC_DR_GER")
	@Column(name = "NUM_SEQ_MENS_LT_PROC_DR")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_LT_PROC_REF_CALC_DR")
	private LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_MENS")
	private Date dataMensagem;

	@Column(name = "NUM_SEQ_PARTIC_PLANO")
	private Long codigoParticipantePlano;

	@Column(name = "DSC_MENS")
	private String descricaoMensagem;

	@Column(name = "IND_TP_MENS")
	private String indicadorTipoMensagem;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTER")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCL")
	private Date dataInclusao;

	@Column(name = "NOM_USU_INCL")
	private String nomeUsuarioAlteracao;

	@Column(name = "NOM_USU_ALTER")
	private String nomeUsuarioInclusao;

	public MensagemLoteProcessamentoRefCalcDevolucao(LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao, Date dataMensagem, Long codigoParticipantePlano,
			String descricaoMensagem, String indicadorTipoMensagem, Date dataInclusao, String nomeUsuarioInclusao) {
		super();
		this.loteProcessamentoReferenciaCalcDevolucao = loteProcessamentoReferenciaCalcDevolucao;
		this.dataMensagem = dataMensagem;
		this.codigoParticipantePlano = codigoParticipantePlano;
		this.descricaoMensagem = descricaoMensagem;
		this.indicadorTipoMensagem = indicadorTipoMensagem;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public MensagemLoteProcessamentoRefCalcDevolucao(LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao, Date dataMensagem, Long codigoParticipantePlano,
			String descricaoMensagem, String indicadorTipoMensagem, Date dataInclusao) {
		super();
		this.loteProcessamentoReferenciaCalcDevolucao = loteProcessamentoReferenciaCalcDevolucao;
		this.dataMensagem = dataMensagem;
		this.codigoParticipantePlano = codigoParticipantePlano;
		this.descricaoMensagem = descricaoMensagem;
		this.indicadorTipoMensagem = indicadorTipoMensagem;
		this.dataInclusao = dataInclusao;
	}

	public MensagemLoteProcessamentoRefCalcDevolucao() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public LoteProcessamentoReferenciaCalcDevolucao getLoteProcessamentoReferenciaCalcDevolucao() {
		return loteProcessamentoReferenciaCalcDevolucao;
	}

	public void setLoteProcessamentoReferenciaCalcDevolucao(LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao) {
		this.loteProcessamentoReferenciaCalcDevolucao = loteProcessamentoReferenciaCalcDevolucao;
	}

	public Date getDataMensagem() {
		return dataMensagem;
	}

	public void setDataMensagem(Date dataMensagem) {
		this.dataMensagem = dataMensagem;
	}

	public Long getCodigoParticipantePlano() {
		return codigoParticipantePlano;
	}

	public void setCodigoParticipantePlano(Long codigoParticipantePlano) {
		this.codigoParticipantePlano = codigoParticipantePlano;
	}

	public String getDescricaoMensagem() {
		return descricaoMensagem;
	}

	public void setDescricaoMensagem(String descricaoMensagem) {
		this.descricaoMensagem = descricaoMensagem;
	}

	public String getIndicadorTipoMensagem() {
		return indicadorTipoMensagem;
	}

	public void setIndicadorTipoMensagem(String indicadorTipoMensagem) {
		this.indicadorTipoMensagem = indicadorTipoMensagem;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

}
