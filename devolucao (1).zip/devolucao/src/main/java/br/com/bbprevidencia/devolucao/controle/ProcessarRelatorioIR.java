package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.contabilidade.bo.DataRecolhimentoBO;
import br.com.bbprevidencia.contabilidade.dto.DataRecolhimento;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioAnaliticoIRDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioImpostoRendaDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioSinteticoIRDTO;
import br.com.bbprevidencia.folha.bo.CaracteristicaDirfBO;
import br.com.bbprevidencia.folha.dto.CaracteristicaDirf;

@Component("processarRelatorioAnalitico")
public class ProcessarRelatorioIR {

	public static Logger log = Logger.getLogger(ProcessarRelatorioIR.class);

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;

	@Autowired
	private DataRecolhimentoBO dataRecolhimentoBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private CaracteristicaDirfBO caracteristicaDirfBO;

	/**
	 * Método encarregado de preencher as informações do relatório analitico de IR
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 * @param cronogramaDevolucao
	 * @param listaEntidadeParticiapnte
	 * @return
	 */
	public List<RelatorioAnaliticoIRDTO> preencheRelatorioAnaliticoIR(CronogramaDevolucao cronogramaDevolucao, List<EntidadeParticipante> listaEntidadeParticipante) {
		try {
			List<RelatorioAnaliticoIRDTO> listaRelatorioAnalitico = new ArrayList<RelatorioAnaliticoIRDTO>();

			if (cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
				listaRelatorioAnalitico = historicoPagamentoDevolucaoBO.extrairRelatorioAnaliticoIR(cronogramaDevolucao, listaEntidadeParticipante);
			} else {
				listaRelatorioAnalitico = movimentoCalculoPagamentoDevolucaoBO.extrairRelatorioAnaliticoIR(cronogramaDevolucao, listaEntidadeParticipante);
			}

			if (UtilJava.isColecaoVazia(listaRelatorioAnalitico)) {
				throw new PrevidenciaException("Não existem informações para este cronograma.");
			} else {
				DataRecolhimento dataRecolhimento = this.dataRecolhimentoBO.pesquisarDataRecolhimentoPorTipoTributoEData("IR", cronogramaDevolucao.getDataPagamento());

				for (RelatorioAnaliticoIRDTO item : listaRelatorioAnalitico) {
					item.setDataRetencao(UtilJava.formataDataPorPadrao((dataRecolhimento.getDataRecolhimento()), "dd/MM/yyyy"));
					PlanoPrevidencia planoPrevidencia = this.planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(item.getCodigoPlano());
					CaracteristicaDirf caracteristicaDirf = this.caracteristicaDirfBO.pesquisarCaracteristicaDirfPorTipo(Long.parseLong(item.getCodigoCaracteristicaDIRF()));

					item.setModalidePlano(planoPrevidencia.getRegraGeralPorDataCompetencia(cronogramaDevolucao.getDataPagamento()).getCodigoModalidadePlano());
					item.preencheTipoRetencao(caracteristicaDirf);
					item.preencheNaturezaRendimento(caracteristicaDirf);

				}
			}

			return listaRelatorioAnalitico;
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 * @param relatorioAnalitico
	 * @return
	 */
	public List<RelatorioSinteticoIRDTO> preencherRelatorioSinteticoIR(List<RelatorioAnaliticoIRDTO> listaRelatorioAnalitico) {
		try {
			List<RelatorioSinteticoIRDTO> listaRelatorioSintetico = new ArrayList<RelatorioSinteticoIRDTO>();

			for (RelatorioAnaliticoIRDTO ra : listaRelatorioAnalitico) {
				if (UtilJava.isColecaoVazia(listaRelatorioSintetico) || !existeCodigoProcessado(listaRelatorioSintetico, ra.getCodigoRetencao())) {
					RelatorioSinteticoIRDTO relatorioSintetico = new RelatorioSinteticoIRDTO();
					relatorioSintetico.setCodigoRetencao(ra.getCodigoRetencao());
					relatorioSintetico.setDataRetencao(ra.getDataRetencao());
					relatorioSintetico.setTipoRetencao(ra.getTipoRetencao());
					relatorioSintetico.setCodigoNaturezaRendimento(ra.getCodigoNaturezaRendimento());
					processarCodigoArrecadacao(listaRelatorioAnalitico, relatorioSintetico, ra.getCodigoRetencao());
					listaRelatorioSintetico.add(relatorioSintetico);
				}
			}
			return listaRelatorioSintetico;
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 * @param listaRelatorioSintetico
	 * @param codigoRetencao
	 * @return
	 */
	private boolean existeCodigoProcessado(List<RelatorioSinteticoIRDTO> listaRelatorioSintetico, String codigoRetencao) {
		for (RelatorioSinteticoIRDTO rs : listaRelatorioSintetico) {
			if (rs.getCodigoRetencao().equalsIgnoreCase(codigoRetencao)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 * @param listaRelatorioAnalitico
	 * @param listaRelatorioSintetico
	 * @param codigoArrecadacao
	 */
	@SuppressWarnings( { "unchecked" })
	private void processarCodigoArrecadacao(List<RelatorioAnaliticoIRDTO> listaRelatorioAnalitico, RelatorioSinteticoIRDTO relatorioSintetico, final String codigoRetencao) {
		try {
			Iterable<RelatorioAnaliticoIRDTO> listaFiltradaPorCodigo = CollectionUtils.select(listaRelatorioAnalitico, new Predicate() {
				@Override
				public boolean evaluate(Object arg0) {
					RelatorioAnaliticoIRDTO item = (RelatorioAnaliticoIRDTO) arg0;
					return item.getCodigoRetencao().equalsIgnoreCase(codigoRetencao);
				}
			});

			Double totalIr = 0D;
			for (RelatorioAnaliticoIRDTO raIr : listaFiltradaPorCodigo) {
				totalIr += raIr.getValorIrrf();
			}

			relatorioSintetico.setValorRetencao(totalIr);

		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}

	public List<RelatorioImpostoRendaDTO> listarRelatorioIR(CronogramaDevolucao cronogramaDevolucao, List<EntidadeParticipante> listaEntidadeParticipante) {
		try {
			if (cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
				return this.historicoPagamentoDevolucaoBO.extrairRelatorioIRcomModalidadePlano(cronogramaDevolucao, listaEntidadeParticipante);
			} else {
				return this.movimentoCalculoPagamentoDevolucaoBO.extrairRelatorioIRcomModalidadePlano(cronogramaDevolucao, listaEntidadeParticipante);
			}
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}

}
