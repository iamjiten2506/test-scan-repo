package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

public class RelatorioSaldoContaDTO {

	private String nomePlano;

	private String nomeParticipante;

	private String nomeContaDevolucao;

	private Date dataPagamento;

	private Double qtdeCotas;

	private Double saldoCotas;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Double getQtdeCotas() {
		return qtdeCotas;
	}

	public void setQtdeCotas(Double qtdeCotas) {
		this.qtdeCotas = qtdeCotas;
	}

	public Double getSaldoCotas() {
		return saldoCotas;
	}

	public void setSaldoCotas(Double saldoCotas) {
		this.saldoCotas = saldoCotas;
	}

	public String getNomeContaDevolucao() {
		return nomeContaDevolucao;
	}

	public void setNomeContaDevolucao(String nomeContaDevolucao) {
		this.nomeContaDevolucao = nomeContaDevolucao;
	}

}
