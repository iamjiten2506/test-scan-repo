package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   13/02/2017
 * Classe de objeto recebendo vários dados de devolução
 */
public class AgrupamentoDevContabilDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Date dataMovimento;
	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private PerfilInvestimento perfilInvestimento;
	private OperacaoInterna operacaoInterna;
	private long codigoMovimento;
	private double valorLiquido;
	private Participante participante;
	private ParticipantePlano participantePlanoDestino;

	public AgrupamentoDevContabilDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AgrupamentoDevContabilDTO(Date dataMovimento, EntidadeParticipante entidadeParticipante, PlanoPrevidencia planoPrevidencia, PerfilInvestimento perfilInvestimento,
			OperacaoInterna operacaoInterna, Participante participante) {
		super();
		this.dataMovimento = dataMovimento;
		this.entidadeParticipante = entidadeParticipante;
		this.planoPrevidencia = planoPrevidencia;
		this.perfilInvestimento = perfilInvestimento;
		this.operacaoInterna = operacaoInterna;
		this.participante = participante;
	}

	public AgrupamentoDevContabilDTO(Date dataMovimento, EntidadeParticipante entidadeParticipante, PlanoPrevidencia planoPrevidencia, PerfilInvestimento perfilInvestimento,
			OperacaoInterna operacaoInterna, Participante participante, ParticipantePlano participantePlano) {
		super();
		this.dataMovimento = dataMovimento;
		this.entidadeParticipante = entidadeParticipante;
		this.planoPrevidencia = planoPrevidencia;
		this.perfilInvestimento = perfilInvestimento;
		this.operacaoInterna = operacaoInterna;
		this.participante = participante;
		this.participantePlanoDestino = participantePlano;
	}

	public Date getDataMovimento() {
		return dataMovimento;
	}

	public void setDataMovimento(Date dataMovimento) {
		this.dataMovimento = dataMovimento;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public PerfilInvestimento getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(PerfilInvestimento perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}

	public OperacaoInterna getOperacaoInterna() {
		return operacaoInterna;
	}

	public void setOperacaoInterna(OperacaoInterna operacaoInterna) {
		this.operacaoInterna = operacaoInterna;
	}

	public double getValorLiquido() {
		return valorLiquido;
	}

	public void setValorLiquido(double valorLiquido) {
		this.valorLiquido = valorLiquido;
	}

	public long getCodigoMovimento() {
		return codigoMovimento;
	}

	public void setCodigoMovimento(long codigoMovimento) {
		this.codigoMovimento = codigoMovimento;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public ParticipantePlano getParticipantePlanoDestino() {
		return participantePlanoDestino;
	}

	public void setParticipantePlanoDestino(ParticipantePlano participantePlanoDestino) {
		this.participantePlanoDestino = participantePlanoDestino;
	}

}