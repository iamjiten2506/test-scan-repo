package br.com.bbprevidencia.devolucao.controle;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.devolucao.bo.DocumentoPlanoTipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.DocumentoPlanoTipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RetornoDocumentoPlanoTipoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe contoller para manipular as requicições do documento plano por tipo de devolução
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 *
 */
@Controller
public class DocumentoPlanoTipoDevolucaoWs {

	private static Logger log = Logger.getLogger(DocumentoPlanoTipoDevolucaoWs.class);

	@Autowired
	private DocumentoPlanoTipoDevolucaoBO documentoTipoDevolucaoBo;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private ServletContext context;

	@RequestMapping(method = RequestMethod.GET, value = "/buscaDocumentoPlanoDevolucaoPorPlanoWs")
	@ResponseBody
	public ResponseEntity<byte[]> buscaDocumentoPlanoDevolucaoPorPlanoWs(@RequestParam(required = false) String codigoUsr, @RequestParam(required = false) List<Long> codigoPn) {
		try {
			String nomeArquivo = "";

			byte[] arquivo = null;

			List<RetornoDocumentoPlanoTipoDevolucaoDTO> dataSource = new ArrayList<RetornoDocumentoPlanoTipoDevolucaoDTO>();

			log.info("Obtendo Lista de Documentos por plano");

			List<PlanoPrevidencia> listaPlano = new ArrayList<PlanoPrevidencia>();

			for (Long l : codigoPn) {
				listaPlano.add(this.planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(l));
			}

			List<DocumentoPlanoTipoDevolucao> listaDocs = new ArrayList<DocumentoPlanoTipoDevolucao>(this.documentoTipoDevolucaoBo.consultarDocumentoPlanoTipoDevolucaoPorListaPlano(listaPlano, true));

			if (UtilJava.isColecaoDiferenteDeVazia(listaDocs)) {
				for (DocumentoPlanoTipoDevolucao dPt : listaDocs) {
					RetornoDocumentoPlanoTipoDevolucaoDTO item = new RetornoDocumentoPlanoTipoDevolucaoDTO();
					item.setNomePlano(dPt.getPlanoPrevidencia().getNomeAbreviadoPlano());
					item.setTipoDevolucao(dPt.getTipoDevolucao().getNome());
					item.setDocumento(dPt.getDocumentoDevolucao().getNome());
					item.setDocumentoObg(dPt.getIndicativoObrigatorio().equalsIgnoreCase("S") ? "SIM" : "NÃO");
					item.setDescricaoAdicional(dPt.getDocumentoDevolucao().getDescricaoSolicitacao03());

					dataSource.add(item);
				}
			}

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
			String logo = context.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
			parametros.put("logo", logo);
			nomeArquivo = relatorioUtil.gerarRelatorio("documentosDevolucao", dataSource, parametros);

			arquivo = Files.readAllBytes(Paths.get(relatorioUtil.reportFile() + nomeArquivo));

			return new ResponseEntity<byte[]>(arquivo, HttpStatus.CREATED);

		} catch (Exception e) {
			log.error(e);
			return null;
		}
	}

}
