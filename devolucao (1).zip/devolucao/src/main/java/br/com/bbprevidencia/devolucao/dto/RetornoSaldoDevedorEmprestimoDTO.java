package br.com.bbprevidencia.devolucao.dto;

public class RetornoSaldoDevedorEmprestimoDTO {

	private double saldoDevedor;

	private String dataQuitacao;

	private String error;

	public RetornoSaldoDevedorEmprestimoDTO() {

	}

	public RetornoSaldoDevedorEmprestimoDTO(double saldoDevedor, String dataQuitacao, String error) {
		super();
		this.saldoDevedor = saldoDevedor;
		this.dataQuitacao = dataQuitacao;
		this.error = error;
	}

	public double getSaldoDevedor() {
		return saldoDevedor;
	}

	public void setSaldoDevedor(double saldoDevedor) {
		this.saldoDevedor = saldoDevedor;
	}

	public String getDataQuitacao() {
		return dataQuitacao;
	}

	public void setDataQuitacao(String dataQuitacao) {
		this.dataQuitacao = dataQuitacao;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}
