package br.com.bbprevidencia.devolucao.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.EmailValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.CpfCnpjValidator;
import br.com.bbprevidencia.bbpcomum.util.TipoMascara;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.LayoutCertificadoParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.TelefoneParticipante;
import br.com.bbprevidencia.folha.bo.RecebedorBO;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.folha.dto.TelefoneRecebedor;
import br.com.bbprevidencia.utils.formatacao.FormatarDados;

@Component
public class ValidacaoUtil {

	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private RecebedorBO recebedorBO;

	/**
	 * Validação de dados obrigatórios do leiaute de certificado de participante.
	 * 
	 * @param layoutCertificadoParticipante
	 * @return List<String>
	 */
	public static List<String> validarLeiaute(LayoutCertificadoParticipante layoutCertificadoParticipante) {

		List<String> listaMensagem = new ArrayList<String>();

		if (layoutCertificadoParticipante == null) {

			listaMensagem.add(Mensagens.getMensagem("ME066", "Leiaute Certificado Participante"));

		} else {

			if (StringUtils.isBlank(layoutCertificadoParticipante.getTituloCertificado())) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Título do Certificado"));
			}
			if (layoutCertificadoParticipante.getTamanhoPapel() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Tamanho do Papel"));
			}
			if (layoutCertificadoParticipante.getLarguraPapel() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Largura do Papel"));
			}
			if (layoutCertificadoParticipante.getAlturaPapel() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Altura do Papel"));
			}
			if (layoutCertificadoParticipante.getOrientacaoPapel() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Orientação do Papel"));
			}
			if (StringUtils.isBlank(layoutCertificadoParticipante.getDescricaoTextoFrente())) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Texto da Frente do Certificado"));
			}
			if (layoutCertificadoParticipante.getFonteFrente() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Fonte da Frente do Certificado"));
			}
			if (layoutCertificadoParticipante.getTamanhoFonteFrente() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Tamanho do Texto (Frente)"));
			}
			if (layoutCertificadoParticipante.getAlinhamentoFrente() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Alinhamento (Texto da Frente)"));
			}
			if (layoutCertificadoParticipante.getMargemEsquerdaFrente() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Esquerda (Margens do Texto da Frente)"));
			}
			if (layoutCertificadoParticipante.getMargemSuperiorFrente() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Cima (Margens do Texto da Frente)"));
			}
			if (layoutCertificadoParticipante.getMargemDireitaFrente() == null) {
				listaMensagem.add(Mensagens.getMensagem("ME114", "Direita (Margens do Texto da Frente)"));
			}
		}

		return listaMensagem;
	}

	/**
	 * Valida se o modelo segue as restrições imposta a esse.
	 * 
	 * @author andre.mello 
	 * @param participante  participante sendo adicionado ou validado quanto às suas restrições.
	 * @return retorna true, caso tenha sido validado corretamente, e false, caso contrário.
	 */
	public Boolean validarParticipanteDadosBasicos(Participante participante) throws NullPointerException {

		Boolean validado = true;

		if (participante == null) {

			throw new NullPointerException("O valor participante não pode ser nulo.");

		} else {

			if (!validarCPF(participante)) {

				validado = false;

			}

			if (!validarDataNascimento(participante)) {

				validado = false;

			}

			if (!validarDataEmissaoRG(participante)) {

				validado = false;

			}

			if (!validarCEP(participante)) {

				validado = false;

			}

			if (!validarEmail(participante)) {

				validado = false;

			}

			if (!validarDataAdmissao(participante)) {

				validado = false;

			}
			/*
			 if (!validarDataSituacaoParticipante(participante)) {

			 validado = false;

			 }
			 */
			if (!validarDataDesligamentoParticipante(participante)) {

				validado = false;

			}
			/*
			 if (!validarSituacaoParticipante(participante)) {

			 validado = false;
			 }
			 */
		}

		return validado;

	}

	/**
	 * Validação da situação do participante.
	 * 
	 * @param participanteBanco
	 * @return boolean
	 */
	/*private boolean validarSituacaoParticipante(Participante participante) {

		boolean dadosInvalido = true;

		try {

			Participante participanteBanco = participanteBO.consultarParticipantePorCodigo(participante.getCodigo());

			if (participanteBanco != null && participanteBanco.getCodigo() != null && participanteBanco.getSituacaoParticipante() != null
					&& StringUtils.isNotBlank(participanteBanco.getSituacaoParticipante().getCodigo())) {

				//Caso 461 do mantis
				if ("05".equals(participanteBanco.getSituacaoParticipante().getCodigo())) {
					Mensagens.addError("MEUC011_01");
					dadosInvalido = false;
				}

				//Caso 460 do mantis
				if (participante.getSituacaoParticipante() != null && StringUtils.isNotBlank(participante.getSituacaoParticipante().getCodigo())
						&& participante.getSituacaoParticipante().getCodigo().equals("05")) {

					if (participante.getDataDesligamento() != null && participante.getDataSituacaoParticipante() != null
							&& !UtilData.isDataIgual(participante.getDataDesligamento(), participante.getDataSituacaoParticipante())) {

						Mensagens.addError("MEUC011_02");
						dadosInvalido = false;
					}
				}
			}

		} catch (Exception e) {
			logger.error("Erro " + this.getClass().getName() + ".validarSituacaoParticipante", e);
			throw new PrevidenciaException("Erro ao validar a situação do participante.", e);
		}

		return dadosInvalido;
	}
	 */
	/**
	 * Valida o CPF do participante.
	 * 
	 * @author andre.mello
	 * @param participante aquele a ter o CPF validado.
	 * @return true, se o cpf do participante for válido e false, caso contrário.
	 */
	public Boolean validarCPF(Participante participante) {

		Boolean validado = true;

		if (participante.getNumeroCpf() == null || participante.getNumeroComplementoCpf() == null) {

			Mensagens.addError("ME50", "CPF");

			validado = false;

		} else {

			if (!CpfCnpjValidator.isValidCPF(TipoMascara.CPF.aplicarMascara(participante.getCpf()))) {

				Mensagens.addError("ME056", UtilJava.formataCPF(participante.getCpf()));

				validado = false;

			}

		}

		return validado;

	}

	/**
	 * Valida a Data de Nascimento do participante.
	 * 
	 * @author andre.mello
	 * @param participante aquele a ter o Data de Nacimento validada.
	 * @return true, caso Data de Nascimento seja válido e false, caso contrário.
	 */
	public Boolean validarDataNascimento(Participante participante) {

		Boolean validado = true;

		if ((participante.getDataNascimento() != null && participante.getDataAdmissao() != null && participante.getDataNascimento().after(participante.getDataAdmissao()))
				&& participante.getDataNascimento().equals(participante.getDataAdmissao())) {

			Mensagens.addError("ME056", FormatarDados.converterPadraoData(participante.getDataNascimento()));
			validado = false;

		}

		return validado;

	}

	/**
	 * Valida a Data de Emissão de RG do participante.
	 * 
	 * @author andre.mello
	 * @param participante aquele a ter o Data de Emissão de RG validada.
	 * @return true, caso Data de Emissão de RG seja válido e false, caso contrário.
	 */
	public Boolean validarDataEmissaoRG(Participante participante) {

		Boolean validado = true;

		if (participante.getDataEmissaoIdentidade() != null && participante.getDataEmissaoIdentidade().after(new Date())) {

			Mensagens.addError("ME057", FormatarDados.converterPadraoData(participante.getDataEmissaoIdentidade()));
			validado = false;

		}

		return validado;

	}

	/**
	 * Valida CEP do Endereço do participante.
	 * 
	 * @author andre.mello
	 * @param participante aquele a ter o CEP do Endereço validado.
	 * @return  true, caso CEP do Endereço seja válido e false, caso contrário.
	 */
	public Boolean validarCEP(Participante participante) {

		Boolean validado = true;

		if (!UtilJava.isStringVazia(participante.getCep(), true) && !FormatarDados.isCEPValido(TipoMascara.CEP.aplicarMascara(participante.getCep()))) {

			Mensagens.addError("ME058", participante.getCep());
			validado = false;

		}

		return validado;

	}

	/**
	 * Valida o email de contato do participante.
	 * 
	 * @author andre.mello
	 * @param participante aquele a ter o email validado.
	 * @return true, caso o email do participante seja válido e false, caso contrário.
	 */
	public Boolean validarEmail(Participante participante) {

		Boolean validado = true;

		if (StringUtils.isNotBlank(participante.getEnderecoEmail()) && !EmailValidator.getInstance().isValid(participante.getEnderecoEmail())) {

			Mensagens.addError("ME059", participante.getEnderecoEmail());
			validado = false;
		}

		return validado;

	}

	/**
	 * Valida se a data da situação do participante é maior que a última situação e menor que a data atual.
	 * 
	 * @author andre.mello
	 * @param participante a ter a data de situação validada.
	 * @return true, caso a data admissão do participante na empresa seja válida e false, caso contrário.
	 */
	public Boolean validarDataSituacaoParticipante(Participante participante) {

		Boolean validado = true;
		Participante participanteBanco = null;

		participanteBanco = participanteBO.consultarPorCodigo(participante);

		if (participante.getDataSituacaoParticipante() != null && participanteBanco.getDataSituacaoParticipante() != null
				&& participante.getDataSituacaoParticipante().before(participanteBanco.getDataSituacaoParticipante())) {

			Mensagens.addError("MEUC02_06");
			validado = false;

		}

		if (participante.getDataSituacaoParticipante() != null && participante.getDataSituacaoParticipante().after(new Date())) {

			Mensagens.addError("MEUC02_11");
			validado = false;
		}

		return validado;

	}

	/**
	 * Mantis 1261
	 * Valida se a data de desligamento do participante é menor que a data atual .
	 * 
	 * @author daniel.pacheco
	 * @param participante a ter a data de desligamento validada.
	 * @return true, caso a data desligamento do participante na empresa seja válida e false, caso contrário.
	 */
	public Boolean validarDataDesligamentoParticipante(Participante participante) {

		Boolean validado = true;

		if (participante.getDataDesligamento() != null && participante.getDataDesligamento().after(new Date())) {

			Mensagens.addError("MEUC02_12");
			validado = false;
		}

		return validado;

	}

	/**
	 * Valida a data de admissão na empresa do participante.
	 *  
	 * @author andre.mello
	 * @param participante aquele a ter a data admissão validada.
	 * @return true, caso a data admissão do participante na empresa seja válida e false, caso contrário.
	 */
	public Boolean validarDataAdmissao(Participante participante) {

		Boolean validado = true;

		if (participante.getDataNascimento() != null && participante.getDataAdmissao() != null
				&& (participante.getDataAdmissao().after(new Date()) || participante.getDataAdmissao().before(participante.getDataNascimento()))) {

			Mensagens.addError("ME059");
			validado = false;

		}

		return validado;

	}

	/**
	 * Método para fazer o de participante para o recebedor no caso de seleção O PROPRIO. 
	 * @author bbpf0170 - Magson Dias
	 * @param  {@link Participante}
	 * @return {@link Recebedor}
	 */
	public Recebedor retornaOproprioRecebedorParticipante(Participante participante, LoginBBPrevWebDTO loginTemporariaDTO) {
		Recebedor recebedor = new Recebedor();
		participante = this.participanteBO.consultarParticipantePorCodigo(participante.getCodigo());

		if (recebedorBO.pesquisarRecebedorPorCpfParticipante(participante.getNumeroCpf(), participante.getNumeroComplementoCpf(), participante.getCodigo()) != null) {
			recebedor = recebedorBO.pesquisarRecebedorPorCpfParticipante(participante.getNumeroCpf(), participante.getNumeroComplementoCpf(), participante.getCodigo());
		} else {
			recebedor.setNome(participante.getNomeParticipante());
			recebedor.setNomeMae(participante.getNomeMae());
			recebedor.setNomePai(participante.getNomePai());
			recebedor.setCpf(participante.getCpf());
			recebedor.setNumeroDocumentoIdent(participante.getNumeroIdentidade());
			recebedor.setNomeOrgaoEmissorIdentidade(participante.getNomeOrgaoIdentidade());
			recebedor.setDataEmissaoIdentidade(participante.getDataEmissaoIdentidade());
			recebedor.setIndicadorTipoSexo(participante.getIndicadorSexo());
			recebedor.setEmail(participante.getEnderecoEmail());
			recebedor.setEmailSecundario(participante.getEnderecoEmailSec());
			recebedor.setIndicadorEstadoCivil(participante.getEstadoCivil().getCodigo());
			recebedor.setDataNascimento(participante.getDataNascimento());

			if (participante.getUnidadeFederativaNascimento() != null) {
				recebedor.setCodUfNasc(participante.getUnidadeFederativaNascimento().getCodigo());
			}
			if (participante.getGrauInstrucao() != null) {
				recebedor.setIndicadorGrauInstrucao(participante.getGrauInstrucao().getCodigo());
			}
			if (participante.getEnderecoUnidadeFederativa() != null) {
				recebedor.setEndCodUf(participante.getEnderecoUnidadeFederativa().getCodigo());
			}
			recebedor.setNomeCidadeNascimento(participante.getNomeCidadeNascimento());
			recebedor.setDataObito(participante.getDataObito());
			recebedor.setLogradouroEndereco(participante.getEnderecoLogradouro());
			recebedor.setNumeroLogradouroEndereco(participante.getNumeroLogradouro());
			recebedor.setComplementoLogradouroEndereco(participante.getEnderecoComplementoLogrd());
			recebedor.setNomeCidadeEndereco(participante.getNomeCidade());
			recebedor.setBairroEndereco(participante.getEnderecoBairro());
			recebedor.setNumCcor(participante.getNumeroContaCorrente());
			recebedor.setNumDvCcor(participante.getNumeroDigitoVerificadorContaCorrente());
			recebedor.setIndicadorTipoConta(participante.getIndicadorTipoConta());
			recebedor.setAgenciaBancaria(participante.getAgenciaBancaria());
			recebedor.setCepEndereco(participante.getEnderecoCep());
			recebedor.setComplementoCepEndereco(participante.getEnderecoComplementoCep());

			if (UtilJava.isColecaoDiferenteDeVazia(participante.getListaTelefoneParticipante())) {

				for (TelefoneParticipante telefone : participante.getListaTelefoneParticipante()) {
					TelefoneRecebedor telefoneRecebedor = new TelefoneRecebedor();
					telefoneRecebedor.setRecebedor(recebedor);
					telefoneRecebedor.setNumeroDDI(telefone.getNumeroDDI());
					telefoneRecebedor.setNumeroDDD(telefone.getNumeroDDD());
					telefoneRecebedor.setNumeroTelefone(telefone.getNumeroTelefone());
					telefoneRecebedor.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
					telefoneRecebedor.setDataInclusao(new Date());
					if (telefone.getTipoTelefone() != null) {
						telefoneRecebedor.setTipoTelefone(telefone.getTipoTelefone());
					}
					recebedor.getListaTelefoneRecebedor().add(telefoneRecebedor);
				}

			}

		}

		return recebedor;
	}

}
