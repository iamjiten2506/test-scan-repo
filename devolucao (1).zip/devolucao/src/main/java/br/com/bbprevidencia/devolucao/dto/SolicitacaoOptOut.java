package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoSolicitacaoOptOutEnum;
import br.com.bbprevidencia.utils.data.UtilData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author  BBPF0468 - Carlos Wallace
 * @since   05/12/2016
 * Classe de persistência para tabela HIS_SIT_REG_DEV.
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
@Entity
@Table(name = "SOL_OPT_OUT", schema = "OWN_DCR")
public class SolicitacaoOptOut implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SOLICITACAO_OPT_OUT_GER", sequenceName = "OWN_DCR.S_SOL_OPT_OUT_01", allocationSize = 1, initialValue = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SOLICITACAO_OPT_OUT_GER")
	@Column(name = "NUM_SEQ_SOL_OPT_OUT")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PARTIC")
	private Participante participante;

	@Column(name = "COD_SITUACAO")
	private Long situacao;

	@Column(name = "NUM_SEQ_MOV_ALC")
	//	@Transient
	private Long movimentoAlcada;

	@Column(name = "NUM_LOT_ALC")
	//	@Transient
	private Long numeroLoteAlcada;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATA_SOLICITACAO")
	private Date dataSolicitacao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_CAL_OPT_OUT")
	private Date dataCalculo;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATA_COTA")
	private Date dataCotaCalculo;

	@Column(name = "VALOR_COTA")
	private Double valorCotaCalculo;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATA_CANCEL_SOL")
	private Date dataCancelamentoSolicitacao;

	@Column(name = "COD_USU_CANCEL_SOL")
	private String nomeUsuarioCancelamentoSolicitacao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@JsonIgnore
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "solicitacaoOptOut", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<CalculoOptOut> listaCalculoSolicitacao;

	@JsonIgnore
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "solicitacaoOptOut", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<LancamentoIntegracaoOptOut> listaIntegracaoSolicitacao;

	@Transient
	private String descSituacao;

	@Transient
	@Column(name = "DSC_MOT_IND")
	private String motivoIndeferimento;

	public Double getSobranteFaltanteOptOut() {
		Double valorAtualizadoPeloIndice = this.listaCalculoSolicitacao.stream()
				.mapToDouble(a -> a.getValorParticipanteAtualizacaoIndice() + a.getValorPatrocinadoraAtualizacaoIndice())
				.sum();
		
		Double valorAtualizadoPelaCota = this.listaCalculoSolicitacao.stream()
				.mapToDouble(a -> a.getValorParticipanteAtualizacaoCota() + a.getValorPatrocinadoraAtualizacaoCota())
				.sum();
		
		return valorAtualizadoPeloIndice - valorAtualizadoPelaCota;
	}

	public String getDescSituacao() {

		String descSituacao = "";

		if (this.getSituacao() != null) {

			return SituacaoSolicitacaoOptOutEnum.getSituacaoDevolucaoEnum(this.getSituacao()).getDescricao();

		}

		return descSituacao;

	}

	public String getTag() {

		Integer tempo = UtilData.calcularDiferencaEmDias(new Date(), UtilData.adicionarDiasData(this.dataSolicitacao, 60));

		return tempo > 40 ? "success" : tempo > 20 ? "warning" : "danger";
	}

	public Double getValorDevolucao() {
		Double valorAtualizadoPeloIndice = this.listaCalculoSolicitacao.stream()
				.mapToDouble(a -> a.getValorParticipanteAtualizacaoIndice() + a.getValorPatrocinadoraAtualizacaoIndice())
				.sum();
		
		Double valorContribuicao = this.listaCalculoSolicitacao.stream()
				.mapToDouble(a -> a.getValorPartic() + a.getValorPatron())
				.sum();
		
		return valorContribuicao + (valorAtualizadoPeloIndice > 0 ? valorAtualizadoPeloIndice - valorContribuicao : 0);
	}
}