package br.com.bbprevidencia.devolucao.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.primefaces.util.Constants;

import br.com.bbprevidencia.bbpcomum.util.Constantes;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.exception.RelatorioException;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

/**
 * Classe utilitária responsável por gerar relatórios.
 * 
 * @author tiago.menezes
 * @since 16/03/2012
 */
public abstract class GerenciaRelatorioUtil {

	private static Logger logger = Logger.getLogger(GerenciaRelatorioUtil.class);

	/**
	 * Método responsável por exportar o relatório em pdf.
	 * 
	 * @param mapaParametros
	 * @param nomeJasper
	 * @param dataSource
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings( { "unchecked", "rawtypes" })
	public static void geraRelatorioPDF(Map mapaParametros, String nomeJasper, JRDataSource dataSource) throws PrevidenciaException {
		try {

			mapaParametros.put(JRParameter.REPORT_LOCALE, new Locale("pt", "BR"));

			ServletContext servletContext = UtilSession.getServletContext();

			String pathRel = servletContext.getRealPath(Constantes.RELATORIOS + nomeJasper + ".jasper");

			JasperPrint print = JasperFillManager.fillReport(pathRel, mapaParametros, dataSource);

			exportarPDF(nomeJasper, print);

		} catch (JRException e) {
			throw new PrevidenciaException(e);
		}

	}

	/**
	 * Gera o relatório jasper no formato pdf.
	 * 
	 * @param nomeRelatorio
	 * @param print
	 * @throws PrevidenciaException
	 */
	public static void exportarPDF(String nomeRelatorio, JasperPrint print) throws PrevidenciaException {

		FacesContext facesContext = FacesContext.getCurrentInstance();
		ExternalContext externalContext = facesContext.getExternalContext();
		HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

		BufferedInputStream input = null;
		BufferedOutputStream output = null;
		try {

			byte[] bytes = JasperExportManager.exportReportToPdf(print);

			// Init servlet response.
			response.reset();
			response.setHeader(Constantes.CONTENT_TYPE, Constantes.APPLICATION_PDF);
			response.setHeader(Constantes.CONTENT_LENGTH, String.valueOf(bytes.length));
			response.setHeader(Constantes.CONTENT_DISPOSITION, "inline; filename=\"" + nomeRelatorio + ".pdf" + "\"");

			input = new BufferedInputStream(new ByteArrayInputStream(bytes), Constantes.DEFAULT_BUFFER_SIZE);
			output = new BufferedOutputStream(response.getOutputStream(), Constantes.DEFAULT_BUFFER_SIZE);

			// Write file contents to response.
			byte[] buffer = new byte[Constantes.DEFAULT_BUFFER_SIZE];
			int length;
			while ((length = input.read(buffer)) > 0) {
				output.write(buffer, 0, length);
			}

			// Finalize task.
			output.flush();

			facesContext.responseComplete();

		} catch (IOException e) {
			e.printStackTrace();
			throw new PrevidenciaException(e);
		} catch (JRException e) {
			e.printStackTrace();
			throw new PrevidenciaException(e);
		} finally {
			close(input);
			close(output);
		}

	}

	/**
	 * Método responsável por exportar o relatório em pdf.
	 * 
	 * @param mapaParametros
	 * @param nomeJasper
	 * @param dataSource
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings( { "rawtypes", "unchecked" })
	public static void exportarStreamPDF(Map mapaParametros, String nomeJasper, JRDataSource dataSource) throws PrevidenciaException {
		try {

			mapaParametros.put(JRParameter.REPORT_LOCALE, new Locale("pt", "BR"));

			ServletContext servletContext = UtilSession.getServletContext();

			String pathRel = servletContext.getRealPath(Constantes.RELATORIOS + nomeJasper + ".jasper");

			JasperPrint print = JasperFillManager.fillReport(pathRel, mapaParametros, dataSource);

			visualizarRelatorio(print, nomeJasper + ".pdf");

		} catch (Exception e) {
			logger.error(e);
			throw new PrevidenciaException(e);
		}

	}

	/**
	 * Método responsável por renderiza o arquivo jasper 
	 * em um browser
	 * 
	 * @param print
	 * @param nomeRelatorio
	 * @throws Exception
	 */
	private static void visualizarRelatorio(JasperPrint print, String nomeRelatorio) {
		try {

			byte[] bytes = JasperExportManager.exportReportToPdf(print);
			renderizarRespostaRequisicao(nomeRelatorio, bytes);

		} catch (Exception e) {
			logger.error(e);
			throw new PrevidenciaException("Erro ao gerar Relatório", e);
		}
	}

	/**
	 * Metodo responsavel por mostrar o arquivo passado como argumento no navegador.
	 * 
	 * @param arquivo
	 * @param nomeArquivo
	 * @throws RelatorioException
	 */
	public static void visualizarArquivo(File arquivo, String nomeArquivo) throws RelatorioException {
		try {

			byte[] dados = FileUtils.readFileToByteArray(arquivo);

			renderizarRespostaRequisicao(nomeArquivo, dados);

		} catch (IOException e) {
			logger.error(e);
			throw new RelatorioException(e);
		}
	}

	/**
	 * Renderiza a opção de download do arquivo passado como argumento no navegador.
	 * 
	 * @param arquivo
	 * @param nomeArquivo
	 */
	public static void baixarArquivo(File arquivo, String nomeArquivo) {
		try {

			if (arquivo != null && StringUtils.isNotBlank(nomeArquivo)) {

				InputStream inputStream = new FileInputStream(arquivo);

				FacesContext facesContext = FacesContext.getCurrentInstance();
				HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();

				String contentDispositionValue = "attachment";
				response.setContentType(Constantes.APPLICATION_PDF);
				response.setHeader(Constantes.CONTENT_DISPOSITION, contentDispositionValue + ";filename=\"" + nomeArquivo + "\"");
				response.addCookie(new Cookie(Constants.DOWNLOAD_COOKIE, "true"));

				byte[] buffer = new byte[2048];
				int length;
				OutputStream outputStream = response.getOutputStream();

				while ((length = (inputStream.read(buffer))) != -1) {
					outputStream.write(buffer, 0, length);
				}

				response.setStatus(200);
				response.getOutputStream().flush();
				inputStream.close();
				facesContext.responseComplete();
			}

		} catch (IOException e) {
			logger.error(e);
			throw new PrevidenciaException(e);
		}
	}

	/**
	 * 
	 * @param nomeArquivo
	 * @param dados
	 * @throws IOException
	 */
	private static void renderizarRespostaRequisicao(String nomeArquivo, byte[] dados) throws IOException {

		HttpServletResponse response = (HttpServletResponse) UtilSession.getContext().getExternalContext().getResponse();
		response.setHeader(Constantes.META_HTTP_EQUIV, Constantes.CACHE_CONTROL);
		response.setHeader(Constantes.CONTENT, Constantes.NO_CACHE);
		response.setHeader(Constantes.EXPIRES, "0");
		response.setHeader(Constantes.PRAGMA, Constantes.PUBLIC);
		response.setHeader(Constantes.CONTENT_DISPOSITION, "inline; filename=\"" + nomeArquivo + "\\");
		response.setHeader(Constantes.CONTENT_TYPE, Constantes.APPLICATION_PDF);
		response.setHeader(Constantes.CONTENT_LENGTH, String.valueOf(dados.length));

		ServletOutputStream os = response.getOutputStream();
		os.write(dados);
		os.flush();
		os.close();
	}

	/**
	 * Fecha o recurso.
	 * 
	 * @param resource
	 */
	private static void close(Closeable resource) {
		if (resource != null) {
			try {
				resource.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}