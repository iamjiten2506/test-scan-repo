package br.com.bbprevidencia.devolucao.controle;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.EmailValidator;
import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bbprevidencia.bbpcomum.util.CpfCnpjValidator;
import br.com.bbprevidencia.bbpcomum.util.TipoMascara;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.AgenciaBancariaBO;
import br.com.bbprevidencia.cadastroweb.bo.BancoBO;
import br.com.bbprevidencia.cadastroweb.bo.DependenteParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.EstadoCivilBO;
import br.com.bbprevidencia.cadastroweb.bo.GrauInstrucaoBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.TipoTelefoneBO;
import br.com.bbprevidencia.cadastroweb.bo.UnidadeFederativaBO;
import br.com.bbprevidencia.cadastroweb.dto.AgenciaBancaria;
import br.com.bbprevidencia.cadastroweb.dto.BancoDTO;
import br.com.bbprevidencia.cadastroweb.dto.DependenteParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EstadoCivil;
import br.com.bbprevidencia.cadastroweb.dto.GrauInstrucao;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.TipoTelefone;
import br.com.bbprevidencia.cadastroweb.dto.UnidadeFederativa;
import br.com.bbprevidencia.cadastroweb.exception.RegistroNaoEncontradoException;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoItemBO;
import br.com.bbprevidencia.devolucao.bo.GrupoRecebimentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucaoVisaoItem;
import br.com.bbprevidencia.devolucao.dto.GrupoRecebimentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.ValidacaoUtil;
import br.com.bbprevidencia.folha.bo.QualidadeRecebedorBO;
import br.com.bbprevidencia.folha.bo.RecebedorBO;
import br.com.bbprevidencia.folha.bo.SituacaoRecebedorBO;
import br.com.bbprevidencia.folha.dto.QualidadeRecebedor;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.folha.dto.SituacaoRecebedor;
import br.com.bbprevidencia.folha.dto.TelefoneRecebedor;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0170 - Magson Dias
 * @since   31/03/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("processoAtualizacaoRecebimentoResgateVisao")
public class ProcessoAtualizacaoRecebimentoResgateVisao {

	private static String FW_PROCESSO_ATUALIZACAO_BENEF_RESGATE = "/paginas/processoAtualizacaoBeneficiarioResgate.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(ProcessoAtualizacaoRecebimentoResgateVisao.class);

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private GrupoRecebimentoDevolucaoBO grupoRecebimentoDevolucaoBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBo;
	@Autowired
	private RecebedorBO recebedorBO;
	@Autowired
	private DependenteParticipanteBO dependenteParticipanteBO;
	@Autowired
	private UnidadeFederativaBO unidadeFederativaBO;
	@Autowired
	private QualidadeRecebedorBO qualidadeRecebedorBO;
	@Autowired
	private SituacaoRecebedorBO situacaoRecebedorBO;
	@Autowired
	private BancoBO bancoBO;
	@Autowired
	private AgenciaBancariaBO agenciaBancariaBO;
	@Autowired
	private EstadoCivilBO estadoCivilBO;
	@Autowired
	private GrauInstrucaoBO grauInstrucaoBO;
	@Autowired
	private ValidacaoUtil validacaoUtil;
	@Autowired
	private DocumentoDevolucaoVisaoItemBO documentoDevolucaoVisaoItemBO;
	@Autowired
	private TipoTelefoneBO tipoTelefoneBO;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean listarStatus;
	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private GrupoRecebimentoDevolucao grupoRecebimentoDevolucao;
	private GrupoRecebimentoDevolucao grupoRecebimentoDevolucaoEditavel;
	private Participante participante;
	private TipoDevolucao tipoDevolucao;
	private Devolucao devolucao;
	private Recebedor recebedor;
	private Date dataAtual;
	private Long codigoDependenteParticipante;
	private Long codigoDependente;
	private Long codigoDependenteEditavel;
	private String mensagem;
	private boolean statusEditar;
	private boolean ativarDependente;
	private Long codigoBanco;
	private Long codigoAgencia;
	private QualidadeRecebedor qualidadeRecebedor;

	private boolean possuiDocumentoRecebedor;
	private boolean possuiDocumentoRecebedorPendente;
	private boolean chamaPendenciasAberturaTela;

	private String descricaoPendencias;
	private DocumentoDevolucao documentoDevolucao;

	private List<DependenteParticipante> listaDependenteParticipante;
	private List<GrupoRecebimentoDevolucao> listaGrupoRecebimentoDevolucao;
	private List<Recebedor> listarRecebedor;
	private List<UnidadeFederativa> listaUnidadeFederativa;
	private List<EstadoCivil> listaEstadoCivil;
	private List<GrauInstrucao> listaGrauInstrucao;
	private List<BancoDTO> listaBanco;
	private List<AgenciaBancaria> listarAgenciaBancaria;
	private List<QualidadeRecebedor> listarQualidadeRecebedor;
	private List<SituacaoRecebedor> listarSituacaoRecebedor;
	private List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem;
	private List<TipoTelefone> listaTipoTelefone;
	private TelefoneRecebedor telefoneRecebedor;

	/**
	 * Método para redicionar a página de pesquisa para página o cadastro de grupo de recebedor. 
	 * 
	 * @author bbpf0170 - Magson Dias
	 * @since 15/03/2017
	 * @param {@link Devolucao} 
	 * @return {@link String}
	 * @throws Exception 
	 * @throws RegistroNaoEncontradoException 
	 */
	public String mostrarCadastroResgate(Devolucao devolucao) throws RegistroNaoEncontradoException, Exception {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoAtualizacaoRecebimentoResgate");
		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoAtualizacaoRecebimentoResgate");
		} else {
			this.possuiAcessoTotal = false;
		}
		this.listarStatus = true;
		// carregando obejsto para exibir no tela. 
		this.setDevolucao(devolucao);
		this.setParticipante(this.devolucao.getParticipantePlano().getParticipante());
		this.entidadeParticipante = entidadeParticipanteBO.consultarPorChavePrimaria(this.participante.getEntidadeParticipante().getChavePrimaria());
		this.planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(devolucao.getParticipantePlano().getPlanoPrevidencia().getCodigo());
		this.listaGrupoRecebimentoDevolucao = grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorDevolucao(this.devolucao);

		this.listarRecebedor = recebedorBO.listaReceborParticipante(this.participante);
		this.listaDependenteParticipante = dependenteParticipanteBO.listarDependentePartic(this.participante);

		// carregar campos do cadastro de recebedor
		this.listarQualidadeRecebedor = qualidadeRecebedorBO.listarTodasQualidadeRecebedor();
		this.listarSituacaoRecebedor = situacaoRecebedorBO.listarTodasSituacaoRecebedor();
		this.listaBanco = bancoBO.listarBanco();
		this.listaEstadoCivil = estadoCivilBO.listarEstadoCivil();
		this.listaGrauInstrucao = grauInstrucaoBO.listarGrauInstrucao();
		this.listaUnidadeFederativa = unidadeFederativaBO.listarUnidadeFederativa();
		this.listaTipoTelefone = tipoTelefoneBO.listarTipoTelefone();

		this.recebedor = new Recebedor();
		this.grupoRecebimentoDevolucao = new GrupoRecebimentoDevolucao();

		return FW_PROCESSO_ATUALIZACAO_BENEF_RESGATE;
	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo inicial de pesquisa
	 * @author  BBPF00170 - Magson Dias
	 * @since  16/03/2017
	 */
	public void retornar() {
		this.listarStatus = true;
		this.setListaDependenteParticipante(null);
		this.setListaGrupoRecebimentoDevolucao(null);
		this.setListaDocumentoDevolucaoVisaoItem(null);
	}

	/**
	 * Retorna o estado inicial da página
	 * @author  BBPF0170 - Magson
	 * @since 17/03/2017
	 */
	public void limpar() {
		this.grupoRecebimentoDevolucao = new GrupoRecebimentoDevolucao();
		this.setCodigoDependente(null);
	}

	/**
	 * Método para adiciona a mensage de erro no faces.
	 * @author  BBPF0170 - MAGSON 
	 * @param mensagem
	 */
	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

	/**
	 * Método responsalveu por salvar um novo grupo de recebimento de devolução. 
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 31/03/2017
	 * @return {@link String}
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String salvarGrupo() {
		this.grupoRecebimentoDevolucao.setCodigoDependente(this.codigoDependente);
		this.grupoRecebimentoDevolucao.setDevolucao(this.devolucao);
		this.grupoRecebimentoDevolucao.setParticipante(this.participante);
		try {
			if (this.grupoRecebimentoDevolucao.getCodigo() == null) {
				this.grupoRecebimentoDevolucao.setDataInclusao(new Date());
				this.grupoRecebimentoDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Grupo de recebimento de devolução salvo com sucesso!";
			} else {
				this.grupoRecebimentoDevolucao.setDataAlteracao(new Date());
				this.grupoRecebimentoDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Grupo de recebimento de devolução atualizado com sucesso!";
			}
			//Transforma o objeto transiente em um objeto persistente.
			if (this.grupoRecebimentoDevolucao.getCodigo() != null) {
				GrupoRecebimentoDevolucao grupoRecebimentoDevolucao = new GrupoRecebimentoDevolucao();
				grupoRecebimentoDevolucao = grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorCodigo(this.grupoRecebimentoDevolucao.getCodigo());
				grupoRecebimentoDevolucao = this.grupoRecebimentoDevolucao;
			}
			if (validaCampos(this.grupoRecebimentoDevolucao)) {
				return "";
			}
			this.grupoRecebimentoDevolucaoBO.salvarGrupoRecebimentoDevolucao(this.grupoRecebimentoDevolucao);
			Mensagens.addMsgInfo(mensagem);
			this.listaGrupoRecebimentoDevolucao = grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorDevolucao(this.devolucao);
			// veririfica se tem documento para recebedor. 
			if (documentoDevolucaoVisaoItemBO
					.verificarDocumentosPorDevolucaoRecebedor(this.grupoRecebimentoDevolucao.getDevolucao(), this.grupoRecebimentoDevolucao.getRecebedor(), loginTemporariaDTO)) {
				Mensagens.addMsgInfo("Favor verificar documento do recebedor!");
				verificarDocumentosDevolucaoRecebedor(this.grupoRecebimentoDevolucao.getDevolucao(), this.grupoRecebimentoDevolucao.getRecebedor());
			}

			// limpar objeto para não aparece apos salvar as informações.
			this.grupoRecebimentoDevolucao = new GrupoRecebimentoDevolucao();
			this.setCodigoDependente(null);
			this.listarStatus = true;

		} catch (PrevidenciaException pEx) {
			addMsgErro(pEx.getMessage());
		} catch (Exception e) {
			addMsgErro(e.getMessage());
		}
		return FW_PROCESSO_ATUALIZACAO_BENEF_RESGATE;
	}

	/**
	 * Método responsavel por carregar o recebedor para um novo grupo de recebimento.
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 */
	public void mostraGrupoRecebimento() {
		this.listaGrupoRecebimentoDevolucao = grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorDevolucao(this.devolucao);
		this.listaDependenteParticipante = dependenteParticipanteBO.listarDependentePartic(this.participante);
		this.ativarDependente = ativarDependente(this.grupoRecebimentoDevolucao.getRecebedor());
	}

	/**
	 * Método para retorna data Atual
	 * @author bbpf0170 - Magson Dias
	 * @return {@link Date} 
	 */
	public Date getDataAtual() {
		if (dataAtual == null)
			dataAtual = new Date();
		return dataAtual;
	}

	/**
	 * Método que deleta um grupo de recebimento de devolução.
	 * @author  BBPF0170 - Magson
	 * @since 17/02/2017
	 * @param {@link GrupoRecebimentoDevolucao}
	 * @return {@link String}
	 */
	public String deletarGrupoRecebimentoDevolucao(GrupoRecebimentoDevolucao grupoRecebimentoDevolucao) {
		try {
			grupoRecebimentoDevolucaoBO.apagarGrupoRecebimentoDevolucao(grupoRecebimentoDevolucao);
			this.listaGrupoRecebimentoDevolucao = grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorDevolucao(this.devolucao);
			limpar();
			Mensagens.addMsgInfo("Registro excluído com sucesso!");
			return FW_PROCESSO_ATUALIZACAO_BENEF_RESGATE;
		} catch (PrevidenciaException pEx) {
			addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			addMsgErro(ex.getMessage());
			return "";
		}

	}

	/**
	 * Método para validar campos do grupo de recebimento de devolucao.
	 * @author	 bbpf0170 - Magson Dias
	 * @return	{@link boolean}
	 * @parem	{@link GrupoRecebimentoDevolucao}
	 * 
	 */
	private boolean validaCampos(GrupoRecebimentoDevolucao grupoRecebimentoDevolucao) {
		boolean res = false;

		if (grupoRecebimentoDevolucao.getRecebedor() == null) {
			addMsgErro("Selecione um recebedor.s");
			res = true;
		}

		if (grupoRecebimentoDevolucao.getDataInicio() == null) {
			addMsgErro("A data fim não pode ser anterior a data inicio.");
			res = true;
		}
		if (grupoRecebimentoDevolucao.getDataFim() != null) {
			Date dataFim = (Date) this.grupoRecebimentoDevolucao.getDataFim();
			if (grupoRecebimentoDevolucao.getDataInicio() != null && dataFim.before(grupoRecebimentoDevolucao.getDataInicio())) {
				addMsgErro("A data fim não pode ser anterior a data inicio.");
				res = true;
			}
		}

		if (grupoRecebimentoDevolucao.getCodigo() == null) {
			if (grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoCadastrado(grupoRecebimentoDevolucao)) {
				addMsgErro("Chave única não pode ser duplicada!");
				res = true;
			}
		}

		return res;
	}

	/**
	 * Método para ativar o campo de dependentes.
	 * @author	 bbpf0170 - Magson Dias
	 * @return	{@link boolean}
	 * @param	{@link Recebedor}
	 */
	public boolean ativarDependente(Recebedor recebedor) {
		boolean res = false;
		if (recebedorBO.pesquisarRecebedorPorCodigoParticipante(recebedor) != null) {
			res = true;
		}
		return res;
	}

	/**
	 *  Método que controla o modo de visualização e edição do grupo de recebimento de devolução. 
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 * @param {@link GrupoRecebimentoDevolucao}
	 */
	public void editarGrupoRecebimento(GrupoRecebimentoDevolucao grupoRecebimentoDevolucao) {
		this.setGrupoRecebimentoDevolucao(grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorCodigo(grupoRecebimentoDevolucao.getCodigo()));
		this.setCodigoDependente(this.grupoRecebimentoDevolucao.getCodigoDependente());
		this.ativarDependente = ativarDependente(this.grupoRecebimentoDevolucao.getRecebedor());
	}

	/**
	 * Método encarredado por iniciar a página manter recebedor.
	 *  
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since   16/02/2017
	 * @return {@link String}
	 * @throws Exception 
	 * @throws RegistroNaoEncontradoException 
	 */
	public String telaRecebedor() throws RegistroNaoEncontradoException, Exception {
		this.listarQualidadeRecebedor = qualidadeRecebedorBO.listarTodasQualidadeRecebedor();
		this.listarSituacaoRecebedor = situacaoRecebedorBO.listarTodasSituacaoRecebedor();
		this.listaBanco = bancoBO.listarBanco();
		this.listaEstadoCivil = estadoCivilBO.listarEstadoCivil();
		this.listaGrauInstrucao = grauInstrucaoBO.listarGrauInstrucao();
		this.listaUnidadeFederativa = unidadeFederativaBO.listarUnidadeFederativa();

		this.recebedor = new Recebedor();
		this.telefoneRecebedor = new TelefoneRecebedor();
		//this.listarRecebedor = recebedorBO.
		return "";

	}

	/**
	 * Método para salvar ou atualizar o registro de um recebedor.
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 17/03/2017
	 * @return	{@link String}
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String salvarRecebedor() {
		this.recebedor.setAgenciaBancaria(this.agenciaBancariaBO.consultarPorCodigoAgenciaEBanco(this.codigoAgencia, this.codigoBanco));
		try {

			if (this.recebedor.getCodigo() == null) {
				this.recebedor.setDataInclusao(new Date());
				this.recebedor.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				this.recebedor.setDataSituacaoRecebedor(new Date());
				this.recebedor.setParticipante(this.participante);
				this.mensagem = "Recebedor salvo com sucesso!";
			} else {
				this.recebedor.setDataAlteracao(new Date());
				this.recebedor.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Recebedor atualizado com sucesso!";
			}
			//if (this.recebedor.getEmailSecundario().equals("")) {
			//	this.recebedor.setEmailSecundario(this.recebedor.getEmail());
			//}
			configurarRecebedor(getRecebedor());
			if (validaCamposRecebedor()) {
				return "";
			}
			recebedorBO.salvar(this.recebedor);
			Mensagens.addMsgInfo(mensagem);
			//recebedor do grupo de recebimento.
			this.listarRecebedor = recebedorBO.listaReceborParticipante(this.participante);
			this.grupoRecebimentoDevolucao.setRecebedor(this.recebedor);
			this.ativarDependente = ativarDependente(this.recebedor);
			PrimeFaces.current().executeScript("PF('recebedorDialog').hide()");
			limparRecebedor();
			return FW_PROCESSO_ATUALIZACAO_BENEF_RESGATE;
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar/atualizar o recebedor.");
			return "";
		}

	}

	/**
	 * Método para configurar o estado do recebedor para que o procedimento de salvar seja efetuado.
	 * 
	 * @author bbpf0170 - Magson Dias
	 * @param {@link Recebedor}
	 */
	private void configurarRecebedor(Recebedor recebedor) {
		configurarCPF(getRecebedor());
		//configurarCep(getParticipante());
	}

	/**
	 * Método para configurar CPF do recebedor 
	 * @author	bbpf0170 - Magson Dias
	 * @param {@link Recebedor}
	 */
	private void configurarCPF(Recebedor recebedor) {
		String cpf = null;
		if (!UtilJava.isStringVazia(recebedor.getCpf())) {
			cpf = new String(TipoMascara.CPF.aplicarMascara(recebedor.getCpf()));
			cpf = cpf.replaceAll("\\.", "");

			if (cpf.split("-")[0] != null && !cpf.split("-")[0].equals(""))
				recebedor.setNumeroCpf(new BigDecimal(cpf.split("-")[0]));

			if (cpf.split("-")[1] != null && !cpf.split("-")[1].equals(""))
				recebedor.setNumeroComplCpf(new BigDecimal(cpf.split("-")[1]));
		}

	}

	/**
	 * Método para validar campos do cadastro de recebedor
	 * @author bbpf0170 - Magson Dias
	 * @return @param {@link boolean}
	 */

	private boolean validaCamposRecebedor() {
		boolean res = false;

		if (StringUtils.isNotBlank(this.recebedor.getEmail()) && !EmailValidator.getInstance().isValid(this.recebedor.getEmail())) {
			addMsgErro("O email digitado não é valido!");
			res = true;
		}
		if (!this.recebedor.getEmailSecundario().equals("")) {
			if (!EmailValidator.getInstance().isValid(this.recebedor.getEmailSecundario())) {
				addMsgErro("O e-mail secundário digitado não é valido!");
				res = true;
			}
		}

		if (this.recebedor.getNumeroCpf() == null || this.recebedor.getNumeroComplCpf() == null) {
			addMsgErro("O CPF digitado não é válido!");
			res = true;
		} else {
			if (!CpfCnpjValidator.isValidCPF(TipoMascara.CPF.aplicarMascara(this.recebedor.getCpf()))) {
				//Mensagens.addError("ME056", UtilJava.formataCPF(recebedor.getCpf()));
				addMsgErro("O CPF digitado não é válido!");
				res = true;
			}
		}

		if (this.getRecebedor().getIndicadorTipoConta().equals("CP") || this.getRecebedor().getIndicadorTipoConta().equals("CC")) {

			if (this.recebedor.getAgenciaBancaria() == null || (this.recebedor.getAgenciaBancaria() != null && this.recebedor.getAgenciaBancaria().getChavePrimaria() == null)) {
				addMsgErro("Os Dados Bancários são obrigatórios!");
				res = true;
			}

		}

		return res;
	}

	/**
	 * Método responsável por retornar o objeto recebedor carregado com as informações do participate.
	 * 
	 * @author BBPF0170 - Magson Dias 
	 * @since 16/02/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return	{@link String}
	 */
	public String retornaOproprio(AjaxBehaviorEvent event) {
		this.setQualidadeRecebedor(this.recebedor.getQualidadeRecebedor());
		try {
			if (this.recebedor.getQualidadeRecebedor().getCodigo() == 1 && this.recebedor.getCodigo() == null) {
				this.recebedor = validacaoUtil.retornaOproprioRecebedorParticipante(this.participante, this.loginTemporariaDTO);
				if (this.recebedor.getQualidadeRecebedor() == null) {
					this.recebedor.setQualidadeRecebedor(this.qualidadeRecebedor);
				}

				if (this.recebedor.getAgenciaBancaria() != null) {
					this.setCodigoBanco(this.recebedor.getAgenciaBancaria().getChavePrimaria().getCodigoBanco());
					this.setCodigoAgencia(this.recebedor.getAgenciaBancaria().getChavePrimaria().getCodigoAgenciaBancaria());
					this.listarAgenciaBancaria = new ArrayList<AgenciaBancaria>(this.agenciaBancariaBO.pequisarAgenciaPorCodigoBanco(this.codigoBanco));
				}

			}
			return "";
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}

	}

	/**
	 * Retorna o estado inicial da página
	 * @author  BBPF0170 - Magson
	 * @since 17/03/2017
	 */
	public void limparRecebedor() {
		this.recebedor = new Recebedor();
		this.setCodigoBanco(null);
		this.setCodigoAgencia(null);
	}

	/**
	 * Método responsável por retornar a lista de agencias de acordo com o código selecionado.
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 16/03/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return	{@link String}
	 */
	public String listarAgencias(AjaxBehaviorEvent event) {
		if (this.getCodigoBanco() == null) {
			addMsgErro("Selecione um Banco.");
		} else {
			try {
				this.listarAgenciaBancaria = new ArrayList<AgenciaBancaria>(this.agenciaBancariaBO.pequisarAgenciaPorCodigoBanco(codigoBanco));
				return "";
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}
		return "";
	}

	/**
	 * Método responsável por salva os documentos referentes ao recebedor.
	 * 
	 * @author BBPF0170 - Magson Dias
	 * @since 16/03/2017
	 */
	public void salvarListaDocumentoDevolucaoVisaoItem() {
		for (DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItem : this.listaDocumentoDevolucaoVisaoItem) {
			DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItemPesq = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorCodigo(documentoDevolucaoVisaoItem.getCodigo());
			if (!documentoDevolucaoVisaoItemPesq.getIndicativoMarcado().equals(documentoDevolucaoVisaoItem.getIndicativoMarcado())) {
				//Marcando a data de marcação do documento.
				if (documentoDevolucaoVisaoItem.getIndicativoMarcado().equals("S")) {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(new Date());
				} else {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(null);
				}
				documentoDevolucaoVisaoItemPesq.setIndicativoMarcado(documentoDevolucaoVisaoItem.getIndicativoMarcado());
				documentoDevolucaoVisaoItemPesq.setNomeUsuarioAlteracao(loginTemporariaDTO.getIdentificacaoUsuario());
				documentoDevolucaoVisaoItemBO.salvarDocumentoDevolucaoVisaoItem(documentoDevolucaoVisaoItemPesq);
			}
		}
		this.listaGrupoRecebimentoDevolucao = grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorDevolucao(this.devolucao);
		PrimeFaces.current().executeScript("PF('documentosDevolucaoRecebedorDialog').hide();");
		//PrimeFaces.current().ajax().update("frmEditarDocumentosRecebedor, ltGrupo");
	}

	/**
	 * Método responsável por verificar os documentos referentes ao recebedor.
	 * 
	 * @author BBPF0170 - Magson Dias
	 * @since 16/03/2017
	 * @param {@link Devolucao}
	 * @param {@link Recebedor}
	 */
	public void verificarDocumentosDevolucaoRecebedor(Devolucao devolucao, Recebedor recebedor) {
		if (devolucao == null) {
			this.setPossuiDocumentoRecebedor(false);
			this.setPossuiDocumentoRecebedorPendente(false);
			this.setChamaPendenciasAberturaTela(false);
		} else {
			this.listaDocumentoDevolucaoVisaoItem = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorDevolucaoRecebedor(devolucao, recebedor);

			this.setPossuiDocumentoRecebedorPendente(false);
			this.setChamaPendenciasAberturaTela(false);
			if (this.listaDocumentoDevolucaoVisaoItem.size() > 0) {
				this.setPossuiDocumentoRecebedor(true);
				if (documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemPendentePorDevolucaoRecebedor(devolucao, recebedor)) {
					this.setPossuiDocumentoRecebedorPendente(true);
				}
			} else {
				this.setPossuiDocumentoRecebedor(false);
			}
			if (this.isPossuiDocumentoRecebedorPendente()) {
				this.setChamaPendenciasAberturaTela(true);
			}
		}
	}

	/**
	 * Método responsável por retorna na tela se exitem ou não documentos pendentes. 
	 * 
	 * @author BBPF0170 - Magson Dias
	 * @since 16/03/2017
	 * @param {@link GrupoRecebimentoDevolucao}
	 */
	public String descricaoPendencias(GrupoRecebimentoDevolucao grpRecebimento) {
		String descricaoPendenciasLocal = new String();
		descricaoPendenciasLocal = "Não existe(m) documento(s)";
		this.listaDocumentoDevolucaoVisaoItem = documentoDevolucaoVisaoItemBO.listarDocumentoDevolucaoVisaoItemPendentePorTipoRecebedor(grpRecebimento.getDevolucao(), grpRecebimento.getRecebedor());

		this.setPossuiDocumentoRecebedorPendente(false);
		this.setChamaPendenciasAberturaTela(false);
		if (this.listaDocumentoDevolucaoVisaoItem.size() > 0) {
			descricaoPendenciasLocal = "Não existe(m) documento(s) pendente(s)";
			this.setPossuiDocumentoRecebedor(true);
			if (documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemPendentePorDevolucaoRecebedor(grpRecebimento.getDevolucao(), grpRecebimento.getRecebedor())) {
				this.setPossuiDocumentoRecebedorPendente(true);
				descricaoPendenciasLocal = "Existe(m) documento(s) Pendende(s)";
			}
		} else {
			descricaoPendenciasLocal = "Não existe(m) documento(s)";
			this.setPossuiDocumentoRecebedor(false);
		}
		if (this.isPossuiDocumentoRecebedorPendente()) {
			this.setChamaPendenciasAberturaTela(true);
		}
		return descricaoPendenciasLocal;
	}

	/**
	 *  Método que controla o modo de visualização e edição do grupo de recebimento de devolução. 
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 * @param {@link GrupoRecebimentoDevolucao}
	 */
	public void editarDocumetos(GrupoRecebimentoDevolucao grupoRecebimentoDevolucao) {
		if (documentoDevolucaoVisaoItemBO.verificarDocumentosPorDevolucaoRecebedor(grupoRecebimentoDevolucao.getDevolucao(), grupoRecebimentoDevolucao.getRecebedor(), loginTemporariaDTO)) {
			verificarDocumentosDevolucaoRecebedor(grupoRecebimentoDevolucao.getDevolucao(), grupoRecebimentoDevolucao.getRecebedor());
			PrimeFaces.current().executeScript("PF('documentosDevolucaoRecebedorDialog').show();");
			PrimeFaces.current().ajax().update("frmEditarDocumentosRecebedor, ltGrupo");
		}
	}

	/**
	 *  Método responsável por limpar os objetos da modal cadastro de documentos pendentes. 
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 */

	public void limparObjetosTemporarios() {
		this.grupoRecebimentoDevolucao = new GrupoRecebimentoDevolucao();
		this.setListaDocumentoDevolucaoVisaoItem(new ArrayList<DocumentoDevolucaoVisaoItem>());
		this.setCodigoDependente(null);
		PrimeFaces.current().executeScript("PF('documentosDevolucaoRecebedorDialog').hide();");
		PrimeFaces.current().ajax().update("frmEditarDocumentosRecebedor, ltGrupo");
	}

	/**
	 * Método responsavel por carregar a pagina para cadastrar um Novo Grupo
	 * @author  BBPF0170 -  Magson
	 * @since   13/02/2017
	 */
	public void cadastrarNovoGrupoRecebimento() {
		this.recebedor = new Recebedor();
		this.grupoRecebimentoDevolucao = new GrupoRecebimentoDevolucao();
		controlarGrupoRecebimento();
	}

	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * @author  BBPF00170 - Magson
	 * @since   13/02/2017
	 */
	public void controlarGrupoRecebimento() {
		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método para adicinar um telefone na tela de cadastro receberdor. 
	 * @author  BBPF00170 - Magson
	 * @since   13/02/2017
	 */
	public String adicionarTelefoneRecebedor() {
		boolean res = false;
		if (this.telefoneRecebedor.getNumeroDDD().equals("")) {
			addMsgErro("Número DDD: campo obrigatório!");
			res = true;
		}
		if (this.telefoneRecebedor.getNumeroTelefone().equals("")) {
			addMsgErro("Número Telefone: campo obrigatório!");
			res = true;
		}
		if (this.telefoneRecebedor.getTipoTelefone() == null) {
			addMsgErro("Tipo: campo obrigatório!");
			res = true;
		}

		if (!res) {
			this.telefoneRecebedor.setRecebedor(this.recebedor);
			this.telefoneRecebedor.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			this.telefoneRecebedor.setDataInclusao(new Date());
			this.recebedor.getListaTelefoneRecebedor().add(this.telefoneRecebedor);
			this.setTelefoneRecebedor(new TelefoneRecebedor());
		}
		return "";
	}

	/**
	 * Método para remover um telefone na tela de cadastro receberdor. 
	 * @author  BBPF00170 - Magson
	 * @since   13/02/2017
	 */
	public void removerTelRecebedor(TelefoneRecebedor telefone) {
		try {
			for (int i = 0; i < this.recebedor.getListaTelefoneRecebedor().size(); i++) {
				if (this.recebedor.getListaTelefoneRecebedor().get(i) == telefone) {
					this.recebedor.getListaTelefoneRecebedor().remove(i);
				}
			}

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi possível realizar a operação", e);

		}

	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public ParticipanteBO getParticipanteBO() {
		return participanteBO;
	}

	public void setParticipanteBO(ParticipanteBO participanteBO) {
		this.participanteBO = participanteBO;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public TipoDevolucaoBO getTipoDevolucaoBo() {
		return tipoDevolucaoBo;
	}

	public void setTipoDevolucaoBo(TipoDevolucaoBO tipoDevolucaoBo) {
		this.tipoDevolucaoBo = tipoDevolucaoBo;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public GrupoRecebimentoDevolucao getGrupoRecebimentoDevolucao() {
		return grupoRecebimentoDevolucao;
	}

	public void setGrupoRecebimentoDevolucao(GrupoRecebimentoDevolucao grupoRecebimentoDevolucao) {
		this.grupoRecebimentoDevolucao = grupoRecebimentoDevolucao;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public List<GrupoRecebimentoDevolucao> getListaGrupoRecebimentoDevolucao() {
		return listaGrupoRecebimentoDevolucao;
	}

	public void setListaGrupoRecebimentoDevolucao(List<GrupoRecebimentoDevolucao> listaGrupoRecebimentoDevolucao) {
		this.listaGrupoRecebimentoDevolucao = listaGrupoRecebimentoDevolucao;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public RecebedorBO getRecebedorBO() {
		return recebedorBO;
	}

	public void setRecebedorBO(RecebedorBO recebedorBO) {
		this.recebedorBO = recebedorBO;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public List<Recebedor> getListarRecebedor() {
		return listarRecebedor;
	}

	public void setListarRecebedor(List<Recebedor> listarRecebedor) {
		this.listarRecebedor = listarRecebedor;
	}

	public void setDataAtual(Date dataAtual) {
		this.dataAtual = dataAtual;
	}

	public List<DependenteParticipante> getListaDependenteParticipante() {
		return listaDependenteParticipante;
	}

	public void setListaDependenteParticipante(List<DependenteParticipante> listaDependenteParticipante) {
		this.listaDependenteParticipante = listaDependenteParticipante;
	}

	public DependenteParticipanteBO getDependenteParticipanteBO() {
		return dependenteParticipanteBO;
	}

	public void setDependenteParticipanteBO(DependenteParticipanteBO dependenteParticipanteBO) {
		this.dependenteParticipanteBO = dependenteParticipanteBO;
	}

	public Long getCodigoDependenteParticipante() {
		return codigoDependenteParticipante;
	}

	public void setCodigoDependenteParticipante(Long codigoDependenteParticipante) {
		this.codigoDependenteParticipante = codigoDependenteParticipante;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public GrupoRecebimentoDevolucao getGrupoRecebimentoDevolucaoEditavel() {
		return grupoRecebimentoDevolucaoEditavel;
	}

	public void setGrupoRecebimentoDevolucaoEditavel(GrupoRecebimentoDevolucao grupoRecebimentoDevolucaoEditavel) {
		this.grupoRecebimentoDevolucaoEditavel = grupoRecebimentoDevolucaoEditavel;
	}

	public Long getCodigoDependente() {
		return codigoDependente;
	}

	public void setCodigoDependente(Long codigoDependente) {
		this.codigoDependente = codigoDependente;
	}

	public Long getCodigoDependenteEditavel() {
		return codigoDependenteEditavel;
	}

	public void setCodigoDependenteEditavel(Long codigoDependenteEditavel) {
		this.codigoDependenteEditavel = codigoDependenteEditavel;
	}

	public boolean isStatusEditar() {
		return statusEditar;
	}

	public void setStatusEditar(boolean statusEditar) {
		this.statusEditar = statusEditar;
	}

	public boolean isAtivarDependente() {
		return ativarDependente;
	}

	public void setAtivarDependente(boolean ativarDependente) {
		this.ativarDependente = ativarDependente;
	}

	public List<UnidadeFederativa> getListaUnidadeFederativa() {
		return listaUnidadeFederativa;
	}

	public void setListaUnidadeFederativa(List<UnidadeFederativa> listaUnidadeFederativa) {
		this.listaUnidadeFederativa = listaUnidadeFederativa;
	}

	public List<EstadoCivil> getListaEstadoCivil() {
		return listaEstadoCivil;
	}

	public void setListaEstadoCivil(List<EstadoCivil> listaEstadoCivil) {
		this.listaEstadoCivil = listaEstadoCivil;
	}

	public List<GrauInstrucao> getListaGrauInstrucao() {
		return listaGrauInstrucao;
	}

	public void setListaGrauInstrucao(List<GrauInstrucao> listaGrauInstrucao) {
		this.listaGrauInstrucao = listaGrauInstrucao;
	}

	public List<BancoDTO> getListaBanco() {
		return listaBanco;
	}

	public void setListaBanco(List<BancoDTO> listaBanco) {
		this.listaBanco = listaBanco;
	}

	public List<AgenciaBancaria> getListarAgenciaBancaria() {
		return listarAgenciaBancaria;
	}

	public void setListarAgenciaBancaria(List<AgenciaBancaria> listarAgenciaBancaria) {
		this.listarAgenciaBancaria = listarAgenciaBancaria;
	}

	public List<QualidadeRecebedor> getListarQualidadeRecebedor() {
		return listarQualidadeRecebedor;
	}

	public void setListarQualidadeRecebedor(List<QualidadeRecebedor> listarQualidadeRecebedor) {
		this.listarQualidadeRecebedor = listarQualidadeRecebedor;
	}

	public List<SituacaoRecebedor> getListarSituacaoRecebedor() {
		return listarSituacaoRecebedor;
	}

	public void setListarSituacaoRecebedor(List<SituacaoRecebedor> listarSituacaoRecebedor) {
		this.listarSituacaoRecebedor = listarSituacaoRecebedor;
	}

	public Long getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(Long codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public Long getCodigoAgencia() {
		return codigoAgencia;
	}

	public void setCodigoAgencia(Long codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	public QualidadeRecebedor getQualidadeRecebedor() {
		return qualidadeRecebedor;
	}

	public void setQualidadeRecebedor(QualidadeRecebedor qualidadeRecebedor) {
		this.qualidadeRecebedor = qualidadeRecebedor;
	}

	public boolean isPossuiDocumentoRecebedor() {
		return possuiDocumentoRecebedor;
	}

	public void setPossuiDocumentoRecebedor(boolean possuiDocumentoRecebedor) {
		this.possuiDocumentoRecebedor = possuiDocumentoRecebedor;
	}

	public boolean isPossuiDocumentoRecebedorPendente() {
		return possuiDocumentoRecebedorPendente;
	}

	public void setPossuiDocumentoRecebedorPendente(boolean possuiDocumentoRecebedorPendente) {
		this.possuiDocumentoRecebedorPendente = possuiDocumentoRecebedorPendente;
	}

	public boolean isChamaPendenciasAberturaTela() {
		return chamaPendenciasAberturaTela;
	}

	public void setChamaPendenciasAberturaTela(boolean chamaPendenciasAberturaTela) {
		this.chamaPendenciasAberturaTela = chamaPendenciasAberturaTela;
	}

	public String getDescricaoPendencias() {
		return descricaoPendencias;
	}

	public void setDescricaoPendencias(String descricaoPendencias) {
		this.descricaoPendencias = descricaoPendencias;
	}

	public List<DocumentoDevolucaoVisaoItem> getListaDocumentoDevolucaoVisaoItem() {
		return listaDocumentoDevolucaoVisaoItem;
	}

	public void setListaDocumentoDevolucaoVisaoItem(List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem) {
		this.listaDocumentoDevolucaoVisaoItem = listaDocumentoDevolucaoVisaoItem;
	}

	public DocumentoDevolucao getDocumentoDevolucao() {
		return documentoDevolucao;
	}

	public void setDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		this.documentoDevolucao = documentoDevolucao;
	}

	public List<TipoTelefone> getListaTipoTelefone() {
		return listaTipoTelefone;
	}

	public void setListaTipoTelefone(List<TipoTelefone> listaTipoTelefone) {
		this.listaTipoTelefone = listaTipoTelefone;
	}

	public TelefoneRecebedor getTelefoneRecebedor() {
		return telefoneRecebedor;
	}

	public void setTelefoneRecebedor(TelefoneRecebedor telefoneRecebedor) {
		this.telefoneRecebedor = telefoneRecebedor;
	}

}
