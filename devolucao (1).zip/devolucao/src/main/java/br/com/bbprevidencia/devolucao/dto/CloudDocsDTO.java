package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

public class CloudDocsDTO implements Serializable {

	private static final long serialVersionUID = -1405743440515496481L;

	//	private final String urlRedirect = "http://www.google.com.br";

	private String urlRedirect = "http://ftp.clouddocs.com.br";

	public String getUrlRedirect() {
		return urlRedirect;
	}

	public void setUrlRedirect(String urlRedirect) {
		this.urlRedirect = urlRedirect;
	}

}
