package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.folha.dto.Consignatario;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 07/02/2017 Classe de objeto recebendo vários dados de devolução
 */
public class FiltroIntegracaoConsignatarioDTO implements Serializable, Comparable<FiltroIntegracaoConsignatarioDTO> {

	private static final long serialVersionUID = 1L;

	private Consignatario consignatario;
	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private PerfilInvestimento perfilInvestimento;
	private OperacaoInterna operacaoInterna;
	private double valorConsignatario;
	private Date dataMovimento;
	private Date dataCompetencia;
	private long codigoSequencialMovimentoLote;

	public FiltroIntegracaoConsignatarioDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FiltroIntegracaoConsignatarioDTO(Consignatario consignatario, EntidadeParticipante entidadeParticipante, PlanoPrevidencia planoPrevidencia, PerfilInvestimento perfilInvestimento,
			OperacaoInterna operacaoInterna) {
		super();
		this.consignatario = consignatario;
		this.entidadeParticipante = entidadeParticipante;
		this.planoPrevidencia = planoPrevidencia;
		this.perfilInvestimento = perfilInvestimento;
		this.operacaoInterna = operacaoInterna;
	}

	public Consignatario getConsignatario() {
		return consignatario;
	}

	public void setConsignatario(Consignatario consignatario) {
		this.consignatario = consignatario;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public PerfilInvestimento getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(PerfilInvestimento perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}

	public OperacaoInterna getOperacaoInterna() {
		return operacaoInterna;
	}

	public void setOperacaoInterna(OperacaoInterna operacaoInterna) {
		this.operacaoInterna = operacaoInterna;
	}

	public double getValorConsignatario() {
		return valorConsignatario;
	}

	public void setValorConsignatario(double valorConsignatario) {
		this.valorConsignatario = valorConsignatario;
	}

	public Date getDataMovimento() {
		return dataMovimento;
	}

	public void setDataMovimento(Date dataMovimento) {
		this.dataMovimento = dataMovimento;
	}

	public long getCodigoSequencialMovimentoLote() {
		return codigoSequencialMovimentoLote;
	}

	public void setCodigoSequencialMovimentoLote(long codigoSequencialMovimentoLote) {
		this.codigoSequencialMovimentoLote = codigoSequencialMovimentoLote;
	}

	public Date getDataCompetencia() {
		return dataCompetencia;
	}

	public void setDataCompetencia(Date dataCompetencia) {
		this.dataCompetencia = dataCompetencia;
	}

	@Override
	public int compareTo(FiltroIntegracaoConsignatarioDTO o) {
		if (o.getConsignatario().getCodigo().equals(this.consignatario.getCodigo())) {

			if (o.getEntidadeParticipante() != null && this.entidadeParticipante != null) {
				if (!o.getEntidadeParticipante().getChavePrimaria().equals(this.entidadeParticipante.getChavePrimaria())) {
					return 1;
				} else if (o.getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante().equals(this.entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante())) {
					return 0;
				} else {
					return -1;
				}
			}

			if (o.getPlanoPrevidencia() != null && this.planoPrevidencia != null) {
				if (!o.getPlanoPrevidencia().getCodigo().equals(this.planoPrevidencia.getCodigo())) {
					return 1;
				} else if (o.getPlanoPrevidencia().getCodigo().equals(this.planoPrevidencia.getCodigo())) {
					return 0;
				} else {
					return -1;
				}
			}

			if (o.getPerfilInvestimento() != null && this.perfilInvestimento != null) {
				if (!o.getPerfilInvestimento().getCodigo().equals(this.perfilInvestimento.getCodigo())) {
					return 1;
				} else if (o.getPerfilInvestimento().getCodigo().equals(this.perfilInvestimento.getCodigo())) {
					return 0;
				} else {
					return -1;
				}
			}

			if (o.getOperacaoInterna() != null && this.operacaoInterna != null) {
				if (!o.getOperacaoInterna().getCodigo().equals(this.operacaoInterna.getCodigo())) {
					return 1;
				} else if (o.getOperacaoInterna().getCodigo().equals(this.operacaoInterna.getCodigo())) {
					return 0;
				} else {
					return -1;
				}
			}

			return 0;
		} else {
			return -1;
		}
	}

}