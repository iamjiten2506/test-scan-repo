package br.com.bbprevidencia.devolucao.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CalcularProcessoDevolucaoResponse {
	private String fichaFinanceiraBase64;
	private String sumulaFinanceiraBase64;
	private Long protocoloCalculo;
}
