package br.com.bbprevidencia.devolucao.enumerador;

public enum SituacaoRegraDevolucaoEnum {

	INSERIDA(1L, "Inserida"),
	EM_HOMOLOGACAO(2L, "Em homoloção"),
	HOMOLOGADA(3L, "Homologada"),
	EM_PRODUCAO(4L, "Em produção"),
	INDEFERIDA(5L, "Indeferida"),
	REVOGADA(6L, "Revogada");

	private Long codigo;
	private String descricao;

	private SituacaoRegraDevolucaoEnum(Long codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return SituacaoRegraDevolucaoEnum
	 */
	public static SituacaoRegraDevolucaoEnum getSituacaoRegraDevolucaoEnum(Long codigo) {
		if (codigo != null) {
			for (SituacaoRegraDevolucaoEnum situacaoRegraDevolucao : values()) {
				if (situacaoRegraDevolucao.getCodigo().equals(codigo)) {
					return situacaoRegraDevolucao;
				}
			}
		}
		return null;
	}

}