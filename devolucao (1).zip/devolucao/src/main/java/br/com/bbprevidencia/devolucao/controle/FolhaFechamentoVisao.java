package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ibm.icu.math.BigDecimal;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.FechamentoFolhaBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   26/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("folhaFechamentoVisao")
public class FolhaFechamentoVisao {

	private static String FW_FOLHA_FECHAMENTO = "/paginas/folhaFechamento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private FechamentoFolhaBO fechamentoFolhaDevolucao;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private CronogramaDevolucao cronogramaDevolucao;

	private Integer progress;

	private boolean indicativoNaoPodeFechar;

	private String retornoProcessamento;

	public Integer getProgress() {
		if (progress == null) {
			progress = 0;
		} else {
			int calculoPercentual = 0;
			double registro = 0;
			double total = 0;

			if (FechamentoFolhaBO.REGISTROPROCESSAMENTO > 0) {

				registro = FechamentoFolhaBO.REGISTROPROCESSAMENTO;
				total = FechamentoFolhaBO.TOTALPROCESSAMENTO;

				calculoPercentual = new BigDecimal((registro / total) * 100).intValue();
			}

			progress = calculoPercentual;

			if (progress > 100) {
				this.limpaSelecao();
				progress = 100;
			} else if (progress == 100) {
				FacesContext.getCurrentInstance().addMessage(
						null,
						new FacesMessage(FacesMessage.SEVERITY_WARN, "Inserindo Informações no Banco de Dados - Aguarde", "Inserindo Informações no Banco de Dados - Aguarde"));
			}

		}

		return progress;
	}

	public void setProgress(Integer progress) {
		this.progress = progress;
	}

	public void onComplete() {

		if (this.retornoProcessamento.equalsIgnoreCase("Término Fechamento Folha")) {
			Mensagens.addMsgInfo("Processo de Fechamento Concluído.");
		}

		gerarRelatorioContabilFechamentoCronograma();

		//		gerarRelatorioEmprestimosFechamentoCronograma();
	}

	private void gerarRelatorioContabilFechamentoCronograma() {
		this.historicoPagamentoDevolucaoBO.gerarRelatorioContabilFechamentoCronograma(this.cronogramaDevolucao);
	}

	public void gerarRelatorioEmprestimosFechamentoCronograma() {
		/*
		CronogramaDevolucao cronogramaDevolucao = new CronogramaDevolucao();
		cronogramaDevolucao = this.cronogramaDevolucaoBO.pesquisarCronogramaDevolucaoPorCodigo(22L);*/
		this.historicoPagamentoDevolucaoBO.gerarRelatorioEmprestimosFechamentoCronograma(cronogramaDevolucao);
	}

	public void cancel() {
		progress = null;
	}

	public void fechar() {

		try {
			FechamentoFolhaBO.REGISTROPROCESSAMENTO = 0;
			FechamentoFolhaBO.TOTALPROCESSAMENTO = 0;

			this.retornoProcessamento = fechamentoFolhaDevolucao.salvarFechamentoFolhaDevolucao(cronogramaDevolucao, this.loginTemporariaDTO, UtilSession.isServidorWeblogic());
		} catch (Exception e) {
			this.cancel();
			PrimeFaces.current().executeScript("cancelPb()");
			Mensagens.addError("Erro ao fechar folha. Erro: " + e.getMessage());
		}
	}

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0333 - Daniel Martins
	 * @since   24/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("folhaFechamento");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.limpaSelecao();

		//Fazer cargas de listas de Combo.
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarCronogramaDevolucaoPermitemFechamento());

		this.verificarSelecao();

		return FW_FOLHA_FECHAMENTO;
	}

	//Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   26/01/2017
	 */
	public void limpaSelecao() {
		this.setCronogramaDevolucao(null);
		this.cancel();
		this.verificarSelecao();

	}

	public void verificarSelecao() {
		if (this.cronogramaDevolucao != null) {
			this.setIndicativoNaoPodeFechar(false);
		} else {
			this.setIndicativoNaoPodeFechar(true);
		}
	}

	public CronogramaDevolucaoBO getCronogramaDevolucaoBO() {
		return cronogramaDevolucaoBO;
	}

	public void setCronogramaDevolucaoBO(CronogramaDevolucaoBO cronogramaDevolucaoBO) {
		this.cronogramaDevolucaoBO = cronogramaDevolucaoBO;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public boolean isIndicativoNaoPodeFechar() {
		return indicativoNaoPodeFechar;
	}

	public void setIndicativoNaoPodeFechar(boolean indicativoNaoPodeFechar) {
		this.indicativoNaoPodeFechar = indicativoNaoPodeFechar;
	}

	public String getRetornoProcessamento() {
		return retornoProcessamento;
	}

	public void setRetornoProcessamento(String retornoProcessamento) {
		this.retornoProcessamento = retornoProcessamento;
	}

}
