package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.beneficio.dto.FichaDevolucao;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   29/12/2016
 * Classe de persistência para tabela PAR_CON_DEV_DET.
 */
@Entity
@Table(name = "PAR_CON_DEV_DET", schema = "OWN_DCR")
@NamedQuery(name = "ParcelaContaDevolucaoDetalhe.findAll", query = "SELECT q FROM ParcelaContaDevolucaoDetalhe q")
public class ParcelaContaDevolucaoDetalhe implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PAR_CON_DEV_DET_GER", sequenceName = "S_PCDD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PAR_CON_DEV_DET_GER")
	@Column(name = "NUM_SEQ_PAR_CON_DEV_DET")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PAR_CON_DEV")
	private ParcelaContaDevolucao parcelaContaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_FICHA_DEV")
	private FichaDevolucao fichaDevolucao;

	@Column(name = "QTD_COT_CON")
	private Double qtdCotaContribuicao;

	@Column(name = "QTD_COT_JUROS")
	private Double qtdCotaJuros;

	@Column(name = "QTD_COT_COR")
	private Double qtdCotaCorrecao;

	@Column(name = "QTD_COT_MULTA")
	private Double qtdCotaMulta;

	@Column(name = "NUM_FATOR_ULT_DEV")
	private Double fatorUltimaDevolucao;

	@Column(name = "DAT_BASE_INI_IDADE_IMP")
	private Date dataBaseInicioIdade;

	@Column(name = "IND_TIP_IMP_CON")
	private String indicadorTipoImpostoConsiderado;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public ParcelaContaDevolucao getParcelaContaDevolucao() {
		return parcelaContaDevolucao;
	}

	public void setParcelaContaDevolucao(ParcelaContaDevolucao parcelaContaDevolucao) {
		this.parcelaContaDevolucao = parcelaContaDevolucao;
	}

	public FichaDevolucao getFichaDevolucao() {
		return fichaDevolucao;
	}

	public void setFichaDevolucao(FichaDevolucao fichaDevolucao) {
		this.fichaDevolucao = fichaDevolucao;
	}

	public Double getQtdCotaContribuicao() {
		return qtdCotaContribuicao;
	}

	public void setQtdCotaContribuicao(Double qtdCotaContribuicao) {
		this.qtdCotaContribuicao = qtdCotaContribuicao;
	}

	public Double getQtdCotaJuros() {
		return qtdCotaJuros;
	}

	public void setQtdCotaJuros(Double qtdCotaJuros) {
		this.qtdCotaJuros = qtdCotaJuros;
	}

	public Double getQtdCotaCorrecao() {
		return qtdCotaCorrecao;
	}

	public void setQtdCotaCorrecao(Double qtdCotaCorrecao) {
		this.qtdCotaCorrecao = qtdCotaCorrecao;
	}

	public Double getQtdCotaMulta() {
		return qtdCotaMulta;
	}

	public void setQtdCotaMulta(Double qtdCotaMulta) {
		this.qtdCotaMulta = qtdCotaMulta;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Double getFatorUltimaDevolucao() {
		return fatorUltimaDevolucao;
	}

	public void setFatorUltimaDevolucao(Double fatorUltimaDevolucao) {
		this.fatorUltimaDevolucao = fatorUltimaDevolucao;
	}

	public Date getDataBaseInicioIdade() {
		return dataBaseInicioIdade;
	}

	public void setDataBaseInicioIdade(Date dataBaseInicioIdade) {
		this.dataBaseInicioIdade = dataBaseInicioIdade;
	}

	public String getIndicadorTipoImpostoConsiderado() {
		return indicadorTipoImpostoConsiderado;
	}

	public void setIndicadorTipoImpostoConsiderado(String indicadorTipoImpostoConsiderado) {
		this.indicadorTipoImpostoConsiderado = indicadorTipoImpostoConsiderado;
	}

}