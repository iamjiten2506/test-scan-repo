package br.com.bbprevidencia.devolucao.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.com.bbprevidencia.bbpcomum.interceptor.HeaderRequestInterceptor;
import br.com.bbprevidencia.cadastroweb.dto.RetornoLoginDTO;
import br.com.bbprevidencia.devolucao.dto.UsuarioLoginSmsDTO;
import br.com.bbprevidencia.devolucao.util.AmbienteUtil.Ambiente;

@Service("restUtil")
public class RestUtil {

	protected static Logger logger = LoggerFactory.getLogger(RestUtil.class.getName());

	public <T> T post(String nomeServico, String servico, Object postObject, Class<T> clazz, Object... uriVariables) {

		String token = getToken();

		if (token != null) {

			String url = "";

			System.setProperty("jsse.enableSNIExtension", "false");
			RestTemplate restTemplate = new RestTemplate();
			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
			interceptors.add(new HeaderRequestInterceptor("AuthToken", token));
			restTemplate.setInterceptors(interceptors);

			if (AmbienteUtil.getAmbiente() == Ambiente.PRODUCAO) {

				url = "http://localhost" + "/" + nomeServico + "/" + servico + "/";

			} else {

				url = "http://sistemashmg.bbp.com.br" + "/" + nomeServico + "/" + servico + "/";
			}

			logger.info("Envio POST, url: " + url);
			T retorno = restTemplate.postForObject(url, postObject, clazz, uriVariables);
			logger.info("Recebido resposta POST, url: " + url);
			return retorno;
		} else
			return null;
	}

	public <T> T get(String nomeServico, String servico, Class<T> clazz, Object... uriVariables) {

		String token = getToken();

		if (token != null) {

			String url = "";

			System.setProperty("jsse.enableSNIExtension", "false");
			RestTemplate restTemplate = new RestTemplate();
			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
			interceptors.add(new HeaderRequestInterceptor("AuthToken", token));
			restTemplate.setInterceptors(interceptors);
			// String url = env.getProperty("url.portal.service") + "/" + nomeServico + "/"
			// + servico;

			if (AmbienteUtil.getAmbiente() == Ambiente.PRODUCAO) {

				url = "http://localhost" + "/" + nomeServico + "/" + servico;

			} else {

				url = "http://sistemashmg.bbp.com.br" + "/" + nomeServico + "/" + servico;
			}

			for (Object paramVar : uriVariables)
				url += "/" + paramVar.toString();
			logger.info("Envio GET, url: " + url);
			T retorno = restTemplate.getForObject(url, clazz);
			logger.info("Recebido resposta GET, url: " + url);
			return retorno;
		} else
			return null;
	}

	private String getToken() {
		UsuarioLoginSmsDTO usuarioLoginSmsDTO = new UsuarioLoginSmsDTO("BBPENGRENAGEM", "12345678", null, null, null);

		String url = "";

		System.setProperty("jsse.enableSNIExtension", "false");
		RestTemplate restTemplate = new RestTemplate();
		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
		restTemplate.setInterceptors(interceptors);

		if (AmbienteUtil.getAmbiente() == Ambiente.PRODUCAO) {

			url = "http://172.30.8.26" + "/login-service/login/autenticarApi/";

		} else {

			url = "http://sistemashmg.bbp.com.br" + "/login-service/login/autenticarApi/";
		}

		logger.info("Request Token url: " + url);
		RetornoLoginDTO retorno = restTemplate.postForObject(url, usuarioLoginSmsDTO, RetornoLoginDTO.class);
		logger.info("Recebido resposta Token url: " + url);
		if (retorno.isUsuarioAutenticado())
			return retorno.getToken();
		else
			return null;
	}
}