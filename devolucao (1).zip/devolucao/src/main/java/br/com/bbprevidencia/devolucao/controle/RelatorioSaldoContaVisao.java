package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioSaldoContaDTO;
import br.com.bbprevidencia.devolucao.dto.TipoContaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório de Saldo por Conta.
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 15/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioSaldoContaVisao")
public class RelatorioSaldoContaVisao {

	private static final String FW_RELATORIO_SALDO_CONTA = "/paginas/relatorioSaldoConta.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioSaldoContaVisao.class);

	@Autowired
	ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private Date dataInicio;
	private Date dataFim;

	@Autowired
	private TipoContaDevolucaoBO tipoContaDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;

	private List<TipoContaDevolucao> listaTipoContaDevolucao;
	private List<TipoContaDevolucao> listaTipoContaDevolucaoSelecionadas;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;

	private PlanoPrevidencia planoPrevidencia;

	private boolean selecionarPlano;

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/03/2017
	 * @return
	 */
	public String inciciarRelatorioSaldoConta() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		this.listaEntidadeParticipante = entidadeParticipanteBO.listarEntidadeParticipante();
		this.listaTipoContaDevolucao = this.tipoContaDevolucaoBO.listarTodos();
		//this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidencia();

		return FW_RELATORIO_SALDO_CONTA;
	}

	public void setarValoresIniciais() {
		this.dataInicio = null;
		this.dataFim = null;
		this.selecionarPlano = false;
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.planoPrevidencia = null;
		this.listaEntidadeParticipanteSelecionadas = new ArrayList<EntidadeParticipante>();
		this.listaTipoContaDevolucaoSelecionadas = new ArrayList<TipoContaDevolucao>();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link EntidadeParticipante}
	 * @return
	 */
	public List<PlanoPrevidencia> listarPlanoPrevidencia(EntidadeParticipante entidadeParticipante) {

		try {
			List<PlanoPrevidencia> listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(entidadeParticipante);

			return listaPlanoPrevidencia;
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * Método encarregado de prencher informações necessárias na tela quando uma entidade participante é selecionada
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/03/2017
	 */
	public void verificaListaPatrocinadora() {
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipanteSelecionadas)) {
			this.selecionarPlano = false;
			this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
			this.planoPrevidencia = null;
			this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		} else {
			if (this.listaEntidadeParticipanteSelecionadas.size() == 1) {
				this.selecionarPlano = true;

				EntidadeParticipante entidadeParticipante = this.listaEntidadeParticipanteSelecionadas.get(0);
				this.listaPlanoPrevidencia = listarPlanoPrevidencia(entidadeParticipante);
			} else {
				this.selecionarPlano = false;
				this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
				this.planoPrevidencia = null;
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
			}
		}
	}

	/**
	 * Método encarregado de emitir o relatório
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/03/2017
	 */
	public void exportarRelatorio(ActionEvent event) {
		try {
			String idEnviado = event.getComponent().getId();
			List<RelatorioSaldoContaDTO> relatorioSaldoConta = new ArrayList<RelatorioSaldoContaDTO>();

			relatorioSaldoConta.addAll(contaDevolucaoBO.pesquisarInformacoesSaldoConta(
					this.getDataInicio(),
					this.getDataFim(),
					this.listaEntidadeParticipanteSelecionadas,
					this.listaPlanoPrevidenciaSelecionados,
					this.listaTipoContaDevolucaoSelecionadas));

			if (UtilJava.isColecaoVazia(relatorioSaldoConta)) {
				Mensagens.addMsgInfo("Não foram encontradas informações para estes parâmetros!");
			} else {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);
				parametros.put("dataInicio", UtilJava.formataDataPorPadrao(this.getDataInicio(), "dd/MM/yyyy"));
				parametros.put("dataFim", this.getDataFim() == null ? "Hoje" : UtilJava.formataDataPorPadrao(this.getDataFim(), "dd/MM/yyyy"));

				JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(relatorioSaldoConta);

				if (idEnviado.equalsIgnoreCase("btEmitirPDF")) {
					//GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "saldoPorConta", dataSource);
					String nomeArquivo = relatorioUtil.gerarRelatorio("saldoPorConta", relatorioSaldoConta, parametros);
					relatorioUtil.abrirPoupUp(nomeArquivo);
				} else {
					String nomeArquivo = relatorioUtil.gerarRelatorioXLS("saldoPorConta", relatorioSaldoConta, parametros);
					relatorioUtil.abrirPoupUp(nomeArquivo);
					//UtilXls.exportarXLS(parametros, "saldoPorConta", dataSource);
				}

			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro("Erro ao exportar relatório.");
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public List<TipoContaDevolucao> getListaTipoContaDevolucao() {
		return listaTipoContaDevolucao;
	}

	public void setListaTipoContaDevolucao(List<TipoContaDevolucao> listaTipoContaDevolucao) {
		this.listaTipoContaDevolucao = listaTipoContaDevolucao;
	}

	public List<TipoContaDevolucao> getListaTipoContaDevolucaoSelecionadas() {
		return listaTipoContaDevolucaoSelecionadas;
	}

	public void setListaTipoContaDevolucaoSelecionadas(List<TipoContaDevolucao> listaTipoContaDevolucaoSelecionadas) {
		this.listaTipoContaDevolucaoSelecionadas = listaTipoContaDevolucaoSelecionadas;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

}
