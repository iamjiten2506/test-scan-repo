package br.com.bbprevidencia.devolucao.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CorpoExtratoPrevDTO {

	private String prazoMaximoOpcao;

	private String motivoOcorrencia;

	private String nomePlanoGuardaChuva;

	private String nomeParticipante;

	private String matriculaParticipante;

	private String cpfParticipante;

	private String sexoParticipante;

	private Date dataNascParticipante;

	private Date dataAdmissao;

	private Date dataDesligamento;

	private Date dataBase;

	private String dataInscricao;

	private String indicaDataDesligamento;

	private String idadeParticipante;

	private String tempoEmpresa;

	private String tempoPlano;

	private Double salarioBase;

	private Double valorUltimaCota;

	private String nomeEspececieElegibilidade;

	private boolean elegivelParaBeneficio;
	
	private String obsExtratoAutoPatrocinio;
	
	private List<DadosAutoPatrocinioDTO> listaAutoPatrocinio = new ArrayList<>();
	
	private String infoInicioBpd;
	
	private List<DadosBpdDTO> listaBpd = new ArrayList<>();
	
	private String infoFinalBpd;
	
	private String possuiAP;
	
	private String possuiBpd;
	
	private String infoInicioResgate;
	
	private String infoFimResgate;
	
	private boolean possuiResgate;
	
	private List<DadosResgateDTO> listaResgate = new ArrayList<>();
	
	private Integer qtdMaxParcelasResgate;
	
	private List<DadosPortabilidadeAnteriorDTO> listaPortabilidadeAnterior = new ArrayList<>();
	
	private boolean possuiPortabilidade;
	
	private List<DadosPortabilidadeDTO> listaPortabilidade = new ArrayList<>();
	
	private String infoInicioPortabilidade;
	
	private String infoFimPortabilidade;
	
	private boolean direitoPortar;
	
	private String txtValorEmprestimo;
	
	private String observacoesGerais;

	public String getPrazoMaximoOpcao() {
		return prazoMaximoOpcao;
	}

	public void setPrazoMaximoOpcao(String prazoMaximoOpcao) {
		this.prazoMaximoOpcao = prazoMaximoOpcao;
	}

	public String getMotivoOcorrencia() {
		return motivoOcorrencia;
	}

	public void setMotivoOcorrencia(String motivoOcorrencia) {
		this.motivoOcorrencia = motivoOcorrencia;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getCpfParticipante() {
		return cpfParticipante;
	}

	public void setCpfParticipante(String cpfParticipante) {
		this.cpfParticipante = cpfParticipante;
	}

	public String getSexoParticipante() {
		return sexoParticipante;
	}

	public void setSexoParticipante(String sexoParticipante) {
		this.sexoParticipante = sexoParticipante;
	}

	public Date getDataNascParticipante() {
		return dataNascParticipante;
	}

	public void setDataNascParticipante(Date dataNascParticipante) {
		this.dataNascParticipante = dataNascParticipante;
	}

	public String getNomePlanoGuardaChuva() {
		return nomePlanoGuardaChuva;
	}

	public void setNomePlanoGuardaChuva(String nomePlanoGuardaChuva) {
		this.nomePlanoGuardaChuva = nomePlanoGuardaChuva;
	}

	public Date getDataAdmissao() {
		return dataAdmissao;
	}

	public void setDataAdmissao(Date dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public Date getDataBase() {
		return dataBase;
	}

	public void setDataBase(Date dataBase) {
		this.dataBase = dataBase;
	}

	public String getDataInscricao() {
		return dataInscricao;
	}

	public void setDataInscricao(String dataInscricao) {
		this.dataInscricao = dataInscricao;
	}

	public Date getDataDesligamento() {
		return dataDesligamento;
	}

	public void setDataDesligamento(Date dataDesligamento) {
		this.dataDesligamento = dataDesligamento;
	}

	public String getIndicaDataDesligamento() {
		return indicaDataDesligamento;
	}

	public void setIndicaDataDesligamento(String indicaDataDesligamento) {
		this.indicaDataDesligamento = indicaDataDesligamento;
	}

	public String getIdadeParticipante() {
		return idadeParticipante;
	}

	public void setIdadeParticipante(String idadeParticipante) {
		this.idadeParticipante = idadeParticipante;
	}

	public String getTempoEmpresa() {
		return tempoEmpresa;
	}

	public void setTempoEmpresa(String tempoEmpresa) {
		this.tempoEmpresa = tempoEmpresa;
	}

	public String getTempoPlano() {
		return tempoPlano;
	}

	public void setTempoPlano(String tempoPlano) {
		this.tempoPlano = tempoPlano;
	}

	public Double getSalarioBase() {
		return salarioBase;
	}

	public void setSalarioBase(Double salarioBase) {
		this.salarioBase = salarioBase;
	}

	public Double getValorUltimaCota() {
		return valorUltimaCota;
	}

	public void setValorUltimaCota(Double valorUltimaCota) {
		this.valorUltimaCota = valorUltimaCota;
	}

	public String getNomeEspececieElegibilidade() {
		return nomeEspececieElegibilidade;
	}

	public void setNomeEspececieElegibilidade(String nomeEspececieElegibilidade) {
		this.nomeEspececieElegibilidade = nomeEspececieElegibilidade;
	}

	public boolean isElegivelParaBeneficio() {
		return elegivelParaBeneficio;
	}

	public void setElegivelParaBeneficio(boolean elegivelParaBeneficio) {
		this.elegivelParaBeneficio = elegivelParaBeneficio;
	}

	public List<DadosAutoPatrocinioDTO> getListaAutoPatrocinio() {
		return listaAutoPatrocinio;
	}

	public void setListaAutopatrocinio(List<DadosAutoPatrocinioDTO> listaAutoPatrocinio) {
		this.listaAutoPatrocinio = listaAutoPatrocinio;
	}

	public String getObsExtratoAutoPatrocinio() {
		return obsExtratoAutoPatrocinio;
	}

	public void setObsExtratoAutoPatrocinio(String obsExtratoAutoPatrocinio) {
		this.obsExtratoAutoPatrocinio = obsExtratoAutoPatrocinio;
	}

	public String getInfoInicioBpd() {
		return infoInicioBpd;
	}

	public void setInfoInicioBpd(String infoInicioBpd) {
		this.infoInicioBpd = infoInicioBpd;
	}

	public List<DadosBpdDTO> getListaBpd() {
		return listaBpd;
	}

	public void setListaBpd(List<DadosBpdDTO> listaBpd) {
		this.listaBpd = listaBpd;
	}

	public String getInfoFinalBpd() {
		return infoFinalBpd;
	}

	public void setInfoFinalBpd(String infoFinalBpd) {
		this.infoFinalBpd = infoFinalBpd;
	}

	public void setListaAutoPatrocinio(List<DadosAutoPatrocinioDTO> listaAutoPatrocinio) {
		this.listaAutoPatrocinio = listaAutoPatrocinio;
	}

	public String getPossuiAP() {
		return possuiAP;
	}

	public void setPossuiAP(String possuiAP) {
		this.possuiAP = possuiAP;
	}

	public String getPossuiBpd() {
		return possuiBpd;
	}

	public void setPossuiBpd(String possuiBpd) {
		this.possuiBpd = possuiBpd;
	}

	public String getInfoInicioResgate() {
		return infoInicioResgate;
	}

	public void setInfoInicioResgate(String infoInicioResgate) {
		this.infoInicioResgate = infoInicioResgate;
	}

	public boolean isPossuiResgate() {
		return possuiResgate;
	}

	public void setPossuiResgate(boolean possuiResgate) {
		this.possuiResgate = possuiResgate;
	}

	public List<DadosResgateDTO> getListaResgate() {
		return listaResgate;
	}

	public void setListaResgate(List<DadosResgateDTO> listaResgate) {
		this.listaResgate = listaResgate;
	}

	public String getInfoFimResgate() {
		return infoFimResgate;
	}

	public void setInfoFimResgate(String infoFimResgate) {
		this.infoFimResgate = infoFimResgate;
	}

	public List<DadosPortabilidadeAnteriorDTO> getListaPortabilidadeAnterior() {
		return listaPortabilidadeAnterior;
	}

	public void setListaPortabilidadeAnterior(List<DadosPortabilidadeAnteriorDTO> listaPortabilidadeAnterior) {
		this.listaPortabilidadeAnterior = listaPortabilidadeAnterior;
	}

	public boolean isPossuiPortabilidade() {
		return possuiPortabilidade;
	}

	public void setPossuiPortabilidade(boolean possuiPortabilidade) {
		this.possuiPortabilidade = possuiPortabilidade;
	}

	public List<DadosPortabilidadeDTO> getListaPortabilidade() {
		return listaPortabilidade;
	}

	public void setListaPortabilidade(List<DadosPortabilidadeDTO> listaPortabilidade) {
		this.listaPortabilidade = listaPortabilidade;
	}

	public String getInfoInicioPortabilidade() {
		return infoInicioPortabilidade;
	}

	public void setInfoInicioPortabilidade(String infoInicioPortabilidade) {
		this.infoInicioPortabilidade = infoInicioPortabilidade;
	}

	public String getInfoFimPortabilidade() {
		return infoFimPortabilidade;
	}

	public void setInfoFimPortabilidade(String infoFimPortabilidade) {
		this.infoFimPortabilidade = infoFimPortabilidade;
	}

	public boolean isDireitoPortar() {
		return direitoPortar;
	}

	public void setDireitoPortar(boolean direitoPortar) {
		this.direitoPortar = direitoPortar;
	}

	public String getTxtValorEmprestimo() {
		return txtValorEmprestimo;
	}

	public void setTxtValorEmprestimo(String txtValorEmprestimo) {
		this.txtValorEmprestimo = txtValorEmprestimo;
	}

	public String getObservacoesGerais() {
		return observacoesGerais;
	}

	public void setObservacoesGerais(String observacoesGerais) {
		this.observacoesGerais = observacoesGerais;
	}

	public Integer getQtdMaxParcelasResgate() {
		return qtdMaxParcelasResgate;
	}

	public void setQtdMaxParcelasResgate(Integer qtdMaxParcelasResgate) {
		this.qtdMaxParcelasResgate = qtdMaxParcelasResgate;
	}
	
	
}
