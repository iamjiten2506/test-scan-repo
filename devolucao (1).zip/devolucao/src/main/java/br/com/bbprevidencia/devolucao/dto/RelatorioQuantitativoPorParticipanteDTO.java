package br.com.bbprevidencia.devolucao.dto;

public class RelatorioQuantitativoPorParticipanteDTO {

	private String nomeEmpresa;

	private String nomeParticipante;

	private String nomePlano;

	private String nomePlanoGuardaChuva;

	private String nomeTipoDevolucao;

	private String ano;

	private String mes;

	private Double valor;

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomePlanoGuardaChuva() {
		return nomePlanoGuardaChuva;
	}

	public void setNomePlanoGuardaChuva(String nomePlanoGuardaChuva) {
		this.nomePlanoGuardaChuva = nomePlanoGuardaChuva;
	}

	public String getNomeTipoDevolucao() {
		return nomeTipoDevolucao;
	}

	public void setNomeTipoDevolucao(String nomeTipoDevolucao) {
		this.nomeTipoDevolucao = nomeTipoDevolucao;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

}
