package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * Classe de persistência para tabela MOV_CAL_PGT_DEV.
 */
@Entity
@Table(name = "MOV_CAL_PGT_DEV", schema = "OWN_DCR")
@NamedQuery(name = "MovimentoCalculoPagamentoDevolucao.findAll", query = "SELECT q FROM MovimentoCalculoPagamentoDevolucao q")
public class MovimentoCalculoPagamentoDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MOV_CAL_PGT_DEV_GER", sequenceName = "S_MCPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MOV_CAL_PGT_DEV_GER")
	@Column(name = "NUM_SEQ_MOV_CAL_PGT_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CRO_DEV")
	private CronogramaDevolucao cronogramaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RECEBEDOR")
	@NotFound(action = NotFoundAction.IGNORE)
	private Recebedor recebedor;

	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "COD_PESSOA"), @JoinColumn(name = "COD_AREA_ATUA") })
	@NotFound(action = NotFoundAction.IGNORE)
	private AtuacaoPessoa atuacaoPessoa;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV")
	private RubricaDevolucao rubricaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PERFIL_INVEST")
	private PerfilInvestimento perfilInvestimento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_COT")
	private Date dataCota;

	@Column(name = "QTD_COT_RUB")
	private Double qtdCotaRubrica;

	@Column(name = "VAL_RUB")
	private double valorRubrica;

	@Column(name = "VAL_COT")
	private double valorCota;

	@Column(name = "VAL_IND_AJU")
	private double valorIndiceAjusta;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private int totalParcelas;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	public PerfilInvestimento getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(PerfilInvestimento perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Double getQtdCotaRubrica() {
		return qtdCotaRubrica;
	}

	public void setQtdCotaRubrica(Double qtdCotaRubrica) {
		this.qtdCotaRubrica = qtdCotaRubrica;
	}

	public double getValorRubrica() {
		return valorRubrica;
	}

	public void setValorRubrica(double valorRubrica) {
		this.valorRubrica = valorRubrica;
	}

	public double getValorCota() {
		return valorCota;
	}

	public void setValorCota(double valorCota) {
		this.valorCota = valorCota;
	}

	public double getValorIndiceAjusta() {
		return valorIndiceAjusta;
	}

	public void setValorIndiceAjusta(double valorIndiceAjusta) {
		this.valorIndiceAjusta = valorIndiceAjusta;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public String toString() {
		return "MovimentoCalculoPagamentoDevolucao [codigo=" + codigo + ", devolucao=" + devolucao + ", cronogramaDevolucao=" + cronogramaDevolucao + ", recebedor=" + recebedor + ", atuacaoPessoa="
				+ atuacaoPessoa + ", rubricaDevolucao=" + rubricaDevolucao + ", perfilInvestimento=" + perfilInvestimento + ", dataCota=" + dataCota + ", qtdCotaRubrica=" + qtdCotaRubrica
				+ ", valorRubrica=" + valorRubrica + ", valorCota=" + valorCota + ", valorIndiceAjusta=" + valorIndiceAjusta + ", dataAlteracao=" + dataAlteracao + ", dataInclusao=" + dataInclusao
				+ ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + "]";
	}

	public int getTotalParcelas() {
		return totalParcelas;
	}

	public void setTotalParcelas(int totalParcelas) {
		this.totalParcelas = totalParcelas;
	}

}
