package br.com.bbprevidencia.devolucao.controle;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.RelatorioComprovanteRendimentoBO;
import br.com.bbprevidencia.devolucao.dto.ComprovanteRendimentosJasperDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.devolucao.util.UtilJson;
import br.com.bbprevidencia.folha.bo.LoteProcessamentoDirfBO;
import br.com.bbprevidencia.folha.bo.RecebedorBO;
import br.com.bbprevidencia.folha.bo.TipoRetencaoDirfBO;
import br.com.bbprevidencia.folha.dto.LoteProcessamentoDirfDTO;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.folha.dto.RelatorioComprovanteRendimentosDTO;
import br.com.bbprevidencia.folha.dto.TipoRetencaoDIRF;

@Scope("session")
@Component("relatorioComprovanteRendimentoVisao")
public class RelatorioComprovanteRendimentoVisao {

	private static final String FW_RELATORIO_COMPROVANTE_RENDIMENTO = "/paginas/relatorioComprovanteRendimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static Logger log = Logger.getLogger(RelatorioComprovanteRendimentoVisao.class);

	private List<LoteProcessamentoDirfDTO> selectedLoteProcessamentoDirf;

	private Recebedor recebedor;

	private EntidadeParticipante entidadeParticipante;

	private TipoRetencaoDIRF tipoRetencaoDIRF;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<LoteProcessamentoDirfDTO> listaLoteProcessamento;

	private List<TipoRetencaoDIRF> listaTipoRetencaoDIRF;

	private List<Recebedor> listaRecebedor;

	@Autowired
	private LoteProcessamentoDirfBO loteProcessamentoDirfBO;

	@Autowired
	private RecebedorBO recebedorBO;

	@Autowired
	private TipoRetencaoDirfBO tipoRetencaoDirfBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private RelatorioComprovanteRendimentoBO relatorioComprovanteRendimentoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	public String iniciarTela() {
		limparFormularioPesquisa();
		this.listaEntidadeParticipante = listarEntidadeParticipante();
		this.listaLoteProcessamento = listarLoteProcessamento();
		this.listaTipoRetencaoDIRF = listarTipoRetencao();
		return FW_RELATORIO_COMPROVANTE_RENDIMENTO;
	}

	public void exportarRelatorio() {
		try {
			if (UtilJava.isColecaoVazia(this.selectedLoteProcessamentoDirf)) {
				throw new PrevidenciaException("Selecione um lote antes de Emitir os Comprovantes!");
			}

			String lote = this.selectedLoteProcessamentoDirf.stream()
					.map(e -> e.getCodigo().toString())
					.collect(Collectors.joining(","));
					
			String matricula = this.recebedor != null ? this.recebedor.getParticipante().getNumeroMatriculaPatrocinadora() : null;
			Long fundo = this.entidadeParticipante != null ? this.entidadeParticipante.getChavePrimaria().getCodigoFundoPrevidencia() : null;
			Long entidade = this.entidadeParticipante != null ? this.entidadeParticipante.getChavePrimaria().getCodigoEntidadeParticipante() : null;
			String cpf = this.recebedor != null ? this.recebedor.getCpf() : null;
			Long tipoRetencao = this.tipoRetencaoDIRF != null ? this.tipoRetencaoDIRF.getCodigo() : null;

			List<ComprovanteRendimentosJasperDTO> listaResultante = new ArrayList<ComprovanteRendimentosJasperDTO>(this.relatorioComprovanteRendimentoBO.retornaListaComprovanteRendimentos(
					matricula,
					fundo,
					entidade,
					cpf,
					tipoRetencao,
					lote));

			if (UtilJava.isColecaoDiferenteDeVazia(listaResultante)) {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/brasao-brasil-gray.png");
				parametros.put("logo", logo);
				
				parametros.put("anoCalendario", this.selectedLoteProcessamentoDirf.get(0).getAnoCalendario());
				parametros.put("anoExercicio", Long.parseLong(this.selectedLoteProcessamentoDirf.get(0).getAnoCalendario()) + 1);
				parametros.put("dataAtual", UtilJava.formataDataPorPadrao(new Date(), "dd/MM/yyyy"));
				
				List<String> listaCpf = listaResultante.parallelStream()
						.filter(UtilJson.distinctByKey(e -> e.getCpf()))
						.map(a -> a.getCpf())
						.collect(Collectors.toList());
				
				if (listaCpf.size() == 1) {
					File file = relatorioUtil.gerarRelatorioPdf("comprovanteRendimentos", listaResultante, parametros, listaCpf.get(0).replace(".", "").replace("-", "") + "_" + this.selectedLoteProcessamentoDirf.get(0).getAnoCalendario());
					this.baixarArquivos(FileUtils.readFileToByteArray(file), file.getName());
				} else {
					List<File> listaRelatorios = new ArrayList<File>();
					listaCpf.forEach(e -> {
						log.info(e);
						List<ComprovanteRendimentosJasperDTO> listaFiltada = listaResultante.parallelStream()
								.filter(a -> a.getCpf().equals(e))
								.collect(Collectors.toList());
						
						File file = relatorioUtil.gerarRelatorioPdf("comprovanteRendimentos", listaFiltada, parametros, e.replace(".", "").replace("-", "") + "_" + listaFiltada.get(0).getAnoCalendario());
						try {
							Files.write(Paths.get("c:/usr/" + file.getName()), FileUtils.readFileToByteArray(file));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						//listaRelatorios.add(file);
					});
					
//					compactarEBaixar(listaRelatorios);
				}
				
			} else {
				Mensagens.addMsgWarn("Não foram encontradas informações para os parâmetros especificados");
			}

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao gerar Comprovantes: " + e.getMessage());
		}

	}

	private void compactarEBaixar(List<File> arquivos) {
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ZipOutputStream zipfile = new ZipOutputStream(bos);
			ZipEntry zipentry = null;

			for (File file : arquivos) {
				zipentry = new ZipEntry(file.getName());
				zipfile.putNextEntry(zipentry);
				zipfile.write(FileUtils.readFileToByteArray(file));
			}

			zipfile.close();

			String nomeArquivo = "COMPROVANTES_" + UtilJava.formataDataPorPadrao(new Date(), "yyyyMMddHHmmss") + ".zip";

			baixarArquivos(bos.toByteArray(), nomeArquivo);

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Erro ao compactar e baixar os arquivos.");
		}

	}

	private void baixarArquivos(byte[] bytes, String name) {
		try {
			HttpServletResponse res = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			res.setContentType("application/txt;charset=UTF-8");
			res.setHeader("Content-disposition", "attachment;filename=" + name);
			res.getOutputStream().write(bytes);
			res.getCharacterEncoding();
			res.getOutputStream().flush();
			res.getOutputStream().close();
			FacesContext.getCurrentInstance().responseComplete();
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException(e.getMessage());
		}
	}

	public String limparPesquisa() {
		PrimeFaces.current().resetInputs("formCR");
		limparFormularioPesquisa();
		return FW_RELATORIO_COMPROVANTE_RENDIMENTO;
	}

	public List<EntidadeParticipante> listarEntidadeParticipante() {
		List<EntidadeParticipante> listaPatrocinadora = new ArrayList<EntidadeParticipante>();

		listaPatrocinadora = entidadeParticipanteBO.listarEntidadeParticipante();

		return listaPatrocinadora;
	}

	public List<LoteProcessamentoDirfDTO> listarLoteProcessamento() {
		List<LoteProcessamentoDirfDTO> listaLote = new ArrayList<LoteProcessamentoDirfDTO>();

		listaLote = loteProcessamentoDirfBO.listaLotesSimplificado();

		return listaLote;
	}

	public List<TipoRetencaoDIRF> listarTipoRetencao() {
		List<TipoRetencaoDIRF> listaTipoRetencao = new ArrayList<TipoRetencaoDIRF>();

		listaTipoRetencao = tipoRetencaoDirfBO.listarTipoRetencaoDirf();

		return listaTipoRetencao;
	}

	public void handleSelecionarRecebedor(SelectEvent event) {
		setRecebedor((Recebedor) event.getObject());
	}

	public List<Recebedor> listarRecebedorPorNome(String nome) {
		return this.recebedorBO.listarRecebedoresPorNome(nome);
	}

	public void limparFormularioPesquisa() {
		this.entidadeParticipante = null;
		this.recebedor = null;
		this.tipoRetencaoDIRF = null;
		this.selectedLoteProcessamentoDirf = null;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public TipoRetencaoDIRF getTipoRetencaoDIRF() {
		return tipoRetencaoDIRF;
	}

	public void setTipoRetencaoDIRF(TipoRetencaoDIRF tipoRetencaoDIRF) {
		this.tipoRetencaoDIRF = tipoRetencaoDIRF;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<LoteProcessamentoDirfDTO> getListaLoteProcessamento() {
		return listaLoteProcessamento;
	}

	public void setListaLoteProcessamento(List<LoteProcessamentoDirfDTO> listaLoteProcessamento) {
		this.listaLoteProcessamento = listaLoteProcessamento;
	}

	public List<TipoRetencaoDIRF> getListaTipoRetencaoDIRF() {
		return listaTipoRetencaoDIRF;
	}

	public void setListaTipoRetencaoDIRF(List<TipoRetencaoDIRF> listaTipoRetencaoDIRF) {
		this.listaTipoRetencaoDIRF = listaTipoRetencaoDIRF;
	}

	public List<Recebedor> getListaRecebedor() {
		return listaRecebedor;
	}

	public void setListaRecebedor(List<Recebedor> listaRecebedor) {
		this.listaRecebedor = listaRecebedor;
	}

	public List<LoteProcessamentoDirfDTO> getSelectedLoteProcessamentoDirf() {
		return selectedLoteProcessamentoDirf;
	}

	public void setSelectedLoteProcessamentoDirf(List<LoteProcessamentoDirfDTO> selectedLoteProcessamentoDirf) {
		this.selectedLoteProcessamentoDirf = selectedLoteProcessamentoDirf;
	}

}
