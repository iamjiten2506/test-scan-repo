package br.com.bbprevidencia.devolucao.dto;

public class RelatorioTermoRegimeTributacaoDTO {

	private String instituidor;

	private String cnpb;

	private String opcaoTributacao;

	/* Dados do participante*/
	private String nomeParticipante;

	private String dataNascimentoParticipante;

	private String cpfParticipante;

	private String emailParticipante;

	private String logradouroParticipante;

	private String numeroLogradouroParticipante;

	private String complementoParticipante;

	private String bairroParticipante;

	private String cidadeParticipante;

	private String cepParticipante;

	private String ufParticipante;

	private String telResidencial;

	private String telComercial;

	private String telCelular;

	private String telOutros;

	public String getInstituidor() {
		return instituidor;
	}

	public void setInstituidor(String instituidor) {
		this.instituidor = instituidor;
	}

	public String getCnpb() {
		return cnpb;
	}

	public void setCnpb(String cnpb) {
		this.cnpb = cnpb;
	}

	public String getOpcaoTributacao() {
		return opcaoTributacao;
	}

	public void setOpcaoTributacao(String opcaoTributacao) {
		this.opcaoTributacao = opcaoTributacao;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getDataNascimentoParticipante() {
		return dataNascimentoParticipante;
	}

	public void setDataNascimentoParticipante(String dataNascimentoParticipante) {
		this.dataNascimentoParticipante = dataNascimentoParticipante;
	}

	public String getCpfParticipante() {
		return cpfParticipante;
	}

	public void setCpfParticipante(String cpfParticipante) {
		this.cpfParticipante = cpfParticipante;
	}

	public String getEmailParticipante() {
		return emailParticipante;
	}

	public void setEmailParticipante(String emailParticipante) {
		this.emailParticipante = emailParticipante;
	}

	public String getLogradouroParticipante() {
		return logradouroParticipante;
	}

	public void setLogradouroParticipante(String logradouroParticipante) {
		this.logradouroParticipante = logradouroParticipante;
	}

	public String getNumeroLogradouroParticipante() {
		return numeroLogradouroParticipante;
	}

	public void setNumeroLogradouroParticipante(String numeroLogradouroParticipante) {
		this.numeroLogradouroParticipante = numeroLogradouroParticipante;
	}

	public String getComplementoParticipante() {
		return complementoParticipante;
	}

	public void setComplementoParticipante(String complementoParticipante) {
		this.complementoParticipante = complementoParticipante;
	}

	public String getBairroParticipante() {
		return bairroParticipante;
	}

	public void setBairroParticipante(String bairroParticipante) {
		this.bairroParticipante = bairroParticipante;
	}

	public String getCidadeParticipante() {
		return cidadeParticipante;
	}

	public void setCidadeParticipante(String cidadeParticipante) {
		this.cidadeParticipante = cidadeParticipante;
	}

	public String getCepParticipante() {
		return cepParticipante;
	}

	public void setCepParticipante(String cepParticipante) {
		this.cepParticipante = cepParticipante;
	}

	public String getUfParticipante() {
		return ufParticipante;
	}

	public void setUfParticipante(String ufParticipante) {
		this.ufParticipante = ufParticipante;
	}

	public String getTelResidencial() {
		return telResidencial;
	}

	public void setTelResidencial(String telResidencial) {
		this.telResidencial = telResidencial;
	}

	public String getTelComercial() {
		return telComercial;
	}

	public void setTelComercial(String telComercial) {
		this.telComercial = telComercial;
	}

	public String getTelCelular() {
		return telCelular;
	}

	public void setTelCelular(String telCelular) {
		this.telCelular = telCelular;
	}

	public String getTelOutros() {
		return telOutros;
	}

	public void setTelOutros(String telOutros) {
		this.telOutros = telOutros;
	}

}
