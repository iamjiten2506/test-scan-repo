package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.TipoContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.TipoContaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter os Tipos de contas devolucao
 * 
 * @author  BBPF0152 - Thiago de Castro Xavier
 * @since 03/02/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("tipoContaDevolucaoVisao")
public class TipoContaDevolucaoVisao {

	private static final String FW_REGRA_CALC_TEMPO_PLANO = "/paginas/tipoContaDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private TipoContaDevolucaoBO tipoContaDevolucaoBO;

	private List<TipoContaDevolucao> listaTipoContaDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página dos tipos de conta devolução
	 * @author  BBPF0152 - Thiago Castro
	 * @since 03/02/2017
	 * @return {@link String}
	 */
	public String inciciarTipoContaDevolucao() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		this.listarStatus = true;

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("tipoContaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.listarStatus = true;

		this.listaTipoContaDevolucao = null;

		this.listaTipoContaDevolucao = new ArrayList<TipoContaDevolucao>(tipoContaDevolucaoBO.listarTodos());

		return FW_REGRA_CALC_TEMPO_PLANO;
	}

	public TipoContaDevolucaoBO getTipoContaDevolucaoBO() {
		return tipoContaDevolucaoBO;
	}

	public void setTipoContaDevolucaoBO(TipoContaDevolucaoBO tipoContaDevolucaoBO) {
		this.tipoContaDevolucaoBO = tipoContaDevolucaoBO;
	}

	public List<TipoContaDevolucao> getListaTipoContaDevolucao() {
		return listaTipoContaDevolucao;
	}

	public void setListaTipoContaDevolucao(List<TipoContaDevolucao> listaTipoContaDevolucao) {
		this.listaTipoContaDevolucao = listaTipoContaDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

}
