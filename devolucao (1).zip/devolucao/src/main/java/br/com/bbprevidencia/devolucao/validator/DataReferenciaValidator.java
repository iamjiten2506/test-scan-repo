package br.com.bbprevidencia.devolucao.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import br.com.bbprevidencia.utils.data.UtilData;

/**
 * 
 * @author paulo.alessandre
 * @since 17/10/2012
 * 
 *        Copyright notice (c) 2012 BBPrevidência S/A
 */
@FacesValidator(value = "dataReferenciaValidator")
public class DataReferenciaValidator implements Validator {

	private static final String KEY_MENSAGEM_VALIDACAO_DATA = "Informe uma data de referência válida.";

	@Override
	public void validate(FacesContext arg0, UIComponent arg1, Object dataReferencia) throws ValidatorException {

		if ((dataReferencia != null && !dataReferencia.toString().isEmpty())) {

			if (!UtilData.isDataMesAnoValida(dataReferencia.toString())) {

				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "", KEY_MENSAGEM_VALIDACAO_DATA));
			}
		}
	}
}
