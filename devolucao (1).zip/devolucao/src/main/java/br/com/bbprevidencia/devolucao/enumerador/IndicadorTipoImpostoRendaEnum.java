package br.com.bbprevidencia.devolucao.enumerador;

/**
 * Enum com os indicadores de Tipo de Imposto de renda no plano
 *
 */
public enum IndicadorTipoImpostoRendaEnum {

	PROGRESSIVO("P", "PROGRESSIVO"),
	REGRESSIVO("R", "REGRESSIVO"),
	NAO_DEFINIDO("N", "NÃO DEFINIDO");

	private String codigo;
	private String descricao;

	IndicadorTipoImpostoRendaEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public static IndicadorTipoImpostoRendaEnum getIndicadorTipoImpostoRendaEnum(String codigo) {
		if (codigo != null) {
			for (IndicadorTipoImpostoRendaEnum indicadorTipoImpostoProgressivoEnum : values()) {
				if (indicadorTipoImpostoProgressivoEnum.getCodigo().equalsIgnoreCase(codigo)) {
					return indicadorTipoImpostoProgressivoEnum;
				}
			}
		}
		return null;
	}

}
