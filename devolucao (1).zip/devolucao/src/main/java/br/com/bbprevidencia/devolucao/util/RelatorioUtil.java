package br.com.bbprevidencia.devolucao.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.jfree.util.Log;
import org.primefaces.PrimeFaces;
import org.primefaces.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.Constantes;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.Exporter;
import net.sf.jasperreports.export.SimpleDocxExporterConfiguration;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;
import net.sf.jasperreports.export.type.PdfVersionEnum;

/**
 * Classe para manipular a extração de relatórios PDF e XLS
 * @author  BBPF0415 - Yanisley Mora Ritchie
 *
 */
@Component(value = "relatorioUtil")
public class RelatorioUtil {

	private static Logger log = Logger.getLogger(RelatorioUtil.class);

	@Autowired
	private ServletContext context;

	public enum FORMATO_RELATORIO {
		XLSX,
		PDF,
		DOCX;
	}

	/**
	 * Gera ID único para o relatório
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @return
	 */
	private static String gerarIdReport() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyyyhhmmss");
		String id = simpleDateFormat.format(new Date());

		return id;
	}

	/**
	 * Elimina as páginas em branco da lista de páginas de um JasperPrint
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param paginas
	 */
	private void removePaginaEmBranco(List<JRPrintPage> paginas) {
		for (Iterator<JRPrintPage> p = paginas.iterator(); p.hasNext();) {
			JRPrintPage pagina = p.next();
			if (pagina.getElements().size() == 0)
				p.remove();
		}
	}

	/**
	 * Retorna caminho onde os relatórios (.jasper e .jrxml e tmps) ficam
	 * armazenados
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * */
	private String reportSourcePath() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance().getExternalContext().getRealPath("/relatorios/") + "/";
		} else {
			return context.getRealPath("/relatorios/") + "/";
		}
	}

	/**
	 * Retorna o caminho onde os relatórios finais ficam no servidor (ex: .PDF)
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * */
	public String reportFile() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance().getExternalContext().getRealPath("/relatorios/") + "/";
		} else {
			return context.getRealPath("/relatorios/") + "/";
		}
	}

	/**
	 * Abrir Janela com Arquivo (PDF, XLS, TXT e etc)
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * */
	public void abrirPoupUp(String fileName) {
		abrirPoupUp(fileName, null);
	}

	/**
	 * Abrir Janela com Arquivo (PDF, XLS, TXT e etc)
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * */
	public void abrirPoupUp(String fileName, String nomeJanela) {
		HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String contextPath = req.getContextPath().replace("/", "");

		if (fileName.endsWith(".pdf")) {
			if (nomeJanela == null) {
				nomeJanela = "Relatório";
			}

			PrimeFaces.current().executeScript(
					"window.open('/" + contextPath + "/relatorios/" + fileName + "','" + nomeJanela
							+ "','width=screen.availWidth, height=screen.availHeight, dependent=yes, menubar=no, toolbar=no, resizable=yes')");
		} else {
			try {
				File arquivo = new File(reportSourcePath() + fileName);

				FacesContext facesContext = FacesContext.getCurrentInstance();
				HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();

				//response.setContentType("application/download");

				if (fileName.endsWith(".xlsx")) {
					response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
				} else {
					response.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
				}

				response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
				response.setContentLength((int) arquivo.length());

				byte[] buffer = new byte[(int) arquivo.length()];

				int length;
				InputStream inputStream = new FileInputStream(arquivo);
				OutputStream outputStream = response.getOutputStream();

				while ((length = inputStream.read(buffer)) >= 0) {
					outputStream.write(buffer, 0, length);
				}

				//response.setStatus(200);
				//response.getOutputStream().flush();
				inputStream.close();
				outputStream.flush();
				outputStream.close();
				facesContext.responseComplete();

			} catch (FileNotFoundException e) {
				log.error(e);
				throw new PrevidenciaException(e);
			} catch (IOException ie) {
				log.error(ie);
				throw new PrevidenciaException(ie);
			} catch (Exception e) {
				log.error(e);
				throw new PrevidenciaException(e);
			}
		}

	}

	@SuppressWarnings( { "unchecked", "rawtypes" })
	public File gerarRelatorioPdf(String relatorio, List beans, Map<String, Object> params, String nomeRelatorio) {
		try {
			if (params == null) {
				params = new HashMap<String, Object>();
			}

			JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(beans);

			String relatorioFormated = relatorio.endsWith(".jasper") ? relatorio : (new StringBuilder()).append(relatorio).append(".jasper").toString();
			JasperPrint jasperPrint = null;

			if (beans != null && beans.size() > 0) {
				jasperPrint = JasperFillManager.fillReport(reportSourcePath() + relatorioFormated, params, beanCollectionDataSource);
			} else {
				jasperPrint = JasperFillManager.fillReport(reportSourcePath() + relatorioFormated, params, new JREmptyDataSource());
			}

			Exporter exporter = null;

			//Elimina as páginas em branco.
			removePaginaEmBranco(jasperPrint.getPages());

			List<JasperPrint> jasperPrintList = new ArrayList<JasperPrint>();
			jasperPrintList.add(jasperPrint);

			exporter = new JRPdfExporter();
			SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
			configuration.setCreatingBatchModeBookmarks(true);
			configuration.setPdfVersion(PdfVersionEnum.VERSION_1_7);
			exporter.setConfiguration(configuration);

			//File fTarget = new File("C:/Temp/saida/" + nomeRelatorio + ".pdf");

			File fTarget = new File(nomeRelatorio + ".pdf");

			exporter.setExporterInput(SimpleExporterInput.getInstance(jasperPrintList));
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(fTarget.getAbsolutePath()));

			exporter.exportReport();

			return fTarget;

		} catch (JRException e) {
			log.error(e);
			return null;
		} catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	/**
	 * Gera o relatório e retorna o nome do relatório gerado
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @throws IOException 
	 * */
	@SuppressWarnings( { "unchecked", "rawtypes" })
	private String gerarRelatorio(String relatorio, List beans, Map<String, Object> params, FORMATO_RELATORIO formatoExportacao) {
		try {
			if (params == null) {
				params = new HashMap<String, Object>();
			}

			JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(beans);

			String relatorioFormated = relatorio.endsWith(".jasper") ? relatorio : (new StringBuilder()).append(relatorio).append(".jasper").toString();
			JasperPrint jasperPrint = null;

			if (beans != null && beans.size() > 0) {
				jasperPrint = JasperFillManager.fillReport(reportSourcePath() + relatorioFormated, params, beanCollectionDataSource);
			} else {
				jasperPrint = JasperFillManager.fillReport(reportSourcePath() + relatorioFormated, params, new JREmptyDataSource());
			}

			StringBuilder nomeRelatorio = new StringBuilder();
			nomeRelatorio.append(reportFile() + relatorio + "_" + gerarIdReport());

			Exporter exporter = null;

			//Elimina as páginas em branco.
			removePaginaEmBranco(jasperPrint.getPages());

			List<JasperPrint> jasperPrintList = new ArrayList<JasperPrint>();
			jasperPrintList.add(jasperPrint);

			if (formatoExportacao.equals(FORMATO_RELATORIO.PDF)) {
				exporter = new JRPdfExporter();
				SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
				configuration.setCreatingBatchModeBookmarks(true);
				configuration.setPdfVersion(PdfVersionEnum.VERSION_1_7);
				exporter.setConfiguration(configuration);
				nomeRelatorio.append(".pdf");
			} else if (formatoExportacao.equals(FORMATO_RELATORIO.XLSX)) {
				exporter = new JRXlsxExporter();
				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				/*configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);//Set configuration as you like it!!
				configuration.setCollapseRowSpan(false);*/

				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);
				configuration.setIgnoreCellBackground(false);
				configuration.setWrapText(true);
				configuration.setRemoveEmptySpaceBetweenRows(true);
				configuration.setCollapseRowSpan(true);

				exporter.setConfiguration(configuration);
				nomeRelatorio.append(".xlsx");
			} else if (formatoExportacao.equals(FORMATO_RELATORIO.DOCX)) {
				exporter = new JRDocxExporter();
				SimpleDocxExporterConfiguration configuration = new SimpleDocxExporterConfiguration();
				exporter.setConfiguration(configuration);
				nomeRelatorio.append(".docx");
			}

			File fTarget = new File(nomeRelatorio.toString());

			exporter.setExporterInput(SimpleExporterInput.getInstance(jasperPrintList));
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(fTarget.getAbsolutePath()));

			exporter.exportReport();

			return fTarget.getName();

		} catch (JRException e) {
			log.error(e);
			return null;
		}
	}

	private String gerarSumula(String relatorio, List beans, Map<String, Object> params, FORMATO_RELATORIO formatoExportacao) {

		try {
			if (params == null) {
				params = new HashMap<String, Object>();
			}

			JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(beans);

			String relatorioFormated = relatorio.endsWith(".jasper") ? relatorio : (new StringBuilder()).append(relatorio).append(".jasper").toString();
			JasperPrint jasperPrint = null;
			System.out.println("relatorioFormated: " + relatorioFormated);

			if (beans != null && beans.size() > 0) {
				jasperPrint = JasperFillManager.fillReport(reportSourcePath() + relatorioFormated, params, beanCollectionDataSource);
			} else {
				jasperPrint = JasperFillManager.fillReport(reportSourcePath() + relatorioFormated, params, new JREmptyDataSource());
			}

			StringBuilder nomeRelatorio = new StringBuilder();
			nomeRelatorio.append(reportFile() + relatorio + "_" + gerarIdReport());

			Exporter exporter = null;

			//Elimina as páginas em branco.
			removePaginaEmBranco(jasperPrint.getPages());

			List<JasperPrint> jasperPrintList = new ArrayList<JasperPrint>();
			jasperPrintList.add(jasperPrint);

			if (formatoExportacao.equals(FORMATO_RELATORIO.PDF)) {
				exporter = new JRPdfExporter();
				SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
				configuration.setCreatingBatchModeBookmarks(true);
				configuration.setPdfVersion(PdfVersionEnum.VERSION_1_7);
				exporter.setConfiguration(configuration);
				nomeRelatorio.append(".pdf");
			} else if (formatoExportacao.equals(FORMATO_RELATORIO.XLSX)) {
				exporter = new JRXlsxExporter();
				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				/*configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);//Set configuration as you like it!!
				configuration.setCollapseRowSpan(false);*/

				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);
				configuration.setIgnoreCellBackground(false);
				configuration.setWrapText(true);
				configuration.setRemoveEmptySpaceBetweenRows(true);
				configuration.setCollapseRowSpan(true);

				exporter.setConfiguration(configuration);
				nomeRelatorio.append(".xlsx");
			} else if (formatoExportacao.equals(FORMATO_RELATORIO.DOCX)) {
				exporter = new JRDocxExporter();
				SimpleDocxExporterConfiguration configuration = new SimpleDocxExporterConfiguration();
				exporter.setConfiguration(configuration);
				nomeRelatorio.append(".docx");
			}

			File fTarget = new File(nomeRelatorio.toString());

			exporter.setExporterInput(SimpleExporterInput.getInstance(jasperPrintList));
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(fTarget.getAbsolutePath()));

			exporter.exportReport();

			return fTarget.getAbsolutePath();

		} catch (JRException e) {
			log.error(e);
			return null;
		}
	}

	/**
	 * Chamada para a geração de relatórios XLS
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 */
	public String gerarRelatorioXLS(String relatorio, List beans, Map<String, Object> params) {
		return gerarRelatorio(relatorio, beans, params, FORMATO_RELATORIO.XLSX);
	}

	/**
	 * Chamada para a geração de relatórios padrão  (.PDF) 
	 * */
	public String gerarRelatorio(String relatorio, List beans, Map<String, Object> params) {
		return gerarRelatorio(relatorio, beans, params, FORMATO_RELATORIO.PDF);
	}

	public String gerarSumula(String relatorio, List beans, Map<String, Object> params) {
		return gerarSumula(relatorio, beans, params, FORMATO_RELATORIO.PDF);
	}

	public String gerarRelatorioDocx(String relatorio, List beans, Map<String, Object> params) {
		return gerarRelatorio(relatorio, beans, params, FORMATO_RELATORIO.DOCX);
	}

	public String gerarRelatorioXls(String relatorio, List beans, Map<String, Object> params) {
		return gerarRelatorio(relatorio, beans, params, FORMATO_RELATORIO.XLSX);
	}

	public static void baixarArquivo(String url, String nomeRelatorio, String tipoArquivo) throws Exception {
		try {
			if (tipoArquivo.equals("pdf")) {
				tipoArquivo = Constantes.APPLICATION_PDF;
			}

			InputStream inputStream = new URL(url).openStream();

			FacesContext facesContext = FacesContext.getCurrentInstance();
			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();

			String contentDispositionValue = "attachment";
			response.setContentType(tipoArquivo);
			response.setHeader(Constantes.CONTENT_DISPOSITION, contentDispositionValue + ";filename=\"" + nomeRelatorio + "\"");
			response.addCookie(new Cookie(Constants.DOWNLOAD_COOKIE, "true"));

			byte[] buffer = new byte[2048];
			int length;
			OutputStream outputStream = response.getOutputStream();

			while ((length = (inputStream.read(buffer))) != -1) {
				outputStream.write(buffer, 0, length);
			}

			response.setStatus(200);
			response.getOutputStream().flush();
			inputStream.close();
			facesContext.responseComplete();

		} catch (IOException e) {
			Log.error(e);
			throw new Exception(e);
		}
	}
}