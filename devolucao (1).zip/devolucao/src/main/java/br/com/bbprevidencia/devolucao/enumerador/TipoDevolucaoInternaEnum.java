package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoDevolucaoInternaEnum {

	BASE(0, "Inserção Base"),
	RESGATE(1, "Resgate Saída de Valor"),
	PORT_EXTERNA(2, "Portabilidade Externa"),
	PORT_INTERNA_PLANOS(4, "Portabilidade Interna entre Planos"),
	PORT_INTERNA_MATRICULA(5, "Portabilidade Interna entre Matrículas");

	private int codigo;
	private String descricao;

	private TipoDevolucaoInternaEnum(int codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return TipoIntegracaoEnum
	 */
	public static TipoDevolucaoInternaEnum getTipoDevolucaoInternaEnum(int codigo) {
		for (TipoDevolucaoInternaEnum tipoIntegracaoEnum : values()) {
			if (tipoIntegracaoEnum.getCodigo() == codigo) {
				return tipoIntegracaoEnum;
			}
		}

		return null;
	}

}