package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoLoteProcessamentoEnum {

	INTEGRACAO("I", "Integração Folha Devolução"),
	PROCESSAMENTO("P", "Processamento Folha");

	private String codigo;
	private String descricao;

	private TipoLoteProcessamentoEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return TipoLoteProcessamentoEnum
	 */
	public static TipoLoteProcessamentoEnum getTipoLoteProcessamentoEnum(String codigo) {
		if (codigo != null) {
			for (TipoLoteProcessamentoEnum tipoLoteProcessamentoEnum : values()) {
				if (tipoLoteProcessamentoEnum.getCodigo().equals(codigo)) {
					return tipoLoteProcessamentoEnum;
				}
			}
		}
		return null;
	}

}