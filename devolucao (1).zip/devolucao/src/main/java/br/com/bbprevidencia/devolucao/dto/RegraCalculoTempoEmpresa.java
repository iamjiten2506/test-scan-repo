package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   28/11/2016
 * Classe de persistência para tabela REGRA_CALCULO_TEMPO_EMPRESA.
 */
@Entity
@Table(name = "REGRA_CALCULO_TEMPO_EMPRESA", schema = "OWN_DCR")
@NamedQuery(name = "RegraCalculoTempoEmpresa.findAll", query = "SELECT q FROM RegraCalculoTempoEmpresa q")
public class RegraCalculoTempoEmpresa implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REGRA_CALCULO_TEMPO_EMPRESA_GER", sequenceName = "S_RCRE_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REGRA_CALCULO_TEMPO_EMPRESA_GER")
	@Column(name = "NUM_SEQ_REG_CAL_TEM_EMP")
	private Long codigo;

	@Column(name = "NOM_REG_CAL_TEM_EMP")
	private String nome;

	@Column(name = "DSC_REG_CAL_TEM_EMP")
	private String descricao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegraCalculoTempoEmpresa other = (RegraCalculoTempoEmpresa) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RegraCalculoTempoEmpresa [codigo=" + codigo + ", nome=" + nome + ", descricao=" + descricao + ", dataAlteracao=" + dataAlteracao + ", dataInclusao=" + dataInclusao
				+ ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + "]";
	}

}