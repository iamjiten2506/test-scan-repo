package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ibm.icu.math.BigDecimal;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO.PARAMETROS;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.SistemaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.ParametroGeral;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.Sistema;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.folha.bo.InformacaoProcessamentoDirfBO;
import br.com.bbprevidencia.folha.bo.LoteProcessamentoDirfBO;
import br.com.bbprevidencia.folha.dto.LoteProcessamentoDirf;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * parar gerar informações DIRF
 * 
 * @author  BBPF0351 - Marco Figueiredo
 * @since 15/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("processamentoDirfDevolucaoVisao")
public class ProcessamentoDirfDevolucaoVisao {

	private static String FW_PROCESSAR_DIRF = "/paginas/processamentoDirf.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	@Autowired
	private LoteProcessamentoDirfBO loteProcessamentoDirfBO;

	@Autowired
	private ParametroGeralBO parametroGeralBO;

	@Autowired
	private SistemaBO sistemaBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private Integer progress;

	private String retornoProcessamento;

	private List<EntidadeParticipante> listaEntidadeParticipante = new ArrayList<EntidadeParticipante>();
	private List<PlanoPrevidencia> listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();

	private LoteProcessamentoDirf loteProcessamentoDirf;

	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;

	private String numeroMatriculaPatrocinadora;

	private boolean indicativoNaoPodeGerar;

	private String anoCalendario;

	private String tipoGeracao;

	/**
	 * Método encarregado por iniciar a página dos cronogramas de devolução
	 * @author  BBPF0351 - Marco Figueiredo
	 * @since 15/01/2018
	 * @return {@link String}
	 */
	public String iniciarTela() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processamentoDIRFDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		preencheListaCombosEValores();

		return FW_PROCESSAR_DIRF;
	}

	private void preencheListaCombosEValores() {
		try {
			this.listaEntidadeParticipante.addAll(this.entidadeParticipanteBO.listarEntidadeParticipanteOrderByNome());

			this.listaPlanoPrevidencia.addAll(this.planoPrevidenciaBO.listarPlanoPrevidencia());

			this.tipoGeracao = "A";
		} catch (Exception e) {
			throw new PrevidenciaException("Erro ao carregar combos de filtros. Erro: ", e.getMessage());
		}

	}

	/**
	 * Calcula o progresso da Barra
	 * @return
	 */
	public Integer getProgress() {
		if (progress == null) {
			progress = 0;
		} else {
			int calculoPercentual = 0;
			double registro = 0;
			double total = 0;

			if (InformacaoProcessamentoDirfBO.REGISTROPROCESSAMENTO != null && InformacaoProcessamentoDirfBO.REGISTROPROCESSAMENTO > 0) {

				registro = InformacaoProcessamentoDirfBO.REGISTROPROCESSAMENTO;
				total = InformacaoProcessamentoDirfBO.TOTALPROCESSAMENTO;

				calculoPercentual = new BigDecimal((registro / total) * 100).intValue();
			}

			progress = calculoPercentual;

			if (progress > 100) {
				this.limpaSelecao();
				progress = 100;
			}

		}

		return progress;
	}

	public void setProgress(Integer progress) {
		this.progress = progress;
	}

	/**
	 * Emite mensagem de final de processamento
	 */
	public void onComplete() {
		if (this.retornoProcessamento.equalsIgnoreCase("Término Processamento")) {
			InformacaoProcessamentoDirfBO.REGISTROPROCESSAMENTO = 0;
			InformacaoProcessamentoDirfBO.TOTALPROCESSAMENTO = 0;
			Mensagens.addMsgInfo("Processamento Completo.");
		}
	}

	private void limpaSelecao() {
		InformacaoProcessamentoDirfBO.REGISTROPROCESSAMENTO = 0;
		InformacaoProcessamentoDirfBO.TOTALPROCESSAMENTO = 0;
		this.setEntidadeParticipante(null);
		this.setPlanoPrevidencia(null);
		this.numeroMatriculaPatrocinadora = null;
		this.anoCalendario = "";

		this.setListaEntidadeParticipante(new ArrayList<EntidadeParticipante>());
		this.setListaPlanoPrevidencia(new ArrayList<PlanoPrevidencia>());

		preencheListaCombosEValores();
	}

	public void filtrarListaPlanos() {
		try {
			this.listaPlanoPrevidencia.clear();
			this.listaPlanoPrevidencia.addAll(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante));
		} catch (Exception e) {
			Mensagens.addMsgErro("Erro ao filtrar planos: " + e.getMessage());
		}
	}

	public String processar() {
		Long codigoSistema = 0L;

		try {
			codigoSistema = validaSistema(this.parametroGeralBO.consultarParametro(PARAMETROS.CODIGO_SISTEMA_DEVOLUCAO));

			Sistema sistema = this.sistemaBO.consultarSistemaPorCodigo(codigoSistema);
			String observacao = "DIRF Devolucao gerado por: " + this.loginTemporariaDTO.getIdentificacaoUsuario();

			//Pesquisar os CPFs para geração de informações para DIRF - Devoluções Efetuadas no ano escolhido
			List<String> listaCPF = this.historicoPagamentoDevolucaoBO.pesquisarCPFRecebedorPagamento(
					this.tipoGeracao,
					this.anoCalendario,
					this.entidadeParticipante,
					this.planoPrevidencia,
					this.numeroMatriculaPatrocinadora);

			if (!UtilJava.isColecaoVazia(listaCPF)) {
				if (this.loteProcessamentoDirf == null) {
					// Gerar todas as informações
					this.loteProcessamentoDirf = this.loteProcessamentoDirfBO.gerarDadosProcessamentoDirf(listaCPF, null, sistema, anoCalendario, loginTemporariaDTO, observacao);
				}

				this.loteProcessamentoDirfBO.salvarLoteProcessamentoDirf(loteProcessamentoDirf);
				this.retornoProcessamento = "Término Processamento";

			} else {
				Mensagens.addMsgErro("Não encontrada informações para DIRF neste período");
				return FW_PROCESSAR_DIRF;
			}

		} catch (PrevidenciaException pr) {
			Mensagens.addMsgErro(pr.getMessage());
		} catch (Exception e) {
			Mensagens.addMsgErro("Erro ao processar. Erro: " + e.getMessage());
		}

		return FW_PROCESSAR_DIRF;
	}

	public String limpar() {
		limpaSelecao();

		return FW_PROCESSAR_DIRF;
	}

	private Long validaSistema(ParametroGeral consultarParametro) {
		Long codigoSistema = 0L;

		if (consultarParametro != null) {
			try {
				codigoSistema = Long.parseLong(consultarParametro.getDescricaoPatrametro());
			} catch (NumberFormatException e) {
				new PrevidenciaException("Parametro CODIGO_SISTEMA_DEVOLUCAO com valor não numérico! Assumindo valor padrão igual a " + codigoSistema);
			}
		} else {
			new PrevidenciaException("Parametro CODIGO_SISTEMA_DEVOLUCAO não cadastrado! Assumindo valor padrão igual a " + codigoSistema);
		}

		return codigoSistema;
	}

	public void cancel() {
		progress = null;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public String getRetornoProcessamento() {
		return retornoProcessamento;
	}

	public void setRetornoProcessamento(String retornoProcessamento) {
		this.retornoProcessamento = retornoProcessamento;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public String getNumeroMatriculaPatrocinadora() {
		return numeroMatriculaPatrocinadora;
	}

	public void setNumeroMatriculaPatrocinadora(String numeroMatriculaPatrocinadora) {
		this.numeroMatriculaPatrocinadora = numeroMatriculaPatrocinadora;
	}

	public boolean isIndicativoNaoPodeGerar() {
		return indicativoNaoPodeGerar;
	}

	public void setIndicativoNaoPodeGerar(boolean indicativoNaoPodeGerar) {
		this.indicativoNaoPodeGerar = indicativoNaoPodeGerar;
	}

	public String getAnoCalendario() {
		return anoCalendario;
	}

	public void setAnoCalendario(String anoCalendario) {
		this.anoCalendario = anoCalendario;
	}

	public String getTipoGeracao() {
		return tipoGeracao;
	}

	public void setTipoGeracao(String tipoGeracao) {
		this.tipoGeracao = tipoGeracao;
	}

	public LoteProcessamentoDirf getLoteProcessamentoDirf() {
		return loteProcessamentoDirf;
	}

	public void setLoteProcessamentoDirf(LoteProcessamentoDirf loteProcessamentoDirf) {
		this.loteProcessamentoDirf = loteProcessamentoDirf;
	}

}
