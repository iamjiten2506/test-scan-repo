package br.com.bbprevidencia.devolucao.dto;

import java.util.ArrayList;
import java.util.List;

public class RelatorioCreditoBancarioDTO {

	private String dataPagamento;

	private Double totalFolha;

	private List<RelatorioCreditoBancarioAnaliticoDTO> listaRelatorioCreditoBancarioAnalitico;

	private List<RelatorioCreditoBancarioSinteticoDTO> listaRelatorioCreditoBancarioSintetico;

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Double getTotalFolha() {
		return totalFolha;
	}

	public void setTotalFolha(Double totalFolha) {
		this.totalFolha = totalFolha;
	}

	public List<RelatorioCreditoBancarioAnaliticoDTO> getListaRelatorioCreditoBancarioAnalitico() {
		if (listaRelatorioCreditoBancarioAnalitico == null) {
			listaRelatorioCreditoBancarioAnalitico = new ArrayList<RelatorioCreditoBancarioAnaliticoDTO>();
		}
		return listaRelatorioCreditoBancarioAnalitico;
	}

	public void setListaRelatorioCreditoBancarioAnalitico(List<RelatorioCreditoBancarioAnaliticoDTO> listaRelatorioCreditoBancarioAnalitico) {
		this.listaRelatorioCreditoBancarioAnalitico = listaRelatorioCreditoBancarioAnalitico;
	}

	public List<RelatorioCreditoBancarioSinteticoDTO> getListaRelatorioCreditoBancarioSintetico() {
		if (listaRelatorioCreditoBancarioSintetico == null) {
			listaRelatorioCreditoBancarioSintetico = new ArrayList<RelatorioCreditoBancarioSinteticoDTO>();
		}
		return listaRelatorioCreditoBancarioSintetico;
	}

	public void setListaRelatorioCreditoBancarioSintetico(List<RelatorioCreditoBancarioSinteticoDTO> listaRelatorioCreditoBancarioSintetico) {
		this.listaRelatorioCreditoBancarioSintetico = listaRelatorioCreditoBancarioSintetico;
	}

}
