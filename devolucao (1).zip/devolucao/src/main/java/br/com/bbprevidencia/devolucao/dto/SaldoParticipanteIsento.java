package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

@Entity
@Table(name = "SALDO_PARTICIPANTE_ISENTO", schema = "OWN_CAD")
@NamedQuery(name = "SaldoParticipanteIsento.findAll", query = "SELECT q FROM SaldoParticipanteIsento q")
public class SaldoParticipanteIsento implements Serializable, BaseEntity, Cloneable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SALDO_PARTICIPANTE_ISENTO_GER", sequenceName = "s_spi_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SALDO_PARTICIPANTE_ISENTO_GER")
	@Column(name = "NUM_SEQ_SALDO_PARTI_ISENT")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@Column(name = "NUM_SEQ_PARTIC_PLANO")
	private Long numSeqPatiPlano;

	@Column(name = "VALOR_UTIL_FOLHA")
	private BigDecimal valorUtilFolha;

	@Column(name = "SALDO_ATUAL")
	private BigDecimal saldoAtual;

	@Column(name = "DATA_UTILIZACAO")
	private Date dataUtilizacao;

	@Column(name = "LOTE_FOLHA")
	private Long loteFolha;

	@Column(name = "NUM_SEQ_BENEF")
	private Long numSeqBeneficio;

	@Column(name = "DATA_ATUALIZACAO")
	private Date dataAtualizacao;

	@Column(name = "NUM_SEQ_UTILI_INDIC_ECONO")
	private Long numSeqUtiIndEco;

	@Column(name = "VALOR_CORRECAO")
	private BigDecimal valorCorrecao;

	@Column(name = "DAT_INC_REG")
	private Date dataInicioRegistro;

	@Column(name = "COD_USU_INC_REG")
	private String codigoUsuarioIncReg;

	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracaoRegistro;

	@Column(name = "COD_USU_ALT_REG")
	private String codUsuAltReg;

	public SaldoParticipanteIsento() {
		super();
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public Long getNumSeqPatiPlano() {
		return numSeqPatiPlano;
	}

	public void setNumSeqPatiPlano(Long numSeqPatiPlano) {
		this.numSeqPatiPlano = numSeqPatiPlano;
	}

	public BigDecimal getValorUtilFolha() {
		return valorUtilFolha;
	}

	public void setValorUtilFolha(BigDecimal valorUtilFolha) {
		this.valorUtilFolha = valorUtilFolha;
	}

	public BigDecimal getSaldoAtual() {
		return saldoAtual;
	}

	public void setSaldoAtual(BigDecimal saldoAtual) {
		this.saldoAtual = saldoAtual;
	}

	public Date getDataUtilizacao() {
		return dataUtilizacao;
	}

	public void setDataUtilizacao(Date dataUtilizacao) {
		this.dataUtilizacao = dataUtilizacao;
	}

	public Long getLoteFolha() {
		return loteFolha;
	}

	public void setLoteFolha(Long loteFolha) {
		this.loteFolha = loteFolha;
	}

	public Long getNumSeqBeneficio() {
		return numSeqBeneficio;
	}

	public void setNumSeqBeneficio(Long numSeqBeneficio) {
		this.numSeqBeneficio = numSeqBeneficio;
	}

	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public Long getNumSeqUtiIndEco() {
		return numSeqUtiIndEco;
	}

	public void setNumSeqUtiIndEco(Long numSeqUtiIndEco) {
		this.numSeqUtiIndEco = numSeqUtiIndEco;
	}

	public BigDecimal getValorCorrecao() {
		return valorCorrecao;
	}

	public void setValorCorrecao(BigDecimal valorCorrecao) {
		this.valorCorrecao = valorCorrecao;
	}

	public Date getDataInicioRegistro() {
		return dataInicioRegistro;
	}

	public void setDataInicioRegistro(Date dataInicioRegistro) {
		this.dataInicioRegistro = dataInicioRegistro;
	}

	public String getCodigoUsuarioIncReg() {
		return codigoUsuarioIncReg;
	}

	public void setCodigoUsuarioIncReg(String codigoUsuarioIncReg) {
		this.codigoUsuarioIncReg = codigoUsuarioIncReg;
	}

	public Date getDataAlteracaoRegistro() {
		return dataAlteracaoRegistro;
	}

	public void setDataAlteracaoRegistro(Date dataAlteracaoRegistro) {
		this.dataAlteracaoRegistro = dataAlteracaoRegistro;
	}

	public String getCodUsuAltReg() {
		return codUsuAltReg;
	}

	public void setCodUsuAltReg(String codUsuAltReg) {
		this.codUsuAltReg = codUsuAltReg;
	}

}
