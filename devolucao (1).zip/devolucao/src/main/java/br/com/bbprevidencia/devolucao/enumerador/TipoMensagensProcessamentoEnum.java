package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoMensagensProcessamentoEnum {

	MS0001("1", "A", "Envio de declaração de escolaridade."),
	MS0002("2", "A", "Beneficiário completará 18 anos."),
	MS0003("3", "A", "Alterado tipo de retenção para isento."),
	MS0004("4", "A", "Processo se encerra próximo mês."),
	MS0005("5", "A", "Cota já disponível"),
	MS0006("6", "A", "Participante possui empréstimo."),
	MS0007("7", "A", "Recebedor possui retenção IR no exterior"),
	MS0008("8", "A", "Processo já pago com data de encerramento anterior."),
	MS0009("9", "A", "Rubrica não descontada."),
	MS0010("10", "A", "Tipo de Retenção."),
	MS0011("11", "A", "Não foi possível calcular o desconto."),
	MS0012("12", "A", "Recebedor Bloqueiado."),
	MS0013("13", "A", "Exclusão de Dependente Imposto."),
	MS0014("14", "A", "Inclusão de Dependente Imposto."),
	MS0015("15", "A", "Dados Bancários Imcompletos."),
	MS0016("16", "A", "Recebedor Completou 65 anos."),
	MS0017("17", "A", "Processo com % de adiantamento de Saldo."),
	MS0018("18", "A", "Exclusão de Beneficiário."),
	MS0019("19", "A", "Inclusão de Beneficiário."),
	MS0020("20", "E", "Problema no Cálculo do Líquido."),
	MS0021("21", "E", "Problema no Cálculo do Imposto."),
	MS0022("22", "E", "Problema Tipo Retenção."),
	MS0023("23", "E", "Devolução sem recebedor válido."),
	MS0024("24", "E", "Problema ao calcular descontos."),
	MS0025("25", "E", "Erro ao buscar valor da cota."),
	MS0026("26", "E", "Competência incorreta."),
	MS0027("27", "E", "Devolução com problema calculo."),
	MS0028("28", "E", "Problema grupo de recebimento."),
	MS0029("29", "E", "Problema pessoa atuação."),
	MS0030("30", "E", "Erro ao inserir em movimento de cálculo."),
	MS0031("31", "E", "Erro ao buscar rubrica para tipo de devolução."),
	MS0032("32", "E", "Rubrica não cadastrada para tipo de devolução."),
	MS0033("33", "E", "Existe outro recebedor para pagamento sem percentual individual cadastrado ou com valor 0.");

	private String codigo;
	private String descricao;
	private String tipo;

	private TipoMensagensProcessamentoEnum(String codigo, String tipo, String descricao) {
		this.codigo = codigo;
		this.tipo = tipo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return MantenedorEnum
	 */
	public static TipoMensagensProcessamentoEnum getMantenedorEnum(String codigo) {
		if (codigo != null) {
			for (TipoMensagensProcessamentoEnum mantenedor : values()) {
				if (mantenedor.getCodigo().equals(codigo)) {
					return mantenedor;
				}
			}
		}
		return null;
	}

}