package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Classe de persistência para tabela PAR_INT_OPT_OUT_DEV.
 * 
 * @author  BBPF0468 - Carlos Wallace
 * @since   07/08/2020
 * 
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
@Entity
@Table(name = "PAR_INT_OPT_OUT_DEV", schema = "OWN_DCR")
@NamedQuery(name = "ParametroIntegracaoOptOutDevolucao.findAll", query = "SELECT p FROM ParametroIntegracaoOptOutDevolucao p")
public class ParametroIntegracaoOptOutDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PAR_INT_OPT_OUT_DEV_GER", sequenceName = "OWN_DCR.S_PAR_INT_OPT_OUT_DEV_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PAR_INT_OPT_OUT_DEV_GER")
	@Column(name = "NUM_SEQ_PAR_INT_OPT_OUT")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV")
	private RubricaDevolucao rubricaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLANO")
	private PlanoPrevidencia planoPrevidencia;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_ECCPA")
	private OperacaoInterna operacaoInternaEstContribCustPartic;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_ECCPT")
	private OperacaoInterna operacaoInternaEstContribCustPatron;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_TCPA")
	private OperacaoInterna operacaoInternaTaxaCarregPartic;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_TCPT")
	private OperacaoInterna operacaoInternaTaxaCarregPatron;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_DRPA")
	private OperacaoInterna operacaoInternaDevRecPartic;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_DRPT")
	private OperacaoInterna operacaoInternaDevRecPatron;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_DAPA")
	private OperacaoInterna operacaoInternaDevAtualizacaoPartic;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_DAPT")
	private OperacaoInterna operacaoInternaDevAtualizacaoPatron;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_SOB")
	private OperacaoInterna operacaoInternaSobrante;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT_FAL")
	private OperacaoInterna operacaoInternaFaltante;

	@Column(name = "TXT_INDICE")
	private String nomeIndice;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INI_VIG")
	private Date dataInicioVigencia;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FIM_VIG")
	private Date dataTerminoVigencia;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

}
