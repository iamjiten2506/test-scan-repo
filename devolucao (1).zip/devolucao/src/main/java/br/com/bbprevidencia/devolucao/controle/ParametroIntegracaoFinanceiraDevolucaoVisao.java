package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.contabilidade.bo.OperacaoInternaBO;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.devolucao.bo.ParametroIntegracaoFinanceiraDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.ParametroIntegracaoFinanceiraDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

@Scope("session")
@Component("parametroIntegracaoFinanceiraDevolucaoVisao")
public class ParametroIntegracaoFinanceiraDevolucaoVisao {
	private static String FW_PARAMETRO_INTEGRACAO_FINANCEIRA_DEV = "/paginas/parametroIntegracaoFinanceiraDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private ParametroIntegracaoFinanceiraDevolucaoBO parametroIntegracaoFinanceiraDevolucaoBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private OperacaoInternaBO operacaoInternaBO;

	private List<ParametroIntegracaoFinanceiraDevolucao> listaParametroIntegracaoFinanceiraDevolucao;

	private List<ParametroIntegracaoFinanceiraDevolucao> listaFiltrada;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<OperacaoInterna> listaOperacaoInterna;

	private ParametroIntegracaoFinanceiraDevolucao parametroIntegracaoFinanceiraDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private PlanoPrevidencia planoPrevidencia;
	private OperacaoInterna operacaoInterna;

	/**
	 * Método encarregado por iniciar a página 
	 * @author  BBPF00170 - Magson 
	 * @since   13/02/2017
	 * @return {@link String}
	 * 
	 */

	public String iniciarParametroIntegracaoFinanceiraDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("parametroIntegracaoFinanceiraDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
		this.listarStatus = true;

		listaParametroIntegracaoFinanceiraDevolucao = new ArrayList<ParametroIntegracaoFinanceiraDevolucao>(parametroIntegracaoFinanceiraDevolucaoBO.listarTodos());
		listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanos());
		listaOperacaoInterna = new ArrayList<OperacaoInterna>(operacaoInternaBO.listarTodasOperacaoInterna());
		return FW_PARAMETRO_INTEGRACAO_FINANCEIRA_DEV;
	}

	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * @author  BBPF00170 - Magson
	 * @since   13/02/2017
	 */
	public void controlarEdicaoParametroIntegracaoFinanceiraDevolucao() {
		if (isListarStatus()) {
			planoPrevidencia = new PlanoPrevidencia();
			operacaoInterna = new OperacaoInterna();
			listaParametroIntegracaoFinanceiraDevolucao = new ArrayList<ParametroIntegracaoFinanceiraDevolucao>(parametroIntegracaoFinanceiraDevolucaoBO.listarTodos());
		}
		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método que controla edição 
	 * 
	 * @author  BBPF0170 MAGSON
	 * @since   08/02/2017
	 * @param 	@ParametroIntegracaoFinanceiraDevolucao
	 * @return  
	 */
	public void editarParametroIntegracaoFinanceiraDevolucao(ParametroIntegracaoFinanceiraDevolucao parametroIntegracaoFinanceiraDevolucao) {
		parametroIntegracaoFinanceiraDevolucao.setDataAlteracao(new Date());
		parametroIntegracaoFinanceiraDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
		setParametroIntegracaoFinanceiraDevolucao(parametroIntegracaoFinanceiraDevolucao);
		controlarEdicaoParametroIntegracaoFinanceiraDevolucao();
	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da página
	 * 
	 * @author  BBPF0170 - Magson
	 * @since 	13/02/2017
	 * 
	 */
	public void limparPesquisa() {
		listaParametroIntegracaoFinanceiraDevolucao = new ArrayList<ParametroIntegracaoFinanceiraDevolucao>(parametroIntegracaoFinanceiraDevolucaoBO.listarTodos());
	}

	/**
	 * Método encarregado de deletar
	 * 
	 * @author  BBPF0170 - Magson
	 * @since 13/02/2017
	 * @param {@link @ParametroIntegracaoFinanceiraDevolucao }
	 * @return {@link String}
	 */
	public String deletarParametroIntegracaoFinanceiraDevolucao(ParametroIntegracaoFinanceiraDevolucao parametroIntegracaoFinanceiraDevolucao) {
		try {

			parametroIntegracaoFinanceiraDevolucaoBO.apagarParametroIntegracaoFinanceiraDevolucao(parametroIntegracaoFinanceiraDevolucao);
			listaParametroIntegracaoFinanceiraDevolucao = parametroIntegracaoFinanceiraDevolucaoBO.listarTodos();
			Mensagens.addMsgInfo("Parâmetro de Integração Financeira excluído com sucesso!");
			return "FW_PARAMETRO_INTEGRACAO_FINANCEIRA_DEV";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar Parâmetro de Integração Financeira.");
			return "";
		}
	}

	/**
	 * Método responsavel por carregar a pagina para cadastrar um Novo Paramentro de Integração Financeira.
	 * @author  BBPF0170 -  Magson
	 * @since   13/02/2017
	 */
	public void cadastrarNovoParametroIntegracaoFinanceiraDevolucao() {
		parametroIntegracaoFinanceiraDevolucao = new ParametroIntegracaoFinanceiraDevolucao();
		controlarEdicaoParametroIntegracaoFinanceiraDevolucao();
	}

	/**
	 * Método para salvar  
	 * 
	 * @author  BBPF0170 - Magson
	 * @since   13/02/2017
	 * 
	 */
	public String salvarParametroIntegracaoFinanceiraDevolucao() {
		try {
			if (this.parametroIntegracaoFinanceiraDevolucao.getCodigo() == null) {
				this.parametroIntegracaoFinanceiraDevolucao.setDataInclusao(new Date());
				this.parametroIntegracaoFinanceiraDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			}

			parametroIntegracaoFinanceiraDevolucaoBO.salvarParametroIntegracaoFinanceiraDevolucao(parametroIntegracaoFinanceiraDevolucao);

			controlarEdicaoParametroIntegracaoFinanceiraDevolucao();

			Mensagens.addMessage("DEV_VMSG019", parametroIntegracaoFinanceiraDevolucao.getCodigo() == null ? "salvo" : "atualizado");

			listaParametroIntegracaoFinanceiraDevolucao = parametroIntegracaoFinanceiraDevolucaoBO.listarTodos();

			return FW_PARAMETRO_INTEGRACAO_FINANCEIRA_DEV;

		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar");
			return "";
		}

	}

	public ParametroIntegracaoFinanceiraDevolucaoBO getParametroIntegracaoFinanceiraDevolucaoBO() {
		return parametroIntegracaoFinanceiraDevolucaoBO;
	}

	public void setParametroIntegracaoFinanceiraDevolucaoBO(ParametroIntegracaoFinanceiraDevolucaoBO parametroIntegracaoFinanceiraDevolucaoBO) {
		this.parametroIntegracaoFinanceiraDevolucaoBO = parametroIntegracaoFinanceiraDevolucaoBO;
	}

	public OperacaoInternaBO getOperacaoInternaBO() {
		return operacaoInternaBO;
	}

	public void setOperacaoInternaBO(OperacaoInternaBO operacaoInternaBO) {
		this.operacaoInternaBO = operacaoInternaBO;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<OperacaoInterna> getListaOperacaoInterna() {
		return listaOperacaoInterna;
	}

	public void setListaOperacaoInterna(List<OperacaoInterna> listaOperacaoInterna) {
		this.listaOperacaoInterna = listaOperacaoInterna;
	}

	public ParametroIntegracaoFinanceiraDevolucao getParametroIntegracaoFinanceiraDevolucao() {
		return parametroIntegracaoFinanceiraDevolucao;
	}

	public void setParametroIntegracaoFinanceiraDevolucao(ParametroIntegracaoFinanceiraDevolucao parametroIntegracaoFinanceiraDevolucao) {
		this.parametroIntegracaoFinanceiraDevolucao = parametroIntegracaoFinanceiraDevolucao;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public OperacaoInterna getOperacaoInterna() {
		return operacaoInterna;
	}

	public void setOperacaoInterna(OperacaoInterna operacaoInterna) {
		this.operacaoInterna = operacaoInterna;
	}

	public List<ParametroIntegracaoFinanceiraDevolucao> getListaParametroIntegracaoFinanceiraDevolucao() {
		return listaParametroIntegracaoFinanceiraDevolucao;
	}

	public void setListaParametroIntegracaoFinanceiraDevolucao(List<ParametroIntegracaoFinanceiraDevolucao> listaParametroIntegracaoFinanceiraDevolucao) {
		this.listaParametroIntegracaoFinanceiraDevolucao = listaParametroIntegracaoFinanceiraDevolucao;
	}

	public List<ParametroIntegracaoFinanceiraDevolucao> getListaFiltrada() {
		return listaFiltrada;
	}

	public void setListaFiltrada(List<ParametroIntegracaoFinanceiraDevolucao> listaFiltrada) {
		this.listaFiltrada = listaFiltrada;
	}

}
