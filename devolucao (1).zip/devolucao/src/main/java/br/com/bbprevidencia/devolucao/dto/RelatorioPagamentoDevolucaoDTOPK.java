package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RelatorioPagamentoDevolucaoDTOPK implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "NUM_SEQ_PARTIC")
	private Long codigo;

	@Column(name = "NOM_RECEBEDOR")
	private String nomeRecebedor;

	@Column(name = "DAT_PGT")
	private Date dataPagamento;

	@Column(name = "NUM_SEQ_PARTIC_PLANO")
	private Long codigoParticPlano;

	@Column(name = "NUM_SEQ_RECEBEDOR")
	private Long codigoRecebedor;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getNomeRecebedor() {
		return nomeRecebedor;
	}

	public void setNomeRecebedor(String nomeRecebedor) {
		this.nomeRecebedor = nomeRecebedor;
	}

	public Long getCodigoParticPlano() {
		return codigoParticPlano;
	}

	public void setCodigoParticPlano(Long codigoParticPlano) {
		this.codigoParticPlano = codigoParticPlano;
	}

	public Long getCodigoRecebedor() {
		return codigoRecebedor;
	}

	public void setCodigoRecebedor(Long codigoRecebedor) {
		this.codigoRecebedor = codigoRecebedor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((codigoParticPlano == null) ? 0 : codigoParticPlano.hashCode());
		result = prime * result + ((codigoRecebedor == null) ? 0 : codigoRecebedor.hashCode());
		result = prime * result + ((dataPagamento == null) ? 0 : dataPagamento.hashCode());
		result = prime * result + ((nomeRecebedor == null) ? 0 : nomeRecebedor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RelatorioPagamentoDevolucaoDTOPK other = (RelatorioPagamentoDevolucaoDTOPK) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (codigoParticPlano == null) {
			if (other.codigoParticPlano != null)
				return false;
		} else if (!codigoParticPlano.equals(other.codigoParticPlano))
			return false;
		if (codigoRecebedor == null) {
			if (other.codigoRecebedor != null)
				return false;
		} else if (!codigoRecebedor.equals(other.codigoRecebedor))
			return false;
		if (dataPagamento == null) {
			if (other.dataPagamento != null)
				return false;
		} else if (!dataPagamento.equals(other.dataPagamento))
			return false;
		if (nomeRecebedor == null) {
			if (other.nomeRecebedor != null)
				return false;
		} else if (!nomeRecebedor.equals(other.nomeRecebedor))
			return false;
		return true;
	}

}
