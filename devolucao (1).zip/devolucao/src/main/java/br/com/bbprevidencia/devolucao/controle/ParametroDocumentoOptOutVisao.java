package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.ListUtils;
import org.apache.log4j.Logger;
import org.primefaces.model.DualListModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.Mensagens;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParametroDocumentoOptOutBO;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.ItemParametroDocumentoOptOut;
import br.com.bbprevidencia.devolucao.dto.ParametroDocumentoOptOut;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

@Scope("session")
@Component("parametroDocumentoOptOutVisao")
public class ParametroDocumentoOptOutVisao {

	private static String FW_PARAMETRO_DOCUMENTO_OPT_OUT = "/paginas/parametroDocumentoOptOut.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static Logger log = Logger.getLogger(ParametroDocumentoOptOutVisao.class);

	@Autowired
	private ParametroDocumentoOptOutBO parametroDocumentoOptOutBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private DocumentoDevolucaoBO documentoDevolucaoBO;

	private List<ParametroDocumentoOptOut> listaParametroDocumentoOptOut;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<DocumentoDevolucao> listaDocumentoDevolucao;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private ParametroDocumentoOptOut parametroDocumentoOptOut;

	private boolean listarStatus;

	private DocumentoDevolucao documentoDevolucao;

	private boolean documentoObrigatorio;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	public String iniciarPagina() {
		listarStatus = true;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		//carregando as informações base
		this.planoPrevidencia = this.planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(141L);
		this.listaPlanoPrevidencia = Arrays.asList(planoPrevidencia);

		this.listaEntidadeParticipante = this.entidadeParticipanteBO.listarEntidadeParticipantePorPlano(planoPrevidencia);

		return FW_PARAMETRO_DOCUMENTO_OPT_OUT;
	}

	public void pesquisarParametroDocumentoOptOut() {
		try {
			this.listaParametroDocumentoOptOut = this.parametroDocumentoOptOutBO.pesquisarPorEntidade(this.entidadeParticipante);
		} catch (Exception e) {
			Mensagens.addMsgErro(e.getMessage());
		}

	}

	public void cadastrarParametroDocumentoOptOut() {
		this.listarStatus = false;
		this.documentoObrigatorio = false;
		this.documentoDevolucao = null;
		this.parametroDocumentoOptOut = new ParametroDocumentoOptOut();
		this.parametroDocumentoOptOut.setPlanoPrevidencia(this.planoPrevidencia);
		this.parametroDocumentoOptOut.setDataInclusao(new Date());
		this.parametroDocumentoOptOut.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

		this.listaDocumentoDevolucao = new ArrayList<DocumentoDevolucao>(this.documentoDevolucaoBO.listarTodosDocumentoDevolucao());

	}

	public void salvarParametroDocumentoOptOut() {
		try {
			if (this.parametroDocumentoOptOut.getEntidadeParticipante() == null)
				throw new PrevidenciaException("Favor selecionar Patrocinadora.");

			if (this.parametroDocumentoOptOut.getListaItemParametroDocumentoOptOut().size() == 0)
				throw new PrevidenciaException("Não foram selecionados documentos.");

			this.parametroDocumentoOptOutBO.salvarParametroDocumentoOptOut(this.parametroDocumentoOptOut);

			Mensagens.addMsgInfo("Parâmetro salvo com sucesso!!");
			limparPesquisa();

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao salvar parâmetros: " + e.getMessage());
		}

	}

	public void limparPesquisa() {
		this.listarStatus = true;
		this.entidadeParticipante = null;
		this.listaParametroDocumentoOptOut = null;
	}

	public void excluirParametroDocumentoOptOut(ParametroDocumentoOptOut parametroDocumentoOptOut) {
		try {
			this.parametroDocumentoOptOutBO.apagarParametroDocumentoOptOut(parametroDocumentoOptOut);
			limparPesquisa();
			Mensagens.addMsgInfo("Parâmetro excluído com sucesso!!");
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao excluir a parametrização de documentos. Erro: " + e.getMessage());
		}
	}

	public void editarParametroDocumentoOptOut(ParametroDocumentoOptOut parametroDocumentoOptOut) {
		this.parametroDocumentoOptOut = parametroDocumentoOptOut;
		this.listaDocumentoDevolucao = this.documentoDevolucaoBO.listarTodosDocumentoDevolucao();
		List<DocumentoDevolucao> listaDocumentoCadastrada = this.parametroDocumentoOptOut.getListaItemParametroDocumentoOptOut()
				.stream()
				.map(ItemParametroDocumentoOptOut::getDocumentoDevolucao)
				.collect(Collectors.toList());
		
		ListUtils.subtract(listaDocumentoDevolucao, listaDocumentoCadastrada);
		this.listarStatus = false;
	}

	public void adicionarItemParametroDocumentoLista() {
		if (this.documentoDevolucao != null) {
			ItemParametroDocumentoOptOut item = ItemParametroDocumentoOptOut.builder().parametroDocumentoOptOut(this.parametroDocumentoOptOut).documentoDevolucao(this.documentoDevolucao).obrigatorio(
					this.documentoObrigatorio).dataInclusao(new Date()).nomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin()).build();

			this.parametroDocumentoOptOut.getListaItemParametroDocumentoOptOut().add(item);

			if (this.listaDocumentoDevolucao.size() > 0)
				this.listaDocumentoDevolucao.remove(this.documentoDevolucao);

			this.documentoDevolucao = null;
			this.documentoObrigatorio = false;
		} else {
			Mensagens.addMsgErro("Documento não selecionado!");
		}
	}

	public void excluirItemParametroDocumentoLista(ItemParametroDocumentoOptOut item) {
		this.listaDocumentoDevolucao.add(item.getDocumentoDevolucao());
		this.parametroDocumentoOptOut.getListaItemParametroDocumentoOptOut().remove(item);
	}

	public List<ParametroDocumentoOptOut> getListaParametroDocumentoOptOut() {
		return listaParametroDocumentoOptOut;
	}

	public void setListaParametroDocumentoOptOut(List<ParametroDocumentoOptOut> listaParametroDocumentoOptOut) {
		this.listaParametroDocumentoOptOut = listaParametroDocumentoOptOut;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<DocumentoDevolucao> getListaDocumentoDevolucao() {
		return listaDocumentoDevolucao;
	}

	public void setListaDocumentoDevolucao(List<DocumentoDevolucao> listaDocumentoDevolucao) {
		this.listaDocumentoDevolucao = listaDocumentoDevolucao;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public ParametroDocumentoOptOut getParametroDocumentoOptOut() {
		return parametroDocumentoOptOut;
	}

	public void setParametroDocumentoOptOut(ParametroDocumentoOptOut parametroDocumentoOptOut) {
		this.parametroDocumentoOptOut = parametroDocumentoOptOut;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public DocumentoDevolucao getDocumentoDevolucao() {
		return documentoDevolucao;
	}

	public void setDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		this.documentoDevolucao = documentoDevolucao;
	}

	public boolean isDocumentoObrigatorio() {
		return documentoObrigatorio;
	}

	public void setDocumentoObrigatorio(boolean documentoObrigatorio) {
		this.documentoObrigatorio = documentoObrigatorio;
	}
}
