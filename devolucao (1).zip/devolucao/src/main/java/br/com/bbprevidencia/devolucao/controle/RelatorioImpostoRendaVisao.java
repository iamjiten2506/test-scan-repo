package br.com.bbprevidencia.devolucao.controle;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.bbpcomum.util.UtilXls;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioAnaliticoIRDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioImpostoRendaDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioSinteticoIRDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.folha.bo.CaracteristicaDirfBO;
import br.com.bbprevidencia.folha.dto.CaracteristicaDirf;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório de Imposto de renda
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 21/06/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioImpostoRendaVisao")
public class RelatorioImpostoRendaVisao {
	private static final String FW_RELATORIO_IMPOSTO_RENDA = "/paginas/relatorioImpostoRenda.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioImpostoRendaVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	RelatorioUtil relatorioUtil;
	@Autowired
	ProcessarRelatorioIR processarRelatorioIR;
	@Autowired
	HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;
	@Autowired
	MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;

	@Autowired
	CaracteristicaDirfBO caracteristicaDirfBO;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private CronogramaDevolucao cronogramaDevolucao;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;

	private String incluirCodigoIR;

	/**
	 * Método encarregado de preencher os dados inciais e carregar página
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 * @return
	 */
	public String iniciarRelatorioImpostoRenda() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_IMPOSTO_RENDA;
	}

	/**
	 * Método encarregado de prencher os dados iniciais do sistema.
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 */
	private void setarValoresIniciais() {
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(this.cronogramaDevolucaoBO.listarCronogramaDescendente());
		this.cronogramaDevolucao = null;
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>();
		this.listaEntidadeParticipanteSelecionadas = new ArrayList<EntidadeParticipante>();
		this.incluirCodigoIR = "N";
	}

	/**
	 * Método encarregado de pesquisar as entidades participantes que participaram do cáculo de determinado cronograma
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 */
	public void listarPatrocinadoraPorCronograma() {
		//Situação do cronograma como fechado
		if (this.cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
			this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.historicoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
		} else {
			this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.movimentoCalculoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
		}

	}

	/**
	 * Limpa os parâmetros de pesquisa
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/06/2017
	 */
	public void limparPesquisa() {
		setarValoresIniciais();
	}

	/**
	 * Método encarregado de exportar o relatório
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/16/2017
	 */
	public void exportarRelatorio() {
		try {
			if (this.cronogramaDevolucao == null || this.cronogramaDevolucao.getCodigo() == null) {
				throw new PrevidenciaException("Favor selecionar um cronograma antes de continuar!");
			}

			List<RelatorioAnaliticoIRDTO> relatorioAnalitico = new ArrayList<RelatorioAnaliticoIRDTO>();
			List<RelatorioSinteticoIRDTO> relatorioSintetico = new ArrayList<RelatorioSinteticoIRDTO>();
			relatorioAnalitico = this.processarRelatorioIR.preencheRelatorioAnaliticoIR(this.cronogramaDevolucao, this.listaEntidadeParticipanteSelecionadas);

			if (UtilJava.isColecaoVazia(relatorioAnalitico)) {
				throw new PrevidenciaException("Não foram encontradas informações para estes parâmetros!");
			} else {
				relatorioSintetico = this.processarRelatorioIR.preencherRelatorioSinteticoIR(relatorioAnalitico);
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);

				parametros.put("listaRelatorioAnalitico", relatorioAnalitico);
				parametros.put("listaRelatorioSintetico", relatorioSintetico);
				parametros.put("analiticoComCodigo", this.incluirCodigoIR);

				List<RelatorioAnaliticoIRDTO> lista = new ArrayList<RelatorioAnaliticoIRDTO>();
				lista.add(new RelatorioAnaliticoIRDTO());

				imprimirRelatorio("impostoRenda", lista, parametros);

			}
		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro("Erro ao exportar relatório: " + ex.getMessage());
		}
	}

	/**
	 * Imprimir relatório
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param relatorio
	 * @param dados
	 * @param param
	 */
	public void imprimirRelatorio(String relatorio, List<RelatorioAnaliticoIRDTO> dados, Map<String, Object> parametros) {
		try {
			String nomeArquivo = relatorioUtil.gerarRelatorio(relatorio, dados, parametros);
			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (Exception e) {
			log.error("Erro ao exportar relatório.", e);
			throw new PrevidenciaException(e);
		}
	}

	public void exportarRelatorioExcel() {
		try {
			if (this.cronogramaDevolucao == null || this.cronogramaDevolucao.getCodigo() == null) {
				throw new PrevidenciaException("Favor selecionar um cronograma antes de continuar!");
			}

			List<RelatorioImpostoRendaDTO> listaRelatorioIR = new ArrayList<RelatorioImpostoRendaDTO>();
			listaRelatorioIR = this.processarRelatorioIR.listarRelatorioIR(this.cronogramaDevolucao, this.listaEntidadeParticipanteSelecionadas);

			if (UtilJava.isColecaoVazia(listaRelatorioIR)) {
				Mensagens.addMsgWarn("Não foram encontrdas informações para os parâmetros informados!");
			} else {

				Workbook wb = new HSSFWorkbook();
				Sheet sheet = wb.createSheet("Planilha1");

				int rownum = 0;
				int cellnum = 0;
				Cell cell;
				Row row;

				row = sheet.createRow(rownum++);
				cell = row.createCell(cellnum++);
				cell.setCellValue("MODALIDADE_PLANO");

				cell = row.createCell(cellnum++);
				cell.setCellValue("PATROCINADORA");

				cell = row.createCell(cellnum++);
				cell.setCellValue("PARTICIPANTE");

				cell = row.createCell(cellnum++);
				cell.setCellValue("CPF");

				cell = row.createCell(cellnum++);
				cell.setCellValue("VALOR_IRRF");

				cell = row.createCell(cellnum++);
				cell.setCellValue("CODIGO_RETENCAO");

				cell = row.createCell(cellnum++);
				cell.setCellValue("NATUREZA_RENDIMENTNO");

				for (RelatorioImpostoRendaDTO linha : listaRelatorioIR) {
					row = sheet.createRow(rownum++);
					cellnum = 0;

					cell = row.createCell(cellnum++);
					cell.setCellValue(linha.getCodigoModalidadePlano());

					cell = row.createCell(cellnum++);
					cell.setCellValue(linha.getPatrocinadora());

					cell = row.createCell(cellnum++);
					cell.setCellValue(linha.getParticipante());

					cell = row.createCell(cellnum++);
					cell.setCellValue(linha.getCpf());

					cell = row.createCell(cellnum++);
					cell.setCellValue(linha.getValorIRRF());

					this.preencheTipoRetencao(linha);

					cell = row.createCell(cellnum++);
					cell.setCellValue(linha.getCodigoRetencao());

					this.preencheNaturezaRendimento(linha);

					cell = row.createCell(cellnum++);
					cell.setCellValue(linha.getCodigoNaturezaRendimento());
				}

				ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyyyhhmmss");
				String id = simpleDateFormat.format(new Date());

				wb.write(outByteStream);
				byte[] outArray = outByteStream.toByteArray();
				UtilXls.imprimeXLS(outArray, "relatorioIR_" + id);
			}

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro(e.getMessage());
		}

	}

	private void preencheTipoRetencao(RelatorioImpostoRendaDTO item) {
		CaracteristicaDirf caracteristicaDirf = this.caracteristicaDirfBO.pesquisarCaracteristicaDirfPorTipo(item.getCodigoDirf());

		String codigoRetencaoBD = caracteristicaDirf.getTipoRetencaoDIRFBD() == null ? "" : caracteristicaDirf.getTipoRetencaoDIRFBD().getCodigoRetencaoDirf();
		String codigoRetencaoProgressivo = caracteristicaDirf.getTipoRetencaoDirfPro() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfPro().getCodigoRetencaoDirf();
		String codigoRetencaoRegressivo = caracteristicaDirf.getTipoRetencaoDirfReg() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfReg().getCodigoRetencaoDirf();
		String codigoRetencaoExterior = caracteristicaDirf.getTipoRetencaoDirfExt() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfExt().getCodigoRetencaoDirf();

		if (item.getCodigoModalidadePlano().equalsIgnoreCase("BD")) {
			item.setCodigoRetencao(codigoRetencaoBD);
			return;
		} else if (item.getIndicadorRetencao().equalsIgnoreCase("P")) {
			item.setCodigoRetencao(codigoRetencaoProgressivo);
			return;
		} else if (item.getIndicadorRetencao().equalsIgnoreCase("R")) {
			item.setCodigoRetencao(codigoRetencaoRegressivo);
			return;
		} else if (item.getIndicadorRetencao().equalsIgnoreCase("E")) {
			item.setCodigoRetencao(codigoRetencaoExterior);
			return;
		}
	}

	private void preencheNaturezaRendimento(RelatorioImpostoRendaDTO item) {

		String codigoNaturezaRendimentoBD = "";
		String codigoNaturezaRendimentoProgressivo = "";
		String codigoNaturezaRendimentoRegressivo = "";
		String codigoNaturezaRendimentoExterior = "";

		CaracteristicaDirf caracteristicaDirf = this.caracteristicaDirfBO.pesquisarCaracteristicaDirfPorTipo(item.getCodigoDirf());

		if (caracteristicaDirf.getTipoRetencaoDIRFBD() != null && caracteristicaDirf.getTipoRetencaoDIRFBD().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoBD = caracteristicaDirf.getTipoRetencaoDIRFBD().getNaturezaRendimento().getCodigoReceita();
		}

		if (caracteristicaDirf.getTipoRetencaoDirfPro() != null && caracteristicaDirf.getTipoRetencaoDirfPro().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoProgressivo = caracteristicaDirf.getTipoRetencaoDirfPro().getNaturezaRendimento().getCodigoReceita();
		}

		if (caracteristicaDirf.getTipoRetencaoDirfReg() != null && caracteristicaDirf.getTipoRetencaoDirfReg().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoRegressivo = caracteristicaDirf.getTipoRetencaoDirfReg().getNaturezaRendimento().getCodigoReceita();
		}

		if (caracteristicaDirf.getTipoRetencaoDirfExt() != null && caracteristicaDirf.getTipoRetencaoDirfExt().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoExterior = caracteristicaDirf.getTipoRetencaoDirfExt().getNaturezaRendimento().getCodigoReceita();
		}

		if (item.getCodigoModalidadePlano().equalsIgnoreCase("BD")) {
			item.setCodigoNaturezaRendimento(codigoNaturezaRendimentoBD);
			return;
		} else if (item.getIndicadorRetencao().equalsIgnoreCase("P")) {
			item.setCodigoNaturezaRendimento(codigoNaturezaRendimentoProgressivo);
			return;
		} else if (item.getIndicadorRetencao().equalsIgnoreCase("R")) {
			item.setCodigoNaturezaRendimento(codigoNaturezaRendimentoRegressivo);
			return;
		} else if (item.getIndicadorRetencao().equalsIgnoreCase("E")) {
			item.setCodigoNaturezaRendimento(codigoNaturezaRendimentoExterior);
			return;
		}
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

	public String getIncluirCodigoIR() {
		return incluirCodigoIR;
	}

	public void setIncluirCodigoIR(String incluirCodigoIR) {
		this.incluirCodigoIR = incluirCodigoIR;
	}

}
