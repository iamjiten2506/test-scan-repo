package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.FundoPrevidencia;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 28/11/2016 Classe de persistência para tabela DEVOLUCAO.
 */
@Entity
@Table(name = "REF_CALC_DR", schema = "OWN_DR")
//Owner antigo do devolucao
@NamedQuery(name = "ReferenciaCalculoDevolucaoPosicionado.findAll", query = "SELECT q FROM ReferenciaCalculoDevolucaoPosicionado q")
public class ReferenciaCalculoDevolucaoPosicionado implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REF_CALC_DR_GER", sequenceName = "S_REF_CALC_DR_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REF_CALC_DR_GER")
	@Column(name = "NUM_SEQ_REF_CALC_DR")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_FUNDO_PREVD")
	private FundoPrevidencia fundoPrevidencia;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SIT_REF_CALC_DR")
	private SituacaoCalculoReferencia situacaoCalculoReferencia;

	@Column(name = "QTD_DR_CALCULADOS")
	private Long qtdDevolucaoCalculada;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_REF")
	private Date dataReferencia;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_COTA")
	private Date dataCota;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTER")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCL")
	private Date dataInclusao;

	@Column(name = "NOM_USU_ALTER")
	private String nomeUsuarioAlteracao;

	@Column(name = "NOM_USU_INCL")
	private String nomeUsuarioInclusao;

	@Transient
	private String dataFormatadaRef;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public FundoPrevidencia getFundoPrevidencia() {
		return fundoPrevidencia;
	}

	public void setFundoPrevidencia(FundoPrevidencia fundoPrevidencia) {
		this.fundoPrevidencia = fundoPrevidencia;
	}

	public SituacaoCalculoReferencia getSituacaoCalculoReferencia() {
		return situacaoCalculoReferencia;
	}

	public void setSituacaoCalculoReferencia(SituacaoCalculoReferencia situacaoCalculoReferencia) {
		this.situacaoCalculoReferencia = situacaoCalculoReferencia;
	}

	public Long getQtdDevolucaoCalculada() {
		return qtdDevolucaoCalculada;
	}

	public void setQtdDevolucaoCalculada(Long qtdDevolucaoCalculada) {
		this.qtdDevolucaoCalculada = qtdDevolucaoCalculada;
	}

	public Date getDataReferencia() {
		return dataReferencia;
	}

	public void setDataReferencia(Date dataReferencia) {
		this.dataReferencia = dataReferencia;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReferenciaCalculoDevolucaoPosicionado other = (ReferenciaCalculoDevolucaoPosicionado) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	public String getDataFormadataReferencia() {
		return br.com.bbprevidencia.bbpcomum.util.UtilJava.formataDataPorPadrao(this.dataReferencia, "dd/MM/YYYY");
	}

	public String getDataFormatadaRef() {
		return br.com.bbprevidencia.bbpcomum.util.UtilJava.formataDataPorPadrao(this.dataReferencia, "dd/MM/YYYY");
	}

	public void setDataFormatadaRef(String dataFormatadaRef) {
		this.dataFormatadaRef = dataFormatadaRef;
	}

}
