package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Transient;

import com.ibm.icu.math.BigDecimal;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;

@Entity
public class RelatorioValoresDevolucaoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RelatorioValoresDevolucaoDTOPK chavePrimaria;

	@Column(name = "NOM_ABREV_ENTID_PARTIC")
	private String nomePatrocinadora;

	@Column(name = "NUM_MATRIC_PATROC")
	private String matriculaParticipante;

	@Column(name = "NOM_PARTIC")
	private String nomeParticipante;

	@Column(name = "CPF")
	private String cpf;

	@Column(name = "NUM_CNPJ")
	private String cnpj;

	@Column(name = "DAT_REQ")
	private Date dataRequerimento;

	@Column(name = "VALOR_PROVENTO")
	private Double valorBruto;

	@Column(name = "VALOR_IR")
	private Double valorIR;

	@Column(name = "VALOR_DESCONTO")
	private Double valorDescontoTotal;

	@Transient
	private Double valorDesconto;

	@Transient
	private Double valorLiquido;

	@Column(name = "VAL_IND_AJU")
	private Double valorCotaPago;

	@Transient
	private String dataFormatada;

	@Transient
	private boolean valorAcimaCinquentaMil;

	@Transient
	private String detalheCoaf;

	@Transient
	private String chaveOcorrenciaCoaf;

	public RelatorioValoresDevolucaoDTOPK getChavePrimaria() {
		return chavePrimaria;
	}

	public void setChavePrimaria(RelatorioValoresDevolucaoDTOPK chavePrimaria) {
		this.chavePrimaria = chavePrimaria;
	}

	public String getNomePatrocinadora() {
		return nomePatrocinadora;
	}

	public void setNomePatrocinadora(String nomePatrocinadora) {
		this.nomePatrocinadora = nomePatrocinadora;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public Double getValorBruto() {
		return valorBruto;
	}

	public void setValorBruto(Double valorBruto) {
		this.valorBruto = valorBruto;
	}

	public Double getValorIR() {
		return valorIR;
	}

	public void setValorIR(Double valorIR) {
		this.valorIR = valorIR;
	}

	public Double getValorDesconto() {
		return valorDesconto();
	}

	public void setValorDesconto(Double valorDesconto) {
		this.valorDesconto = valorDesconto();
	}

	public Double getValorLiquido() {
		return valorLiquido();
	}

	public void setValorLiquido(Double valorLiquido) {
		this.valorLiquido = valorLiquido();
	}

	public Double getValorCotaPago() {
		return valorCotaPago;
	}

	public void setValorCotaPago(Double valorCotaPago) {
		this.valorCotaPago = valorCotaPago;
	}

	public String getDataFormatada() {
		return UtilJava.formataDataPorPadrao(chavePrimaria.getDataPagamento(), "dd/MM/yyyy");
	}

	public void setDataFormatada(String dataFormatada) {
		this.dataFormatada = dataFormatada;
	}

	public Double getValorDescontoTotal() {
		return valorDescontoTotal;
	}

	public void setValorDescontoTotal(Double valorDescontoTotal) {
		this.valorDescontoTotal = valorDescontoTotal;
	}

	public Double valorLiquido() {
		return new BigDecimal(this.valorBruto - this.valorDescontoTotal).doubleValue();
	}

	public Double valorDesconto() {
		return new BigDecimal(this.valorDescontoTotal - this.valorIR).doubleValue();
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	@Override
	public String toString() {

		String dadosConcatenados = UtilJava.formataDataPorPadrao(this.dataRequerimento, "ddMMyyyy") + ';' + this.getChavePrimaria().getNomeRecebedor() + ';' + this.cpf + ';' + this.cnpj + ';'
				+ UtilJava.formataDataPorPadrao(this.getChavePrimaria().getDataPagamento(), "ddMMyyyy") + ';'
				+ String.format("%.2f", (this.valorBruto - this.valorDescontoTotal == 0D) ? 0D : this.valorBruto) + ';' + String.format("%.2f", this.valorIR) + ';'
				+ String.format("%.2f", (this.valorBruto - this.valorDescontoTotal == 0D) ? 0D : (this.valorBruto - this.valorIR)) + "\n";

		return dadosConcatenados;
	}

	public boolean isValorAcimaCinquentaMil() {
		return this.valorBruto >= 50000;
	}

	public void setValorAcimaCinquentaMil(boolean valorAcimaCinquentaMil) {
		this.valorAcimaCinquentaMil = valorAcimaCinquentaMil;
	}

	public String getDetalheCoaf() {
		String detalhe = "PGTO DE RESGATE - VALOR BRUTO R$ " + this.valorBruto + " - VALOR EMPRESTIMO R$ " + (this.valorDescontoTotal - this.valorIR) + " - VALOR IRRF R$ " + this.valorIR
				+ " - VALOR LIQUIDO R$ " + String.format("%.2f", (this.valorBruto - this.valorDescontoTotal));

		return detalhe.replace(".", "").replace(",", "");
	}

	public void setDetalheCoaf(String detalheCoaf) {
		this.detalheCoaf = detalheCoaf;
	}

	public String getChaveOcorrenciaCoaf() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(this.chavePrimaria.getDataPagamento());
		int mes = (cal.get(Calendar.MONTH) + 1);
		int ano = (cal.get(Calendar.YEAR));

		String chave = UtilJava.adicionaZeroEquerda(2, mes) + UtilJava.adicionaZeroEquerda(4, ano) + "-" + chavePrimaria.getCodigoRecebedor();

		return chave;
	}

	public void setChaveOcorrenciaCoaf(String chaveOcorrenciaCoaf) {
		this.chaveOcorrenciaCoaf = chaveOcorrenciaCoaf;
	}

}
