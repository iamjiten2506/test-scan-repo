package br.com.bbprevidencia.devolucao.enumerador;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;

/**
 * Enum que contém as formas de pagamento das parcelas remanescentes
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 31/01/2017
 *
 * Copyright notice (c) 2013 BBPrevidência S/A
 */
public enum IndicadorFormaPagamentoContribCarencia {
	FINAL("F", "Final", "Pagamento de todas as parcelas remanenscentes quando a última vencer."),
	VENCIMENTO("V", "Vencimento", "Pagamento de parcelas remanenscentes conforme forem vencendo.");

	private String codigo;
	private String descricao;
	private String descricaoLonga;

	private IndicadorFormaPagamentoContribCarencia(String codigo, String descricao, String descricaoLonga) {
		this.codigo = codigo;
		this.descricao = descricao;
		this.descricaoLonga = descricaoLonga;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricaoLonga() {
		return descricaoLonga;
	}

	public void setDescricaoLonga(String descricaoLonga) {
		this.descricaoLonga = descricaoLonga;
	}

	/**
	 * Método encarregado de retornar todos os elementos da Enum
	 * @return
	 */
	public static List<SelectItem> listaElementosEnum() {
		List<SelectItem> listaElementos = new ArrayList<SelectItem>();

		for (IndicadorFormaPagamentoContribCarencia indicador : values()) {
			listaElementos.add(new SelectItem(indicador.getCodigo(), indicador.getDescricao()));
		}

		return listaElementos;
	}

	/**
	 * Retorna a Enum por código
	 * @param codigo
	 * @return
	 */
	public static IndicadorFormaPagamentoContribCarencia getIndicadorFormaPagamentoContribCarencia(String codigo) {
		if (!UtilJava.isStringVazia(codigo)) {
			for (IndicadorFormaPagamentoContribCarencia item : values()) {
				if (item.getCodigo().equalsIgnoreCase(codigo)) {
					return item;
				}
			}
		}

		return null;
	}

}
