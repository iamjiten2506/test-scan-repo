package br.com.bbprevidencia.devolucao.dto;

public class DadosPortabilidadeDTO {

	private String nomePlano;
	private Double valorPortavel;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public Double getValorPortavel() {
		return valorPortavel;
	}

	public void setValorPortavel(Double valorPortavel) {
		this.valorPortavel = valorPortavel;
	}

}
