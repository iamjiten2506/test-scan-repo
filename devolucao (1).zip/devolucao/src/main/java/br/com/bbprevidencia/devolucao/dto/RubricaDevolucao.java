package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.folha.dto.CaracteristicaDirf;
import br.com.bbprevidencia.folha.dto.Consignatario;
import br.com.bbprevidencia.folha.dto.TipoRubrica;

/**
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since   17/01/2017
 * Classe de persistência para tabela RUBRICA_DEVOLUCAO.
 */
@Entity
@Table(name = "RUBRICA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "RubricaDevolucao.findAll", query = "SELECT q FROM RubricaDevolucao q")
public class RubricaDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "RUBRICA_DEV_GER", sequenceName = "S_RD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RUBRICA_DEV_GER")
	@Column(name = "NUM_SEQ_RUB_DEV")
	private Long codigo;

	@Column(name = "NOM_RUB_DEV")
	private String nome;

	@Column(name = "IND_PRO_DES")
	private String indicadorProventoDesconto;

	@Column(name = "IND_APR_CON")
	private String indicadorExigeApropContabil;

	//Fazer joins com objetos a serem criados, todos abaixo
	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIPO_RUBRICA")
	private TipoRubrica tipoRubrica;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CONSIGNATARIO")
	private Consignatario consignatario;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CARACT_DIRF")
	private CaracteristicaDirf caracteristicaDirf;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIndicadorProventoDesconto() {
		return indicadorProventoDesconto;
	}

	public void setIndicadorProventoDesconto(String indicadorProventoDesconto) {
		this.indicadorProventoDesconto = indicadorProventoDesconto;
	}

	public TipoRubrica getTipoRubrica() {
		return tipoRubrica;
	}

	public void setTipoRubrica(TipoRubrica tipoRubrica) {
		this.tipoRubrica = tipoRubrica;
	}

	public Consignatario getConsignatario() {
		return consignatario;
	}

	public void setConsignatario(Consignatario consignatario) {
		this.consignatario = consignatario;
	}

	public CaracteristicaDirf getCaracteristicaDirf() {
		return caracteristicaDirf;
	}

	public void setCaracteristicaDirf(CaracteristicaDirf caracteristicaDirf) {
		this.caracteristicaDirf = caracteristicaDirf;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getIndicadorExigeApropContabil() {
		return indicadorExigeApropContabil;
	}

	public void setIndicadorExigeApropContabil(String indicadorExigeApropContabil) {
		this.indicadorExigeApropContabil = indicadorExigeApropContabil;
	}

	@Transient
	public boolean isProvento() {
		return this.indicadorProventoDesconto.equals("P");
	}

	@Transient
	public boolean isDesconto() {
		return this.indicadorProventoDesconto.equals("D");
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((caracteristicaDirf == null) ? 0 : caracteristicaDirf.hashCode());
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((consignatario == null) ? 0 : consignatario.hashCode());
		result = prime * result + ((dataAlteracao == null) ? 0 : dataAlteracao.hashCode());
		result = prime * result + ((dataInclusao == null) ? 0 : dataInclusao.hashCode());
		result = prime * result + ((indicadorProventoDesconto == null) ? 0 : indicadorProventoDesconto.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((nomeUsuarioAlteracao == null) ? 0 : nomeUsuarioAlteracao.hashCode());
		result = prime * result + ((nomeUsuarioInclusao == null) ? 0 : nomeUsuarioInclusao.hashCode());
		result = prime * result + ((tipoRubrica == null) ? 0 : tipoRubrica.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RubricaDevolucao other = (RubricaDevolucao) obj;
		if (caracteristicaDirf == null) {
			if (other.caracteristicaDirf != null)
				return false;
		} else if (!caracteristicaDirf.equals(other.caracteristicaDirf))
			return false;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (consignatario == null) {
			if (other.consignatario != null)
				return false;
		} else if (!consignatario.equals(other.consignatario))
			return false;
		if (dataAlteracao == null) {
			if (other.dataAlteracao != null)
				return false;
		} else if (!dataAlteracao.equals(other.dataAlteracao))
			return false;
		if (dataInclusao == null) {
			if (other.dataInclusao != null)
				return false;
		} else if (!dataInclusao.equals(other.dataInclusao))
			return false;
		if (indicadorProventoDesconto == null) {
			if (other.indicadorProventoDesconto != null)
				return false;
		} else if (!indicadorProventoDesconto.equals(other.indicadorProventoDesconto))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (nomeUsuarioAlteracao == null) {
			if (other.nomeUsuarioAlteracao != null)
				return false;
		} else if (!nomeUsuarioAlteracao.equals(other.nomeUsuarioAlteracao))
			return false;
		if (nomeUsuarioInclusao == null) {
			if (other.nomeUsuarioInclusao != null)
				return false;
		} else if (!nomeUsuarioInclusao.equals(other.nomeUsuarioInclusao))
			return false;
		if (tipoRubrica == null) {
			if (other.tipoRubrica != null)
				return false;
		} else if (!tipoRubrica.equals(other.tipoRubrica))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RubricaDevolucao [codigo=" + codigo + ", nome=" + nome + ", indicadorProventoDesconto=" + indicadorProventoDesconto + ", tipoRubrica=" + tipoRubrica + ", consignatario="
				+ consignatario + ", caracteristicaDirf=" + caracteristicaDirf + ", dataAlteracao=" + dataAlteracao + ", dataInclusao=" + dataInclusao + ", nomeUsuarioAlteracao="
				+ nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + "]";
	}

}