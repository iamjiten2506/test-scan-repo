package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Antonio Figueiredo
 * @since   07/05/2018
 * Classe de persistência para tabela LOTE_PROC_REF_CALC_DR.
 */
@Entity
@Table(name = "LOTE_PROC_REF_CALC_DR", schema = "OWN_DR")
@NamedQuery(name = "LoteProcessamentoReferenciaCalcDevolucao.findAll", query = "SELECT q FROM LoteProcessamentoReferenciaCalcDevolucao q")
public class LoteProcessamentoReferenciaCalcDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "LOTE_PROC_REF_CALC_DR_GER", sequenceName = "S_LPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LOTE_PROC_REF_CALC_DR_GER")
	@Column(name = "NUM_SEQ_LT_PROC_REF_CALC_DR")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REF_CALC_DR")
	private ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado;

	@Column(name = "DAT_LOTE")
	private Date dataLoteProcessamento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTER")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCL")
	private Date dataInclusao;

	@Column(name = "NOM_USU_ALTER")
	private String nomeUsuarioAlteracao;

	@Column(name = "NOM_USU_INCL")
	private String nomeUsuarioInclusao;

	public LoteProcessamentoReferenciaCalcDevolucao() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoteProcessamentoReferenciaCalcDevolucao(ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado, Date dataLoteProcessamento, Date dataInclusao,
			String nomeUsuarioInclusao) {
		super();
		this.referenciaCalculoDevolucaoPosicionado = referenciaCalculoDevolucaoPosicionado;
		this.dataLoteProcessamento = dataLoteProcessamento;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public ReferenciaCalculoDevolucaoPosicionado getReferenciaCalculoDevolucaoPosicionado() {
		return referenciaCalculoDevolucaoPosicionado;
	}

	public void setReferenciaCalculoDevolucaoPosicionado(ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado) {
		this.referenciaCalculoDevolucaoPosicionado = referenciaCalculoDevolucaoPosicionado;
	}

	public Date getDataLoteProcessamento() {
		return dataLoteProcessamento;
	}

	public void setDataLoteProcessamento(Date dataLoteProcessamento) {
		this.dataLoteProcessamento = dataLoteProcessamento;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoteProcessamentoReferenciaCalcDevolucao other = (LoteProcessamentoReferenciaCalcDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}