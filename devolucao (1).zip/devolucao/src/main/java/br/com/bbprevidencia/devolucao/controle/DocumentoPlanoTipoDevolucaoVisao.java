package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoPlanoTipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.DocumentoPlanoTipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * Documento Devolução
 * 
 * @author  BBPF0170 - Magson Dias
 * @since 24/04/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

/**
 * @author  BBPF0170 - Magson Dias
 *
 */
@Scope("session")
@Component("documentoPlanoTipoDevolucaoVisao")
public class DocumentoPlanoTipoDevolucaoVisao {
	private static final String FW_DOCUMENTO_TIPO_DEVOLUCAO = "/paginas/documentoPlanoTipoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	public static final String ASSUNTO_ALTERAR_SENHA = "Senha acesso ao sistema BB Previdência";
	private static final Logger log = Logger.getLogger(DocumentoPlanoTipoDevolucaoVisao.class);

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private DocumentoPlanoTipoDevolucaoBO documentoPlanoTipoDevolucaoBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;
	@Autowired
	private DocumentoDevolucaoBO documentoDevolucaoBO;

	//private Long codigoEntidadeParticipante;
	//private Long codigoTipoDevolucao;
	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private boolean possuiAcessoTotal;
	private boolean listarStatus;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private DocumentoPlanoTipoDevolucao documentoPlanoTipoDevolucao;
	private Long codigoDocumentoDevolucao;
	private String mensagem;
	private TipoDevolucao tipoDevolucao;
	private DocumentoDevolucao documentoDevolucao;

	//private List<SelectItem> listaEntidadeParticipante;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<DocumentoPlanoTipoDevolucao> listaDocumentoPlanoTipoDevolucao;
	private List<TipoDevolucao> listaTipoDevolucao;
	private List<DocumentoDevolucao> listaDocumentoDevolucao;
	private List<EntidadeParticipante> listaEntidadeParticipante;

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0070 - Magson Dias.
	 * @since   02/05/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("documentoPlanoTipoDevolucao");
		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("documentoPlanoTipoDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
		//this.listarStatus = true;
		limpar();
		this.documentoPlanoTipoDevolucao = new DocumentoPlanoTipoDevolucao();
		this.listaEntidadeParticipante = listarEntidadeParticipante();
		this.listaTipoDevolucao = listarTipoDevolucao();

		this.listaDocumentoDevolucao = this.documentoDevolucaoBO.listarTodosDocumentoDevolucao();

		return FW_DOCUMENTO_TIPO_DEVOLUCAO;
	}

	/**
	 * Método para salvar um novo registro do tipo Documento por plano e tipo de devolução.
	 *  
	 * @author  BBPF0070 - Magson Dias.
	 * @since   02/05/2017
	 * @return {@link String}
	 */
	public String salvarDocumentoPorPlano() {
		try {
			if (validaCampos()) {
				return "";
			}

			if (this.documentoPlanoTipoDevolucao.getCodigo() == null) {
				this.documentoPlanoTipoDevolucao.setDataInclusao(new Date());
				this.documentoPlanoTipoDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Documento de devolução salvo com sucesso!";
			} else if (this.documentoPlanoTipoDevolucao.getCodigo() != null) {
				this.documentoPlanoTipoDevolucao.setDataAlteracao(new Date());
				this.documentoPlanoTipoDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Documento de devolução alterado com sucesso!";
			}

			this.documentoPlanoTipoDevolucaoBO.salvarDocumentoDevolucao(this.documentoPlanoTipoDevolucao);

			Mensagens.addMsgInfo(mensagem);
		} catch (Exception ex) {
			ex.getMessage();
		}

		this.listarStatus = true;
		return FW_DOCUMENTO_TIPO_DEVOLUCAO;
	}

	/**
	 * Método para deletar um registo do tipo de documento por plano e tipo de devolução. 
	 *  
	 * @author  BBPF0070 - Magson Dias.
	 * @since   02/05/2017
	 * @return {@link String}
	 * @param  {@link DocumentoPlanoTipoDevolucao}
	 */
	public String deletarDocumento(DocumentoPlanoTipoDevolucao documentoPlanoTipoDevolucao) {
		try {
			this.documentoPlanoTipoDevolucaoBO.apagarDocumentoPlanoTipoDevolucao(documentoPlanoTipoDevolucao);
			mensagem = "Documento de devolução deletado com sucesso!";
			retornar();
			Mensagens.addMsgInfo(mensagem);
		} catch (Exception e) {
			e.getMessage();
		}
		return FW_DOCUMENTO_TIPO_DEVOLUCAO;
	}

	/**
	 * Cria uma lista de itens da entidade participante.
	 *  
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @return {@link  List<SelectItem> }
	 */
	public List<EntidadeParticipante> listarEntidadeParticipante() {
		return this.entidadeParticipanteBO.listarEntidadeParticipante();
	}

	/**
	 * Método responsável por retornar a lista de Planos associados à patrocionadora selecionada.
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return	{@link String}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {

		if (this.entidadeParticipante == null) {
			this.setListaPlanoPrevidencia(new ArrayList<PlanoPrevidencia>());
		} else {
			try {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante()));
				
				if (!UtilJava.isColecaoVazia(this.listaPlanoPrevidencia)) {
					if (!UtilJava.isColecaoVazia(this.documentoPlanoTipoDevolucaoBO.consultarDocumentoPlanoTipoDevolucaoPorListaPlano(this.listaPlanoPrevidencia, false))){
						this.listaDocumentoPlanoTipoDevolucao = new ArrayList<>(this.documentoPlanoTipoDevolucaoBO.consultarDocumentoPlanoTipoDevolucaoPorListaPlano(this.listaPlanoPrevidencia, false));
					}
				}
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}
		return FW_DOCUMENTO_TIPO_DEVOLUCAO;
	}

	/**
	 * Método responsável por listar todos os tipos de devoluções
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @return {@link List<SelectItem>}
	 */
	public List<TipoDevolucao> listarTipoDevolucao() {

		return tipoDevolucaoBO.listarTodosTipoDevolucao();
	}

	/**
	 * Método para retornar os documento por plano e codigo do tipo de devolução.
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 03/05/2017
	 * @return {@link String}
	 */
	public String pesquisarDocumentoTipoDevolucao() {
		if ((this.getEntidadeParticipante() != null) && (this.planoPrevidencia != null || this.tipoDevolucao != null || this.documentoDevolucao != null)) {
			this.listaDocumentoPlanoTipoDevolucao = new ArrayList<DocumentoPlanoTipoDevolucao>();

			this.listaDocumentoPlanoTipoDevolucao = this.documentoPlanoTipoDevolucaoBO.listaDocumentoPlanoTipoDevolucaoPorPlanoTipoDevolucaoDocumento(
					this.planoPrevidencia,
					this.tipoDevolucao,
					this.documentoDevolucao);
		}

		return FW_DOCUMENTO_TIPO_DEVOLUCAO;
	}

	/**
	 * Método para limpar a pesquisa. 
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 03/05/2017
	 * @return {@link String}
	 */
	public String limparPesquisa() {
		limpar();
		return FW_DOCUMENTO_TIPO_DEVOLUCAO;
	}

	/**
	 * Método responsalveu por habilitar a tela de um novo cadastro. 
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 	02/05/2017
	 */
	public void cadastraNovoDocumento() {
		listarStatus = false;
		this.documentoPlanoTipoDevolucao = new DocumentoPlanoTipoDevolucao();
		this.codigoDocumentoDevolucao = null;
		this.tipoDevolucao = null;
	}

	/**
	 * Método responsalveu por controla a edição/salva um documento de devolução. 
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 02/05/2017
	 * @param {@link DocumentoPlanoTipoDevolucao }
	 */
	public void editarDocumento(DocumentoPlanoTipoDevolucao documentoPlanoTipoDevolucao) {
		this.documentoPlanoTipoDevolucao = new DocumentoPlanoTipoDevolucao();
		this.setDocumentoPlanoTipoDevolucao(documentoPlanoTipoDevolucao);

		listarStatus = false;

	}

	/**
	 * Método responsalveu por limpar objetos apos ação.
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 03/05/2017
	 * @return {@link String}
	 */
	public void limpar() {
		listarStatus = true;
		this.documentoPlanoTipoDevolucao = null;
		this.planoPrevidencia = null;
		this.entidadeParticipante = null;
		this.tipoDevolucao = null;
		this.documentoDevolucao = null;

		this.listaDocumentoPlanoTipoDevolucao = new ArrayList<DocumentoPlanoTipoDevolucao>();
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
	}

	/**
	 * Método para retornar a pagina de pesquisa.   
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 03/05/2017
	 */
	public void retornar() {
		listarStatus = true;
		this.listaDocumentoPlanoTipoDevolucao = new ArrayList<>(this.documentoPlanoTipoDevolucaoBO.consultarDocumentoPlanoTipoDevolucaoPorListaPlano(this.listaPlanoPrevidencia, false));
	}

	/**
	 * Método para validar campos
	 * @author bbpf0170 - Magson Dias
	 * @return {@link boolean}
	 */

	private boolean validaCampos() {
		boolean res = false;
		if (this.documentoPlanoTipoDevolucao.getPlanoPrevidencia() == null) {
			addMsgErro("Selecione um plano!");
			res = true;
		}
		if (this.documentoPlanoTipoDevolucao.getTipoDevolucao() == null) {
			addMsgErro("Selecione um tipo de devolução!");
			res = true;
		}

		if (this.documentoPlanoTipoDevolucao.getDocumentoDevolucao() == null) {
			addMsgErro("Selecione um tipo de documento de devolução!");
			res = true;
		}

		if (this.documentoPlanoTipoDevolucao.getDataInicio() == null) {
			addMsgErro("Campo data inicio é de preenchimento obrigatório!");
			res = true;
		}
		if (this.documentoPlanoTipoDevolucao.getIndicativoValido() == null) {
			addMsgErro("Selecione um indicativo! (Valido)");
		}
		if (this.documentoPlanoTipoDevolucao.getIndicativoObrigatorio() == null) {
			addMsgErro("Selecione um indicativo! (Obrigatório)");
		}
		return res;
	}

	/**
	 * Método para adiciona a mensage de erro no faces.
	 * @author  BBPF0170 - MAGSON 
	 * @param {@link String mensagem}
	 */
	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

	// abaixa é apresentado os gettes e settes
	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public DocumentoPlanoTipoDevolucao getDocumentoPlanoTipoDevolucao() {
		return documentoPlanoTipoDevolucao;
	}

	public void setDocumentoPlanoTipoDevolucao(DocumentoPlanoTipoDevolucao documentoPlanoTipoDevolucao) {
		this.documentoPlanoTipoDevolucao = documentoPlanoTipoDevolucao;
	}

	public List<DocumentoPlanoTipoDevolucao> getListaDocumentoPlanoTipoDevolucao() {
		return listaDocumentoPlanoTipoDevolucao;
	}

	public void setListaDocumentoPlanoTipoDevolucao(List<DocumentoPlanoTipoDevolucao> listaDocumentoPlanoTipoDevolucao) {
		this.listaDocumentoPlanoTipoDevolucao = listaDocumentoPlanoTipoDevolucao;
	}

	public Long getCodigoDocumentoDevolucao() {
		return codigoDocumentoDevolucao;
	}

	public void setCodigoDocumentoDevolucao(Long codigoDocumentoDevolucao) {
		this.codigoDocumentoDevolucao = codigoDocumentoDevolucao;
	}

	public List<DocumentoDevolucao> getListaDocumentoDevolucao() {
		return listaDocumentoDevolucao;
	}

	public void setListaDocumentoDevolucao(List<DocumentoDevolucao> listaDocumentoDevolucao) {
		this.listaDocumentoDevolucao = listaDocumentoDevolucao;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public DocumentoDevolucao getDocumentoDevolucao() {
		return documentoDevolucao;
	}

	public void setDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		this.documentoDevolucao = documentoDevolucao;
	}

}
