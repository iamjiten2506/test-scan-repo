package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter a Situação Devolução
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   02/02/2017
 * 
 *     Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("situacaoDevolucaoVisao")
public class SituacaoDevolucaoVisao {

	private static final String FW_SITUACAO_DEVOLUCAO = "/paginas/situacaoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	private List<SituacaoDevolucao> listaSituacaoDevolucao;

	private SituacaoDevolucao situacaoDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página da Situação da Regra de Devolução
	 * @author  BBPF0415 - Yanisley Mora  Ritchie
	 * @since 25/01/2017
	 * @return {@link String}
	 */
	public String iniciarSituacaoDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("situacaoDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.situacaoDevolucao = null;

		this.listarStatus = true;

		listaSituacaoDevolucao = new ArrayList<SituacaoDevolucao>(situacaoDevolucaoBO.listarTodosSituacaoDevolucao());

		return FW_SITUACAO_DEVOLUCAO;
	}

	public SituacaoDevolucaoBO getSituacaoDevolucaoBO() {
		return situacaoDevolucaoBO;
	}

	public void setSituacaoDevolucaoBO(SituacaoDevolucaoBO situacaoDevolucaoBO) {
		this.situacaoDevolucaoBO = situacaoDevolucaoBO;
	}

	public List<SituacaoDevolucao> getListaSituacaoDevolucao() {
		return listaSituacaoDevolucao;
	}

	public void setListaSituacaoDevolucao(List<SituacaoDevolucao> listaSituacaoDevolucao) {
		this.listaSituacaoDevolucao = listaSituacaoDevolucao;
	}

	public SituacaoDevolucao getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

}
