package br.com.bbprevidencia.devolucao.util;

import javax.servlet.http.HttpServletRequest;

import org.primefaces.context.PrimeFacesContext;

public class AmbienteUtil {

	public static enum Ambiente {
		DESENVOLVIMENTO,
		CLONE,
		PRODUCAO
	}

	public static Ambiente getAmbiente() {
		HttpServletRequest request = (HttpServletRequest) PrimeFacesContext.getCurrentInstance().getExternalContext().getRequest();
		String serverName = request.getServerName().toLowerCase();

		if (serverName.contains("localhost"))
			return Ambiente.DESENVOLVIMENTO;
		else if (serverName.contains("sistemashmg.bbp.com.br"))
			return Ambiente.CLONE;
		else
			return Ambiente.PRODUCAO;
	}

	public static String getURLBase() {
		switch (AmbienteUtil.getAmbiente()) {
		case PRODUCAO:
			return "https://www.bbprevidencia.com.br";
		case DESENVOLVIMENTO:
			// return "http://localhost:8080";
			return "http://sistemashmg.bbp.com.br";
		default:
			return "http://sistemashmg.bbp.com.br";
		}
	}

	public static String getUrlAmbiente() {
		HttpServletRequest request = (HttpServletRequest) PrimeFacesContext.getCurrentInstance().getExternalContext().getRequest();
		return request.getRequestURL().toString().replace(request.getRequestURI(), "");
	}
}
