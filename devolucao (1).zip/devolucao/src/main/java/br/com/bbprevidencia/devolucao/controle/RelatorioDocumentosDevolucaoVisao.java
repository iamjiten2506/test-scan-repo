package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DocumentoPlanoTipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.DocumentoPlanoTipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RetornoDocumentoPlanoTipoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório Quantitativo de Devoluções.
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 15/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioDocumentosDevolucaoVisao")
public class RelatorioDocumentosDevolucaoVisao {

	private static final String FW_RELATORIO_DOCUMENTOS_DEVOLUCAO = "/paginas/relatorioDocumentosDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioDocumentosDevolucaoVisao.class);

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private DocumentoPlanoTipoDevolucaoBO documentoTipoDevolucaoBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;

	/**
	 * Método encarregado de carregar a página incial de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 08/02/2017
	 * @return
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidencia());

		return FW_RELATORIO_DOCUMENTOS_DEVOLUCAO;
	}

	/**
	 * Método encarregado de emitir o relatório
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/03/2017
	 */
	public void exportarRelatorio(ActionEvent e) {
		try {
			if (UtilJava.isColecaoVazia(this.listaPlanoPrevidenciaSelecionados)) {
				throw new PrevidenciaException("Deve selecionar algum plano antes de emitir o relatório.");
			}

			List<RetornoDocumentoPlanoTipoDevolucaoDTO> dataSource = new ArrayList<RetornoDocumentoPlanoTipoDevolucaoDTO>();

			List<DocumentoPlanoTipoDevolucao> listaDocs = new ArrayList<DocumentoPlanoTipoDevolucao>(this.documentoTipoDevolucaoBO.consultarDocumentoPlanoTipoDevolucaoPorListaPlano(
					this.listaPlanoPrevidenciaSelecionados,
					false));

			if (UtilJava.isColecaoDiferenteDeVazia(listaDocs)) {
				for (DocumentoPlanoTipoDevolucao dPt : listaDocs) {
					RetornoDocumentoPlanoTipoDevolucaoDTO item = new RetornoDocumentoPlanoTipoDevolucaoDTO();
					item.setNomePlano(dPt.getPlanoPrevidencia().getNomeAbreviadoPlano());
					item.setTipoDevolucao(dPt.getTipoDevolucao().getNome());
					item.setDocumento(dPt.getDocumentoDevolucao().getNome());
					item.setDocumentoObg(dPt.getIndicativoObrigatorio().equalsIgnoreCase("S") ? "SIM" : "NÃO");
					item.setDescricaoAdicional(dPt.getDocumentoDevolucao().getDescricaoSolicitacao03());

					dataSource.add(item);
				}

				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);
				String nomeArquivo = relatorioUtil.gerarRelatorio("documentosDevolucao", dataSource, parametros);
				relatorioUtil.abrirPoupUp(nomeArquivo);
			} else {
				throw new PrevidenciaException("Não foram encontrados documentos para os planos selecioandos.");
			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro("Erro ao exportar relatório: " + ex.getMessage());
		}

	}

	/**
	 * Limpa os valores de pesquisa
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @return
	 */
	public void limparPesquisa() {
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

}
