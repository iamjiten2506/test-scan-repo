package br.com.bbprevidencia.devolucao.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Repository;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.dto.AcompSolPortParticipante;
import br.com.bbprevidencia.infra.repository.JpaDao;

/**
 * Classe de acesso aos dados de Acompanhamento de Solicitação de Portabilidade
 *
 * @author  BBPF0468 - Carlos Wallace
 * @since 31/07/2018
 * 
 *        Copyright notice (c) 2019 BBPrevidência S/A
 */
@Repository
@Qualifier("acompSolPortParticipanteDao")
@Scope(proxyMode = ScopedProxyMode.NO, value = "prototype")
public class AcompSolPortParticipanteDAO extends JpaDao<AcompSolPortParticipante> implements Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(AcompSolPortParticipanteDAO.class);

	/**
	 * Salva ou altera a solicitação correspondente. Salva se o mesmo já contenha
	 * id na sessao do provedor de persistência, ou insere se nao há id
	 * correspondente.
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 31/07/2019
	 * @param {@link AcompSolPortParticipante}
	 * @throws PrevidenciaException
	 */
	//
	public void salvarAcompSolicitacao(AcompSolPortParticipante acompSolPortParticipante) throws PrevidenciaException {

		if (acompSolPortParticipante == null) {
			throw new PrevidenciaException("O Objeto Devolução Detalhe deve estar inicializado para inserçao ou alteraçao.");
		} else {

			try {
				if (acompSolPortParticipante.getCodigo() != null) {
					update(acompSolPortParticipante);
				} else {
					save(acompSolPortParticipante);
				}
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Salva lista solicitação correspondente. Salva se o mesmo já contenha
	 * id na sessao do provedor de persistência, ou insere se nao há id
	 * correspondente.
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 31/07/2019
	 * @param {@link AcompSolPortParticipante}
	 * @throws PrevidenciaException
	 */
	public void salvarListaAcompSolicitacao(List<AcompSolPortParticipante> listaAcompSolPortPartic) throws PrevidenciaException {

		if (UtilJava.isColecaoVazia(listaAcompSolPortPartic)) {
			throw new PrevidenciaException("A coleção de solicitações deve estar preenchida");
		} else {

			try {
				saveAll(listaAcompSolPortPartic);

				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Metodo responsável por listar todas as solicitações por filtro 
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 31/07/2018	 * 
	 * @return {@link - List<AcompSolPortParticipante>}
	 * @throws PrevidenciaException
	 */
	public List<AcompSolPortParticipante> pesquisarAcompSolicitacao(Participante participante, String status, Date dataInicio, Date dataFim) throws PrevidenciaException {

		try {

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT acomp ");
			sql.append("   from AcompSolPortParticipante acomp ");

			if (status != null && status != "") {

				//Verifica as situações
				if (status.equals("1")) {//Análise

					sql.append("  WHERE acomp.solicitacaoProcessada = 0");

				} else if (status.equals("2")) {//Aguardando TSP

					sql.append("  WHERE acomp.statusAguardandoTSP = 0");

				} else if (status.equals("3")) {//Pendência

					sql.append("  WHERE acomp.statusPendenciaRgCpf = 0 or acomp.statusPendenciaDeslig = 0");

				} else if (status.equals("4")) {//Aguardando Fechar Processamento

					sql.append("  WHERE acomp.statusAguardandoProcessamento = 0");

				} else if (status.equals("5")) {//Concluída

					sql.append("  WHERE  acomp.statusAguardandoTSP = 1 and acomp.statusPendenciaRgCpf = 1 and acomp.statusPendenciaDeslig = 1  and " + " acomp.statusAguardandoProcessamento = 1 and "
							+ " acomp.solicitacaoProcessada = 0");

				} else {//Processada

					sql.append("  WHERE acomp.statusAguardandoTSP = 1 and acomp.statusPendenciaRgCpf = 1 and acomp.statusPendenciaDeslig = 1 and acomp.statusAguardandoProcessamento = 1 " + " and  "
							+ " acomp.solicitacaoProcessada = 1");

				}

			}

			if (participante != null) {

				if (sql.toString().contains("WHERE")) {

					sql.append(" and acomp.participante.codigo = " + participante.getCodigo());

				} else {

					sql.append(" WHERE acomp.participante.codigo = " + participante.getCodigo());

				}

			}

			if (dataInicio != null) {

				if (sql.toString().contains("WHERE")) {

					sql.append(" and (acomp.dataInclusao >= :dataInicio or :dataInicio is null)");

				} else {

					sql.append(" WHERE (acomp.dataInclusao >= :dataInicio or :dataInicio is null)");

				}

			}

			if (dataFim != null) {

				if (sql.toString().contains("WHERE")) {

					sql.append(" and (acomp.dataInclusao <= :dataFim or :dataFim is null)");

				} else {

					sql.append(" WHERE (acomp.dataInclusao <= :dataFim or :dataFim is null)");

				}

			}

			sql.append(" order by acomp.dataInclusao");

			Query query = getEntityManager().createQuery(sql.toString());

			//Caso dataInicio tenha sido informada adiciona como parâmetro na Query
			if (dataInicio != null) {

				query.setParameter("dataInicio", dataInicio, TemporalType.DATE);

			}

			//Caso dataFim tenha sido informada adiciona como parâmetro na Query
			if (dataFim != null) {

				query.setParameter("dataFim", dataFim, TemporalType.DATE);

			}

			return query.getResultList();

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar esta operaçao", e);
		}

	}
}
