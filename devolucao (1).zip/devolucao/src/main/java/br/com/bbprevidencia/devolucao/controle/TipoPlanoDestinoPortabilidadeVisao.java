package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.TipoPlanoDestinoPortabilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.TipoPlanoDestinoPortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.TipoEntidadePortabilidadeEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe controller que manipula as requisições do TIPO ENTIDADE DESTINO PORTABILIDADE.
 * 
 * @author Magson Dias
 * @since 23/02/2017
 * 
 * Copyright notice (c) 2016 BBPrevidência S/A
 */

@Scope("session")
@Component("tipoPlanoDestinoPortabilidadeVisao")
public class TipoPlanoDestinoPortabilidadeVisao {

	private static final String FW_TIPO_PLANO_DESTINO_PORTAB = "/paginas/tipoPlanoDestinoPortabilidade.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private TipoPlanoDestinoPortabilidadeDevolucaoBO tipoPlanoDestinoPortabilidadeDevolucaoBO;

	private List<TipoPlanoDestinoPortabilidadeDevolucao> listaTipoPlanoDestinoPortabilidadeDevolucao;
	private List<TipoEntidadePortabilidadeEnum> listaEnumTipoEntidadePortabilidade;
	private TipoEntidadePortabilidadeEnum tipoEntidadePortabilidadeEnum;

	private TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidadeDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página dos tipos de plano destino portabilidade
	 * @author  BBPF00170 - MAGSON DIAS
	 * @since 22/02/2017
	 * @return {@link String}
	 */
	public String inciciarTipoPlanoDestinoPortabilidade() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.listarStatus = true;
		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("tipoPlanoDestinoPortabilidade");
		} else {
			this.possuiAcessoTotal = false;
		}
		this.listarStatus = true;
		this.limparTela();

		this.listaTipoPlanoDestinoPortabilidadeDevolucao = new ArrayList<TipoPlanoDestinoPortabilidadeDevolucao>(tipoPlanoDestinoPortabilidadeDevolucaoBO.listarTodos());
		return FW_TIPO_PLANO_DESTINO_PORTAB;

	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da página
	 * 
	 * @author  BBPF0170 - Magson
	 * @since 	16/02/2017
	 * 
	 */
	public void limparTela() {
		this.tipoPlanoDestinoPortabilidadeDevolucao = null;
		this.listaTipoPlanoDestinoPortabilidadeDevolucao = new ArrayList<TipoPlanoDestinoPortabilidadeDevolucao>(tipoPlanoDestinoPortabilidadeDevolucaoBO.listarTodos());
	}

	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 16/02/2017
	 */
	public void controlarEdicaoVisualizacao() {
		if (isListarStatus()) {
			this.listaTipoPlanoDestinoPortabilidadeDevolucao = new ArrayList<TipoPlanoDestinoPortabilidadeDevolucao>(tipoPlanoDestinoPortabilidadeDevolucaoBO.listarTodos());
		}
		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método que seleciona um TIPO ENTIDADE DESTINO PORTABILIDADE, e a colocar em modo de edição. 
	 * 
	 * @author  BBPF0170 - Magson Dias.
	 * @since 23/02/2017
	 * @param {@link TipoPlanoDestinoPortabilidadeDevolucao}
	 */
	public void editarTipoPlanoDestinoPortabilidade(TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidadeDevolucao) {
		tipoPlanoDestinoPortabilidadeDevolucao.setDataAlteracao(new Date());
		tipoPlanoDestinoPortabilidadeDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
		setTipoPlanoDestinoPortabilidadeDevolucao(tipoPlanoDestinoPortabilidadeDevolucao);
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método que chama a tela para um novo cadastro de TIPO ENTIDADE DESTINO PORTABILIDADE.
	 * @author BBPF0170	- MAGSON 
	 * @since 23/02/2017
	 */
	public void cadastrarNovaTipoPlanoDestinoPortabilidade() {
		tipoPlanoDestinoPortabilidadeDevolucao = new TipoPlanoDestinoPortabilidadeDevolucao();
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método encarregado de salavar um novo registro TIPO ENTIDADE DESTINO PORTABILIDADE.
	 * 
	 * @author  BBPF00170 - MAGSON 
	 * @since 16/02/2017
	 * @return {@link String}
	 */
	public String salvarTipoPlanoDestinoPortabiliade() {
		try {
			// valida dados obrigatórios
			if (validaCampos()) {
				return "";
			}

			if (tipoPlanoDestinoPortabilidadeDevolucao.getCodigo() == null) {
				tipoPlanoDestinoPortabilidadeDevolucao.setDataInclusao(new Date());
				tipoPlanoDestinoPortabilidadeDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			}
			tipoPlanoDestinoPortabilidadeDevolucaoBO.salvarTipoPlanoDestinoPortabilidadeDevolucao(tipoPlanoDestinoPortabilidadeDevolucao);

			Mensagens.addMessage("DEV_VMSG024", tipoPlanoDestinoPortabilidadeDevolucao.getCodigo() == null ? "salvo" : "atualizado");

			listaTipoPlanoDestinoPortabilidadeDevolucao = new ArrayList<TipoPlanoDestinoPortabilidadeDevolucao>(tipoPlanoDestinoPortabilidadeDevolucaoBO.listarTodos());
			controlarEdicaoVisualizacao();
			return FW_TIPO_PLANO_DESTINO_PORTAB;

		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar Tipo entidade destino portabilidade.");
			return "";
		}
	}

	/**
	 * Método encarregado de deletar um registro TIPO ENTIDADE DESTINO PORTABILIDADE.
	 * 
	 * @author  BBPF00170 - MAGSON 
	 * @since 23/02/2017
	 * @param {@link TipoPlanoDestinoPortabilidadeDevolucao}
	 * @return {@link String}
	 */
	public String deletarTipoPlanoDestinoPortabilidade(TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidadeDevolucao) {
		try {
			tipoPlanoDestinoPortabilidadeDevolucaoBO.apagarTipoPlanoDestinoPortabilidadeDevolucao(tipoPlanoDestinoPortabilidadeDevolucao);

			listaTipoPlanoDestinoPortabilidadeDevolucao = new ArrayList<TipoPlanoDestinoPortabilidadeDevolucao>(tipoPlanoDestinoPortabilidadeDevolucaoBO.listarTodos());
			Mensagens.addMsgInfo("Tipo Entidade excluído com sucesso!");
			return FW_TIPO_PLANO_DESTINO_PORTAB;
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar o registro.");
			return "";
		}
	}

	/**
	 * Método responsável por validar os campos da tela tipo entidade destino portabilidade. 
	 * @author  BBPF00170 - MAGSON 
	 * @return boolean
	 */
	private boolean validaCampos() {
		boolean res = false;
		if (UtilJava.isStringVazia(tipoPlanoDestinoPortabilidadeDevolucao.getNome())) {
			addMsgErro("Campo nome de preenchimento obrigatório.");
			res = true;
		}
		if (UtilJava.isStringVazia(tipoPlanoDestinoPortabilidadeDevolucao.getDescricao())) {
			addMsgErro("Campo descrição de preenchimento obrigatório.");
			res = true;
		}
		if (UtilJava.isStringVazia(tipoPlanoDestinoPortabilidadeDevolucao.getTipoEntidadePortabilidadeEnum().getCodigo())) {
			addMsgErro("Campo tipo é de seleção obrigatório.");
			res = true;
		}
		return res;
	}

	/**
	 * Adiciona a mensage de erro no faces.
	 * @author  BBPF00170 - MAGSON 
	 * @param mensagem
	 */
	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

	public TipoPlanoDestinoPortabilidadeDevolucaoBO getTipoPlanoDestinoPortabilidadeDevolucaoBO() {
		return tipoPlanoDestinoPortabilidadeDevolucaoBO;
	}

	public void setTipoPlanoDestinoPortabilidadeDevolucaoBO(TipoPlanoDestinoPortabilidadeDevolucaoBO tipoPlanoDestinoPortabilidadeDevolucaoBO) {
		this.tipoPlanoDestinoPortabilidadeDevolucaoBO = tipoPlanoDestinoPortabilidadeDevolucaoBO;
	}

	public List<TipoPlanoDestinoPortabilidadeDevolucao> getListaTipoPlanoDestinoPortabilidadeDevolucao() {
		return listaTipoPlanoDestinoPortabilidadeDevolucao;
	}

	public void setListaTipoPlanoDestinoPortabilidadeDevolucao(List<TipoPlanoDestinoPortabilidadeDevolucao> listaTipoPlanoDestinoPortabilidadeDevolucao) {
		this.listaTipoPlanoDestinoPortabilidadeDevolucao = listaTipoPlanoDestinoPortabilidadeDevolucao;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public List<TipoEntidadePortabilidadeEnum> getListaEnumTipoEntidadePortabilidade() {
		return listaEnumTipoEntidadePortabilidade;
	}

	public void setListaEnumTipoEntidadePortabilidade(List<TipoEntidadePortabilidadeEnum> listaEnumTipoEntidadePortabilidade) {
		this.listaEnumTipoEntidadePortabilidade = listaEnumTipoEntidadePortabilidade;
	}

	public TipoPlanoDestinoPortabilidadeDevolucao getTipoPlanoDestinoPortabilidadeDevolucao() {
		return tipoPlanoDestinoPortabilidadeDevolucao;
	}

	public void setTipoPlanoDestinoPortabilidadeDevolucao(TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidadeDevolucao) {
		this.tipoPlanoDestinoPortabilidadeDevolucao = tipoPlanoDestinoPortabilidadeDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public TipoEntidadePortabilidadeEnum getTipoEntidadePortabilidadeEnum() {
		return tipoEntidadePortabilidadeEnum;
	}

	public void setTipoEntidadePortabilidadeEnum(TipoEntidadePortabilidadeEnum tipoEntidadePortabilidadeEnum) {
		this.tipoEntidadePortabilidadeEnum = tipoEntidadePortabilidadeEnum;
	}

}
