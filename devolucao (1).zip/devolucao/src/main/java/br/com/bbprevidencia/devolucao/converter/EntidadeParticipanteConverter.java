package br.com.bbprevidencia.devolucao.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import br.com.bbprevidencia.bbpcomum.util.FabricaManagedBean;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipantePK;

@FacesConverter(value = "entidadeParticipanteConverter")
public class EntidadeParticipanteConverter implements Converter {

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
	 */
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String valor) {
		try {

			if (!UtilJava.isStringVazia(valor)) {
				return consultarPorChavePrimaria(valor);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public String getAsString(FacesContext context, UIComponent component, Object obj) {
		if (obj != null && obj instanceof EntidadeParticipante) {

			EntidadeParticipante entidade = (EntidadeParticipante) obj;

			if (entidade.getChavePrimaria() != null && entidade.getChavePrimaria().getCodigoFundoPrevidencia() != null && entidade.getChavePrimaria().getCodigoEntidadeParticipante() != null) {
				return entidade.getChavePrimaria().getCodigoFundoPrevidencia() + "@@@" + entidade.getChavePrimaria().getCodigoEntidadeParticipante().toString();
			}
		}
		return null;
	}

	/**
	 * Consulta pessoa através da chave passada como argumento.
	 * 
	 * @param chavePessoa
	 * @return Pessoa
	 */
	public EntidadeParticipante consultarPorChavePrimaria(String codigoEntidadeParticipante) {
		EntidadeParticipante entidadeParticipanteRetorno = null;
		if (codigoEntidadeParticipante != null) {
			if (codigoEntidadeParticipante.indexOf("@@@") > 0) {
				String[] arrayChave = codigoEntidadeParticipante.split("@@@");
				EntidadeParticipantePK chavePrimaria = new EntidadeParticipantePK();
				chavePrimaria.setCodigoFundoPrevidencia(new Long(arrayChave[0]));
				chavePrimaria.setCodigoEntidadeParticipante(new Long(arrayChave[1]));
				EntidadeParticipanteBO entidadeParticipanteBO = (EntidadeParticipanteBO) FabricaManagedBean.getManagedBean(EntidadeParticipanteBO.class);
				try {
					entidadeParticipanteRetorno = entidadeParticipanteBO.consultarPorChavePrimaria(chavePrimaria);
				} catch (Exception e) {
				}
			}
		}

		return entidadeParticipanteRetorno;
	}

}
