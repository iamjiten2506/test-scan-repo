package br.com.bbprevidencia.devolucao.util;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component("servicoEmail")
public class ServicoEmail {

	Logger logger = LoggerFactory.getLogger(ServicoEmail.class);

	@Autowired
	private JavaMailSender javaMailSender;

	@SuppressWarnings("finally")
	public boolean enviarEmail(String remetente, String destinatario, String assunto, String mensagem) {
		boolean emailEnviado = false;
		try {

			MimeMessage message = this.javaMailSender.createMimeMessage();

			message.setSubject(assunto);
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(remetente);
			helper.setTo(destinatario);
			helper.setText(mensagem, true);

			this.javaMailSender.send(message);

			emailEnviado = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			return emailEnviado;
		}
	}

	@SuppressWarnings("finally")
	public boolean enviarEmailComAnexo(String remetente, String destinatario, String assunto, String mensagem, String nomeArquivo, File anexo) {
		boolean emailEnviado = false;
		try {

			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			helper.setSubject(assunto);
			helper.setText(mensagem, true);
			helper.setTo(destinatario);
			helper.setFrom(remetente);

			helper.addAttachment(nomeArquivo, anexo);

			javaMailSender.send(message);

			emailEnviado = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			return emailEnviado;
		}
	}

	@SuppressWarnings("finally")
	public boolean enviarEmail(String remetente, String[] destinatario, String assunto, String mensagem) {
		boolean emailEnviado = false;
		try {

			MimeMessage message = this.javaMailSender.createMimeMessage();

			message.setSubject(assunto);
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(remetente);
			helper.setTo(destinatario);
			helper.setText(mensagem, true);

			this.javaMailSender.send(message);

			emailEnviado = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			return emailEnviado;
		}
	}

	@SuppressWarnings("finally")
	public boolean enviarEmailComAnexo(String remetente, String[] destinatario, String assunto, String mensagem, String nomeArquivo, File anexo) {
		boolean emailEnviado = false;
		try {

			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			helper.setSubject(assunto);
			helper.setText(mensagem, true);
			helper.setTo(destinatario);
			helper.setFrom(remetente);

			helper.addAttachment(nomeArquivo, anexo);

			javaMailSender.send(message);

			emailEnviado = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			return emailEnviado;
		}
	}

	@SuppressWarnings("finally")
	public boolean enviarEmailComAnexos(String remetente, String destinatario, String assunto, String mensagem, HashMap<String, File> anexos) {
		boolean emailEnviado = false;
		try {

			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			helper.setSubject(assunto);
			helper.setText(mensagem, true);
			helper.setTo(destinatario);
			helper.setFrom(remetente);

			//Percorre os anexos e adiciona ao Email
			for (Map.Entry<String, File> entry : anexos.entrySet()) {
				String nomeAnexo = entry.getKey();
				File arquivoAnexo = entry.getValue();
				helper.addAttachment(nomeAnexo, arquivoAnexo);
			}
			//envia o arquivo
			//			helper.addAttachment(nomeArquivo, anexo);

			javaMailSender.send(message);

			emailEnviado = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			return emailEnviado;
		}
	}
}
