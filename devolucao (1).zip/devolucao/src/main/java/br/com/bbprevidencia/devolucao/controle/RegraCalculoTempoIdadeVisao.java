package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoIdadeBO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoIdade;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter as Regras de Cálculo de Tempo de Idade
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   10/03/2017
 * 
 *  Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("regraCalculoTempoIdadeVisao")
public class RegraCalculoTempoIdadeVisao {

	private static String FW_REGRA_CALC_TEMPO_IDA = "/paginas/regraCalculoTempoIdade.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private RegraCalculoTempoIdadeBO regraCalculoTempoIdadeBO;

	private List<RegraCalculoTempoIdade> listaRegraCalculoTempoIdade;

	private RegraCalculoTempoIdade regraCalculoTempoIdade;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página das Regras de Cálculo Tempo Idade
	 * @author  BBPF0333 - Daniel Martins
	 * @since   10/03/2017
	 * @return {@link String}
	 */
	public String inciciarRegraCalculoTempoIdade() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("regraCalculoTempoIdade");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.regraCalculoTempoIdade = null;

		this.listarStatus = true;

		listaRegraCalculoTempoIdade = new ArrayList<RegraCalculoTempoIdade>(regraCalculoTempoIdadeBO.listarRegraCalculoTempoIdade());

		return FW_REGRA_CALC_TEMPO_IDA;
	}

	public RegraCalculoTempoIdadeBO getRegraCalculoTempoIdadeBO() {
		return regraCalculoTempoIdadeBO;
	}

	public void setRegraCalculoTempoIdadeBO(RegraCalculoTempoIdadeBO regraCalculoTempoIdadeBO) {
		this.regraCalculoTempoIdadeBO = regraCalculoTempoIdadeBO;
	}

	public List<RegraCalculoTempoIdade> getListaRegraCalculoTempoIdade() {
		return listaRegraCalculoTempoIdade;
	}

	public void setListaRegraCalculoTempoIdade(List<RegraCalculoTempoIdade> listaRegraCalculoTempoIdade) {
		this.listaRegraCalculoTempoIdade = listaRegraCalculoTempoIdade;
	}

	public RegraCalculoTempoIdade getRegraCalculoTempoIdade() {
		return regraCalculoTempoIdade;
	}

	public void setRegraCalculoTempoIdade(RegraCalculoTempoIdade regraCalculoTempoIdade) {
		this.regraCalculoTempoIdade = regraCalculoTempoIdade;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public static String getFW_REGRA_CALC_TEMPO_IDA() {
		return FW_REGRA_CALC_TEMPO_IDA;
	}

	public static void setFW_REGRA_CALC_TEMPO_IDA(String fW_REGRA_CALC_TEMPO_IDA) {
		FW_REGRA_CALC_TEMPO_IDA = fW_REGRA_CALC_TEMPO_IDA;
	}

}
