package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   07/02/2017
 * Classe de objeto recebendo vários dados de devolução
 */
public class LiquidoDevolucaoDTO implements Serializable, Comparable<LiquidoDevolucaoDTO> {

	private static final long serialVersionUID = 1L;

	private Devolucao devolucao;
	private Recebedor recebedor;
	private AtuacaoPessoa atuacaoPessoa;
	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private PerfilInvestimento perfilInvestimento;
	private OperacaoInterna operacaoInterna;
	private double valorLiquido;
	private ParticipantePlano participantePortabilidaeInterna;

	public LiquidoDevolucaoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LiquidoDevolucaoDTO(Devolucao devolucao, Recebedor recebedor, AtuacaoPessoa atuacaoPessoa) {
		super();
		this.devolucao = devolucao;
		this.recebedor = recebedor;
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public LiquidoDevolucaoDTO(Devolucao devolucao, Recebedor recebedor, AtuacaoPessoa atuacaoPessoa, EntidadeParticipante entidadeParticipante, PlanoPrevidencia planoPrevidencia,
			PerfilInvestimento perfilInvestimento, OperacaoInterna operacaoInterna, double valorLiquido) {
		super();
		this.devolucao = devolucao;
		this.recebedor = recebedor;
		this.atuacaoPessoa = atuacaoPessoa;
		this.entidadeParticipante = entidadeParticipante;
		this.planoPrevidencia = planoPrevidencia;
		this.perfilInvestimento = perfilInvestimento;
		this.operacaoInterna = operacaoInterna;
		this.valorLiquido = valorLiquido;
	}

	public LiquidoDevolucaoDTO(Devolucao devolucao, Recebedor recebedor, AtuacaoPessoa atuacaoPessoa, EntidadeParticipante entidadeParticipante, PlanoPrevidencia planoPrevidencia,
			PerfilInvestimento perfilInvestimento, OperacaoInterna operacaoInterna, double valorLiquido, ParticipantePlano participantePlano) {
		super();
		this.devolucao = devolucao;
		this.recebedor = recebedor;
		this.atuacaoPessoa = atuacaoPessoa;
		this.entidadeParticipante = entidadeParticipante;
		this.planoPrevidencia = planoPrevidencia;
		this.perfilInvestimento = perfilInvestimento;
		this.operacaoInterna = operacaoInterna;
		this.valorLiquido = valorLiquido;
		this.participantePortabilidaeInterna = participantePlano;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public PerfilInvestimento getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(PerfilInvestimento perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}

	public double getValorLiquido() {
		return valorLiquido;
	}

	public void setValorLiquido(double valorLiquido) {
		this.valorLiquido = valorLiquido;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public OperacaoInterna getOperacaoInterna() {
		return operacaoInterna;
	}

	public void setOperacaoInterna(OperacaoInterna operacaoInterna) {
		this.operacaoInterna = operacaoInterna;
	}

	@Override
	public int compareTo(LiquidoDevolucaoDTO o) {
		if (o.getDevolucao().getCodigo().equals(this.devolucao.getCodigo())) {

			if (o.recebedor != null && this.recebedor != null) {
				if (!o.getRecebedor().getCodigo().equals(this.recebedor.getCodigo())) {
					return 1;
				} else if (o.getRecebedor().getCodigo().equals(this.recebedor.getCodigo())) {
					return 0;
				} else {
					return -1;
				}
			}

			if (o.getAtuacaoPessoa() != null && this.atuacaoPessoa != null) {
				if (!o.getAtuacaoPessoa().getChavePrimaria().equals(this.atuacaoPessoa.getChavePrimaria())) {
					return 1;
				} else if (o.getAtuacaoPessoa().getChavePrimaria().equals(this.atuacaoPessoa.getChavePrimaria())) {
					return 0;
				} else {
					return -1;
				}
			}

			return 0;
		} else {
			return -1;
		}
	}

	public ParticipantePlano getParticipantePortabilidaeInterna() {
		return participantePortabilidaeInterna;
	}

	public void setParticipantePortabilidaeInterna(ParticipantePlano participantePortabilidaeInterna) {
		this.participantePortabilidaeInterna = participantePortabilidaeInterna;
	}

}