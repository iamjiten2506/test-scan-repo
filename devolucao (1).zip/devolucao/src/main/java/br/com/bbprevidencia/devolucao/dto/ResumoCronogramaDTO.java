package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ResumoCronogramaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "NUM_SEQ_DEV")
	private Long codigo;

	@Column(name = "PLANO")
	private String plano;

	@Column(name = "PARTICIPANTE")
	private String participante;

	@Column(name = "DATA_PAGAMENTO")
	private Date dataPagamento;

	@Column(name = "DATA_COTA")
	private Date dataCota;

	@Column(name = "QTDE_COTAS_PARTIC")
	private Double totalCotasPartic;

	@Column(name = "QTDE_COTAS_PATROC")
	private Double totalCotasPatroc;

	@Column(name = "QTDE_COTAS_REVER")
	private Double totalCotasRever;

	@Column(name = "VALOR_PARTIC")
	private Double totalValorPartic;

	@Column(name = "VALOR_PATROC")
	private Double totalValorPatroc;

	@Column(name = "VALOR_REVER")
	private Double totalValorRever;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getPlano() {
		return plano;
	}

	public void setPlano(String plano) {
		this.plano = plano;
	}

	public String getParticipante() {
		return participante;
	}

	public void setParticipante(String participante) {
		this.participante = participante;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Double getTotalCotasPartic() {
		return totalCotasPartic;
	}

	public void setTotalCotasPartic(Double totalCotasPartic) {
		this.totalCotasPartic = totalCotasPartic;
	}

	public Double getTotalCotasPatroc() {
		return totalCotasPatroc;
	}

	public void setTotalCotasPatroc(Double totalCotasPatroc) {
		this.totalCotasPatroc = totalCotasPatroc;
	}

	public Double getTotalCotasRever() {
		return totalCotasRever;
	}

	public void setTotalCotasRever(Double totalCotasRever) {
		this.totalCotasRever = totalCotasRever;
	}

	public Double getTotalValorPartic() {
		return totalValorPartic;
	}

	public void setTotalValorPartic(Double totalValorPartic) {
		this.totalValorPartic = totalValorPartic;
	}

	public Double getTotalValorPatroc() {
		return totalValorPatroc;
	}

	public void setTotalValorPatroc(Double totalValorPatroc) {
		this.totalValorPatroc = totalValorPatroc;
	}

	public Double getTotalValorRever() {
		return totalValorRever;
	}

	public void setTotalValorRever(Double totalValorRever) {
		this.totalValorRever = totalValorRever;
	}

}
