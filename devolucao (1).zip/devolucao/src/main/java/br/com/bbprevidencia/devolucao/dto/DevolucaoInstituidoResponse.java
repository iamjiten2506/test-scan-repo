package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DevolucaoInstituidoResponse {
	private Double valorBrutoDevolucao;
	private Double valorImposto;
	private Double percentualImposto;
	private Double valorLiquidoDevolucao;
	private Long codigoTipoDevolucao;

	private Double valorTotalParticipante;
	private Double valorTotalPatrocinadora;
	private Double valorResgatavelParticipante;
	private Double valorResgatavelPatrocinadora;
	private Double valorNaoResgatavelParticipante;
	private Double valorNaoResgatavelPatrocinadora;
	private Double valorContaResgatavelParticipante;
	private Double valorContaResgatavelPatrocinadora;
	private Double valorContaNaoResgatavelParticipante;
	private Double valorContaNaoResgatavelPatrocinadora;
	private Double valorContaRemanescenteParticipante;
	private Double valorContaRemanescentePatrocinadora;
	private Double valorContaReversaoParticipante;
	private Double valorContaReversaoPatrocinadora;

	private Double quantidadeCotasResgatavelParticipante;
	private Double quantidadeCotasResgatavelPatrocinadora;
	private Double quantidadeCotasNaoResgatavelParticipante;
	private Double quantidadeCotasNaoResgatavelPatrocinadora;
	private Double quantidadeCotasContaResgatavelParticipante;
	private Double quantidadeCotasContaResgatavelPatrocinadora;
	private Double quantidadeCotasContaResgatavel;
	private Double quantidadeCotasContaNaoResgatavelParticipante;
	private Double quantidadeCotasContaNaoResgatavelPatrocinadora;
	private Double quantidadeCotasContaRemanescenteParticipante;
	private Double quantidadeCotasContaRemanescentePatrocinadora;
	private Double quantidadeCotasContaReversaoParticipante;
	private Double quantidadeCotasContaReversaoPatrocinadora;
	private Double quantidadeCotasTotalParticipante;
	private Double quantidadeCotasTotalPatrocinadora;
	private Double quantidadeCotasTotalResgatavel;

}
