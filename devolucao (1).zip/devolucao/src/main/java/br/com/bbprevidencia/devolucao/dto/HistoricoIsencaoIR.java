package br.com.bbprevidencia.devolucao.dto;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.Participante;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "HISTORICO_ISENCAO_IR", schema = "OWN_CAD")
public class HistoricoIsencaoIR implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "NUM_SEQ_HIST_ISEN_IR", sequenceName = "S_HII_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NUM_SEQ_HIST_ISEN_IR")
	@Column(name = "NUM_SEQ_HIST_ISEN_IR")
	private Long codigo;

    @ManyToOne
	@JoinColumn(name = "NUM_SEQ_PARTIC")
	private Participante participante;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INICIO")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FIM")
	private Date dataFim;

	@Column(name = "CD_MOTIVO_ISENCAO")
	private String codigoMotivoIsencao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTER")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCL")
	private Date dataInclusao;

	@Column(name = "NOM_USU_ALTER")
	private String nomeUsuarioAlteracao;

	@Column(name = "NOM_USU_INCL")
	private String nomeUsuarioInclusao;

    @Override
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Participante getParticipante() {
        return participante;
    }

    public void setParticipante(Participante participante) {
        this.participante = participante;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }

    public String getCodigoMotivoIsencao() {
        return codigoMotivoIsencao;
    }

    public void setCodigoMotivoIsencao(String codigoMotivoIsencao) {
        this.codigoMotivoIsencao = codigoMotivoIsencao;
    }

    public Date getDataAlteracao() {
        return dataAlteracao;
    }

    public void setDataAlteracao(Date dataAlteracao) {
        this.dataAlteracao = dataAlteracao;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public String getNomeUsuarioAlteracao() {
        return nomeUsuarioAlteracao;
    }

    public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
        this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
    }

    public String getNomeUsuarioInclusao() {
        return nomeUsuarioInclusao;
    }

    public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
        this.nomeUsuarioInclusao = nomeUsuarioInclusao;
    }

}