package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DevolucaoDeferimentoJobDTO {

	@Id
	@Column(name = "NUM_SEQ_DEV")
	private Long id;

	@Column(name = "NUM_SEQ_SIT_DEV")
	private Long situacaoId;

	@Column(name = "NUM_SEQ_MOV_ALC")
	private Long alcadaId;

	@Column(name = "DAT_COT")
	private Date dataCota;

	@Column(name = "VAL_COT")
	private Double valorCota;

	@Column(name = "VAL_IND_AJU")
	private Double valorIndiceAjustado;

	@Column(name = "QTD_TOTAL")
	private Double quantidadeTotal;

	@Column(name = "VALOR_IMPOSTO")
	private Double valorImposto;

	@Column(name = "NOM_PARTIC")
	private String nomeParticipante;

	@Column(name = "NUM_MATRIC_PATROC")
	private String matriculaParticipante;

	@Column(name = "DAT_REQ")
	private Date dataRequerimento;

	@Column(name = "IND_TIP_DEV")
	private String tipoDevolucao;

	@Column(name = "IND_FORMA_DEV")
	private String formaDevolucao;

	@Column(name = "NOM_ABREV_PLANO")
	private String nomePlano;

	@Column(name = "PER_DEV")
	private Double percentualDevolucao;

}
