package br.com.bbprevidencia.devolucao.listener;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.devolucao.dto.DevolucaoPosicionadoDTO;

@Component
public class Producer {

	@Autowired
	private AmqpTemplate amqpTemplate;

	@Value("jsa.exchange")
	private String exchange;

	@Value("jsa.routingkey")
	private String routingkey;

	public void produce(DevolucaoPosicionadoDTO devolucaoDTO) {
		amqpTemplate.convertAndSend("jsa.queue", devolucaoDTO);
		System.out.println("Send msg = " + devolucaoDTO);
	}

}