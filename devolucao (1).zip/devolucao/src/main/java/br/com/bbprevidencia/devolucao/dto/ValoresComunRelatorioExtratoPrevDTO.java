package br.com.bbprevidencia.devolucao.dto;

public class ValoresComunRelatorioExtratoPrevDTO {

	private boolean mostrarOpcaoContribuicao;
	private boolean possuiRisco;

	public boolean isMostrarOpcaoContribuicao() {
		return mostrarOpcaoContribuicao;
	}

	public void setMostrarOpcaoContribuicao(boolean mostrarOpcaoContribuicao) {
		this.mostrarOpcaoContribuicao = mostrarOpcaoContribuicao;
	}

	public boolean isPossuiRisco() {
		return possuiRisco;
	}

	public void setPossuiRisco(boolean possuiRisco) {
		this.possuiRisco = possuiRisco;
	}

}
