package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoFolhaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoFolhaSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoFolhaDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoFolhaSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter a tipo folha Devolução
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   02/02/2017
 * 
 *     Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("tipoFolhaDevolucaoVisao")
public class TipoFolhaDevolucaoVisao {

	private static String FW_TIPO_FOLHA_DEVOLUCAO = "/paginas/tipoFolhaDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private TipoFolhaDevolucaoBO tipoFolhaDevolucaoBO;

	@Autowired
	private TipoFolhaSituacaoDevolucaoBO tipoFolhaSituacaoDevolucaoBO;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	private TipoFolhaSituacaoDevolucao tipoFolhaSituacaoDevolucao;

	private List<TipoFolhaDevolucao> listaTipoFolhaDevolucao;

	private List<TipoFolhaDevolucao> listaFiltrada;

	private List<TipoFolhaDevolucao> listaTipoFolhaDevolucaoCadastro;

	private List<SituacaoDevolucao> listaSituacaoDevolucao;

	private TipoFolhaDevolucao tipoFolhaDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private String indiceListaTipoFolha;

	/**
	 * Método encarregado por iniciar a página da tipo folha Devolução
	 * @author  BBPF0333 - Daniel Martins
	 * @since   02/02/2017
	 * @return {@link String}
	 */
	public String iniciarTipoFolhaDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("tipoFolhaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.tipoFolhaDevolucao = null;

		this.tipoFolhaSituacaoDevolucao = new TipoFolhaSituacaoDevolucao();

		this.listarStatus = true;

		listaTipoFolhaDevolucao = new ArrayList<TipoFolhaDevolucao>(tipoFolhaDevolucaoBO.listarTodosTipoFolhaDevolucao());

		listaTipoFolhaDevolucaoCadastro = new ArrayList<TipoFolhaDevolucao>(tipoFolhaDevolucaoBO.listarTodosTipoFolhaDevolucao());

		this.listaSituacaoDevolucao = new ArrayList<SituacaoDevolucao>(situacaoDevolucaoBO.listarTodosSituacaoDevolucao());

		return FW_TIPO_FOLHA_DEVOLUCAO;
	}

	/**
	 * Método encarregado de cadastrar um novo tipo de de Folha Situação Devolução
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/05/2017
	 * @param {@link TipoFolhaDevolucao}
	 */
	public void cadastrarTipoFolhaSituacaoDevolucao(TipoFolhaDevolucao tipoFolhaDevolucao) {
		this.tipoFolhaSituacaoDevolucao.setTipoFolhaDevolucao(tipoFolhaDevolucao);

		PrimeFaces.current().executeScript("PF('tipoFolhaSituacaoDevolucaoDialog').show()");
	}

	/**
	 * Método encarregado de salvar um tipo de Folha Situação Devolução
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/05/2017
	 */
	public void salvarTipoFolhaSituacaoDevolucao() {
		try {
			if (this.tipoFolhaSituacaoDevolucao.getSituacaoDevolucao() == null || this.tipoFolhaSituacaoDevolucao.getTipoFolhaDevolucao() == null) {
				Mensagens.addMsgErro("Informações necessárias devem ser preechidas antes de salvar!");
			} else {
				if (this.tipoFolhaSituacaoDevolucao.getCodigo() == null) {
					this.tipoFolhaSituacaoDevolucao.setDataInclusao(new Date());
					this.tipoFolhaSituacaoDevolucao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				} else {
					this.tipoFolhaSituacaoDevolucao.setDataAlteracao(new Date());
					this.tipoFolhaSituacaoDevolucao.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				}

				this.tipoFolhaSituacaoDevolucaoBO.salvarTipoFolhaSituacaoDevolucao(this.tipoFolhaSituacaoDevolucao);

				this.listaTipoFolhaDevolucao = new ArrayList<TipoFolhaDevolucao>(this.tipoFolhaDevolucaoBO.listarTodosTipoFolhaDevolucao());
				PrimeFaces.current().executeScript("PF('tipoFolhaSituacaoDevolucaoDialog').hide()");
				limparObjetosTemporarios();
			}
		} catch (PrevidenciaException pE) {
			Mensagens.addMsgErro(pE.getMessage());
		} catch (Exception e) {
			Mensagens.addMsgErro(e.getMessage());
		}
	}

	/**
	 * Método responsável por limpar objetos temporários
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/05/2017
	 */
	public void limparObjetosTemporarios() {
		this.tipoFolhaSituacaoDevolucao = new TipoFolhaSituacaoDevolucao();
		String codigoExpansaoLista = "expandeLinhaTipoFolha(" + this.indiceListaTipoFolha + ")";
		PrimeFaces.current().executeScript(codigoExpansaoLista);
	}

	/**
	 * Método encarregado de excluir um tipo de folha situação devolução
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link TipoFolhaSituacaoDevolucao}
	 * @since 12/05/2017
	 */
	public String excluirTipoFolhaSituacaoDevolucao(TipoFolhaSituacaoDevolucao tipoFolhaSituacaoDevolucao) {
		try {
			if (tipoFolhaSituacaoDevolucao != null) {
				this.tipoFolhaSituacaoDevolucaoBO.apagarTipoFolhaSituacaoDevolucao(tipoFolhaSituacaoDevolucao);

				this.listaTipoFolhaDevolucao = new ArrayList<TipoFolhaDevolucao>(this.tipoFolhaDevolucaoBO.listarTodosTipoFolhaDevolucao());
				limparObjetosTemporarios();
				Mensagens.addMsgInfo("Tipo Folha Situação Devolução deletada com Sucesso!");

			}

		} catch (PrevidenciaException pE) {
			Mensagens.addMsgErro(pE.getMessage());
		}

		return FW_TIPO_FOLHA_DEVOLUCAO;
	}

	public static String getFwTipoFolhaDevolucao() {
		return FW_TIPO_FOLHA_DEVOLUCAO;
	}

	public static void setFwTipoFolhaDevolucao(String fwTipoFolhaDevolucao) {
		FW_TIPO_FOLHA_DEVOLUCAO = fwTipoFolhaDevolucao;
	}

	public TipoFolhaDevolucaoBO getTipoFolhaDevolucaoBO() {
		return tipoFolhaDevolucaoBO;
	}

	public void setTipoFolhaDevolucaoBO(TipoFolhaDevolucaoBO tipoFolhaDevolucaoBO) {
		this.tipoFolhaDevolucaoBO = tipoFolhaDevolucaoBO;
	}

	public List<TipoFolhaDevolucao> getListaTipoFolhaDevolucao() {
		return listaTipoFolhaDevolucao;
	}

	public void setListaTipoFolhaDevolucao(List<TipoFolhaDevolucao> listaTipoFolhaDevolucao) {
		this.listaTipoFolhaDevolucao = listaTipoFolhaDevolucao;
	}

	public TipoFolhaDevolucao getTipoFolhaDevolucao() {
		return tipoFolhaDevolucao;
	}

	public void setTipoFolhaDevolucao(TipoFolhaDevolucao tipoFolhaDevolucao) {
		this.tipoFolhaDevolucao = tipoFolhaDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public TipoFolhaSituacaoDevolucao getTipoFolhaSituacaoDevolucao() {
		return tipoFolhaSituacaoDevolucao;
	}

	public void setTipoFolhaSituacaoDevolucao(TipoFolhaSituacaoDevolucao tipoFolhaSituacaoDevolucao) {
		this.tipoFolhaSituacaoDevolucao = tipoFolhaSituacaoDevolucao;
	}

	public List<SituacaoDevolucao> getListaSituacaoDevolucao() {
		return listaSituacaoDevolucao;
	}

	public void setListaSituacaoDevolucao(List<SituacaoDevolucao> listaSituacaoDevolucao) {
		this.listaSituacaoDevolucao = listaSituacaoDevolucao;
	}

	public List<TipoFolhaDevolucao> getListaTipoFolhaDevolucaoCadastro() {
		return listaTipoFolhaDevolucaoCadastro;
	}

	public void setListaTipoFolhaDevolucaoCadastro(List<TipoFolhaDevolucao> listaTipoFolhaDevolucaoCadastro) {
		this.listaTipoFolhaDevolucaoCadastro = listaTipoFolhaDevolucaoCadastro;
	}

	public String getIndiceListaTipoFolha() {
		return indiceListaTipoFolha;
	}

	public void setIndiceListaTipoFolha(String indiceListaTipoFolha) {
		this.indiceListaTipoFolha = indiceListaTipoFolha;
	}

	public List<TipoFolhaDevolucao> getListaFiltrada() {
		return listaFiltrada;
	}

	public void setListaFiltrada(List<TipoFolhaDevolucao> listaFiltrada) {
		this.listaFiltrada = listaFiltrada;
	}

}
