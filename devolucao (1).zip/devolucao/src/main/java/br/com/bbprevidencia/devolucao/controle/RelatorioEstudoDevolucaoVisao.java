package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraElegibilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.EstudoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraElegibilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar om reatório de estudo de Devolução
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 31/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioEstudoDevolucaoVisao")
public class RelatorioEstudoDevolucaoVisao {

	private static final String FW_RELATORIO_ESTUDO_DEVOLUCAO = "/paginas/relatorioEstudoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioEstudoDevolucaoVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private DevolucaoBO devolucaoBO;
	@Autowired
	private RegraDevolucaoBO regraDevolucaoBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;
	@Autowired
	private RegraCalculoDevolucaoBO regraCalculoDevolucaoBO;
	@Autowired
	private RegraElegibilidadeDevolucaoBO regraElegibilidadeDevolucaoBO;
	@Autowired
	RelatorioUtil relatorioUtil;

	private boolean selecionarParticipante;
	private boolean selecionarPlano;

	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<TipoDevolucao> listaTipoDevolucao;

	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private Participante participante;
	private RegraDevolucao regraDevolucao;
	private TipoDevolucao tipoDevolucao;
	private RegraCalculoDevolucao regraCalculoDevolucao;
	private RegraElegibilidadeDevolucao regraElegibilidadeDevolucao;
	private Date dataRequerimento;
	private List<Devolucao> listaDevolucao;

	/**
	 * Método encarregado de chamar a página de preenchimento de parâmetros
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/04/2017
	 * @return
	 */
	public String iniciarRelatorioEstudoDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_ESTUDO_DEVOLUCAO;
	}

	/**
	 * Setar os valores iniciais da Tela
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/04/2017
	 */
	private void setarValoresIniciais() {
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipante)) {
			this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.entidadeParticipanteBO.listarEntidadeParticipanteOrderByNome());
		}

		if (UtilJava.isColecaoVazia(this.listaTipoDevolucao)) {
			this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBO.listarTodosTipoDevolucao());
		}

		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.participante = new Participante();
		this.planoPrevidencia = new PlanoPrevidencia();

		this.selecionarParticipante = false;
		this.selecionarPlano = false;
		this.regraDevolucao = null;
		this.regraCalculoDevolucao = null;
		this.dataRequerimento = new Date();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/03/2017
	 */
	public void listarPlanoPrevidenciaPorPatrocinadora() {
		try {
			if (this.getEntidadeParticipante() != null) {
				this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante);
				this.selecionarPlano = true;
				this.selecionarParticipante = true;
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 */
	public void listarTipoDevolucaoPorPlanoPrevidencia() {
		try {
			if (this.getPlanoPrevidencia() != null) {
				this.selecionarParticipante = true;
				List<TipoDevolucao> listaTipoDevolucaoTemp = this.tipoDevolucaoBO.listarTodosTipoDevolucaoPorPlanoPrevidencia(getPlanoPrevidencia());

				if (UtilJava.isColecaoDiferenteDeVazia(listaTipoDevolucaoTemp)) {
					this.listaTipoDevolucao = listaTipoDevolucaoTemp;
				}
			} else {
				this.selecionarParticipante = false;
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo digitado no autocomplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.getPlanoPrevidencia().getCodigo() != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.getEntidadeParticipante());
		}
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() == null) {
			setParticipante(new Participante());
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/03/2017
	 * @param event
	 */
	public void limparPesquisa() {
		setarValoresIniciais();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/03/2017
	 * @param event
	 */
	public void exportarRelatorio(ActionEvent event) {
		try {
			String idEnviado = event.getComponent().getId();

			this.regraDevolucao = this.regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigencia(this.planoPrevidencia, new Date());

			if (this.regraDevolucao == null) {
				throw new PrevidenciaException("Não há regra devolução ativa para este plano!");
			}

			this.regraCalculoDevolucao = this.regraCalculoDevolucaoBO.pesquisarRegraCalculoDevolucaoPorRegraVigenciaTipo(this.regraDevolucao, new Date(), this.tipoDevolucao);

			if (this.regraCalculoDevolucao == null) {
				throw new PrevidenciaException("Não há regra de cálculo ativa para a regra devolução e o tipo de devolução!");
			}

			this.regraElegibilidadeDevolucao = this.regraElegibilidadeDevolucaoBO.pesquisarRegraElegibilidadePorRegraCalculoDevolucao(this.regraCalculoDevolucao);
			if (this.regraElegibilidadeDevolucao == null) {
				throw new PrevidenciaException("Não existe regra de elegibilidade vigente para a regra de cálculo!");
			} else {
				EstudoDevolucaoDTO relatorioEstudoDevolucao = new EstudoDevolucaoDTO();

				relatorioEstudoDevolucao = this.regraElegibilidadeDevolucaoBO.montarRelatorioEstudoDevolucao(
						this.participante,
						this.planoPrevidencia,
						this.regraElegibilidadeDevolucao,
						this.dataRequerimento,
						this.tipoDevolucao);

				if (relatorioEstudoDevolucao.getNomeUsuarioSolicitante() == null) {
					relatorioEstudoDevolucao.setNomeUsuarioSolicitante(loginTemporariaDTO.getUsuarioSessao().getName());
				}

				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
				parametros.put("listaCondicoesEstudo", relatorioEstudoDevolucao.getListaCondicoes());

				String logo = UtilSession.getRealPath("imagens/logoBBPrevidencia.jpg");

				parametros.put("logo", logo);

				List<EstudoDevolucaoDTO> listaEstudoDevolucao = new ArrayList<EstudoDevolucaoDTO>();
				listaEstudoDevolucao.add(relatorioEstudoDevolucao);
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(listaEstudoDevolucao);
				//GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "estudoDevolucao", dataSource);
				String nomeArquivo = relatorioUtil.gerarRelatorio("estudoDevolucao", listaEstudoDevolucao, parametros);
				relatorioUtil.abrirPoupUp(nomeArquivo);

			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}
	}

	public boolean isSelecionarParticipante() {
		return selecionarParticipante;
	}

	public void setSelecionarParticipante(boolean selecionarParticipante) {
		this.selecionarParticipante = selecionarParticipante;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public RegraElegibilidadeDevolucao getRegraElegibilidadeDevolucao() {
		return regraElegibilidadeDevolucao;
	}

	public void setRegraElegibilidadeDevolucao(RegraElegibilidadeDevolucao regraElegibilidadeDevolucao) {
		this.regraElegibilidadeDevolucao = regraElegibilidadeDevolucao;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

}
