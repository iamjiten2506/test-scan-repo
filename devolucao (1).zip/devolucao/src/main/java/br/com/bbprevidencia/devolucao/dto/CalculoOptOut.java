package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.HistoricoFinanceiroPago;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
@Entity
@Table(name = "CAL_OPT_OUT", schema = "OWN_DCR")
public class CalculoOptOut implements Serializable {

	private static final long serialVersionUID = 5300640860092928380L;

	@Id
	@SequenceGenerator(name = "CALCULO_OPT_OUT_GER", sequenceName = "OWN_DCR.S_CAL_OPT_OUT_01", allocationSize = 1, initialValue = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CALCULO_OPT_OUT_GER")
	@Column(name = "NUM_SEQ_CAL_OPT_OUT")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SOL_OPT_OUT")
	private SolicitacaoOptOut solicitacaoOptOut;

	@Column(name = "NUM_SEQ_HIST_FIN_PAGO")
	private Long numeroHistoricoFinanceiroPago;

	@Transient
	private HistoricoFinanceiroPago historicoFinanceiroPago;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_DEPOSI")
	private Date dataDeposito;

	@Column(name = "VAL_INDICE_FATOR")
	private Double valorIndiceFator;

	@Column(name = "VAL_PARTIC")
	private Double valorPartic;

	@Column(name = "VAL_TAXA_PARTIC")
	private Double valorTaxaPartic;

	@Column(name = "VAL_PATRON")
	private Double valorPatron;

	@Column(name = "VAL_TAXA_PATRON")
	private Double valorTaxaPatron;

	@Column(name = "VAL_PARTIC_ATUAL_INDICE")
	private Double valorParticipanteAtualizacaoIndice;

	@Column(name = "VAL_PATROC_ATUAL_INDICE")
	private Double valorPatrocinadoraAtualizacaoIndice;

	@Column(name = "VAL_PARTIC_ATUAL_COTA")
	private Double valorParticipanteAtualizacaoCota;

	@Column(name = "VAL_PATRON_ATUAL_COTA")
	private Double valorPatrocinadoraAtualizacaoCota;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Transient
	private Integer order = 1;

}