package br.com.bbprevidencia.devolucao.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class EmailRetornoDTO {

	private Boolean emailEnviado;
	private String msgRetorno;

}
