package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   29/12/2016
 * Classe de persistência para tabela PAR_CON_DEV_DET_IMP.
 */
@Entity
@Table(name = "PAR_CON_DEV_DET_IMP", schema = "OWN_DCR")
@NamedQuery(name = "ParcelaContaDevolucaoDetalheImposto.findAll", query = "SELECT q FROM ParcelaContaDevolucaoDetalheImposto q")
public class ParcelaContaDevolucaoDetalheImposto implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PAR_CON_DEV_DET_IMP_GER", sequenceName = "S_PCDDI_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PAR_CON_DEV_DET_IMP_GER")
	@Column(name = "NUM_SEQ_PAR_CON_DEV_DET_IMP")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PAR_CON_DEV_DET")
	private ParcelaContaDevolucaoDetalhe parcelaContaDevolucaoDetalhe;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CRO_DEV")
	private CronogramaDevolucao cronogramaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RECEBEDOR")
	private Recebedor recebedor;

	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "COD_PESSOA"), @JoinColumn(name = "COD_AREA_ATUA") })
	private AtuacaoPessoa atuacaoPessoa;

	@Column(name = "NUM_IDADE_ANOS_IMP")
	private Double numeroAnosIdade;

	@Column(name = "DAT_BASE_FIN_IDADE_IMP")
	private Date dataBaseFinalIdade;

	@Column(name = "NUM_PER_IMP")
	private Double numeroPercentualIrrf;

	@Column(name = "VAL_IMP_DES_DED")
	private Double valorDeducaoFaixa;

	@Column(name = " VAL_IMP_DES_DEP")
	private Double valorDependente;

	@Column(name = "VAL_IMP_DES_INS")
	private Double valorIsencao;

	@Column(name = "VAL_BRUTO")
	private Double valorBruto;

	@Column(name = "VAL_IMP")
	private Double valorIrrf;

	@Column(name = "VAL_LIQ")
	private Double valorLiquido;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Column(name = "SALDO_ISENTO")
	private Double saldoIsento;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public ParcelaContaDevolucaoDetalhe getParcelaContaDevolucaoDetalhe() {
		return parcelaContaDevolucaoDetalhe;
	}

	public void setParcelaContaDevolucaoDetalhe(ParcelaContaDevolucaoDetalhe parcelaContaDevolucaoDetalhe) {
		this.parcelaContaDevolucaoDetalhe = parcelaContaDevolucaoDetalhe;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public Double getNumeroAnosIdade() {
		return numeroAnosIdade;
	}

	public void setNumeroAnosIdade(Double numeroAnosIdade) {
		this.numeroAnosIdade = numeroAnosIdade;
	}

	public Date getDataBaseFinalIdade() {
		return dataBaseFinalIdade;
	}

	public void setDataBaseFinalIdade(Date dataBaseFinalIdade) {
		this.dataBaseFinalIdade = dataBaseFinalIdade;
	}

	public Double getNumeroPercentualIrrf() {
		return numeroPercentualIrrf;
	}

	public void setNumeroPercentualIrrf(Double numeroPercentualIrrf) {
		this.numeroPercentualIrrf = numeroPercentualIrrf;
	}

	public Double getValorBruto() {
		return valorBruto;
	}

	public void setValorBruto(Double valorBruto) {
		this.valorBruto = valorBruto;
	}

	public Double getValorIrrf() {
		return valorIrrf;
	}

	public void setValorIrrf(Double valorIrrf) {
		this.valorIrrf = valorIrrf;
	}

	public Double getValorLiquido() {
		return valorLiquido;
	}

	public void setValorLiquido(Double valorLiquido) {
		this.valorLiquido = valorLiquido;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Double getValorDeducaoFaixa() {
		return valorDeducaoFaixa;
	}

	public void setValorDeducaoFaixa(Double valorDeducaoFaixa) {
		this.valorDeducaoFaixa = valorDeducaoFaixa;
	}

	public Double getValorDependente() {
		return valorDependente;
	}

	public void setValorDependente(Double valorDependente) {
		this.valorDependente = valorDependente;
	}

	public Double getValorIsencao() {
		return valorIsencao;
	}

	public void setValorIsencao(Double valorIsencao) {
		this.valorIsencao = valorIsencao;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public Double getSaldoIsento() {
		return saldoIsento;
	}

	public void setSaldoIsento(Double saldoIsento) {
		this.saldoIsento = saldoIsento;
	}

}