package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   23/01/2017
 * Classe de persistência para tabela TIP_MSG_PRO_DEV.
 */
@Entity
@Table(name = "LOT_PRO_DEV", schema = "OWN_DCR")
@NamedQuery(name = "LoteProcessamentoDevolucao.findAll", query = "SELECT q FROM LoteProcessamentoDevolucao q")
public class LoteProcessamentoDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "LOT_PRO_DEV_GER", sequenceName = "S_LPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LOT_PRO_DEV_GER")
	@Column(name = "NUM_SEQ_LOT_PRO_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CRO_DEV")
	private CronogramaDevolucao cronogramaDevolucao;

	@Column(name = "DAT_LOT_PRO_DEV")
	private Date dataLoteProcessamento;

	@Column(name = "IND_TIP_LOT_PRO_DEV")
	private String tipoProcessamento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private String descricao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public Date getDataLoteProcessamento() {
		return dataLoteProcessamento;
	}

	public void setDataLoteProcessamento(Date dataLoteProcessamento) {
		this.dataLoteProcessamento = dataLoteProcessamento;
	}

	public String getTipoProcessamento() {
		return tipoProcessamento;
	}

	public void setTipoProcessamento(String tipoProcessamento) {
		this.tipoProcessamento = tipoProcessamento;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getDescricao() {

		descricao = "Lote:" + codigo.toString() + " - Data: " + UtilJava.formataDataPorPadrao(dataLoteProcessamento, "dd/MM/yyyy - HH:mm:ss");

		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoteProcessamentoDevolucao other = (LoteProcessamentoDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}