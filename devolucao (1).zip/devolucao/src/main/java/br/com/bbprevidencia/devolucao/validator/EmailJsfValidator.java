package br.com.bbprevidencia.devolucao.validator;

import java.text.MessageFormat;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class EmailJsfValidator implements Validator {

	private static final String KEY_MENSAGEM_VALIDACAO = "br.gov.saude.infraestrutura.validacao.EMAIL";

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		if (value == null) {
			return;
		}
		if (value instanceof String) {
			String email = (String) value;
			if (!br.com.bbprevidencia.bbpcomum.util.EmailValidator.isValid(email)) {
				String label = (String) component.getAttributes().get("label");
				FacesMessage message = new FacesMessage();
				message.setSeverity(FacesMessage.SEVERITY_ERROR);
				message.setSummary(getSummary(label));
				throw new ValidatorException(message);
			}
		}
	}

	private String getSummary(String label) {
		return MessageFormat.format(ResourceBundle.getBundle(FacesContext.getCurrentInstance().getApplication().getMessageBundle()).getString(KEY_MENSAGEM_VALIDACAO), label);
	}

}
