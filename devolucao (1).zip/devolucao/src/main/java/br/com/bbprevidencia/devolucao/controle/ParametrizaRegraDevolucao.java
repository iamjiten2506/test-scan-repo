package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoRegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.PlanoContribFaixasDevBO;
import br.com.bbprevidencia.devolucao.bo.PlanoVigenciaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoContribFaixasBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoContribuicaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraElegibilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoRegraBO;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoRegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.PlanoContribFaixasDev;
import br.com.bbprevidencia.devolucao.dto.PlanoVigenciaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucaoContribFaixas;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucaoContribuicao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucaoParametrizacaoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraElegibilidadeDevolucao;

/**
 * Classe de controle que manipula as requisições de Parametrização das 
 * Regras de Devolução
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 08/02/2017
 * 
 *	Copyright notice (c) 2016 BBPrevidência S/A
 */

@Scope("session")
@Component("parametrizaRegraDevolucao")
public class ParametrizaRegraDevolucao {

	public static Logger log = Logger.getLogger(ParametrizaRegraDevolucao.class);

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private PlanoVigenciaDevolucaoBO planoVigenciaDevolucaoBO;

	@Autowired
	private RegraCalculoDevolucaoBO regraCalculoDevolucaoBO;

	@Autowired
	private RegraElegibilidadeDevolucaoBO regraElegibilidadeDevolucaoBO;

	@Autowired
	private RegraDevolucaoContribuicaoBO regraDevolucaoContribuicaoBO;

	@Autowired
	private RegraDevolucaoContribFaixasBO regraDevolucaoContribFaixasBO;

	@Autowired
	private PlanoContribFaixasDevBO planoContribFaixasDevBO;

	@Autowired
	private RegraDevolucaoBO regraDevolucaoBO;

	@Autowired
	private HistoricoSituacaoRegraDevolucaoBO historicoSituacaoRegraDevolucaoBO;

	@Autowired
	private SituacaoRegraBO situacaoRegraBO;

	private RegraDevolucaoParametrizacaoDTO regraDevolucaoCompleto;

	private PlanoPrevidencia planoPrevidencia;

	private PlanoVigenciaDevolucao planoVigenciaDevolucao;

	private RegraDevolucao novaRegraDevolucao;

	private RegraDevolucao novaRegraDevolucao2;

	private List<RegraDevolucao> listaRegraDevolucao = new ArrayList<RegraDevolucao>();
	private LoginBBPrevWebDTO loginBBPrevWebDTO;

	/**
	 * Método responsável por preencher a Lista de Regras de devolucao
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 10/02/2017
	 * @param {@link PlanoVigenciaDevolucao}
	 */
	public void preencherListaRegraDevolucao(PlanoVigenciaDevolucao planoVigenciaDevolucao) {
		this.listaRegraDevolucao = new ArrayList<RegraDevolucao>(regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigenciaDevolucao(planoVigenciaDevolucao));
	}

	/**
	 * Método encarregado de Salvar Regrda de devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/02/2017
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { PrevidenciaException.class })
	public void salvarRegraDevolucao() {
		try {
			if (this.novaRegraDevolucao == null) {
				throw new PrevidenciaException("Não foi posível salvar a regra de devolução! Regra em branco.");
			}

			this.regraDevolucaoCompleto = new RegraDevolucaoParametrizacaoDTO();

			// Preenchimento da Regra de Devolução
			preencheRegraDevolucao(this.getNovaRegraDevolucao());

			// Preenchimento da lista de regras de cálculo de Devolução
			if (UtilJava.isColecaoVazia(this.regraDevolucaoCompleto.getRegraDevolucao().getListaRegraCalculoDevolucao())) {
				throw new PrevidenciaException("Não foram definidas regras de cálculo para a regra de Devolução.");
			} else {

				preencheListaRegraCalculoDevolucao(this.regraDevolucaoCompleto.getRegraDevolucao());

				for (RegraCalculoDevolucao rCd : this.regraDevolucaoCompleto.getRegraDevolucao().getListaRegraCalculoDevolucao()) {

					if (rCd == null) {
						throw new PrevidenciaException("Não foram definidas regras de cálculo para a regra de Devolução.");
					} else {

						if (UtilJava.isColecaoVazia(rCd.getListaRegraElegibilidadeDevolucao())) {
							throw new PrevidenciaException("Não foram definidas regras de elegibilidade associadas à regra de Cálculo.");
						}

						if (UtilJava.isColecaoVazia(rCd.getListaRegraDevolucaoContribuicao())) {
							throw new PrevidenciaException("Não foram definidas regras de Contribuição associadas à regra de Cálculo.");
						} else {
							for (RegraDevolucaoContribuicao regraDevContrib : rCd.getListaRegraDevolucaoContribuicao()) {
								if (UtilJava.isColecaoVazia(regraDevContrib.getListaRegraDevolucaoContribFaixas())) {
									throw new PrevidenciaException("Não foram definidas as Faixas de Devolução Contribuição.");
								}

								Long totalQuantidadeContribuicoes = 0L;
								for (RegraDevolucaoContribFaixas regDevContribFaixas : regraDevContrib.getListaRegraDevolucaoContribFaixas()) {
									totalQuantidadeContribuicoes += regDevContribFaixas.getQuantidadeContribuicao();
								}

								if (totalQuantidadeContribuicoes > 0L && UtilJava.isColecaoVazia(regraDevContrib.getListaPlanoContrtibFaixasDev())) {
									throw new PrevidenciaException("Não foram definidas as Faixas de Contribuição de Plano para o tipo de contribuiçao "
											+ regraDevContrib.getTipoContribuicao().getDescricaoTipoContribuicao());
								}
							}
						}
					}

					preencheListaRegraElegibilidadeDevolucao(this.regraDevolucaoCompleto.getListaRegraCalculoDevolucao());

					preencheListaRegraDevolucaoContribuicao(this.regraDevolucaoCompleto.getListaRegraCalculoDevolucao());

					preencheListaRegraDevolucaoContribFaixas(this.regraDevolucaoCompleto.getListaRegraDevolucaoContribuicao());
				}
			}

			// Preenchimento da lista das Faixas de Plano de Devolução
			preencheListaPlanoContribFaixasDev(this.regraDevolucaoCompleto.getListaRegraDevolucaoContribuicao());

			//Preenchimento dos historico da regra de Devolução
			preencheHistoricoSituacaoRegraDevolucao(this.regraDevolucaoCompleto.getRegraDevolucao());

			// Salvar regra de devolução
			this.regraDevolucaoBO.salvarRegraDevolucao(this.regraDevolucaoCompleto.getRegraDevolucao());

			//Salvar Lista de regras de Cálculo de Devolução
			this.regraCalculoDevolucaoBO.salvarListaRegraCalculoDevolucao(this.regraDevolucaoCompleto.getListaRegraCalculoDevolucao());

			//Salvar Lista de regras Elegibilidade de Devolução
			this.regraElegibilidadeDevolucaoBO.salvarListaRegraElegibilidadeDevolucao(this.regraDevolucaoCompleto.getListaRegraElegibilidadeDevolucao());

			//Salvar Lista de regras de Contribuição
			this.regraDevolucaoContribuicaoBO.salvarListaRegraDevolucaoContribuicao(this.regraDevolucaoCompleto.getListaRegraDevolucaoContribuicao());

			//Salvar Lista de Faixas de Contribuição
			this.regraDevolucaoContribFaixasBO.salvarListaRegraDevolucaoContribfaixas(this.regraDevolucaoCompleto.getListaRegraDevolucaoContribFaixas());

			//Salvar Histórico da situaçao da regra de Devolução
			this.historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao());

			//Salvar Regras Plano de Faixas de Devolução
			if (UtilJava.isColecaoDiferenteDeVazia(this.regraDevolucaoCompleto.getListaRegraPlanoContibFaixasDevolucao())) {
				this.planoContribFaixasDevBO.salvarListaPlanoContribFaixasDev(this.regraDevolucaoCompleto.getListaRegraPlanoContibFaixasDevolucao());
			}

		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			throw pEx;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi posível salvar a regra de devolução!", e);
		}
	}

	/**
	 * Método encarregado de preenher o Histórico da situação da regra de devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 23/02/2017
	 * @param {@link RegraDevolucao}
	 */
	private void preencheHistoricoSituacaoRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setRegraDevolucao(regraDevolucao);
		this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setSituacaoRegra(regraDevolucao.getSituacaoRegraDevolucao());
		this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setDataHistoricoSituacao(new Date());
		this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setDescricaoHistorico("Inserção de Nova Regra de Devolução");

		if (regraDevolucao.getCodigo() == null) {
			this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setDataInclusao(regraDevolucao.getDataInclusao());
			this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setNomeUsuarioInclusao(regraDevolucao.getNomeUsuarioInclusao());
		} else {
			this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setDataInclusao(regraDevolucao.getDataAlteracao());
			this.regraDevolucaoCompleto.getHistoricoSituacaoRegraDevolucao().setNomeUsuarioInclusao(regraDevolucao.getNomeUsuarioAlteracao());
		}
	}

	/**
	 * Método responsável de preencher a Lista de Planos Regras de Faixas Contribuições Devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/02/2017
	 * @param {@link RegraDevolucaoContribuicao}
	 */
	private void preencheListaPlanoContribFaixasDev(List<RegraDevolucaoContribuicao> listaRegraDevolucaoContribuicao) {
		if (UtilJava.isColecaoVazia(listaRegraDevolucaoContribuicao)) {
			this.regraDevolucaoCompleto.setListaRegraPlanoContibFaixasDevolucao(new ArrayList<PlanoContribFaixasDev>());
		} else {
			for (RegraDevolucaoContribuicao rDc : listaRegraDevolucaoContribuicao) {
				for (PlanoContribFaixasDev pCfd : rDc.getListaPlanoContrtibFaixasDev()) {
					pCfd.setRegraDevolucaoContribuicao(rDc);
					this.regraDevolucaoCompleto.getListaRegraPlanoContibFaixasDevolucao().add(pCfd);
				}
			}

			for (PlanoContribFaixasDev pCfd : this.regraDevolucaoCompleto.getListaRegraPlanoContibFaixasDevolucao()) {
				if (pCfd.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() == null) {
					pCfd.setDataInclusao(pCfd.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getDataInclusao());
					pCfd.setNomeUsuarioInclusao(pCfd.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioInclusao());
				} else {
					pCfd.setDataAlteracao(pCfd.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getDataAlteracao());
					pCfd.setNomeUsuarioAlteracao(pCfd.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioAlteracao());
				}
			}
		}

	}

	/**
	 * Método responsável de preencher a Lista de Regras de Faixas Contribuições 
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/02/2017
	 * @param {@link RegraDevolucaoContribuicao}
	 */
	private void preencheListaRegraDevolucaoContribFaixas(List<RegraDevolucaoContribuicao> listaRegraDevolucaoContribuicao) {
		if (UtilJava.isColecaoVazia(listaRegraDevolucaoContribuicao)) {
			this.regraDevolucaoCompleto.setListaRegraDevolucaoContribFaixas(new ArrayList<RegraDevolucaoContribFaixas>());
		} else {
			for (RegraDevolucaoContribuicao rDc : listaRegraDevolucaoContribuicao) {
				for (RegraDevolucaoContribFaixas rDcf : rDc.getListaRegraDevolucaoContribFaixas()) {
					rDcf.setRegraDevolucaoContribuicao(rDc);
					this.regraDevolucaoCompleto.getListaRegraDevolucaoContribFaixas().add(rDcf);
				}
			}

			for (RegraDevolucaoContribFaixas rDcf : this.regraDevolucaoCompleto.getListaRegraDevolucaoContribFaixas()) {
				if (rDcf.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() == null) {
					rDcf.setDataInclusao(rDcf.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getDataInclusao());
					rDcf.setNomeUsuarioInclusao(rDcf.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioInclusao());
				} else {
					rDcf.setDataAlteracao(rDcf.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getDataAlteracao());
					rDcf.setNomeUsuarioAlteracao(rDcf.getRegraDevolucaoContribuicao().getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioAlteracao());
				}
			}
		}

	}

	/**
	 * Método responsável de preencher a Lista de Contribuições de Devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/02/2017
	 * @param listaRegraCalculoDevolucao
	 */
	private void preencheListaRegraDevolucaoContribuicao(List<RegraCalculoDevolucao> listaRegraCalculoDevolucao) {
		if (UtilJava.isColecaoVazia(listaRegraCalculoDevolucao)) {
			this.regraDevolucaoCompleto.setListaRegraDevolucaoContribuicao(new ArrayList<RegraDevolucaoContribuicao>());
		} else {
			for (RegraCalculoDevolucao rCd : listaRegraCalculoDevolucao) {
				for (RegraDevolucaoContribuicao rDc : rCd.getListaRegraDevolucaoContribuicao()) {
					rDc.setRegraCalculoDevolucao(rCd);
					this.regraDevolucaoCompleto.getListaRegraDevolucaoContribuicao().add(rDc);
				}
			}

			for (RegraDevolucaoContribuicao rDc : this.regraDevolucaoCompleto.getListaRegraDevolucaoContribuicao()) {
				if (rDc.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() == null) {
					rDc.setDataInclusao(new Date());
					rDc.setNomeUsuarioInclusao(rDc.getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioInclusao());
				} else {
					rDc.setDataAlteracao(new Date());
					rDc.setNomeUsuarioAlteracao(rDc.getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioAlteracao());
				}
			}
		}
	}

	/**
	 * Método responsável de preencher a Lista de Regra de Elegibilidade Devolução
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   10/03/2017
	 * @param   listaRegraElegibilidadeDevolucao
	 */
	private void preencheListaRegraElegibilidadeDevolucao(List<RegraCalculoDevolucao> listaRegraCalculoDevolucao) {
		if (UtilJava.isColecaoVazia(listaRegraCalculoDevolucao)) {
			this.regraDevolucaoCompleto.setListaRegraElegibilidadeDevolucao(new ArrayList<RegraElegibilidadeDevolucao>());
		} else {

			for (RegraCalculoDevolucao rCd : listaRegraCalculoDevolucao) {
				for (RegraElegibilidadeDevolucao rDc : rCd.getListaRegraElegibilidadeDevolucao()) {
					rDc.setRegraCalculoDevolucao(rCd);
					this.regraDevolucaoCompleto.getListaRegraElegibilidadeDevolucao().add(rDc);
				}
			}

			for (RegraElegibilidadeDevolucao rDc : this.regraDevolucaoCompleto.getListaRegraElegibilidadeDevolucao()) {
				if (rDc.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() == null) {
					rDc.setDataInclusao(new Date());
					rDc.setNomeUsuarioInclusao(rDc.getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioInclusao());
				} else {
					rDc.setDataAlteracao(new Date());
					rDc.setNomeUsuarioAlteracao(rDc.getRegraCalculoDevolucao().getRegraDevolucao().getNomeUsuarioAlteracao());
				}
			}
		}
	}

	/**
	 * Método responsável por preecher a lista de Regras de Cálculo de Devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/02/2017
	 * @param {@link RegraDevolucao}
	 */
	private void preencheListaRegraCalculoDevolucao(RegraDevolucao regraDevolucao) {
		if (UtilJava.isColecaoVazia(regraDevolucao.getListaRegraCalculoDevolucao())) {
			this.regraDevolucaoCompleto.setListaRegraCalculoDevolucao(new ArrayList<RegraCalculoDevolucao>());
		} else {
			this.regraDevolucaoCompleto.setListaRegraCalculoDevolucao(regraDevolucao.getListaRegraCalculoDevolucao());

			for (RegraCalculoDevolucao rCd : this.regraDevolucaoCompleto.getListaRegraCalculoDevolucao()) {
				if (regraDevolucao.getCodigo() == null) {
					rCd.setRegraDevolucao(regraDevolucao);
					rCd.setNomeUsuarioInclusao(regraDevolucao.getNomeUsuarioInclusao());
					rCd.setDataInclusao(regraDevolucao.getDataInclusao());
					rCd.setCodigo(null);
				} else {
					rCd.setNomeUsuarioAlteracao(rCd.getRegraDevolucao().getNomeUsuarioAlteracao());
					rCd.setDataAlteracao(rCd.getRegraDevolucao().getDataAlteracao());
				}
			}
		}
	}

	/**
	 * Método responsável por preencher a regra de cálculo antes de salvar e setar as datas corretas.
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/02/2017
	 * @param {@link RegraDevolucao}
	 */
	private void preencheRegraDevolucao(RegraDevolucao regraDevolucao) {
		if (regraDevolucao.getCodigo() == null) {
			regraDevolucao.setDataInclusao(new Date());
			//regraDevolucao.setNomeUsuarioInclusao("BBPF0415");
			regraDevolucao.setNomeUsuarioInclusao(getLoginBBPrevWebDTO().getUsuarioSessao().getDescricaoLogin());
		} else {
			regraDevolucao.setDataAlteracao(new Date());
			//regraDevolucao.setNomeUsuarioAlteracao("BBPF0415");
			regraDevolucao.setNomeUsuarioAlteracao(getLoginBBPrevWebDTO().getUsuarioSessao().getDescricaoLogin());
		}

		this.regraDevolucaoCompleto.setRegraDevolucao(regraDevolucao);
	}

	/**
	 * Método responsável por preecher as informações de alteração na Regra de Devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param regraDevolucao
	 * @param codigoSituacao
	 * @return
	 */
	public RegraDevolucao alterarAntesSalvarRegraDevolucao(RegraDevolucao regraDevolucao, Long codigoSituacao) {
		regraDevolucao.setSituacaoRegraDevolucao(situacaoRegraBO.pesquisarSituacaoRegraPorCodigo(codigoSituacao));
		regraDevolucao.setDataAlteracao(new Date());
		regraDevolucao.setNomeUsuarioAlteracao(getLoginBBPrevWebDTO().getUsuarioSessao().getDescricaoLogin());

		if (codigoSituacao == 6L) {
			regraDevolucao.setDataEntradaEmProd(null);
		} else if (codigoSituacao == 4L) {
			regraDevolucao.setDataEntradaEmProd(new Date());
		}

		return regraDevolucao;
	}

	/**
	 * Método responsável por criar um novo histórico para uma regra de devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param regraDevolucao
	 * @return
	 */
	public HistoricoSituacaoRegraDevolucao criarHistoricoRegraDevolucao(RegraDevolucao regraDevolucao, String descricaoHistorico) {
		HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao = new HistoricoSituacaoRegraDevolucao();
		historicoSituacaoRegraDevolucao.setDataHistoricoSituacao(new Date());
		historicoSituacaoRegraDevolucao.setRegraDevolucao(regraDevolucao);
		historicoSituacaoRegraDevolucao.setSituacaoRegra(regraDevolucao.getSituacaoRegraDevolucao());
		historicoSituacaoRegraDevolucao.setDataInclusao(new Date());
		historicoSituacaoRegraDevolucao.setNomeUsuarioInclusao(regraDevolucao.getNomeUsuarioAlteracao());

		switch (regraDevolucao.getSituacaoRegraDevolucao().getCodigo().intValue()) {
		case 2:
			historicoSituacaoRegraDevolucao.setDescricaoHistorico(descricaoHistorico == null ? "Regra enviada para Homologação" : descricaoHistorico);
			break;
		case 3:
			historicoSituacaoRegraDevolucao.setDescricaoHistorico(descricaoHistorico == null ? "Regra Homologada" : descricaoHistorico);
			break;
		case 4:
			historicoSituacaoRegraDevolucao.setDescricaoHistorico(descricaoHistorico == null ? "Regra autorizada para entrar em produção" : descricaoHistorico);
			break;
		case 5:
			historicoSituacaoRegraDevolucao.setDescricaoHistorico(descricaoHistorico == null ? "Regra indeferida" : descricaoHistorico);
			break;
		case 6:
			historicoSituacaoRegraDevolucao.setDescricaoHistorico(descricaoHistorico == null ? "Regra revogada" : descricaoHistorico);
			break;
		}

		return historicoSituacaoRegraDevolucao;
	}

	/**
	 * Método responsável de enviar uma regra para Homologação
	 * 	
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/0/2017
	 * @param {@link RegraDevolucao}
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { PrevidenciaException.class })
	public void enviarRegraParaHomologacao(RegraDevolucao regraDevolucao) {
		try {
			RegraDevolucao regraDevolucaoParaSalvar = alterarAntesSalvarRegraDevolucao(regraDevolucao, 2L);
			HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao = criarHistoricoRegraDevolucao(regraDevolucaoParaSalvar, null);

			regraDevolucaoBO.salvarRegraDevolucao(regraDevolucaoParaSalvar);
			historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(historicoSituacaoRegraDevolucao);
		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			throw pEx;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi posível enviar a regra para Homologação!", e);
		}

	}

	/**
	 * Método responsável por Homologar uma regra de Devolução
	 * 	
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/0/2017
	 * @param {@link RegraDevolucao}
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { PrevidenciaException.class })
	public void homologarRegraDevolucao(RegraDevolucao regraDevolucao) {
		try {
			RegraDevolucao regraDevolucaoParaSalvar = alterarAntesSalvarRegraDevolucao(regraDevolucao, 3L);
			HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao = criarHistoricoRegraDevolucao(regraDevolucaoParaSalvar, null);

			regraDevolucaoBO.salvarRegraDevolucao(regraDevolucaoParaSalvar);
			historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(historicoSituacaoRegraDevolucao);
		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			throw pEx;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi posível Homologar a Regra de Devolução!", e);
		}

	}

	/**
	 * Método responsável por Autorizar uma regra de Devolução
	 * 	
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param {@link RegraDevolucao}
	 * @param revogarAnterior
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { PrevidenciaException.class })
	public void autorizarRegraDevolucao(RegraDevolucao regraDevolucao, boolean revogarVigente) {
		try {
			// Revogar a Regra Vigente
			if (revogarVigente) {

				RegraDevolucao regraDevolucaoVigente = regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigenciaSituacao(regraDevolucao.getPlanoVigenciaDevolucao());

				//Se existe regra vigente mando a revogar
				if (regraDevolucaoVigente != null) {
					regraDevolucaoVigente = alterarAntesSalvarRegraDevolucao(regraDevolucaoVigente, 6L);

					HistoricoSituacaoRegraDevolucao historicoSituacaoRegraVigente = criarHistoricoRegraDevolucao(regraDevolucaoVigente, null);

					regraDevolucaoBO.salvarRegraDevolucao(regraDevolucaoVigente);
					historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(historicoSituacaoRegraVigente);
				}
			}

			// Colocar em produção a nova regra
			RegraDevolucao regraDevolucaoParaSalvar = alterarAntesSalvarRegraDevolucao(regraDevolucao, 4L);
			HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao = criarHistoricoRegraDevolucao(regraDevolucaoParaSalvar, null);

			regraDevolucaoBO.salvarRegraDevolucao(regraDevolucaoParaSalvar);
			historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(historicoSituacaoRegraDevolucao);
		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			throw pEx;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi posível Autorizar a Regra de Devolução!", e);
		}

	}

	/**
	 * Método responsável por Indeferir uma regra de Devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param {@link RegraDevolucao}
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { PrevidenciaException.class })
	public void indeferirRegraDevolucao(RegraDevolucao regraDevolucao, String motivoIndeferimento) {
		try {
			RegraDevolucao regraDevolucaoParaSalvar = alterarAntesSalvarRegraDevolucao(regraDevolucao, 5L);
			HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao = criarHistoricoRegraDevolucao(regraDevolucaoParaSalvar, motivoIndeferimento);

			regraDevolucaoBO.salvarRegraDevolucao(regraDevolucaoParaSalvar);
			historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(historicoSituacaoRegraDevolucao);
		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			throw pEx;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi posível Indeferir a Regra de Devolução!", e);
		}
	}

	/**
	 * Método responsável por revogar uma regra de devolução e enviar a última revogada para produção
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param {@link RegraDevolucao}
	 * @param {@link PlanoVigenciaDevolucao}
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { PrevidenciaException.class })
	public void revogarRegraDevolucao(RegraDevolucao regraDevolucao, PlanoVigenciaDevolucao planoVigenciaDevolucao) {
		try {
			//Pegar a última regra revogada
			RegraDevolucao regraDevolucaoRevogada = regraDevolucaoBO.pesquisarUltimaRegraDevolucaoRevogada(planoVigenciaDevolucao);

			if (regraDevolucaoRevogada.getCodigo() == null) {
				throw new PrevidenciaException("Não existe uma regra revogada que possa ser colocada em produção");
			}

			//Colocar a regra atual como revogada
			RegraDevolucao regraDevolucaoParaSalvar = alterarAntesSalvarRegraDevolucao(regraDevolucao, 6L);
			HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucao = criarHistoricoRegraDevolucao(regraDevolucaoParaSalvar, null);

			regraDevolucaoBO.salvarRegraDevolucao(regraDevolucaoParaSalvar);
			historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(historicoSituacaoRegraDevolucao);

			//Colocar a revogada em produção
			regraDevolucaoRevogada = alterarAntesSalvarRegraDevolucao(regraDevolucaoRevogada, 4L);
			HistoricoSituacaoRegraDevolucao historicoSituacaoRegraDevolucaoRevogada = criarHistoricoRegraDevolucao(regraDevolucaoRevogada, null);

			regraDevolucaoBO.salvarRegraDevolucao(regraDevolucaoRevogada);
			historicoSituacaoRegraDevolucaoBO.salvarHistoricoSituacaoRegraDevolucao(historicoSituacaoRegraDevolucaoRevogada);
		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			throw pEx;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi posível Revogar a Regra de Devolução!", e);
		}

	}

	//Getters and Setters
	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public PlanoVigenciaDevolucao getPlanoVigenciaDevolucao() {
		return planoVigenciaDevolucao;
	}

	public void setPlanoVigenciaDevolucao(PlanoVigenciaDevolucao planoVigenciaDevolucao) {
		this.planoVigenciaDevolucao = planoVigenciaDevolucao;
	}

	public List<RegraDevolucao> getListaRegraDevolucao() {
		return listaRegraDevolucao;
	}

	public void setListaRegraDevolucao(List<RegraDevolucao> listaRegraDevolucao) {
		this.listaRegraDevolucao = listaRegraDevolucao;
	}

	public RegraDevolucao getNovaRegraDevolucao() {
		if (this.novaRegraDevolucao == null) {
			this.novaRegraDevolucao = new RegraDevolucao();
		}
		return novaRegraDevolucao;
	}

	public void setNovaRegraDevolucao(RegraDevolucao novaRegraDevolucao) {
		this.novaRegraDevolucao = novaRegraDevolucao;
	}

	public RegraDevolucao getNovaRegraDevolucao2() {
		if (this.novaRegraDevolucao2 == null) {
			this.novaRegraDevolucao2 = new RegraDevolucao();
		}
		return novaRegraDevolucao2;
	}

	public void setNovaRegraDevolucao2(RegraDevolucao novaRegraDevolucao2) {
		this.novaRegraDevolucao2 = novaRegraDevolucao2;
	}

	public RegraDevolucaoParametrizacaoDTO getRegraDevolucaoCompleto() {
		return regraDevolucaoCompleto;
	}

	public void setRegraDevolucaoCompleto(RegraDevolucaoParametrizacaoDTO regraDevolucaoCompleto) {
		this.regraDevolucaoCompleto = regraDevolucaoCompleto;
	}

	public LoginBBPrevWebDTO getLoginBBPrevWebDTO() {
		if (loginBBPrevWebDTO == null) {
			this.loginBBPrevWebDTO = UtilSession.getLoginSessao();
		}

		return loginBBPrevWebDTO;
	}

	public void setLoginBBPrevWebDTO(LoginBBPrevWebDTO loginBBPrevWebDTO) {
		this.loginBBPrevWebDTO = loginBBPrevWebDTO;
	}

}
