package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

public class RecebedoresResgateSumulaDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String nome;
	private String banco;
	private String agencia;
	private String conta;
	private String tipoDeposito;
	private String percentualRecebimento;
	private String cpf;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getTipoDeposito() {
		return tipoDeposito;
	}

	public void setTipoDeposito(String tipoDeposito) {
		this.tipoDeposito = tipoDeposito;
	}

	public String getPercentualRecebimento() {
		return percentualRecebimento;
	}

	public void setPercentualRecebimento(String percentualRecebimento) {
		this.percentualRecebimento = percentualRecebimento;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

}
