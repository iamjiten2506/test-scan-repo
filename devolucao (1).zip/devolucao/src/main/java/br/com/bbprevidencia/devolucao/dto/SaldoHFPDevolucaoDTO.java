package br.com.bbprevidencia.devolucao.dto;

/**
 * Classe auxiliar para montar uma lista de saldos de ficha financeira até o momento da devolução
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 07/06/2017
 *
 */
public class SaldoHFPDevolucaoDTO {

	private int ordem = 1;

	private String tipo;

	private Double qtdCotaContribuicao;

	private Double qtdCotaJuros;

	private Double qtdCotaCorrecao;

	private Double qtdCotaMulta;

	private String indicadorMulta;
	private String indicadorJuros;
	private String indicadorCorrecao;

	public SaldoHFPDevolucaoDTO() {
		super();
	}

	public SaldoHFPDevolucaoDTO(String tipo, Double qtdCotaContribuicao, Double qtdCotaJuros, Double qtdCotaCorrecao, Double qtdCotaMulta, String indicadorMulta, String indicadorJuros,
			String indicadorCorrecao) {
		super();
		this.tipo = tipo;
		this.qtdCotaContribuicao = qtdCotaContribuicao;
		this.qtdCotaJuros = qtdCotaJuros;
		this.qtdCotaCorrecao = qtdCotaCorrecao;
		this.qtdCotaMulta = qtdCotaMulta;
		this.indicadorMulta = indicadorMulta;
		this.indicadorJuros = indicadorJuros;
		this.indicadorCorrecao = indicadorCorrecao;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Double getQtdCotaContribuicao() {
		return qtdCotaContribuicao;
	}

	public void setQtdCotaContribuicao(Double qtdCotaContribuicao) {
		this.qtdCotaContribuicao = qtdCotaContribuicao;
	}

	public Double getQtdCotaJuros() {
		return qtdCotaJuros;
	}

	public void setQtdCotaJuros(Double qtdCotaJuros) {
		this.qtdCotaJuros = qtdCotaJuros;
	}

	public Double getQtdCotaCorrecao() {
		return qtdCotaCorrecao;
	}

	public void setQtdCotaCorrecao(Double qtdCotaCorrecao) {
		this.qtdCotaCorrecao = qtdCotaCorrecao;
	}

	public Double getQtdCotaMulta() {
		return qtdCotaMulta;
	}

	public void setQtdCotaMulta(Double qtdCotaMulta) {
		this.qtdCotaMulta = qtdCotaMulta;
	}

	public int getOrdem() {
		return ordem;
	}

	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}

	public String getIndicadorMulta() {
		return indicadorMulta;
	}

	public void setIndicadorMulta(String indicadorMulta) {
		this.indicadorMulta = indicadorMulta;
	}

	public String getIndicadorJuros() {
		return indicadorJuros;
	}

	public void setIndicadorJuros(String indicadorJuros) {
		this.indicadorJuros = indicadorJuros;
	}

	public String getIndicadorCorrecao() {
		return indicadorCorrecao;
	}

	public void setIndicadorCorrecao(String indicadorCorrecao) {
		this.indicadorCorrecao = indicadorCorrecao;
	}

}
