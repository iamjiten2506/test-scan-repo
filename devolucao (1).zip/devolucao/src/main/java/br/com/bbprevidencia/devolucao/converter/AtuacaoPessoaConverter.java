package br.com.bbprevidencia.devolucao.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import br.com.bbprevidencia.bbpcomum.util.FabricaManagedBean;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.pessoa.bo.AtuacaoPessoaBO;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoaPK;

@FacesConverter(value = "atuacaoPessoaConverter")
public class AtuacaoPessoaConverter implements Converter {

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
	 */
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String valor) {
		try {

			if (!UtilJava.isStringVazia(valor)) {
				return consultarPorChavePrimaria(valor);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public String getAsString(FacesContext context, UIComponent component, Object obj) {
		if (obj != null && obj instanceof AtuacaoPessoa) {

			AtuacaoPessoa atuacaoPessoa = (AtuacaoPessoa) obj;

			if (atuacaoPessoa.getChavePrimaria() != null && atuacaoPessoa.getChavePrimaria().getCodigoAreaAtuacao() != null && atuacaoPessoa.getChavePrimaria().getCodigo() != null) {
				return atuacaoPessoa.getChavePrimaria().getCodigoAreaAtuacao() + "@@@" + atuacaoPessoa.getChavePrimaria().getCodigo().toString();
			}
		}
		return null;
	}

	/**
	 * Consulta pessoa através da chave passada como argumento.
	 * 
	 * @param chavePessoa
	 * @return Pessoa
	 */
	public AtuacaoPessoa consultarPorChavePrimaria(String codigoAtuacaoPessoaPK) {
		AtuacaoPessoa atuacaoPessoaRetorno = null;
		if (codigoAtuacaoPessoaPK != null) {
			if (codigoAtuacaoPessoaPK.indexOf("@@@") > 0) {
				String[] arrayChave = codigoAtuacaoPessoaPK.split("@@@");
				AtuacaoPessoaPK chavePrimaria = new AtuacaoPessoaPK();
				chavePrimaria.setCodigo(new Long(arrayChave[0]));
				chavePrimaria.setCodigoAreaAtuacao(new String(arrayChave[1]));
				AtuacaoPessoaBO atuacaoPessoaBO = (AtuacaoPessoaBO) FabricaManagedBean.getManagedBean(AtuacaoPessoaBO.class);
				try {

					atuacaoPessoaRetorno = atuacaoPessoaBO.consultarPorChavePrimaria(chavePrimaria);

				} catch (Exception e) {
				}
			}
		}

		return atuacaoPessoaRetorno;
	}

}
