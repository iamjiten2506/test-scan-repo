package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

public class RelatorioSimulacaoResgateDTO {

	private String nomePlano;
	private String nomeParticipante;
	private String matriculaParticipante;
	private String situacaoPlano;
	private String indicadorFundador;
	private String tipoTributacao;
	private Date dataAdmissao;
	private Date dataInscricaoPlano;
	private Date dataDesligamento;
	private Date dataCancelamentoPlano;
	private Date dataUltProcessoPlano;
	private Date dataUltimoLancamento;
	private Double saldoResgParticipante;
	private Double prcResgParticipante;
	private Double saldoResgPatrocinadora;
	private Double prcResgPatrocinadora;
	private Double valorBruto;
	private Double valorIR;
	private Double prcIR;
	private Double saldoRemaParticicipante;
	private Double saldoRemaPatrocinadora;
	private Double prcRemaParticipante;
	private Double prcRemaPatrocinadora;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getSituacaoPlano() {
		return situacaoPlano;
	}

	public void setSituacaoPlano(String situacaoPlano) {
		this.situacaoPlano = situacaoPlano;
	}

	public String getIndicadorFundador() {
		return indicadorFundador;
	}

	public void setIndicadorFundador(String indicadorFundador) {
		this.indicadorFundador = indicadorFundador;
	}

	public String getTipoTributacao() {
		return tipoTributacao;
	}

	public void setTipoTributacao(String tipoTributacao) {
		this.tipoTributacao = tipoTributacao;
	}

	public Date getDataAdmissao() {
		return dataAdmissao;
	}

	public void setDataAdmissao(Date dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public Date getDataInscricaoPlano() {
		return dataInscricaoPlano;
	}

	public void setDataInscricaoPlano(Date dataInscricaoPlano) {
		this.dataInscricaoPlano = dataInscricaoPlano;
	}

	public Date getDataDesligamento() {
		return dataDesligamento;
	}

	public void setDataDesligamento(Date dataDesligamento) {
		this.dataDesligamento = dataDesligamento;
	}

	public Date getDataCancelamentoPlano() {
		return dataCancelamentoPlano;
	}

	public void setDataCancelamentoPlano(Date dataCancelamentoPlano) {
		this.dataCancelamentoPlano = dataCancelamentoPlano;
	}

	public Date getDataUltProcessoPlano() {
		return dataUltProcessoPlano;
	}

	public void setDataUltProcessoPlano(Date dataUltProcessoPlano) {
		this.dataUltProcessoPlano = dataUltProcessoPlano;
	}

	public Date getDataUltimoLancamento() {
		return dataUltimoLancamento;
	}

	public void setDataUltimoLancamento(Date dataUltimoLancamento) {
		this.dataUltimoLancamento = dataUltimoLancamento;
	}

	public Double getSaldoResgParticipante() {
		return saldoResgParticipante;
	}

	public void setSaldoResgParticipante(Double saldoResgParticipante) {
		this.saldoResgParticipante = saldoResgParticipante;
	}

	public Double getPrcResgParticipante() {
		return prcResgParticipante;
	}

	public void setPrcResgParticipante(Double prcResgParticipante) {
		this.prcResgParticipante = prcResgParticipante;
	}

	public Double getSaldoResgPatrocinadora() {
		return saldoResgPatrocinadora;
	}

	public void setSaldoResgPatrocinadora(Double saldoResgPatrocinadora) {
		this.saldoResgPatrocinadora = saldoResgPatrocinadora;
	}

	public Double getPrcResgPatrocinadora() {
		return prcResgPatrocinadora;
	}

	public void setPrcResgPatrocinadora(Double prcResgPatrocinadora) {
		this.prcResgPatrocinadora = prcResgPatrocinadora;
	}

	public Double getValorBruto() {
		return valorBruto;
	}

	public void setValorBruto(Double valorBruto) {
		this.valorBruto = valorBruto;
	}

	public Double getValorIR() {
		return valorIR;
	}

	public void setValorIR(Double valorIR) {
		this.valorIR = valorIR;
	}

	public Double getPrcIR() {
		return prcIR;
	}

	public void setPrcIR(Double prcIR) {
		this.prcIR = prcIR;
	}

	public Double getSaldoRemaParticicipante() {
		return saldoRemaParticicipante;
	}

	public void setSaldoRemaParticicipante(Double saldoRemaParticicipante) {
		this.saldoRemaParticicipante = saldoRemaParticicipante;
	}

	public Double getSaldoRemaPatrocinadora() {
		return saldoRemaPatrocinadora;
	}

	public void setSaldoRemaPatrocinadora(Double saldoRemaPatrocinadora) {
		this.saldoRemaPatrocinadora = saldoRemaPatrocinadora;
	}

	public Double getPrcRemaParticipante() {
		return prcRemaParticipante;
	}

	public void setPrcRemaParticipante(Double prcRemaParticipante) {
		this.prcRemaParticipante = prcRemaParticipante;
	}

	public Double getPrcRemaPatrocinadora() {
		return prcRemaPatrocinadora;
	}

	public void setPrcRemaPatrocinadora(Double prcRemaPatrocinadora) {
		this.prcRemaPatrocinadora = prcRemaPatrocinadora;
	}

}
