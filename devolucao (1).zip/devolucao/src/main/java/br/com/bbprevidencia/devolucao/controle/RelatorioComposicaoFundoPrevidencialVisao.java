package br.com.bbprevidencia.devolucao.controle;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.bbpcomum.util.UtilXls;
import br.com.bbprevidencia.cadastroweb.bo.PlanoGuardaChuvaBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoGuardaChuva;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.LancamentoIntegracaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioComposicaoFundoPrevidencialDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório de Saldo por Conta.
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 15/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioComposicaoFundoPrevidencialVisao")
public class RelatorioComposicaoFundoPrevidencialVisao {

	private static final String FW_RELATORIO_COMP_FUNDO_PREVIDENCIAL = "/paginas/relatorioComposicaoFundoPrevidencial.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioComposicaoFundoPrevidencialVisao.class);

	@Autowired
	RelatorioUtil relatorioUtil;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private Date dataInicio;
	private Date dataFim;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private PlanoGuardaChuvaBO planoGuardaChuvaBO;

	@Autowired
	private LancamentoIntegracaoDevolucaoBO lancamentoIntegracaoDevolucaoBO;

	private List<PlanoGuardaChuva> listaPlanoGuardaChuva;

	private PlanoGuardaChuva planoGuardaChuva;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;

	private boolean selecionarPlano;

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/03/2017
	 * @return
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		this.listaPlanoGuardaChuva = this.planoGuardaChuvaBO.listarTodos();

		return FW_RELATORIO_COMP_FUNDO_PREVIDENCIAL;
	}

	public void setarValoresIniciais() {
		this.dataInicio = null;
		this.dataFim = null;
		this.selecionarPlano = false;
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.planoGuardaChuva = null;
	}

	/**
	 * Método encarregado de emitir o relatório
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/03/2017
	 */
	public void exportarRelatorio(ActionEvent event) {
		try {
			String idEnviado = event.getComponent().getId();
			List<RelatorioComposicaoFundoPrevidencialDTO> relatorioComposicao = new ArrayList<RelatorioComposicaoFundoPrevidencialDTO>();

			relatorioComposicao = this.lancamentoIntegracaoDevolucaoBO.listarComposicaoFundoPrevidencial(this.planoGuardaChuva, this.listaPlanoPrevidenciaSelecionados, this.dataInicio, this.dataFim);

			if (UtilJava.isColecaoVazia(relatorioComposicao)) {
				Mensagens.addMsgInfo("Não foram encontradas informações para estes parâmetros!");
			} else {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);

				JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(relatorioComposicao);

				if (idEnviado.equalsIgnoreCase("btEmitirPDF")) {
					String nomeArquivo = relatorioUtil.gerarRelatorio("composicaoFundoPrevidencial", relatorioComposicao, parametros);
					relatorioUtil.abrirPoupUp(nomeArquivo);
				} else {
					this.exportarParaExcel(relatorioComposicao);
				}

			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro("Erro ao exportar relatório.");
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	private void exportarParaExcel(List<RelatorioComposicaoFundoPrevidencialDTO> relatorioComposicao) {
		try {
			Workbook wb = new HSSFWorkbook();
			Sheet sheet = wb.createSheet("Planilha1");

			int rownum = 0;
			int cellnum = 0;
			Cell cell;
			Row row;

			HSSFDataFormat numberFormat = (HSSFDataFormat) wb.createDataFormat();
			CellStyle headerStyle = wb.createCellStyle();
			headerStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);

			Font font = wb.createFont();
			font.setBold(true);
			headerStyle.setFont(font);

			CellStyle textStyle = wb.createCellStyle();
			textStyle.setVerticalAlignment(VerticalAlignment.CENTER);

			CellStyle textStyleRight = wb.createCellStyle();
			textStyleRight.setAlignment(HorizontalAlignment.RIGHT);
			textStyleRight.setVerticalAlignment(VerticalAlignment.CENTER);
			textStyleRight.setFont(font);

			CellStyle numberStyle = wb.createCellStyle();
			numberStyle.setDataFormat(numberFormat.getFormat("#,##0.00"));
			numberStyle.setAlignment(HorizontalAlignment.RIGHT);

			CellStyle numberStyleBold = wb.createCellStyle();
			numberStyleBold.setDataFormat(numberFormat.getFormat("#,##0.00"));
			numberStyleBold.setAlignment(HorizontalAlignment.RIGHT);
			numberStyleBold.setFont(font);

			numberStyle.setVerticalAlignment(VerticalAlignment.CENTER);
			// Configurando Header
			row = sheet.createRow(rownum++);
			cell = UtilJava.addCelula(row, cellnum++, headerStyle, "MATRICULA");
			cell = UtilJava.addCelula(row, cellnum++, headerStyle, "PLANO");
			cell = UtilJava.addCelula(row, cellnum++, headerStyle, "PARTE_PLANO");
			cell = UtilJava.addCelula(row, cellnum++, headerStyle, "DATA_MOVIMENTO");
			cell = UtilJava.addCelula(row, cellnum++, headerStyle, "VALOR");

			for (RelatorioComposicaoFundoPrevidencialDTO obj : relatorioComposicao) {
				row = sheet.createRow(rownum++);
				cellnum = 0;

				cell = UtilJava.addCelula(row, cellnum++, textStyle, obj.getMatricula());
				cell = UtilJava.addCelula(row, cellnum++, textStyle, obj.getNomePlano());
				cell = UtilJava.addCelula(row, cellnum++, textStyle, obj.getNomePartePlano());
				cell = UtilJava.addCelula(row, cellnum++, textStyle, UtilJava.formataDataPorPadrao(obj.getDataMovimento(), "dd/MM/yyyy"));
				cell = UtilJava.addCelula(row, cellnum++, numberStyle, obj.getValorIntegrado());
			}

			row = sheet.createRow(rownum++);
			cell = row.createCell(0);
			cell.setCellValue("Total:");
			cell.setCellStyle(textStyleRight);

			cell = row.createCell(4);
			cell.setCellType(CellType.FORMULA);
			cell.setCellStyle(numberStyleBold);
			cell.setCellFormula("SUM(E2:E" + (relatorioComposicao.size() + 1) + ")");
			CellRangeAddress cra = new CellRangeAddress(row.getRowNum(), row.getRowNum(), row.getFirstCellNum(), 3);
			sheet.addMergedRegion(cra);

			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();

			wb.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();
			UtilXls.imprimeXLS(outArray, "composicaoFundoPrevidencial_" + UtilJava.formataDataPorPadrao(new Date(), "ddMMyyyhhmmss"));

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao exportar arquivo em Excel:" + e.getMessage());
		}

	}

	public void listarPartePlanoPorPlanoGuardaChuva(AjaxBehaviorEvent event) {
		try {
			if (this.listaPlanoGuardaChuva != null) {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
				this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();

				this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPorPlanoGuardaChuva(this.planoGuardaChuva);
				this.selecionarPlano = true;
			}
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro(e.getMessage());
		}

	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

	public List<PlanoGuardaChuva> getListaPlanoGuardaChuva() {
		return listaPlanoGuardaChuva;
	}

	public void setListaPlanoGuardaChuva(List<PlanoGuardaChuva> listaPlanoGuardaChuva) {
		this.listaPlanoGuardaChuva = listaPlanoGuardaChuva;
	}

	public PlanoGuardaChuva getPlanoGuardaChuva() {
		return planoGuardaChuva;
	}

	public void setPlanoGuardaChuva(PlanoGuardaChuva planoGuardaChuva) {
		this.planoGuardaChuva = planoGuardaChuva;
	}

}
