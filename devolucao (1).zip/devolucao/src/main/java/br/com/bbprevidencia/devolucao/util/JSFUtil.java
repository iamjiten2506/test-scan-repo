/**
 * 
 */
package br.com.bbprevidencia.devolucao.util;

import java.io.IOException;
import java.util.List;

import javax.faces.FacesException;
import javax.faces.FactoryFinder;
import javax.faces.application.StateManager;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.faces.render.ResponseStateManager;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.faces.renderkit.RenderKitUtils;

/**
 *
 * @author Tiago Menezes
 * @since 13/12/2012
 * 
 * Copyright notice (c) 2012 BBPrevidência S/A 
 */
public class JSFUtil {

	private static FacesContext facesContext;

	/**
	 * 
	 * @return FacesContext
	 */
	public static FacesContext getFacesContext() {
		if (facesContext == null) {
			facesContext = FacesContext.getCurrentInstance();
		}
		return facesContext;
	}

	/**
	 * Cria o ciclo de vida padrão do JSF (Java Server Faces)
	 * 
	 * @return Lifecycle
	 */
	public static Lifecycle getLifecycleDefault() {
		LifecycleFactory lifecycleFactory = (LifecycleFactory) FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
		Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);
		return lifecycle;
	}

	/**
	 * 
	 * @return FacesContextFactory
	 */
	public static FacesContextFactory getFacesContextFactory() {
		FacesContextFactory contextFactory = (FacesContextFactory) FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
		return contextFactory;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 */
	public static void setFacesContext(HttpServletRequest request, HttpServletResponse response) {
		ServletContext servletContext = request.getSession().getServletContext();
		facesContext = getFacesContextFactory().getFacesContext(servletContext, request, response, getLifecycleDefault());
	}

	/**
	 * 
	 * @param recurso
	 */
	public static void setViewRoot(String recurso) {
		UIViewRoot viewRoot = getFacesContext().getApplication().getViewHandler().createView(getFacesContext(), recurso);
		getFacesContext().setViewRoot(viewRoot);
	}

	/**
	 * 
	 * @return ViewHandler
	 */
	public static ViewHandler getViewHandler() {
		return getFacesContext().getApplication().getViewHandler();
	}

	/**
	 * 
	 */
	public static void renderView() {
		try {
			getViewHandler().renderView(getFacesContext(), getFacesContext().getViewRoot());
		} catch (FacesException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @return UIViewRoot
	 */
	public static UIViewRoot restoreView() {
		String viewId = getFacesContext().getViewRoot().getViewId();
		String renderKitId = getFacesContext().getViewRoot().getRenderKitId();
		return getStateManager().restoreView(getFacesContext(), viewId, renderKitId);
	}

	/**
	 * 
	 * @return StateManager
	 */
	private static StateManager getStateManager() {
		return getFacesContext().getApplication().getStateManager();
	}

	/**
	 * 
	 * @return boolean
	 */
	public static boolean isPostback() {
		// Get the renderKitId by calling viewHandler.calculateRenderKitId().
		String renderkitId = getViewHandler().calculateRenderKitId(getFacesContext());
		ResponseStateManager rsm = RenderKitUtils.getResponseStateManager(getFacesContext(), renderkitId);
		return rsm.isPostback(getFacesContext());
	}

	/**
	 * Busca o componente na pagina atraves do codigo do componente.
	 * 
	 * @param codigo
	 * @return UIComponent
	 */
	public static UIComponent buscarComponente(String codigo) {

		UIViewRoot root = FacesContext.getCurrentInstance().getViewRoot();

		return buscarComponente(root, codigo);
	}

	/**
	 * Metodo recursivo para encontrar o componente atraves do codigo.
	 * 
	 * @param componente
	 * @param codigo
	 * @return UIComponent
	 */
	private static UIComponent buscarComponente(UIComponent componente, String codigo) {

		if (componente == null) {
			return null;
		} else if (componente.getId() != null && componente.getId().equals(codigo)) {
			return componente;
		} else {

			List<UIComponent> listaComponentes = componente.getChildren();
			if (listaComponentes == null || listaComponentes.isEmpty()) {
				return null;
			}

			for (UIComponent filho : listaComponentes) {
				UIComponent resultado = buscarComponente(filho, codigo);
				if (resultado != null) {
					return resultado;
				}
			}
			return null;
		}
	}

}
