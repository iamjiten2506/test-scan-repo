package br.com.bbprevidencia.devolucao.dto;

import br.com.bbprevidencia.cadastroweb.dto.*;
import br.com.bbprevidencia.interno.dto.UnidadeOrganizacional;
import br.com.bbprevidencia.pessoa.dto.AtividadeEconomica;
import br.com.bbprevidencia.pessoa.dto.Profissao;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "PESSOA", schema = "OWN_CGP")
@NamedQuery(name = "PessoaEntidadePortal.findAll", query = "SELECT q FROM PessoaEntidadePortal q")
public class PessoaEntidadePortal implements Serializable, BaseEntity {
	private static final long serialVersionUID = -1L;
	@Id
	@SequenceGenerator(name = "PESSOA_GER", sequenceName = "S_PESSOA_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PESSOA_GER")
	@Column(name = "COD_PESSOA")
	private Long codigo;
	@Column(name = "NOM_PESSOA")
	private String nome;
	@Column(name = "NOM_ABREV_PESSOA")
	private String nomeAbreviado;
	@Column(name = "COD_TIPO_PESSOA")
	private String tipoPessoa;
	@Column(name = "NUM_CIC")
	private String codigoCIC;
	@Column(name = "DAT_PESQUI_SERASA")
	private Date dataPesquisaSerasa;
	@Column(name = "DSC_OBSERV_SERASA")
	private String descricaoObservacaoSerasa;
	@Column(name = "IND_PESSOA_BRAS")
	private String indicadorBrasileiro;
	@Column(name = "IND_SOCIO_ADMIN_PROCUR")
	private String indicadorSocioAdminProc;
	@Column(name = "DAT_VALID_DADO")
	private Date dataValidacaoDado;
	@Column(name = "NUM_INSCR_INSS")
	private Long inscricaoInss;
	@Column(name = "NUM_RG")
	private String identidade;
	@Column(name = "DSC_ORGAO_EMISS")
	private String orgaoEmissor;
	@Column(name = "DAT_EMISS_RG")
	private Date dataEmissao;
	@ManyToOne
	@JoinColumn(name = "IND_ESTADO_CIVIL")
	private EstadoCivil estadoCivil;
	@Column(name = "NUM_REGIST_PROFIS")
	private String registroProfissional;
	@Column(name = "IND_SEXO")
	private String indicadorSexo;
	@Column(name = "DAT_NASC")
	private Date dataNascimento;
	@Column(name = "DSC_NATUR")
	private String descricaoNaturalidade;
	@Column(name = "NOM_PAI")
	private String nomePai;
	@Column(name = "NOM_MAE")
	private String nomeMae;
	@Column(name = "NOM_CONJUG")
	private String nomeConjuge;
	@Column(name = "IND_TIPO_DOC_IDENT")
	private Integer indicadorTipoDocIdentidade;
	@Column(name = "VAL_RENDIM")
	private Double valorRendimento;
	@Column(name = "NUM_INSCR_MUNIC")
	private String numeroInscricaoMunicipal;
	@Column(name = "NUM_INSCR_ESTADU")
	private String numeroInscricaoEstadual;
	@Column(name = "NOM_FANTAS")
	private String nomeFantasia;
	@Column(name = "NUM_NIRE")
	private String numeroIdentificadorRegEmpresarial;
	@Column(name = "VAL_PATRIM_LIQUID")
	private Double valorPatrimonioLiquido;
	@Column(name = "DAT_ATUALZ_PATRIM_LIQUID")
	private Date dataAtualizacaoPatrimonioLiquido;
	@Column(name = "DAT_ATUALZ_CAPITL_SOCIAL")
	private Date dataAtualizacaoCapitalSocial;
	@Column(name = "VAL_CAPITL_SOCIAL")
	private Double valorCapitalSocial;
	@Column(name = "IND_SITUAC_FINANC")
	private String indicadorSituacaoFinanceira;
	@Column(name = "IND_ISENTO_COFINS")
	private String indicadorIsentoCofins;
	@Column(name = "IND_ISENTO_PIS_PASEP")
	private String indicadorIsentoPisPasep;
	@ManyToOne
	@JoinColumn(name = "COD_UNID_ORGANZ_INCL")
	private UnidadeOrganizacional unidadeOrganizacional;
	@ManyToOne
	@JoinColumn(name = "COD_PAIS")
	private Pais pais;
	@ManyToOne
	@JoinColumn(name = "COD_PROFIS")
	private Profissao profissao;
	@ManyToOne
	@JoinColumn(name = "COD_CNAE")
	private AtividadeEconomica atividadeEconomica;
	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "NUM_SEQ_PARTIC"), @JoinColumn(name = "NUM_SEQ_DEP") })
	private DependenteParticipante dependenteParticipante;
	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCL")
	private Date dataInclusao;
	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTER")
	private Date dataAlteracao;
	@Column(name = "NOM_USU_INCL")
	private String nomeUsuarioInclusao;
	@Column(name = "NOM_USU_ALTER")
	private String nomeUsuarioAlteracao;
	@Column(name = "NOM_RAZAO_SOCIAL")
	private String razaoSocial;
	@Column(name = "IND_ISENTO_IR")
	private String indicadorIsentoIR;
	@Column(name = "IND_ISENTO_CSRF")
	private String indicadorIsentoCSRF;
	@Column(name = "IND_PPE")
	private String indicadorPPE;
	@Column(name = "NUM_SEQ_PIX_ALFAN")
	private Long pixAlfandega;
	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "NUM_SEQ_ENTID_PARTIC", referencedColumnName = "NUM_SEQ_ENTID_PARTIC"), @JoinColumn(name = "NUM_SEQ_FUNDO_PREVD", referencedColumnName = "NUM_SEQ_FUNDO_PREVD") })
	private EntidadeParticipante entidadeParticipante;

	public PessoaEntidadePortal() {
	}

	public Long getCodigo() {
		return this.codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNomeAbreviado() {
		return this.nomeAbreviado;
	}

	public void setNomeAbreviado(String nomeAbreviado) {
		this.nomeAbreviado = nomeAbreviado;
	}

	public String getTipoPessoa() {
		return this.tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public String getCodigoCIC() {
		return this.codigoCIC;
	}

	public void setCodigoCIC(String codigoCIC) {
		this.codigoCIC = codigoCIC;
	}

	public Date getDataPesquisaSerasa() {
		return this.dataPesquisaSerasa;
	}

	public void setDataPesquisaSerasa(Date dataPesquisaSerasa) {
		this.dataPesquisaSerasa = dataPesquisaSerasa;
	}

	public String getDescricaoObservacaoSerasa() {
		return this.descricaoObservacaoSerasa;
	}

	public void setDescricaoObservacaoSerasa(String descricaoObservacaoSerasa) {
		this.descricaoObservacaoSerasa = descricaoObservacaoSerasa;
	}

	public String getIndicadorBrasileiro() {
		return this.indicadorBrasileiro;
	}

	public void setIndicadorBrasileiro(String indicadorBrasileiro) {
		this.indicadorBrasileiro = indicadorBrasileiro;
	}

	public String getIndicadorSocioAdminProc() {
		return this.indicadorSocioAdminProc;
	}

	public void setIndicadorSocioAdminProc(String indicadorSocioAdminProc) {
		this.indicadorSocioAdminProc = indicadorSocioAdminProc;
	}

	public Date getDataValidacaoDado() {
		return this.dataValidacaoDado;
	}

	public void setDataValidacaoDado(Date dataValidacaoDado) {
		this.dataValidacaoDado = dataValidacaoDado;
	}

	public Long getInscricaoInss() {
		return this.inscricaoInss;
	}

	public void setInscricaoInss(Long inscricaoInss) {
		this.inscricaoInss = inscricaoInss;
	}

	public String getIdentidade() {
		return this.identidade;
	}

	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}

	public String getOrgaoEmissor() {
		return this.orgaoEmissor;
	}

	public void setOrgaoEmissor(String orgaoEmissor) {
		this.orgaoEmissor = orgaoEmissor;
	}

	public Date getDataEmissao() {
		return this.dataEmissao;
	}

	public void setDataEmissao(Date dataEmissao) {
		this.dataEmissao = dataEmissao;
	}

	public EstadoCivil getEstadoCivil() {
		return this.estadoCivil;
	}

	public void setEstadoCivil(EstadoCivil estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public String getRegistroProfissional() {
		return this.registroProfissional;
	}

	public void setRegistroProfissional(String registroProfissional) {
		this.registroProfissional = registroProfissional;
	}

	public String getIndicadorSexo() {
		return this.indicadorSexo;
	}

	public void setIndicadorSexo(String indicadorSexo) {
		this.indicadorSexo = indicadorSexo;
	}

	public Date getDataNascimento() {
		return this.dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getDescricaoNaturalidade() {
		return this.descricaoNaturalidade;
	}

	public void setDescricaoNaturalidade(String descricaoNaturalidade) {
		this.descricaoNaturalidade = descricaoNaturalidade;
	}

	public String getNomePai() {
		return this.nomePai;
	}

	public void setNomePai(String nomePai) {
		this.nomePai = nomePai;
	}

	public String getNomeMae() {
		return this.nomeMae;
	}

	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}

	public String getNomeConjuge() {
		return this.nomeConjuge;
	}

	public void setNomeConjuge(String nomeConjuge) {
		this.nomeConjuge = nomeConjuge;
	}

	public Integer getIndicadorTipoDocIdentidade() {
		return this.indicadorTipoDocIdentidade;
	}

	public void setIndicadorTipoDocIdentidade(Integer indicadorTipoDocIdentidade) {
		this.indicadorTipoDocIdentidade = indicadorTipoDocIdentidade;
	}

	public Double getValorRendimento() {
		return this.valorRendimento;
	}

	public void setValorRendimento(Double valorRendimento) {
		this.valorRendimento = valorRendimento;
	}

	public String getNumeroInscricaoMunicipal() {
		return this.numeroInscricaoMunicipal;
	}

	public void setNumeroInscricaoMunicipal(String numeroInscricaoMunicipal) {
		this.numeroInscricaoMunicipal = numeroInscricaoMunicipal;
	}

	public String getNumeroInscricaoEstadual() {
		return this.numeroInscricaoEstadual;
	}

	public void setNumeroInscricaoEstadual(String numeroInscricaoEstadual) {
		this.numeroInscricaoEstadual = numeroInscricaoEstadual;
	}

	public String getNomeFantasia() {
		return this.nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public String getNumeroIdentificadorRegEmpresarial() {
		return this.numeroIdentificadorRegEmpresarial;
	}

	public void setNumeroIdentificadorRegEmpresarial(String numeroIdentificadorRegEmpresarial) {
		this.numeroIdentificadorRegEmpresarial = numeroIdentificadorRegEmpresarial;
	}

	public Double getValorPatrimonioLiquido() {
		return this.valorPatrimonioLiquido;
	}

	public void setValorPatrimonioLiquido(Double valorPatrimonioLiquido) {
		this.valorPatrimonioLiquido = valorPatrimonioLiquido;
	}

	public Date getDataAtualizacaoPatrimonioLiquido() {
		return this.dataAtualizacaoPatrimonioLiquido;
	}

	public void setDataAtualizacaoPatrimonioLiquido(Date dataAtualizacaoPatrimonioLiquido) {
		this.dataAtualizacaoPatrimonioLiquido = dataAtualizacaoPatrimonioLiquido;
	}

	public Date getDataAtualizacaoCapitalSocial() {
		return this.dataAtualizacaoCapitalSocial;
	}

	public void setDataAtualizacaoCapitalSocial(Date dataAtualizacaoCapitalSocial) {
		this.dataAtualizacaoCapitalSocial = dataAtualizacaoCapitalSocial;
	}

	public Double getValorCapitalSocial() {
		return this.valorCapitalSocial;
	}

	public void setValorCapitalSocial(Double valorCapitalSocial) {
		this.valorCapitalSocial = valorCapitalSocial;
	}

	public String getIndicadorSituacaoFinanceira() {
		return this.indicadorSituacaoFinanceira;
	}

	public void setIndicadorSituacaoFinanceira(String indicadorSituacaoFinanceira) {
		this.indicadorSituacaoFinanceira = indicadorSituacaoFinanceira;
	}

	public String getIndicadorIsentoCofins() {
		return this.indicadorIsentoCofins;
	}

	public void setIndicadorIsentoCofins(String indicadorIsentoCofins) {
		this.indicadorIsentoCofins = indicadorIsentoCofins;
	}

	public String getIndicadorIsentoPisPasep() {
		return this.indicadorIsentoPisPasep;
	}

	public void setIndicadorIsentoPisPasep(String indicadorIsentoPisPasep) {
		this.indicadorIsentoPisPasep = indicadorIsentoPisPasep;
	}

	public UnidadeOrganizacional getUnidadeOrganizacional() {
		return this.unidadeOrganizacional;
	}

	public void setUnidadeOrganizacional(UnidadeOrganizacional unidadeOrganizacional) {
		this.unidadeOrganizacional = unidadeOrganizacional;
	}

	public Pais getPais() {
		return this.pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}

	public Profissao getProfissao() {
		return this.profissao;
	}

	public void setProfissao(Profissao profissao) {
		this.profissao = profissao;
	}

	public AtividadeEconomica getAtividadeEconomica() {
		return this.atividadeEconomica;
	}

	public void setAtividadeEconomica(AtividadeEconomica atividadeEconomica) {
		this.atividadeEconomica = atividadeEconomica;
	}

	public DependenteParticipante getDependenteParticipante() {
		return this.dependenteParticipante;
	}

	public void setDependenteParticipante(DependenteParticipante dependenteParticipante) {
		this.dependenteParticipante = dependenteParticipante;
	}

	public Date getDataInclusao() {
		return this.dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Date getDataAlteracao() {
		return this.dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return this.nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return this.nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getRazaoSocial() {
		return this.razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getIndicadorIsentoIR() {
		return this.indicadorIsentoIR;
	}

	public void setIndicadorIsentoIR(String indicadorIsentoIR) {
		this.indicadorIsentoIR = indicadorIsentoIR;
	}

	public String getIndicadorIsentoCSRF() {
		return this.indicadorIsentoCSRF;
	}

	public void setIndicadorIsentoCSRF(String indicadorIsentoCSRF) {
		this.indicadorIsentoCSRF = indicadorIsentoCSRF;
	}

	public String getIndicadorPPE() {
		return this.indicadorPPE;
	}

	public void setIndicadorPPE(String indicadorPPE) {
		this.indicadorPPE = indicadorPPE;
	}

	//        public int hashCode() {
	//            int prime = true;
	//            int result = 1;
	//            result = 31 * result + (this.codigo == null ? 0 : this.codigo.hashCode());
	//            return result;
	//        }

	//        public boolean equals(Object obj) {
	//            if (this == obj) {
	//                return true;
	//            } else if (obj == null) {
	//                return false;
	//            } else if (this.getClass() != obj.getClass()) {
	//                return false;
	//            } else {
	//                br.com.bbprevidencia.pessoa.dto.PessoaEntidade other = (br.com.bbprevidencia.pessoa.dto.PessoaEntidade)obj;
	//                if (this.codigo == null) {
	//                    if (other.codigo != null) {
	//                        return false;
	//                    }
	//                } else if (!this.codigo.equals(other.codigo)) {
	//                    return false;
	//                }
	//
	//                return true;
	//            }
	//        }

	public boolean isIsentoConfins() {
		return this.indicadorIsentoCofins != null && (this.indicadorIsentoCofins.equals("S") || this.tipoPessoa.equals("F"));
	}

	public boolean isIsentoPisPasep() {
		return this.indicadorIsentoPisPasep != null && (this.indicadorIsentoPisPasep.equals("S") || this.tipoPessoa.equals("F"));
	}

	public boolean isIsentoIR() {
		return this.indicadorIsentoIR != null && (this.indicadorIsentoIR.equals("S") || this.tipoPessoa.equals("F"));
	}

	public boolean isIsentoCRSF() {
		return this.indicadorIsentoCSRF != null && (this.indicadorIsentoCSRF.equals("S") || this.tipoPessoa.equals("F"));
	}

	public Long getPixAlfandega() {
		return this.pixAlfandega;
	}

	public void setPixAlfandega(Long pixAlfandega) {
		this.pixAlfandega = pixAlfandega;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return this.entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}
}
