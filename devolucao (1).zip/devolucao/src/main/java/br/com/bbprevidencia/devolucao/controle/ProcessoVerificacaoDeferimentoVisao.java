package br.com.bbprevidencia.devolucao.controle;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.MappingJsonFactory;

import br.com.bbprevidencia.alcada.dto.RetornoMovAlcadaDTO;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.HistoricoFinanceiroSpParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author BBPF0333 - Daniel Martins
 * @since 24/01/2017
 *
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("processoVerificacaoDeferimentoVisao")
public class ProcessoVerificacaoDeferimentoVisao {

	private static String FW_PROCESSO_VERIFICACAO_DEFERIMENTO = "/paginas/processoVerificacaoDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static Logger log = Logger.getLogger(ProcessoVerificacaoDeferimentoVisao.class);

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private AmbienteServico ambienteServico;

	@Autowired
	private ParametroGeralBO parametroGeralBO;

	@Autowired
	private HistoricoFinanceiroSpParticipanteBO historicoFinanceiroSpParticipanteBO;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<TipoDevolucao> listaTipoDevolucao;

	private List<Devolucao> listaDevolucaoDeferido;

	private List<Devolucao> listaDevolucaoSelecionadasDeferido;

	private Devolucao devolucaoSelecianadaDeferido;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private CronogramaDevolucao cronogramaDevolucao;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private TipoDevolucao tipoDevolucao;

	private String numeroMatriculaPatrocinadora;

	@Value("#{propriedades['url.ambiente']}")
	private String urlAmbiente;

	/**
	 * Método encarredado por iniciar a página
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 24/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoVerificacaoDeferimento");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.listarDevolucaoDeferido();

		// Fazer cargas de listas de Combo.
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarCronogramaDevolucaoPermitemProcessamento());
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(entidadeParticipanteBO.listarEntidadeParticipante());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanos());
		this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBO.listarTodosTipoDevolucao());

		return FW_PROCESSO_VERIFICACAO_DEFERIMENTO;
	}

	// Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 26/01/2017
	 */
	public void limpaSelecao() {
		this.setCronogramaDevolucao(null);
		this.setEntidadeParticipante(null);
		this.setPlanoPrevidencia(null);
		this.setTipoDevolucao(null);
		this.setNumeroMatriculaPatrocinadora(null);
	}

	public String listarDevolucaoDeferido() {

		SituacaoDevolucao situacaoDevolucao = new SituacaoDevolucao();

		situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.EM_DEFERIMENTO.getCodigo());

		List<Devolucao> listaDevolucaoTmp = new ArrayList<Devolucao>();

		this.listaDevolucaoDeferido = new ArrayList<Devolucao>();

		listaDevolucaoTmp = devolucaoBO.listarDevolucaoPorSituacao(situacaoDevolucao);

		if (listaDevolucaoTmp != null) {

			for (Devolucao devolucao : listaDevolucaoTmp) {

				RetornoMovAlcadaDTO retornoMovAlcadaDTO = new RetornoMovAlcadaDTO();

				try {

					// Solicitar Lote.
					URL url = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/verificaAutMovAlcadaWs?numeroAlcada=" + devolucao.getMovimentoAlcada());
					HttpURLConnection connection = (HttpURLConnection) url.openConnection();
					connection.setConnectTimeout(15000);
					connection.connect();

					String responseJson = inputStreamToString(connection.getInputStream());

					retornoMovAlcadaDTO = (RetornoMovAlcadaDTO) fromJson(responseJson, RetornoMovAlcadaDTO.class);

					connection.disconnect();

					if (retornoMovAlcadaDTO.isStatus()) {

						// Deferidos
						if (retornoMovAlcadaDTO.isAutorizado()) {
							devolucao.setDescricaoDeferimento("DEFERIDO");
							this.listaDevolucaoDeferido.add(devolucao);
						} else if (retornoMovAlcadaDTO.isIndeferido()) {// Indeferidos
							devolucao.setDescricaoDeferimento("INDEFERIDO");
							devolucao.setMotivoIndeferimento(retornoMovAlcadaDTO.getDescricao());
							this.listaDevolucaoDeferido.add(devolucao);
						} else { // Aguardando Autorização
							devolucao.setDescricaoDeferimento("AGUARDANDO DEFERIMENTO");
							this.listaDevolucaoDeferido.add(devolucao);
						}

					}

				} catch (Exception e) {
					// TODO: handle exception

					Mensagens.addMsgErro("Erro ao buscar deferimento(deferidos). Erro:" + e.getMessage());

					log.error("Erro ao buscar deferimento(deferidos). Erro:" + e.getMessage());

					break;

				}

			}

		}

		this.listaDevolucaoDeferido = contaDevolucaoBO.carregarSaldoResgatavelEmListaDevolucao(this.listaDevolucaoDeferido);

		return FW_PROCESSO_VERIFICACAO_DEFERIMENTO;

	}

	public String verificarDeferidos() {

		try {

			if (listaDevolucaoSelecionadasDeferido == null || listaDevolucaoSelecionadasDeferido.size() == 0) {
				Mensagens.addMsgErro("Favor selecionar pelo menos uma devolução.");
				return FW_PROCESSO_VERIFICACAO_DEFERIMENTO;
			}

			for (Devolucao devolucaoLista : listaDevolucaoSelecionadasDeferido) {

				Devolucao devolucaoAtualizavel = new Devolucao();

				devolucaoAtualizavel = devolucaoBO.pesquisarDevolucaoPorCodigo(devolucaoLista.getCodigo());

				// Busca situação para atualização de devolução enviada para deferimento.
				SituacaoDevolucao situacaoDevolucao = new SituacaoDevolucao();

				situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.CONCEDIDO.getCodigo());

				if (devolucaoLista.getDescricaoDeferimento().equals("INDEFERIDO")) {
					situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.INDEFERIDO.getCodigo());
				}

				if (devolucaoLista.getDescricaoDeferimento().equals("AGUARDANDO DEFERIMENTO")) {
					Mensagens.addMsgInfo("Processo aguardando deferimento: " + devolucaoLista.getCodigo());
					continue;
				}

				devolucaoAtualizavel.setSituacaoDevolucao(situacaoDevolucao);
				devolucaoAtualizavel.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getIdentificacaoUsuario());
				devolucaoBO.salvarDevolucao(devolucaoAtualizavel);

				// Historico de situação.
				HistoricoSituacaoDevolucao historicoSituacaoDevolucao = new HistoricoSituacaoDevolucao();
				historicoSituacaoDevolucao = historicoSituacaoDevolucaoBO.gerarHistoricoSituacaoDevolucao(devolucaoAtualizavel);
				historicoSituacaoDevolucao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getIdentificacaoUsuario());
				historicoSituacaoDevolucaoBO.salvarHistoricoSituacaoDevolucao(historicoSituacaoDevolucao);

				// Anotação devolução
				AnotacaoDevolucao anotacaoDevolucao = new AnotacaoDevolucao();
				anotacaoDevolucao = anotacaoDevolucaoBO.gerarAnotacaoDevolucao(devolucaoAtualizavel, "Retornado do deferimento - Deferido", new Date(), loginTemporariaDTO);

				if (devolucaoLista.getDescricaoDeferimento().equals("INDEFERIDO")) {
					anotacaoDevolucao = anotacaoDevolucaoBO.gerarAnotacaoDevolucao(devolucaoAtualizavel, "Retornado do deferimento - Indeferido", new Date(), loginTemporariaDTO);
				}

				anotacaoDevolucaoBO.salvarAnotacaoDevolucao(anotacaoDevolucao);

			}

			return listarDevolucaoDeferido();

		} catch (Exception e) {
			Mensagens.addError("Erro ao retornar deferidos. Erro: " + e.getMessage());
			log.error("Erro ao retornar deferidos. Erro: " + e.getMessage());
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e.getMessage());
		}
	}

	public static String inputStreamToString(InputStream is) throws IOException {
		if (is != null) {
			Writer writer = new StringWriter();

			char[] buffer = new char[1024];
			try {
				Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				int n;
				while ((n = reader.read(buffer)) != -1) {
					writer.write(buffer, 0, n);
				}
			} finally {
				is.close();
			}
			return writer.toString();
		} else {
			return "";
		}
	}

	public static Object fromJson(String json, Class objectClass) throws Exception {
		JsonFactory f = new MappingJsonFactory();
		JsonParser jp = f.createJsonParser(json);
		Object obj = jp.readValueAs(objectClass);
		return obj;
	}

	public CronogramaDevolucaoBO getCronogramaDevolucaoBO() {
		return cronogramaDevolucaoBO;
	}

	public void setCronogramaDevolucaoBO(CronogramaDevolucaoBO cronogramaDevolucaoBO) {
		this.cronogramaDevolucaoBO = cronogramaDevolucaoBO;
	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public TipoDevolucaoBO getTipoDevolucaoBO() {
		return tipoDevolucaoBO;
	}

	public void setTipoDevolucaoBO(TipoDevolucaoBO tipoDevolucaoBO) {
		this.tipoDevolucaoBO = tipoDevolucaoBO;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public String getNumeroMatriculaPatrocinadora() {
		return numeroMatriculaPatrocinadora;
	}

	public void setNumeroMatriculaPatrocinadora(String numeroMatriculaPatrocinadora) {
		this.numeroMatriculaPatrocinadora = numeroMatriculaPatrocinadora;
	}

	public DevolucaoBO getDevolucaoBO() {
		return devolucaoBO;
	}

	public void setDevolucaoBO(DevolucaoBO devolucaoBO) {
		this.devolucaoBO = devolucaoBO;
	}

	public ContaDevolucaoBO getContaDevolucaoBO() {
		return contaDevolucaoBO;
	}

	public void setContaDevolucaoBO(ContaDevolucaoBO contaDevolucaoBO) {
		this.contaDevolucaoBO = contaDevolucaoBO;
	}

	public SituacaoDevolucaoBO getSituacaoDevolucaoBO() {
		return situacaoDevolucaoBO;
	}

	public void setSituacaoDevolucaoBO(SituacaoDevolucaoBO situacaoDevolucaoBO) {
		this.situacaoDevolucaoBO = situacaoDevolucaoBO;
	}

	public HistoricoSituacaoDevolucaoBO getHistoricoSituacaoDevolucaoBO() {
		return historicoSituacaoDevolucaoBO;
	}

	public void setHistoricoSituacaoDevolucaoBO(HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO) {
		this.historicoSituacaoDevolucaoBO = historicoSituacaoDevolucaoBO;
	}

	public AnotacaoDevolucaoBO getAnotacaoDevolucaoBO() {
		return anotacaoDevolucaoBO;
	}

	public void setAnotacaoDevolucaoBO(AnotacaoDevolucaoBO anotacaoDevolucaoBO) {
		this.anotacaoDevolucaoBO = anotacaoDevolucaoBO;
	}

	public AmbienteServico getAmbienteServico() {
		return ambienteServico;
	}

	public void setAmbienteServico(AmbienteServico ambienteServico) {
		this.ambienteServico = ambienteServico;
	}

	public ParametroGeralBO getParametroGeralBO() {
		return parametroGeralBO;
	}

	public void setParametroGeralBO(ParametroGeralBO parametroGeralBO) {
		this.parametroGeralBO = parametroGeralBO;
	}

	public List<Devolucao> getListaDevolucaoDeferido() {
		return listaDevolucaoDeferido;
	}

	public void setListaDevolucaoDeferido(List<Devolucao> listaDevolucaoDeferido) {
		this.listaDevolucaoDeferido = listaDevolucaoDeferido;
	}

	public List<Devolucao> getListaDevolucaoSelecionadasDeferido() {
		return listaDevolucaoSelecionadasDeferido;
	}

	public void setListaDevolucaoSelecionadasDeferido(List<Devolucao> listaDevolucaoSelecionadasDeferido) {
		this.listaDevolucaoSelecionadasDeferido = listaDevolucaoSelecionadasDeferido;
	}

	public Devolucao getDevolucaoSelecianadaDeferido() {
		return devolucaoSelecianadaDeferido;
	}

	public void setDevolucaoSelecianadaDeferido(Devolucao devolucaoSelecianadaDeferido) {
		this.devolucaoSelecianadaDeferido = devolucaoSelecianadaDeferido;
	}
}
