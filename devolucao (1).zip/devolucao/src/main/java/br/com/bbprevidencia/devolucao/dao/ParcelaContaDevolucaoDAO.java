package br.com.bbprevidencia.devolucao.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoGuardaChuva;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucaoPagto;
import br.com.bbprevidencia.devolucao.dto.RelatorioParcelaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoAnaliticoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoConsolidadoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoPorParticipanteDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoFolhaSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.infra.repository.JpaDao;

/**
 * Classe de acesso aos dados de Devolução Reserva
 *
 * @author  BBPF0351 - Marco Figueiredo
 * @since 27/12/2016
 * 
 *        Copyright notice (c) 2016 BBPrevidência S/A
 */
@Repository
@Qualifier("parcelaContaDevolucaoDao")
@Scope(proxyMode = ScopedProxyMode.NO, value = "prototype")
public class ParcelaContaDevolucaoDAO extends JpaDao<ParcelaContaDevolucao> implements Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(ParcelaContaDevolucaoDAO.class);

	/**
	 * Salva ou altera a parcela conta devolução correspondente. Salva se o mesmo já contenha
	 * id na sessao do provedor de persistência, ou insere se nao há id
	 * correspondente.
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 03/01/2017
	 * @param {@link salvarParcelaContaDevolucao}
	 * @throws PrevidenciaException
	 */
	//@Transactional(propagation = Propagation.REQUIRED)
	public void salvarParcelaContaDevolucao(ParcelaContaDevolucao parcelaContaDevolucao) throws PrevidenciaException {

		if (parcelaContaDevolucao == null) {
			throw new PrevidenciaException("O Objeto Parcela Conta Devolução  deve estar inicializado para inserçao ou alteraçao.");
		} else {

			try {
				if (parcelaContaDevolucao.getCodigo() != null) {
					update(parcelaContaDevolucao);
				} else {
					save(parcelaContaDevolucao);
				}
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Salva em lista parcela conta devolução correspondente. Salva se o mesmo já contenha
	 * id na sessao do provedor de persistência, ou insere se nao há id
	 * correspondente.
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 03/01/2017
	 * @param {@link salvarParcelaContaDevolucao}
	 * @throws PrevidenciaException
	 */
	public void salvarListaParcelaContaDevolucao(List<ParcelaContaDevolucao> listaParcelaContaDevolucao) throws PrevidenciaException {

		if (UtilJava.isColecaoVazia(listaParcelaContaDevolucao)) {
			throw new PrevidenciaException("O Objeto Parcela Conta Devolução  deve estar inicializado para inserçao ou alteraçao.");
		} else {

			try {
				saveAll(listaParcelaContaDevolucao);
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Salva em lista parcela conta devolução correspondente bacth
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 03/01/2017
	 * @param {@link salvarParcelaContaDevolucao}
	 * @throws PrevidenciaException
	 */
	public void salvarTodosParcelaContaDevolucao(List<ParcelaContaDevolucao> listaParcelaContaDevolucao) throws PrevidenciaException {

		if (UtilJava.isColecaoVazia(listaParcelaContaDevolucao)) {
			throw new PrevidenciaException("O Objeto Parcela Conta Devolução  deve estar inicializado para inserçao ou alteraçao.");
		} else {

			try {
				this.saveInBatches(listaParcelaContaDevolucao, listaParcelaContaDevolucao.size());
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Exclui parcela conta devolução correspondente.
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 03/01/2017
	 * @param {@link ParcelaContaDevolucao}
	 * @throws PrevidenciaException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void apagarParcelaContaDevolucao(ParcelaContaDevolucao parcelaContaDevolucao) throws PrevidenciaException {

		if (parcelaContaDevolucao == null) {
			throw new PrevidenciaException("O Objeto Parcela Conta Devolução deve estar inicializado para exclusão.");
		} else {

			try {
				delete(parcelaContaDevolucao.getCodigo());
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Metodo responsável por pesquisar parcela conta devolução por código
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 03/01/2017
	 * @param Long
	 * @return {@link - ParcelaContaDevolucao}
	 * @throws PrevidenciaException
	 */
	public ParcelaContaDevolucao pesquisarParcelaContaDevolucaoPorCodigo(Long numero) throws PrevidenciaException {

		try {

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT FUS ");
			sql.append("   from ParcelaContaDevolucao FUS ");
			sql.append("  WHERE FUS.codigo =  ? ");

			return (ParcelaContaDevolucao) getEntityManager().createQuery(sql.toString()).setParameter(1, numero).getSingleResult();

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * Metodo responsável por pesquisar parcela conta devolução em aberto para pagamento
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 24/01/2017
	 * @param Date
	 * @return {@link - List<ParcelaContaDevolucao>}
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings("unchecked")
	public List<ParcelaContaDevolucao> pesquisarParcelaContaDevolucaoEmAbertoPorEntidadeParticipanteEData(CronogramaDevolucao cronogramaDevolucao,
			List<EntidadeParticipante> listaEntidadeParticipante, PlanoPrevidencia planoPrevidencia, Participante participante) throws PrevidenciaException {

		try {

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT FUS ");
			sql.append("   from ParcelaContaDevolucao FUS ");
			sql.append("  WHERE FUS.dataMinimaParcela <=  :data ");
			sql.append("    AND ( FUS.indicadorParcelaPaga = 'N' OR FUS.indicadorParcelaPaga IS NULL )");

			sql.append("    and ( FUS.devolucao.indicadorFormaPagtoContribCarencia = 'V' or ");
			sql.append("        ( FUS.devolucao.indicadorFormaPagtoContribCarencia = 'F' and FUS.tipoContaDevolucao.codigo = 1 ) or  ");
			sql
					.append("        ( FUS.tipoContaDevolucao.codigo = 3 AND FUS.dataMinimaParcela <= (select max(FU.dataMinimaParcela) from ParcelaContaDevolucao FU WHERE FU.devolucao = FUS.devolucao ) AND ");
			sql.append("        :data >= (select max(FU.dataMinimaParcela) from ParcelaContaDevolucao FU WHERE FU.devolucao = FUS.devolucao ) ) )");

			//Limitação de situação por tipo de folha.
			sql.append("    and  FUS.devolucao.situacaoDevolucao.codigo in (  ");
			for (TipoFolhaSituacaoDevolucao tipoFolhaSituacaoDevolucao : cronogramaDevolucao.getTipoFolhaDevolucao().getListaTipoFolhaSituacaoDevolucao()) {

				if (cronogramaDevolucao != null && cronogramaDevolucao.getIndicadorPagarParceladosReferencia().equals("N")
						&& tipoFolhaSituacaoDevolucao.getSituacaoDevolucao().getCodigo().equals(SituacaoDevolucaoEnum.EM_PARCELAMENTO.getCodigo()))
					continue;

				sql.append("'" + tipoFolhaSituacaoDevolucao.getSituacaoDevolucao().getCodigo() + "' , ");
			}

			sql = sql.deleteCharAt(sql.lastIndexOf(","));
			sql.append(")");

			//Limitação de Entidade da seleção.
			sql.append("    and  FUS.devolucao.participantePlano.participante.entidadeParticipante.chavePrimaria.codigoEntidadeParticipante in (  ");

			for (EntidadeParticipante p : listaEntidadeParticipante) {
				sql.append("'" + p.getChavePrimaria().getCodigoEntidadeParticipante() + "' , ");
			}

			sql = sql.deleteCharAt(sql.lastIndexOf(","));
			sql.append(")");

			//Limitação de plano prevideência
			if (planoPrevidencia != null) {
				sql.append("  AND FUS.devolucao.participantePlano.planoPrevidencia.codigo =  " + planoPrevidencia.getCodigo());
			}

			//Limitação participante
			if (participante != null) {
				sql.append("  AND FUS.devolucao.participantePlano.participante.codigo =  " + participante.getCodigo());
			}

			Query query = getEntityManager().createQuery(sql.toString());
			query.setParameter("data", cronogramaDevolucao.getDataPagamento());
			query.setHint("javax.persistence.query.timeout", 10000);

			return query.getResultList();

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * Metodo responsável por pesquisar parcela conta devolução em aberto para pagamento
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 24/01/2017
	 * @param Date
	 * @return {@link - List<ParcelaContaDevolucao>}
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings("unchecked")
	public List<ParcelaContaDevolucao> pesquisarParcelaContaDevolucaoPorDevolucaoEDataPagto(Date dataCronogramaPagto, Devolucao devolucao) throws PrevidenciaException {

		try {

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT FUS ");
			sql.append("   from ParcelaContaDevolucao FUS ");
			sql.append("  WHERE FUS.dataMinimaParcela <=  ? ");
			sql.append("    AND ( FUS.indicadorParcelaPaga = 'N' OR FUS.indicadorParcelaPaga IS NULL )");
			sql.append("    AND FUS.devolucao = ?");

			Query query = getEntityManager().createQuery(sql.toString());
			query.setParameter(1, dataCronogramaPagto);
			query.setParameter(2, devolucao);

			return query.getResultList();

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * Metodo responsável por pesquisar todas as parcelas de uma devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link Devolucao}
	 * @return
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings("unchecked")
	public List<ParcelaContaDevolucao> pesquisarParcelaContaDevolucaoPorDevolucao(Devolucao devolucao) throws PrevidenciaException {
		try {

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT FUS ");
			sql.append("   from ParcelaContaDevolucao FUS ");
			sql.append("   where FUS.devolucao = ?");

			Query query = getEntityManager().createQuery(sql.toString());
			query.setParameter(1, devolucao);

			return query.getResultList();

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}
	}

	/**
	 * Metodo responsável por pesquisar todas as parcelas de uma devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link Devolucao}
	 * @return
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings("unchecked")
	public boolean pesquisarParcelaContaDevolucaoAbertasPorDevolucao(List<ParcelaContaDevolucaoPagto> listaParcelaContaDevolucaoPagto, Devolucao devolucao) throws PrevidenciaException {
		try {

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT FUS ");
			sql.append("   from ParcelaContaDevolucao FUS ");
			sql.append("   where FUS.devolucao = ?");

			sql.append(" and  FUS.codigo not in (  ");

			for (ParcelaContaDevolucaoPagto p : listaParcelaContaDevolucaoPagto) {
				sql.append("'" + p.getCodigo() + "' , ");
			}

			sql = sql.deleteCharAt(sql.lastIndexOf(","));
			sql.append(")");

			sql.append(" and  (FUS.indicadorParcelaPaga is null or FUS.indicadorParcelaPaga = ?) ");

			Query query = getEntityManager().createQuery(sql.toString());
			query.setParameter(1, devolucao);
			query.setParameter(2, "N");

			List<ParcelaContaDevolucao> listaParcelaContaDevolucao = query.getResultList();

			if (listaParcelaContaDevolucao.size() == 0) {
				return false;
			} else {
				return true;
			}

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}
	}

	/**
	 * Método responsável por carregar os dados do relatório Quantitativo de Devoluções
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/03/2017
	 * @param dataInicio
	 * @param dataFim
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RelatorioQuantitativoDevolucaoDTO> pesquisaQuantitativoDevolucoes(Date dataInicio, Date dataFim, String tipoDevolucao, List<EntidadeParticipante> listaEntidades) {
		try {
			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT PCD.parcelaContaDevolucao.devolucao.participantePlano.planoPrevidencia.nomePlano, ");
			sql.append("         to_char(PCD.cronogramaDevolucao.dataPagamento, 'YYYY - MONTH', 'NLS_LANGUAGE=BRAZILIAN PORTUGUESE'), ");
			sql.append("		 count(distinct PCD.parcelaContaDevolucao.devolucao.participantePlano.participante.codigo), ");
			sql.append("         trunc(PCD.cronogramaDevolucao.dataPagamento, 'MM') ");
			sql.append("   from ParcelaContaDevolucaoPagto PCD ");
			sql.append("  where PCD.parcelaContaDevolucao.indicadorParcelaPaga = :indicadorParcelaPaga ");
			sql.append("    and PCD.cronogramaDevolucao.dataPagamento >= :dataInicio ");
			sql.append("    and (PCD.cronogramaDevolucao.dataPagamento <= :dataFim or :dataFim is null) ");
			sql.append("    AND (PCD.parcelaContaDevolucao.devolucao.regraCalculoDevolucao.tipoDevolucao.indicadorTipoDevolucao = :tipoDevolucao or :tipoDevolucao is null) ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidades)) {
				sql.append(" AND PCD.parcelaContaDevolucao.devolucao.participantePlano.participante.entidadeParticipante.chavePrimaria.codigoEntidadeParticipante IN (");

				for (EntidadeParticipante ep : listaEntidades) {
					sql.append(ep.getChavePrimaria().getCodigoEntidadeParticipante() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			sql.append(" group by PCD.parcelaContaDevolucao.devolucao.participantePlano.planoPrevidencia.nomePlano, ");
			sql.append("		 to_char(PCD.cronogramaDevolucao.dataPagamento, 'YYYY - MONTH', 'NLS_LANGUAGE=BRAZILIAN PORTUGUESE'), ");
			sql.append("         trunc(PCD.cronogramaDevolucao.dataPagamento, 'MM') ");
			sql.append(" order by trunc(PCD.cronogramaDevolucao.dataPagamento, 'MM') ");

			Query query = getEntityManager().createQuery(sql.toString());
			query.setParameter("indicadorParcelaPaga", "S");
			query.setParameter("dataInicio", dataInicio);
			query.setParameter("dataFim", dataFim);
			query.setParameter("tipoDevolucao", tipoDevolucao);

			List<RelatorioQuantitativoDevolucaoDTO> listaRelatorioQuantitativoDevolucaoDTO = new ArrayList<RelatorioQuantitativoDevolucaoDTO>();

			Iterator<Object> listaResultante = query.getResultList().iterator();

			while (listaResultante.hasNext()) {
				Object[] objetoResultante = (Object[]) listaResultante.next();

				RelatorioQuantitativoDevolucaoDTO relatorioQuantitativoDevolucaoDTO = new RelatorioQuantitativoDevolucaoDTO();
				if (objetoResultante[0] != null) {
					relatorioQuantitativoDevolucaoDTO.setNomePlanoGuardaChuva(objetoResultante[0].toString());
				}

				if (objetoResultante[1] != null) {
					relatorioQuantitativoDevolucaoDTO.setMesAno(objetoResultante[1].toString());
				}

				if (objetoResultante[2] != null) {
					relatorioQuantitativoDevolucaoDTO.setQuantidadeProcessos(Long.parseLong(objetoResultante[2].toString()));
				}

				listaRelatorioQuantitativoDevolucaoDTO.add(relatorioQuantitativoDevolucaoDTO);

			}
			return listaRelatorioQuantitativoDevolucaoDTO;

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * Método responsável por carregar os dados do relatório Quantitativo Consolidado
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 * @param dataInicio
	 * @param dataFim
	 * @param listaEntidadeParticipante
	 * @param listaPlanoPrevidencia
	 * @param listaPlanoGuardaChuva
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RelatorioQuantitativoConsolidadoDTO> pesquisarQuantitativoConsolidado(Date dataInicio, Date dataFim, List<EntidadeParticipante> listaEntidadeParticipante,
			List<PlanoPrevidencia> listaPlanoPrevidencia, List<PlanoGuardaChuva> listaPlanoGuardaChuva) throws PrevidenciaException {

		try {
			StringBuilder sql = new StringBuilder();

			sql.append("SELECT   EP.NOM_ABREV_ENTID_PARTIC, ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append("    PPR.NOM_PLANO, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50))  AS  NOM_PLANO, ");
			}

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append("     PGC.NOM_PLANO_GUARDA_CHUVA, ");
			} else {
				sql.append("  	 CAST ('TODOS' AS VARCHAR2(50))  AS  NOM_PLANO_GUARDA_CHUVA, ");
			}

			sql.append("         TD.NOM_TIP_DEV, ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'YYYY'), ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'MM/YYYY'), ");
			sql.append("         COUNT(UNIQUE PCD.NUM_SEQ_DEV), ");
			sql.append("         SUM(PCD.QTD_COT * PCDP.VAL_IND_AJU) ");
			sql.append("   FROM  DEVOLUCAO DEV, ");
			sql.append("         PARCELA_CONTA_DEVOLUCAO PCD, ");
			sql.append("         PAR_CON_DEV_PAG PCDP, ");
			sql.append("         PARTICIPANTE_PLANO PP, ");
			sql.append("         PLANO_PREVIDENCIA PPR, ");
			sql.append("         PLANO_GUARDA_CHUVA PGC, ");
			sql.append("         ENTIDADE_PARTICIPANTE EP, ");
			sql.append("         PARTICIPANTE PA, ");
			sql.append("         TIPO_DEVOLUCAO  TD, ");
			sql.append("         REGRA_CALCULO_DEVOLUCAO RCD, ");

			sql.append("         CRONOGRAMA_DEVOLUCAO CRON ");

			sql.append("   WHERE DEV.NUM_SEQ_PARTIC_PLANO = PP.NUM_SEQ_PARTIC_PLANO ");
			sql.append("     AND DEV.NUM_SEQ_DEV = PCD.NUM_SEQ_DEV ");
			sql.append("     AND PP.NUM_SEQ_PLANO = PPR.NUM_SEQ_PLANO ");
			sql.append("     AND PPR.NUM_SEQ_PLANO_GUARDA_CHUVA = PGC.NUM_SEQ_PLANO_GUARDA_CHUVA ");
			sql.append("     AND PP.NUM_SEQ_PARTIC = PA.NUM_SEQ_PARTIC ");
			sql.append("     AND PA.NUM_SEQ_ENTID_PARTIC = EP.NUM_SEQ_ENTID_PARTIC ");
			sql.append("     AND DEV.NUM_SEQ_REG_CAL_DEV = RCD.NUM_SEQ_REG_CAL_DEV ");
			sql.append("     AND RCD.NUM_SEQ_TIP_DEV = TD.NUM_SEQ_TIP_DEV ");
			sql.append("     AND PCD.NUM_SEQ_PAR_CON_DEV = PCDP.NUM_SEQ_PAR_CON_DEV ");

			sql.append("     AND CRON.NUM_SEQ_CRO_DEV = PCDP.NUM_SEQ_CRO_DEV ");

			sql.append("     AND CRON.DAT_PGT >= TO_DATE (:dataInicio, 'DD/MM/YYYY') ");
			sql.append("     AND (:dataFim IS NULL OR CRON.DAT_PGT <= TO_DATE (:dataFim, 'DD/MM/YYYY')) ");

			//Preencher caso existam Entidades Participantes
			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante)) {
				sql.append(" AND EP.NUM_SEQ_ENTID_PARTIC IN  (");

				for (EntidadeParticipante ep : listaEntidadeParticipante) {
					sql.append(ep.getChavePrimaria().getCodigoEntidadeParticipante() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso existam Planos
			if (UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append(" AND PP.NUM_SEQ_PLANO IN (");

				for (PlanoPrevidencia pp : listaPlanoPrevidencia) {
					sql.append(pp.getCodigo() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso existam Planos Guarda Chuva
			if (UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append(" AND PGC.NUM_SEQ_PLANO_GUARDA_CHUVA IN (");

				for (PlanoGuardaChuva pgc : listaPlanoGuardaChuva) {
					sql.append(pgc.getCodigo() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			sql.append(" GROUP BY EP.NOM_ABREV_ENTID_PARTIC, ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append("    PPR.NOM_PLANO, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append("     PGC.NOM_PLANO_GUARDA_CHUVA, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			sql.append("         TD.NOM_TIP_DEV, ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'YYYY'), ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'MM/YYYY') ");
			sql.append(" ORDER BY EP.NOM_ABREV_ENTID_PARTIC, ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append("    PPR.NOM_PLANO, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append("     PGC.NOM_PLANO_GUARDA_CHUVA, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			sql.append("         TD.NOM_TIP_DEV, ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'YYYY'), ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'MM/YYYY') ");

			Query query = getEntityManager().createNativeQuery(sql.toString());
			query.setParameter("dataInicio", UtilJava.formataDataPorPadrao(dataInicio, "dd/MM/yyyy"));
			query.setParameter("dataFim", UtilJava.formataDataPorPadrao(dataFim, "dd/MM/yyyy"));

			List<RelatorioQuantitativoConsolidadoDTO> listaRelatorioQuantitativoConsolidado = new ArrayList<RelatorioQuantitativoConsolidadoDTO>();

			Iterator<Object> listaResultante = query.getResultList().iterator();

			while (listaResultante.hasNext()) {
				Object[] objetoResultante = (Object[]) listaResultante.next();

				RelatorioQuantitativoConsolidadoDTO relatorioQuantitativoConsolidadoDTO = new RelatorioQuantitativoConsolidadoDTO();
				if (objetoResultante[0] != null) {
					relatorioQuantitativoConsolidadoDTO.setNomeEmpresa(objetoResultante[0].toString());
				}

				if (objetoResultante[1] != null) {
					relatorioQuantitativoConsolidadoDTO.setNomePlano(objetoResultante[1].toString());
				}

				if (objetoResultante[2] != null) {
					relatorioQuantitativoConsolidadoDTO.setNomePlanoGuardaChuva(objetoResultante[2].toString());
				}

				if (objetoResultante[3] != null) {
					relatorioQuantitativoConsolidadoDTO.setNomeTipoDevolucao(objetoResultante[3].toString());
				}

				if (objetoResultante[4] != null) {
					relatorioQuantitativoConsolidadoDTO.setAno(objetoResultante[4].toString());
				}

				if (objetoResultante[5] != null) {
					relatorioQuantitativoConsolidadoDTO.setMes(objetoResultante[5].toString());
				}

				if (objetoResultante[6] != null) {
					relatorioQuantitativoConsolidadoDTO.setQuantidade(Integer.parseInt(objetoResultante[6].toString()));
				}

				if (objetoResultante[7] != null) {
					relatorioQuantitativoConsolidadoDTO.setValor(Double.parseDouble(objetoResultante[7].toString()));
				}

				listaRelatorioQuantitativoConsolidado.add(relatorioQuantitativoConsolidadoDTO);

			}

			return listaRelatorioQuantitativoConsolidado;

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}
	}

	@SuppressWarnings("unchecked")
	public List<RelatorioQuantitativoPorParticipanteDTO> pesquisarQuantitativoPorParticipante(Date dataInicio, Date dataFim, List<EntidadeParticipante> listaEntidadeParticipante,
			List<PlanoPrevidencia> listaPlanoPrevidencia, List<PlanoGuardaChuva> listaPlanoGuardaChuva) throws PrevidenciaException {

		try {
			StringBuilder sql = new StringBuilder();

			sql.append("SELECT   EP.NOM_ABREV_ENTID_PARTIC, ");
			sql.append("         PA.NOM_PARTIC, ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append("    PPR.NOM_PLANO, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50))  AS  NOM_PLANO, ");
			}

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append("     PGC.NOM_PLANO_GUARDA_CHUVA, ");
			} else {
				sql.append("  	 CAST ('TODOS' AS VARCHAR2(50))  AS  NOM_PLANO_GUARDA_CHUVA, ");
			}

			sql.append("         TD.NOM_TIP_DEV, ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'YYYY'), ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'MM/YYYY'), ");
			sql.append("         SUM(PCD.QTD_COT * PCDP.VAL_IND_AJU) ");
			sql.append("   FROM  DEVOLUCAO DEV, ");
			sql.append("         PARCELA_CONTA_DEVOLUCAO PCD, ");
			sql.append("         PAR_CON_DEV_PAG PCDP, ");
			sql.append("         PARTICIPANTE_PLANO PP, ");
			sql.append("         PLANO_PREVIDENCIA PPR, ");
			sql.append("         PLANO_GUARDA_CHUVA PGC, ");
			sql.append("         ENTIDADE_PARTICIPANTE EP, ");
			sql.append("         PARTICIPANTE PA, ");
			sql.append("         TIPO_DEVOLUCAO  TD, ");
			sql.append("         REGRA_CALCULO_DEVOLUCAO RCD, ");

			sql.append("         CRONOGRAMA_DEVOLUCAO CRON ");

			sql.append("   WHERE DEV.NUM_SEQ_PARTIC_PLANO = PP.NUM_SEQ_PARTIC_PLANO ");
			sql.append("     AND DEV.NUM_SEQ_DEV = PCD.NUM_SEQ_DEV ");
			sql.append("     AND PP.NUM_SEQ_PLANO = PPR.NUM_SEQ_PLANO ");
			sql.append("     AND PPR.NUM_SEQ_PLANO_GUARDA_CHUVA = PGC.NUM_SEQ_PLANO_GUARDA_CHUVA ");
			sql.append("     AND PP.NUM_SEQ_PARTIC = PA.NUM_SEQ_PARTIC ");
			sql.append("     AND PA.NUM_SEQ_ENTID_PARTIC = EP.NUM_SEQ_ENTID_PARTIC ");
			sql.append("     AND DEV.NUM_SEQ_REG_CAL_DEV = RCD.NUM_SEQ_REG_CAL_DEV ");
			sql.append("     AND RCD.NUM_SEQ_TIP_DEV = TD.NUM_SEQ_TIP_DEV ");
			sql.append("     AND PCD.NUM_SEQ_PAR_CON_DEV = PCDP.NUM_SEQ_PAR_CON_DEV ");

			sql.append("     AND CRON.NUM_SEQ_CRO_DEV = PCDP.NUM_SEQ_CRO_DEV ");

			sql.append("     AND CRON.DAT_PGT >= TO_DATE (:dataInicio, 'DD/MM/YYYY') ");
			sql.append("     AND (:dataFim IS NULL OR CRON.DAT_PGT <= TO_DATE (:dataFim, 'DD/MM/YYYY')) ");

			//Preencher caso existam Entidades Participantes
			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante)) {
				sql.append(" AND EP.NUM_SEQ_ENTID_PARTIC IN  (");

				for (EntidadeParticipante ep : listaEntidadeParticipante) {
					sql.append(ep.getChavePrimaria().getCodigoEntidadeParticipante() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso existam Planos
			if (UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append(" AND PP.NUM_SEQ_PLANO IN (");

				for (PlanoPrevidencia pp : listaPlanoPrevidencia) {
					sql.append(pp.getCodigo() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso existam Planos Guarda Chuva
			if (UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append(" AND PGC.NUM_SEQ_PLANO_GUARDA_CHUVA IN (");

				for (PlanoGuardaChuva pgc : listaPlanoGuardaChuva) {
					sql.append(pgc.getCodigo() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			sql.append(" GROUP BY EP.NOM_ABREV_ENTID_PARTIC, PA.NOM_PARTIC, ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append("    PPR.NOM_PLANO, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append("     PGC.NOM_PLANO_GUARDA_CHUVA, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			sql.append("         TD.NOM_TIP_DEV, ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'YYYY'), ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'MM/YYYY') ");
			sql.append(" ORDER BY EP.NOM_ABREV_ENTID_PARTIC, ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append("    PPR.NOM_PLANO, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante) && listaEntidadeParticipante.size() == 1 && UtilJava.isColecaoDiferenteDeVazia(listaPlanoGuardaChuva)) {
				sql.append("     PGC.NOM_PLANO_GUARDA_CHUVA, ");
			} else {
				sql.append("  	CAST ('TODOS' AS VARCHAR2(50)), ");
			}

			sql.append("         TD.NOM_TIP_DEV, ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'YYYY'), ");
			sql.append("         TO_CHAR(CRON.DAT_PGT, 'MM/YYYY') ");

			Query query = getEntityManager().createNativeQuery(sql.toString());
			query.setParameter("dataInicio", UtilJava.formataDataPorPadrao(dataInicio, "dd/MM/yyyy"));
			query.setParameter("dataFim", UtilJava.formataDataPorPadrao(dataFim, "dd/MM/yyyy"));

			List<RelatorioQuantitativoPorParticipanteDTO> listaRelatorioQuantitativoPorParticipante = new ArrayList<RelatorioQuantitativoPorParticipanteDTO>();

			Iterator<Object> listaResultante = query.getResultList().iterator();

			while (listaResultante.hasNext()) {
				Object[] objetoResultante = (Object[]) listaResultante.next();

				RelatorioQuantitativoPorParticipanteDTO relatorioQuantitativoPorParticipanteDTO = new RelatorioQuantitativoPorParticipanteDTO();

				if (objetoResultante[0] != null) {
					relatorioQuantitativoPorParticipanteDTO.setNomeEmpresa(objetoResultante[0].toString());
				}

				if (objetoResultante[1] != null) {
					relatorioQuantitativoPorParticipanteDTO.setNomeParticipante(objetoResultante[1].toString());
				}

				if (objetoResultante[2] != null) {
					relatorioQuantitativoPorParticipanteDTO.setNomePlano(objetoResultante[2].toString());
				}

				if (objetoResultante[3] != null) {
					relatorioQuantitativoPorParticipanteDTO.setNomePlanoGuardaChuva(objetoResultante[3].toString());
				}

				if (objetoResultante[4] != null) {
					relatorioQuantitativoPorParticipanteDTO.setNomeTipoDevolucao(objetoResultante[4].toString());
				}

				if (objetoResultante[5] != null) {
					relatorioQuantitativoPorParticipanteDTO.setAno(objetoResultante[5].toString());
				}

				if (objetoResultante[6] != null) {
					relatorioQuantitativoPorParticipanteDTO.setMes(objetoResultante[6].toString());
				}

				if (objetoResultante[7] != null) {
					relatorioQuantitativoPorParticipanteDTO.setValor(Double.parseDouble(objetoResultante[7].toString()));
				}

				listaRelatorioQuantitativoPorParticipante.add(relatorioQuantitativoPorParticipanteDTO);

			}

			return listaRelatorioQuantitativoPorParticipante;

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 * 
	 * @param listaEntidadeParticipante
	 * @param listaPlanoPrevidencia
	 * @param participante
	 * @param listaTipoDevolucao
	 * @param tipoParcelamento
	 * @param listaStatusPagamento
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RelatorioParcelaDevolucaoDTO> relatorioParcelaDevolucao(List<EntidadeParticipante> listaEntidadeParticipante, List<PlanoPrevidencia> listaPlanoPrevidencia, Participante participante,
			List<TipoDevolucao> listaTipoDevolucao, String tipoParcelamento, List<String> listaStatusPagamento) {

		try {
			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT * FROM ( ");
			sql.append(" SELECT ROW_NUMBER () OVER (PARTITION BY PCD.NUM_SEQ_DEV ORDER BY PCD.NUM_SEQ_PAR_CON_DEV) NUM_PARCELA, ");
			sql.append("        (SELECT COUNT(1) FROM PARCELA_CONTA_DEVOLUCAO PC1 WHERE PC1.NUM_SEQ_DEV = DEV.NUM_SEQ_DEV) TOT_PARCELA, ");
			sql.append("        EPR.NOM_ABREV_ENTID_PARTIC, ");
			sql.append("        PPR.NOM_PLANO, ");
			sql.append("        PAR.NUM_MATRIC_PATROC, ");
			sql.append("        PAR.NOM_PARTIC, ");
			sql.append("        TO_CHAR(TRUNC(PCD.DAT_PAR_CON_DEV), 'DD/MM/YYYY') DAT_PAR_CON_DEV, ");
			sql.append("        PCD.QTD_COT, ");
			sql.append("        TCD.NOM_TIP_CON_DEV ");
			sql.append("  FROM PARCELA_CONTA_DEVOLUCAO   PCD, ");
			sql.append("       DEVOLUCAO                 DEV, ");
			sql.append("       PARTICIPANTE_PLANO        PPL, ");
			sql.append("       PARTICIPANTE              PAR, ");
			sql.append("       PLANO_PREVIDENCIA         PPR, ");
			sql.append("       ENTIDADE_PARTICIPANTE     EPR, ");
			sql.append("       TIPO_CONTA_DEVOLUCAO      TCD, ");
			sql.append("       REGRA_CALCULO_DEVOLUCAO   RCD        ");
			sql.append(" WHERE PCD.NUM_SEQ_DEV = DEV.NUM_SEQ_DEV ");
			sql.append("   AND DEV.NUM_SEQ_PARTIC_PLANO = PPL.NUM_SEQ_PARTIC_PLANO ");
			sql.append("   AND PPL.NUM_SEQ_PARTIC = PAR.NUM_SEQ_PARTIC ");
			sql.append("   AND PPL.NUM_SEQ_PLANO = PPR.NUM_SEQ_PLANO ");
			sql.append("   AND PAR.NUM_SEQ_ENTID_PARTIC = EPR.NUM_SEQ_ENTID_PARTIC ");
			sql.append("   AND PCD.NUM_SEQ_TIP_CON_DEV = TCD.NUM_SEQ_TIP_CON_DEV ");
			sql.append("   AND DEV.NUM_SEQ_REG_CAL_DEV = RCD.NUM_SEQ_REG_CAL_DEV ");
			sql.append("   AND DEV.NUM_SEQ_SIT_DEV IN (3, 4, 5, 6, 7) ");

			//Preencher caso existam Entidades Participantes
			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidadeParticipante)) {
				sql.append(" AND EPR.NUM_SEQ_ENTID_PARTIC IN  (");

				for (EntidadeParticipante ep : listaEntidadeParticipante) {
					sql.append(ep.getChavePrimaria().getCodigoEntidadeParticipante() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso existam Planos
			if (UtilJava.isColecaoDiferenteDeVazia(listaPlanoPrevidencia)) {
				sql.append(" AND PPL.NUM_SEQ_PLANO IN (");

				for (PlanoPrevidencia pp : listaPlanoPrevidencia) {
					sql.append(pp.getCodigo() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso existam Tipos de Devolução
			if (UtilJava.isColecaoDiferenteDeVazia(listaTipoDevolucao)) {
				sql.append(" AND RCD.NUM_SEQ_TIP_DEV IN (");

				for (TipoDevolucao tp : listaTipoDevolucao) {
					sql.append(tp.getCodigo() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso existam Staus de Pagamento
			if (UtilJava.isColecaoDiferenteDeVazia(listaStatusPagamento)) {
				sql.append(" AND PCD.IND_PAR_PGT IN (");

				for (String pago : listaStatusPagamento) {
					sql.append("'" + pago + "', ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			//Preencher caso o participaante não seja nulo
			if (participante.getCodigo() != null) {
				sql.append(" AND PAR.NUM_SEQ_PARTIC = " + participante.getCodigo() + " ");
			}

			sql.append(" ) BASE  ");

			//Verifica os tipos de devoluções a trazer conforme tipo de parcelamento
			if (tipoParcelamento.equalsIgnoreCase("U")) {
				sql.append(" WHERE BASE.TOT_PARCELA = 1");
			} else {
				if (tipoParcelamento.equalsIgnoreCase("P")) {
					sql.append(" WHERE BASE.TOT_PARCELA > 1");
				}
			}

			sql.append(" ORDER BY  NOM_ABREV_ENTID_PARTIC,  NOM_PLANO, NOM_PARTIC, NUM_PARCELA ");

			Query query = getEntityManager().createNativeQuery(sql.toString());

			List<RelatorioParcelaDevolucaoDTO> listaRelatorioParcelaDevolucaoDTO = new ArrayList<RelatorioParcelaDevolucaoDTO>();

			Iterator<Object> listaResultante = query.getResultList().iterator();

			while (listaResultante.hasNext()) {
				Object[] objetoResultante = (Object[]) listaResultante.next();

				RelatorioParcelaDevolucaoDTO relatorioParcelaDevolucaoDTO = new RelatorioParcelaDevolucaoDTO();
				if (objetoResultante[0] != null) {
					relatorioParcelaDevolucaoDTO.setParcela(objetoResultante[0].toString());
				}

				if (objetoResultante[1] != null) {
					relatorioParcelaDevolucaoDTO.setTotalParcelas(objetoResultante[1].toString());
				}

				if (objetoResultante[2] != null) {
					relatorioParcelaDevolucaoDTO.setNomeEntidadeParticipante(objetoResultante[2].toString());
				}

				if (objetoResultante[3] != null) {
					relatorioParcelaDevolucaoDTO.setNomePlano(objetoResultante[3].toString());
				}

				if (objetoResultante[4] != null) {
					relatorioParcelaDevolucaoDTO.setMatriculaParticipante(objetoResultante[4].toString());
				}

				if (objetoResultante[5] != null) {
					relatorioParcelaDevolucaoDTO.setNomeParticipante(objetoResultante[5].toString());
				}

				if (objetoResultante[6] != null) {
					relatorioParcelaDevolucaoDTO.setDataPagamento(UtilJava.formataData(objetoResultante[6].toString()));
				}

				if (objetoResultante[7] != null) {
					relatorioParcelaDevolucaoDTO.setQuantidadeCotas(Double.parseDouble(objetoResultante[7].toString()));
				}

				if (objetoResultante[8] != null) {
					relatorioParcelaDevolucaoDTO.setNomeContaDevolucao(objetoResultante[8].toString());
				}

				listaRelatorioParcelaDevolucaoDTO.add(relatorioParcelaDevolucaoDTO);

			}

			return listaRelatorioParcelaDevolucaoDTO;

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/01/2018
	 * @param dataInicio
	 * @param dataFim
	 * @param tipoDevolucao
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RelatorioQuantitativoAnaliticoDevolucaoDTO> pesquisaQuantitativoAnaliticoDevolucoes(Date dataInicio, Date dataFim, String tipoDevolucao, List<EntidadeParticipante> listaEntidades) {
		try {
			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT DISTINCT PCD.parcelaContaDevolucao.devolucao.participantePlano.planoPrevidencia.nomePlano, ");
			sql.append("        TO_CHAR(PCD.cronogramaDevolucao.dataPagamento, 'YYYY - MONTH', 'NLS_LANGUAGE=BRAZILIAN PORTUGUESE'), ");
			sql.append("        PCD.parcelaContaDevolucao.devolucao.participantePlano.participante.nomeParticipante, ");
			sql.append("        PCD.parcelaContaDevolucao.devolucao.participantePlano.participante.numeroMatriculaPatrocinadora, ");
			sql.append("        PCD.parcelaContaDevolucao.devolucao.participantePlano.participante.numeroCpf, ");
			sql.append("        PCD.parcelaContaDevolucao.devolucao.participantePlano.participante.numeroComplementoCpf ");
			sql.append("   FROM ParcelaContaDevolucaoPagto PCD ");
			sql.append("  WHERE PCD.parcelaContaDevolucao.indicadorParcelaPaga = :indicadorParcelaPaga ");
			sql.append("    AND PCD.cronogramaDevolucao.dataPagamento >= :dataInicio ");
			sql.append("    AND (PCD.cronogramaDevolucao.dataPagamento <= :dataFim or :dataFim is null) ");
			sql.append("    AND (PCD.parcelaContaDevolucao.devolucao.regraCalculoDevolucao.tipoDevolucao.indicadorTipoDevolucao = :tipoDevolucao or :tipoDevolucao is null) ");

			if (UtilJava.isColecaoDiferenteDeVazia(listaEntidades)) {
				sql.append(" AND PCD.parcelaContaDevolucao.devolucao.participantePlano.participante.entidadeParticipante.chavePrimaria.codigoEntidadeParticipante IN (");

				for (EntidadeParticipante ep : listaEntidades) {
					sql.append(ep.getChavePrimaria().getCodigoEntidadeParticipante() + ", ");
				}

				sql = sql.deleteCharAt(sql.lastIndexOf(","));
				sql.append(")");
			}

			sql.append("  ORDER BY TO_CHAR(PCD.cronogramaDevolucao.dataPagamento, 'YYYY - MONTH', 'NLS_LANGUAGE=BRAZILIAN PORTUGUESE'), ");
			sql.append("        PCD.parcelaContaDevolucao.devolucao.participantePlano.planoPrevidencia.nomePlano ");

			Query query = getEntityManager().createQuery(sql.toString());
			query.setParameter("indicadorParcelaPaga", "S");
			query.setParameter("dataInicio", dataInicio);
			query.setParameter("dataFim", dataFim);
			query.setParameter("tipoDevolucao", tipoDevolucao);

			List<RelatorioQuantitativoAnaliticoDevolucaoDTO> listaQuantitativoAnaliticoDevolucaoDTO = new ArrayList<RelatorioQuantitativoAnaliticoDevolucaoDTO>();

			Iterator<Object> listaResultante = query.getResultList().iterator();

			while (listaResultante.hasNext()) {
				Object[] objetoResultante = (Object[]) listaResultante.next();

				RelatorioQuantitativoAnaliticoDevolucaoDTO quantitativoAnaliricoDevolucaoDTO = new RelatorioQuantitativoAnaliticoDevolucaoDTO();

				quantitativoAnaliricoDevolucaoDTO.setNomePlano(objetoResultante[0] == null ? null : objetoResultante[0].toString());

				quantitativoAnaliricoDevolucaoDTO.setMesAno(objetoResultante[1] == null ? null : objetoResultante[1].toString());

				quantitativoAnaliricoDevolucaoDTO.setNomeParticipante(objetoResultante[2] == null ? null : objetoResultante[2].toString());

				quantitativoAnaliricoDevolucaoDTO.setMatricula(objetoResultante[3] == null ? null : objetoResultante[3].toString());

				quantitativoAnaliricoDevolucaoDTO.setCpfParticipante((objetoResultante[4] != null && objetoResultante[5] != null) ? UtilJava.formataCPF(String.format(
						"%09d",
						((BigDecimal) objetoResultante[4]).longValue())
						+ String.format("%02d", ((BigDecimal) objetoResultante[5]).longValue())) : null);

				listaQuantitativoAnaliticoDevolucaoDTO.add(quantitativoAnaliricoDevolucaoDTO);

			}

			return listaQuantitativoAnaliticoDevolucaoDTO;

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}
	}

}
