package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.ToggleEvent;
import org.primefaces.event.data.SortEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PerfilInvestimentoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.SaldoHistoricoFinanceiroPagoDTO;
import br.com.bbprevidencia.cadastroweb.enumerador.MantenedorEnum;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.cotas.bo.ValorCotaPlanoBO;
import br.com.bbprevidencia.cotas.dto.ValorCotaPlano;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.CalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoItemBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoPlanoTipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoDetalheBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoDetalheImpostoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoPagtoBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraElegibilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.CalculoDevolucaoBaseVisao;
import br.com.bbprevidencia.devolucao.dto.ContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DevolucaoAntigoDTO;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucaoVisaoItem;
import br.com.bbprevidencia.devolucao.dto.DocumentoPlanoTipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.ElegibilidadeDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucaoDetalheImposto;
import br.com.bbprevidencia.devolucao.dto.ParcelaContaDevolucaoDetalheImpostoDTO;
import br.com.bbprevidencia.devolucao.dto.ProcessoRetencaoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.SaldoHFPDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.SumulaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.IndicadorFormaPagamentoContribCarencia;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio para
 * o Cálculo / Visualização das Devoluções
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 26/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("devolucaoMigracaoVisao")
public class DevolucaoMigracaoVisao {

	private static final String FW_PESQUISA_DEVOLUCAO = "/paginas/pesquisaDevolucaoMigracao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_CALCULO_DEVOLUCAO = "/paginas/calculoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final String FW_ENVIO_DEFERIMENTO = "/paginas/processoEnvioDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_CANCELAMENTO_DEVOLUCAO = "/paginas/processoCancelamento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_VERIFICACAO_DEFERIMENTO = "/paginas/processoVerificacaoDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_CONFERENCIA = "/paginas/processoConferencia.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_RECEBIMENTO = "/paginas/processoAtualizacaoRecebimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_DEVOLUCAO_MANUAL_REQUERIMENTO = "/paginas/devolucaoManualRequerimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(DevolucaoMigracaoVisao.class);

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private CalculoDevolucaoBO calculoDevolucao;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBo;

	@Autowired
	private PerfilInvestimentoBO perfilInvestimentoBO;

	@Autowired
	private ValorCotaPlanoBO valorCotaPlanoBO;

	@Autowired
	private RegraDevolucaoBO regraDevolucaoBO;

	@Autowired
	private RegraCalculoDevolucaoBO regraCalculoDevolucaoBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;

	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoDetalheBO parcelaContaDevolucaoDetalheBO;

	@Autowired
	private ParcelaContaDevolucaoDetalheImpostoBO parcelaContaDevolucaoDetalheImpostoBO;

	@Autowired
	private RegraElegibilidadeDevolucaoBO regraElegibilidadeDevolucaoBO;

	@Autowired
	private DocumentoDevolucaoVisaoItemBO documentoDevolucaoVisaoItemBO;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private DocumentoPlanoTipoDevolucaoBO documentoPlanoTipoDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoPagtoBO parcelaContaDevolucaoPagtoBO;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<Participante> listaParticipante;

	private List<TipoDevolucao> listaTipoDevolucao;

	private List<SelectItem> listaIndicadorFormaPagamentoContribCarencia;

	private List<SituacaoDevolucao> listaSituacaoDevolucao;

	private String indicadorFormaPagamentoContribCarencia;

	private TipoDevolucao tipoDevolucao;

	private Devolucao devolucao;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private Participante participante;

	private SituacaoDevolucao situacaoDevolucao;

	private boolean patrocinadoraEditavel;

	private boolean listarStatus;

	private boolean cadastrarNovaDevolucao;

	private Integer numTotalParcelas;

	private Date dataRequerimento;

	private ValorCotaPlano valorCotaPlano;

	private RegraDevolucao regraDevolucao;

	private RegraCalculoDevolucao regraCalculoDevolucao;

	private DevolucaoCompletoDTO devolucaoCalculoCompleto;

	private boolean processoCalculoConcluido;

	private boolean processoSalvo;

	private boolean possueEmprestimo;

	private boolean possuiAcessoConsulta;

	private CalculoDevolucaoBaseVisao calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();

	private int colunaOrdenadaContasDevolucao = 1;

	private int colunaOrdenadaParcelasContasDevolucao = 1;

	private AnotacaoDevolucao anotacaoDevolucao;

	private double percentualOpcao;
	private double valorEmprestimo;
	private boolean alteraPercentual;

	// Variaveis de controle de ambiente
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean possuiAcessoTotal;

	private String urlRetorno;
	private String variavelRetorno;

	private boolean permiteSalvarProcessoCalculado;

	private String mensagemAntesSalvar;

	private List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem;

	private boolean possuiDocumentoDevolucao;
	private boolean possuiDocumentoDevolucaoPendente;
	private boolean chamaPendenciasAberturaTela;
	private String descricaoPendencias;
	private Double totalSaldoReserva;
	private boolean devolucaoManual;

	private Date dataRequerimentoAte;
	private Date dataRequerimentoDesde;

	private List<DevolucaoAntigoDTO> listaDevolucaoAntigoDTO = new ArrayList<DevolucaoAntigoDTO>();
	private List<DevolucaoAntigoDTO> listaDevolucaoAntigoDTOSelecionados = new ArrayList<DevolucaoAntigoDTO>();

	/**
	 * Método encarredado por iniciar a página de pesquisa de das devoluções
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return {@link String}
	 */
	public String iniciarDevolucao() {

		validarAcessoFuncionalidade();

		limparFormularioPesquisa();

		this.listaEntidadeParticipante = listarEntidadeParticipante();

		this.listaTipoDevolucao = listarTipoDevolucao();

		this.listaIndicadorFormaPagamentoContribCarencia = listarIndicadorPagamentoContribCarencia();

		this.listaSituacaoDevolucao = listarSituacaoDevolucao();

		this.listaPlanoPrevidencia = listarPlanoPrevidencia();

		return FW_PESQUISA_DEVOLUCAO;
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/06/2017
	 * @return
	 */
	private List<PlanoPrevidencia> listarPlanoPrevidencia() {
		try {
			if (this.entidadeParticipante == null || this.entidadeParticipante.getChavePrimaria() == null) {
				return this.planoPrevidenciaBO.listarPlanoPrevidencia();
			} else {
				return this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante());
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new PrevidenciaException(e.getMessage());
		}
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 05/06/2017
	 * @return
	 */
	private List<SituacaoDevolucao> listarSituacaoDevolucao() {
		return this.situacaoDevolucaoBO.listarTodosSituacaoDevolucao();
	}

	/**
	 * Valida o tipo de acesso à página
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/05/2017
	 */
	public void validarAcessoFuncionalidade() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("pesquisaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo
	 * inicial de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * 
	 */
	public void limparFormularioPesquisa() {
		this.patrocinadoraEditavel = true;
		this.listarStatus = true;

		this.planoPrevidencia = null;
		this.listaPlanoPrevidencia = null;
		this.entidadeParticipante = null;
		this.participante = null;
		this.setParticipante(new Participante());
		this.listaParticipante = null;
		this.devolucao = null;
		this.cadastrarNovaDevolucao = false;
		this.tipoDevolucao = null;
		this.valorEmprestimo = 0D;
		this.setValorCotaPlano(null);
		this.setDataRequerimento(null);
		this.setNumTotalParcelas(1);
		this.setProcessoCalculoConcluido(false);
		this.setColunaOrdenadaContasDevolucao(1);
		this.setProcessoSalvo(false);
		this.setPermiteSalvarProcessoCalculado(false);
		this.setDataRequerimentoAte(null);
		this.setDataRequerimentoDesde(null);
		this.setSituacaoDevolucao(null);

	}

	/**
	 * Método responsável por retornar a lista de Planos associados à
	 * patrocionadora selecionada.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @param {@link
	 * 			AjaxBehaviorEvent}
	 * @return {@link String}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {

		// Limapdo os valores antigos à pesquisa
		setPlanoPrevidencia(null);
		setParticipante(new Participante());
		setListaParticipante(null);

		try {
			this.listaPlanoPrevidencia = listarPlanoPrevidencia();

		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}

		return FW_PESQUISA_DEVOLUCAO;
	}

	/**
	 * Cria uma lista de itens da entidade participante.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return
	 */
	public List<EntidadeParticipante> listarEntidadeParticipante() {
		List<EntidadeParticipante> listaPatrocinadora = new ArrayList<EntidadeParticipante>();

		listaPatrocinadora = entidadeParticipanteBO.listarEntidadeParticipante();

		return listaPatrocinadora;
	}

	/**
	 * Retorna o estado inicial da página
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return
	 */
	public String limparPesquisa() {
		PrimeFaces.current().resetInputs("formDevolucao");
		return iniciarDevolucao();
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o
	 * texo digitado no autocomplete
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link
	 * 			String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.planoPrevidencia != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else if (this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			return new ArrayList<Participante>();
		}

	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());
	}

	/**
	 * Método responsável por setar o Plano escolhido no select do plano
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link
	 * 			SelectEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		setParticipante(new Participante());
		setListaParticipante(null);
		setTipoDevolucao(null);

		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

			// Fazer recargar a lista de tipos de devolução por plano
			this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBo.listarTodosTipoDevolucaoPorPlanoPrevidencia(this.getPlanoPrevidencia()));

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Método responsável por listar todos os tipos de devoluções
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2017
	 * @return
	 */
	public List<TipoDevolucao> listarTipoDevolucao() {
		List<TipoDevolucao> listaTipoDevolucaoTemp = new ArrayList<TipoDevolucao>();
		listaTipoDevolucaoTemp = tipoDevolucaoBo.listarTodosTipoDevolucao();

		return listaTipoDevolucaoTemp;
	}

	/**
	 * Método encarregado de pesquisar a devolução conforme os parâmetros de
	 * pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/06/2017
	 */
	public void pesquisarDevolucao() {
		try {
			this.cadastrarNovaDevolucao = false;

			this.listaDevolucaoAntigoDTO = this.devolucaoBO.consultarDevolucaoPorDevolucaoSistemaAntigoParcelados(
					this.entidadeParticipante,
					this.planoPrevidencia,
					this.participante,
					this.dataRequerimentoDesde,
					this.dataRequerimentoAte);

		} catch (Exception e) {
			log.error(e.getMessage());
			Mensagens.addMsgErro(e.getMessage());
			throw new PrevidenciaException(e.getMessage());

		}
	}

	/**
	 * Método encarregado de calcular o total resgatável da devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/04/2017
	 * 
	 * @return {@link String}
	 */
	private void calcularTotalSaldoResgatavel(List<ContaDevolucao> listaContaDevolucao) {
		this.totalSaldoReserva = 0D;
		for (ContaDevolucao cd : listaContaDevolucao) {
			this.totalSaldoReserva += (cd.getQtdTotalCotasContribuicao() + cd.getQtdTotalCotasCorrecao() + cd.getQtdTotalCotasJuros() + cd.getQtdTotalCotasMulta());
		}

	}

	/**
	 * Método para redirecionar a página de pesquisa para a página de cadastro
	 * de uma nova devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/01/2017
	 * 
	 * @return {@link String}
	 */
	public String mostrarPaginaDevolucaoModoCalculo() {

		try {
			this.setValorEmprestimo(0D);
			// Validar Preenchimento Previo antes de ir à página de Cálculo
			validarPreenchimentoPrevioAoCalculo();

			// pesquisar o Valor Cota Plano Atual
			pesquisarValorCotaPlano(new Date());

			this.processoCalculoConcluido = false;

			this.regraDevolucao = this.regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigencia(this.planoPrevidencia, new Date());

			this.regraCalculoDevolucao = this.regraCalculoDevolucaoBO.pesquisarRegraCalculoDevolucaoPorRegraVigenciaTipo(this.regraDevolucao, new Date(), this.getTipoDevolucao());

			preenchePercentualMaximoDevolucao();

			this.setCadastrarNovaDevolucao(true);
			this.setDevolucaoManual(false);

			getCalculoDevolucaoTela();

			this.setPossueEmprestimo(false);

			if (this.participante.getIndicadorEmprestimo().toString().equals("S")) {
				this.setPossueEmprestimo(true);
			}

			return FW_CALCULO_DEVOLUCAO;
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao gerar dados devolução. Erro: " + e.getMessage());
			return FW_PESQUISA_DEVOLUCAO;// Retorna para tela de pesquisa
		}
	}

	private void preenchePercentualMaximoDevolucao() {

		this.setPercentualOpcao(regraCalculoDevolucao.getTipoDevolucao().getMaximoPercentualDevolucao());

		// Se devolução for total, não deixa editar e utiliza o máximo
		if (regraCalculoDevolucao.getTipoDevolucao().getIndicadorFormaDevolucao().equals("T")) {
			this.alteraPercentual = true;
		} else {
			this.alteraPercentual = false;
		}

	}

	/**
	 * Método para verificar que as informações prévias para o cálculo foram
	 * preenchidas
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 */
	private void validarPreenchimentoPrevioAoCalculo() {

		if (getEntidadeParticipante() == null) {
			throw new PrevidenciaException("Favor, selecionar uma patrocinadora.");
		}

		if (getPlanoPrevidencia() == null) {
			throw new PrevidenciaException("Favor, selecionar um Plano.");
		}

		if (getParticipante().getCodigo() == null) {
			throw new PrevidenciaException("Favor, selecionar um Participante.");
		}

		if (this.getTipoDevolucao() == null) {
			throw new PrevidenciaException("Favor, selecionar um Tipo de Devolução.");
		}

	}

	/**
	 * Método para pesquisar Valor Cota Plano
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link
	 * 			Date}
	 */
	public String pesquisarValorCotaPlano(Date dataPosicaoCota) {
		if (this.getEntidadeParticipante() == null) {
			Mensagens.addMsgErro("Favor, selecionar uma patrocinadora.");
			return null;
		}

		ParticipantePlano participantePlano = new ParticipantePlano();

		participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(), this.getPlanoPrevidencia());

		// List<PerfilInvestimento> listaPefilIvestimento = new
		// ArrayList<PerfilInvestimento>(perfilInvestimentoBO.listarPerfilInvestimentoPorEntidadeParticipante(getEntidadeParticipante()));
		List<PerfilInvestimento> listaPefilIvestimento = new ArrayList<PerfilInvestimento>(perfilInvestimentoBO.listarPerfilInvestimentoPorParticipantePlano(participantePlano));

		for (PerfilInvestimento perfilInvestimento : listaPefilIvestimento) {

			ValorCotaPlano valorCotaPlano = valorCotaPlanoBO.pesquisarCotaPlanoPorEmpresaPlanoPerfil(dataPosicaoCota, participantePlano.getParticipante().getEntidadeParticipante(), participantePlano
					.getPlanoPrevidencia(), perfilInvestimento);

			if (valorCotaPlano != null) {
				this.valorCotaPlano = valorCotaPlano;
			} else {
				this.valorCotaPlano = null;
			}
		}

		if (valorCotaPlano != null) {
			this.valorCotaPlano = valorCotaPlano;
		} else {
			this.valorCotaPlano = null;
		}

		return "S";
	}

	/**
	 * Método encarregado de retornar todos os Indicadores da Forma de Pagamento
	 * da Contribuição de Carência
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/01/2017
	 * @return {@link List<SelectItem>}
	 */
	public List<SelectItem> listarIndicadorPagamentoContribCarencia() {
		return IndicadorFormaPagamentoContribCarencia.listaElementosEnum();

	}

	/**
	 * Método encarregado de Calcular o Processo de devolução e preencher a tela
	 * com as informações retornadas
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/02/2017
	 * @return {@link String}
	 */
	public String calcularProcessoDevolucao() {
		FacesContext context = FacesContext.getCurrentInstance();

		try {

			String dataCotaCalculo;

			String dataRequerimento;

			if (this.getValorCotaPlano().getChavePrimaria().getDataPosicaoCota() != null) {
				dataCotaCalculo = UtilJava.formataDataPorPadrao(this.getValorCotaPlano().getChavePrimaria().getDataPosicaoCota(), "dd/MM/yyyy");
			} else {
				// pesquiso novamente o ValorCotaPlano para a data atual
				pesquisarValorCotaPlano(new Date());
				dataCotaCalculo = UtilJava.formataDataPorPadrao(this.getValorCotaPlano().getChavePrimaria().getDataPosicaoCota(), "dd/MM/yyyy");
			}

			if (this.getCalculoDevolucaoTela().getDataRequerimento() != null) {
				dataRequerimento = UtilJava.formataDataPorPadrao(this.getCalculoDevolucaoTela().getDataRequerimento(), "dd/MM/yyyy");
			} else {
				dataRequerimento = UtilJava.formataDataPorPadrao(new Date(), "dd/MM/yyyy");
			}

			// Verificação de empréstimo
			if (this.participante.getIndicadorEmprestimo().toString().equals("S")) {

				if (this.valorEmprestimo == 0) {

					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Favor preencher valor de empréstimo."));
					return FW_CALCULO_DEVOLUCAO;

				}

			}

			ParticipantePlano participantePlano = new ParticipantePlano();

			participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(), this.getPlanoPrevidencia());

			String opcaoTributacao = participantePlano.getTipoRegimeTributacao().getCodigo();

			this.devolucaoCalculoCompleto = this.calculoDevolucao.calcularDevolucao(this.getParticipante().getCodigo(), // código
					// do
					// participante
					this.getPlanoPrevidencia().getCodigo(), // codigo do plano
					this.getTipoDevolucao().getCodigo(), // tipo de volu
					dataRequerimento, // data do requerimento em string
					null, // tipo de devoluçao
					"S", // s o n
					this.getNumTotalParcelas(), // Quantidade Total de parcelas
					dataCotaCalculo, // data da cota tipo string
					this.getIndicadorFormaPagamentoContribCarencia(),
					null,
					getPercentualOpcao(),
					this.valorEmprestimo,
					opcaoTributacao);// forma
			// de
			// pagamento

			expandirDetalheParcelaDevolucao(devolucaoCalculoCompleto.getListaParcelaContaDevolucao());

			setProcessoCalculoConcluido(true);

			if (isProcessoCalculoConcluido()) {

				// Verificar se existem documentos devolução para o Plano -
				// Yanisley
				List<DocumentoPlanoTipoDevolucao> listaDocPlanoDev = new ArrayList<DocumentoPlanoTipoDevolucao>(documentoPlanoTipoDevolucaoBO.listaDocumentoPlanoTipoDevolucaoPorPlanoTipoDevolucao(
						this.planoPrevidencia,
						this.tipoDevolucao.getCodigo()));

				if (UtilJava.isColecaoDiferenteDeVazia(listaDocPlanoDev)) {
					this.setPermiteSalvarProcessoCalculado(true);
				} else {
					String mensagemSaidaDevolucao = "Plano " + this.planoPrevidencia.getNomePlano() + " sem documentos de devolução cadastrados.";
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));
					PrimeFaces.current().ajax().update(":txtPopup");
					this.setPermiteSalvarProcessoCalculado(false);
				}

				this.setIndicadorFormaPagamentoContribCarencia(this.devolucaoCalculoCompleto.getDevolucao().getIndicadorFormaPagtoContribCarencia());
				this.setNumTotalParcelas(this.devolucaoCalculoCompleto.getDevolucao().getNumeroTotalParcelas());
				this.getCalculoDevolucaoTela().setDataRequerimento(this.devolucaoCalculoCompleto.getDevolucao().getDataRequerimento());

				ElegibilidadeDevolucaoDTO elegibilidadeDevolucaoDTO = new ElegibilidadeDevolucaoDTO();

				elegibilidadeDevolucaoDTO = regraElegibilidadeDevolucaoBO.isElegivelPorDevolucao(this.devolucaoCalculoCompleto.getDevolucao());

				if (elegibilidadeDevolucaoDTO.isElegivel()) {
					System.out.println("Elegível");
				} else {
					System.out.println("Não Elegível");

					// Mensagem de carta de indeferimento
					String mensagemSaidaDevolucao = "O Participante não é elegível para efetuar o "
							+ this.devolucaoCalculoCompleto.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getNome() + "<br /> Motivo: " + elegibilidadeDevolucaoDTO.getDescricao()
							+ ".<br />" + "Clique <b><a href='#'>aqui</a></b> para imprimir a carta de indeferimento.";
					// Mensagens.addMsgWarn(mensagemSaidaDevolucao);
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));
					PrimeFaces.current().ajax().update(":txtPopup");
					this.setPermiteSalvarProcessoCalculado(false);

				}

				// Exigencia de desligamento
				if (elegibilidadeDevolucaoDTO.isNaoDesligadoDevolucaoExigeDesligamento()) {
					String mensagemSaidaDevolucao = "O Participante não desligado.";
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));

					this.setPermiteSalvarProcessoCalculado(false);
				}

				if (elegibilidadeDevolucaoDTO.isMotivoDesligamentoNuloOuDiferenteExigido()) {

					String mensagemSaidaDevolucao = new String();

					if (this.devolucaoCalculoCompleto.getDevolucao().getParticipantePlano().getParticipante().getMotivoDesligamento() == null) {
						mensagemSaidaDevolucao = "Participante sem motivo de desligamento preenchido.";
					} else {
						mensagemSaidaDevolucao = "Participante com motivo de desligamento diferente do exigido.";
					}
					context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", mensagemSaidaDevolucao));

					this.setPermiteSalvarProcessoCalculado(false);
				}

				/*
				 * if (this.devolucaoCalculoCompleto.getDevolucao().
				 * getRegraCalculoDevolucao().getTipoDevolucao().
				 * getIndicadorTipoDevolucao().equalsIgnoreCase("R")) { if
				 * (!UtilJava.isNumeroNuloOuZero(this.devolucaoCalculoCompleto.
				 * getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao()
				 * .getMesesCarenciaResgate()) &&
				 * this.devolucaoCalculoCompleto.getDevolucao().
				 * getRegraCalculoDevolucao().getRegraDevolucao().
				 * getMesesCarenciaResgate() >
				 * this.devolucaoCalculoCompleto.getDevolucao()
				 * .getMesesPlanoCalculo()) { } } else { if
				 * (!UtilJava.isNumeroNuloOuZero(this.devolucaoCalculoCompleto.
				 * getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao()
				 * .getMesesCarenciaPortabilidade()) &&
				 * this.devolucaoCalculoCompleto.getDevolucao().
				 * getRegraCalculoDevolucao().getRegraDevolucao().
				 * getMesesCarenciaPortabilidade() >
				 * this.devolucaoCalculoCompleto
				 * .getDevolucao().getMesesPlanoCalculo()) { String
				 * mensagemSaidaPortabilidade =
				 * "O Participante não possui o tempo de plano necessário para efetuar a Portabilidade.<br/>"
				 * +
				 * "Clique <strong><a href='#'>aqui</a></strong> para imprimir a carta de indeferimento."
				 * ; context.addMessage(null, new
				 * FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso",
				 * mensagemSaidaPortabilidade));
				 * this.setPermiteSalvarProcessoCalculado(false); } }
				 */

				if (UtilJava.isColecaoDiferenteDeVazia(this.devolucaoCalculoCompleto.getDevolucao().getListaDescontoDevolucao())) {
					this.setMensagemAntesSalvar("O participante possui descontos. Deseja continuar?");
				} else {
					this.setMensagemAntesSalvar("Confirma Salvar o processo de Devolução?");
				}

				calcularTotalSaldoResgatavel(this.devolucaoCalculoCompleto.getListaContaDevolucao());
				// this.calculoDevolucaoTela.calcularTotaisContasDevolucao(this.devolucaoCalculoCompleto.getListaContaDevolucao(),
				// this.devolucaoCalculoCompleto.getDevolucao().getValorIndiceAjustado());

			}
		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			// Mensagens.addMsgErro(pEx.getMessage());

			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", pEx.getMessage()));

		}

		return FW_CALCULO_DEVOLUCAO;
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/06/2017
	 * @param saldoHistoricoFinanceiroPagoDTO
	 * @return
	 */
	private List<SaldoHFPDevolucaoDTO> montarListaSaldoHFPDevolucaoDTO(SaldoHistoricoFinanceiroPagoDTO saldoHistoricoFinanceiroPagoDTO) {
		List<SaldoHFPDevolucaoDTO> listaRetorno = new ArrayList<SaldoHFPDevolucaoDTO>();

		listaRetorno.add(new SaldoHFPDevolucaoDTO("Participante", saldoHistoricoFinanceiroPagoDTO.getQtdCotaContribuicaoPartic(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaJurosParticipante(),
				saldoHistoricoFinanceiroPagoDTO.getQtdCotaCorrecaoParticipante(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaMultaParticipante(), saldoHistoricoFinanceiroPagoDTO.getIndicadorMulta(),
				saldoHistoricoFinanceiroPagoDTO.getIndicadorJuros(), saldoHistoricoFinanceiroPagoDTO.getIndicadorCorrecao()));

		listaRetorno.add(new SaldoHFPDevolucaoDTO("Patrocinadora", saldoHistoricoFinanceiroPagoDTO.getQtdCotaContribuicaoPatronal(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaJurosPatronal(),
				saldoHistoricoFinanceiroPagoDTO.getQtdCotaCorrecaoPatronal(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaMultaPatronal(), saldoHistoricoFinanceiroPagoDTO.getIndicadorMulta(),
				saldoHistoricoFinanceiroPagoDTO.getIndicadorJuros(), saldoHistoricoFinanceiroPagoDTO.getIndicadorCorrecao()));

		listaRetorno.add(new SaldoHFPDevolucaoDTO("Autopatrocinado", saldoHistoricoFinanceiroPagoDTO.getQtdCotaContribuicaoPatronalParticipante(), saldoHistoricoFinanceiroPagoDTO
				.getQtdCotaJurosPatronalParticipante(), saldoHistoricoFinanceiroPagoDTO.getQtdCotaCorrecaoPatronalParticipante(),
				saldoHistoricoFinanceiroPagoDTO.getQtdCotaMultaPatronalParticipante(), saldoHistoricoFinanceiroPagoDTO.getIndicadorMulta(), saldoHistoricoFinanceiroPagoDTO.getIndicadorJuros(),
				saldoHistoricoFinanceiroPagoDTO.getIndicadorCorrecao()));

		return listaRetorno;
	}

	/**
	 * Método para retornar a descrição do indicador do mantenedor
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param indicadorMantenedor
	 * @since 01/02/2017
	 * @return {@link String}
	 */
	public String buscarDescricaoMantenedor(String codigo) {
		return MantenedorEnum.getMantenedorEnum(codigo).getDescricao();
	}

	/**
	 * Método responsável de calacular os totais do DataTable da Contas de
	 * Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * 
	 */
	public void calcularTotaisContas(Object o) {
		if (this.colunaOrdenadaContasDevolucao != 0) {
			this.calculoDevolucaoTela.calcularTotaisContasDevolucao(this.devolucaoCalculoCompleto.getListaContaDevolucao(), this.devolucaoCalculoCompleto.getDevolucao().getValorIndiceAjustado(), o
					.toString(), this.getColunaOrdenadaContasDevolucao());
		}

	}

	/**
	 * Método encarregado de calcular os totais que são mostrados no Datatable
	 * das parcelas de devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param o
	 */
	public void calcularTotaisParcelasContas(Object o) {
		if (this.colunaOrdenadaParcelasContasDevolucao != 0) {
			this.calculoDevolucaoTela.calcularTotaisContasParcelas(this.devolucaoCalculoCompleto.getListaParcelaContaDevolucaoDetalheImposto(), this.devolucaoCalculoCompleto
					.getListaParcelaContaDevolucao(), this.devolucaoCalculoCompleto.getDevolucao().getValorIndiceAjustado(), o.toString(), this.colunaOrdenadaParcelasContasDevolucao);
		}
	}

	/**
	 * Método encarregado de salvar a coluna que foi selecionada para ordenar o
	 * datatable das Contas de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param {@link
	 * 			SortEvent}
	 */
	public void onSortContasDevolucao(SortEvent event) {
		if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Tipo"))
			colunaOrdenadaContasDevolucao = 1;
		else if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Mantenedor"))
			colunaOrdenadaContasDevolucao = 2;
		else if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Automantenedor"))
			colunaOrdenadaContasDevolucao = 3;

	}

	/**
	 * Método encarregado de pegar a coluna que foi clicada no datatable das
	 * Parcelas de Contas de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link
	 * 			SortEvent}
	 */
	public void onSortParcelasContasDevolucao(SortEvent event) {
		if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Tipo"))
			colunaOrdenadaParcelasContasDevolucao = 1;
		else if (event.getSortColumn().getHeaderText().equalsIgnoreCase("Parcela Paga"))
			colunaOrdenadaParcelasContasDevolucao = 2;
	}

	/**
	 * Método para pesuisar o Valor Cota Plano quando a data é selecionada na UI
	 * do Calendar
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link
	 * 			SelectEvent}R
	 */
	public void dataPosicaoCotaSelecionada(SelectEvent event) {
		if (event.getObject() instanceof Date) {
			pesquisarValorCotaPlano((Date) event.getObject());
		} else {
			System.out.println("Chegou outra Coisa");
		}
	}

	/**
	 * Método para pesuisar o Valor Cota Plano quando a data é digitada
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * @param {@link
	 * 			AjaxBehaviorEvent}
	 */
	public void dataPosicaoCotaAltecaoManual(AjaxBehaviorEvent event) {
		Date dataManual = (Date) ((UIOutput) event.getSource()).getValue();

		pesquisarValorCotaPlano(dataManual);

	}

	/**
	 * Método encarregado de salvar o processo de devolução após o processo de
	 * cálculo
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/02/2017
	 * 
	 */
	public String salvarProcessoDevolucao() {
		if (this.getDevolucaoCalculoCompleto() != null) {
			try {
				this.calculoDevolucao.salvarDevolucao(getDevolucaoCalculoCompleto());
				Mensagens.addMsgInfo("Processo de devolução salvo com Sucesso!");
				this.setProcessoSalvo(true);

				if (documentoDevolucaoVisaoItemBO.verificarDocumentosPorDevolucao(getDevolucaoCalculoCompleto().getDevolucao(), loginTemporariaDTO)) {

					Mensagens.addMsgInfo("Favor verificar documento de devolução!");

					verificarDocumentosDevolucao(getDevolucaoCalculoCompleto().getDevolucao());

				}

			} catch (PrevidenciaException pEx) {
				Mensagens.addMsgErro(pEx.getMessage());
				this.setProcessoSalvo(false);
			} catch (Exception ex) {
				Mensagens.addMsgErro("Erro ao salvar o processo de Devolulução.");
				this.setProcessoSalvo(false);
			}
		}

		return FW_CALCULO_DEVOLUCAO;
	}

	/**
	 * Método encarregado de retornar ao modo pesquisa inicial mantendo a lista
	 * de Planos
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/02/2017
	 */
	public String retornarPaginaPesquisa() {
		this.setProcessoCalculoConcluido(false);
		this.setProcessoSalvo(false);
		this.setDevolucaoCalculoCompleto(null);
		this.setCadastrarNovaDevolucao(false);
		this.calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();
		this.setValorCotaPlano(null);
		this.setColunaOrdenadaParcelasContasDevolucao(1);
		this.setColunaOrdenadaContasDevolucao(1);

		this.setParticipante(new Participante());
		this.setTipoDevolucao(null);

		return getUrlRetorno();
	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */

	public void expandirDetalheParcelaDevolucao(ToggleEvent event) {
		/*
		 * ParcelaContaDevolucao parcelaContaDevolucao = (ParcelaContaDevolucao)
		 * event.getData();
		 * 
		 * this.listaParcelaContaDevolucaoDetalheImpostoDTO.clear();
		 * this.listaParcelaContaDevolucaoDetalheImposto.clear();
		 * 
		 * if (this.processoSalvo) {
		 * this.listaParcelaContaDevolucaoDetalheImposto = new
		 * ArrayList<ParcelaContaDevolucaoDetalheImposto>(
		 * parcelaContaDevolucaoDetalheImpostoBO
		 * .pesquisarParcelaContaDevolucaoDetalheImpostoPorParcelaContaDevolucaoECronograma
		 * (parcelaContaDevolucao, null)); } else { for
		 * (ParcelaContaDevolucaoDetalheImposto
		 * parcelaContaDevolucaoDetalheImposto : this.devolucaoCalculoCompleto.
		 * getListaParcelaContaDevolucaoDetalheImposto()) {
		 * 
		 * if (parcelaContaDevolucao.equals(parcelaContaDevolucaoDetalheImposto.
		 * getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao())){
		 * this.listaParcelaContaDevolucaoDetalheImposto.add(
		 * parcelaContaDevolucaoDetalheImposto); } } }
		 * 
		 * listaParcelaContaDevolucaoDetalheImpostoDTO.addAll(
		 * parcelaContaDevolucaoDetalheImpostoBO.agruparDataETipoImposto(this.
		 * listaParcelaContaDevolucaoDetalheImposto));
		 */
	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */
	public void expandirDetalheParcelaDevolucao(List<ParcelaContaDevolucao> listaParcelaContaDevolucao) {

		for (ParcelaContaDevolucao parcelaContaDevolucao : listaParcelaContaDevolucao) {

			// this.listaParcelaContaDevolucaoDetalheImpostoDTO.clear();
			// this.listaParcelaContaDevolucaoDetalheImposto.clear();

			List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevolucaoDetalheImposto = new ArrayList<>();

			if (this.processoSalvo) {
				listaParcelaContaDevolucaoDetalheImposto = new ArrayList<ParcelaContaDevolucaoDetalheImposto>(
						parcelaContaDevolucaoDetalheImpostoBO
								.pesquisarParcelaContaDevolucaoDetalheImpostoPorParcelaContaDevolucaoECronograma(
										parcelaContaDevolucao, null));
			} else {
				for (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto : this.devolucaoCalculoCompleto
						.getListaParcelaContaDevolucaoDetalheImposto()) {

					if (parcelaContaDevolucao.equals(parcelaContaDevolucaoDetalheImposto
							.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao())) {
						listaParcelaContaDevolucaoDetalheImposto.add(parcelaContaDevolucaoDetalheImposto);
					}
				}
			}

			parcelaContaDevolucao.setListaParcelaContaDevolucaoDetalheImpostoDTO(parcelaContaDevolucaoDetalheImpostoBO
					.agruparDataETipoImposto(listaParcelaContaDevolucaoDetalheImposto));

		}

	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */
	public void expandirDetalheParcelaDevolucaoImpostoDTO(List<ParcelaContaDevolucaoDetalheImpostoDTO> listaParcelaContaDevolucaoDetalheImpostoDTO) {

		for (ParcelaContaDevolucaoDetalheImpostoDTO parcelaContaDevolucaoDetalheImpostoDTO : listaParcelaContaDevolucaoDetalheImpostoDTO) {
			parcelaContaDevolucaoDetalheImpostoDTO.setListaParcelaContaDevolucaoDetalheImposto(parcelaContaDevolucaoDetalheImpostoDTO.getListaParcelaContaDevolucaoDetalheImposto());
		}
	}

	/**
	 * Método encarregado de Processar o evento de expasão do DataTable
	 * id="ltParcelasContasDevolucao" para carregar a lista do Detalahmento da
	 * Parcela de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * @param event
	 */

	public void expandirDetalheParcelaDevolucaoImpostoDTO(ToggleEvent event) {
		/*
		 * ParcelaContaDevolucaoDetalheImpostoDTO
		 * parcelaContaDevolucaoDetalheImpostoDTO =
		 * (ParcelaContaDevolucaoDetalheImpostoDTO) event.getData();
		 * 
		 * 
		 * listaParcelaContaDevolucaoDetalheImpostoFiltro.addAll(
		 * parcelaContaDevolucaoDetalheImpostoDTO.
		 * getListaParcelaContaDevolucaoDetalheImposto());
		 */
	}

	/**
	 * Método encarregado de Calculo o total de impostos a pagar por parcela
	 * conta devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * 
	 * @param {@link
	 * 			ParcelaContaDevolucao}
	 */
	public double calcularImpostosParcela(ParcelaContaDevolucao parcelaContaDevolucao) {
		double totalImpostoParcela = 0D;

		for (ParcelaContaDevolucaoDetalheImposto detalheImposto : devolucaoCalculoCompleto.getListaParcelaContaDevolucaoDetalheImposto()) {
			if (detalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().equals(parcelaContaDevolucao) && detalheImposto.getCronogramaDevolucao() == null) {
				totalImpostoParcela += detalheImposto.getValorIrrf();
			}
		}

		return totalImpostoParcela;

	}

	public double calcularImpostosPago(ParcelaContaDevolucao parcelaContaDevolucao) {
		double totalImpostoParcela = 0D;
		for (ParcelaContaDevolucaoDetalheImposto detalheImposto : devolucaoCalculoCompleto.getListaParcelaContaDevolucaoDetalheImposto()) {
			if (detalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().equals(parcelaContaDevolucao) && detalheImposto.getCronogramaDevolucao() != null) {
				totalImpostoParcela += detalheImposto.getValorIrrf();
			}
		}

		return totalImpostoParcela;
	}

	/**
	 * Metodo responsável pelo cancelamento da inclusão de uma nova Anotação de
	 * Devoluçao
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 */
	public void cancelarInclusaoAnotacaoDevolucao() {
		this.anotacaoDevolucao = new AnotacaoDevolucao();
	}

	/**
	 * Método responsável de incluir novas Anotações de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/02/2017
	 * 
	 */
	public void incluirAnotacaoDevolucao(Devolucao devolucao) {

		this.anotacaoDevolucao.setDevolucao(devolucao);

		if (this.anotacaoDevolucao.getDataAnotacao() == null) {
			this.anotacaoDevolucao.setDataAnotacao(new Date());
		}

		if (this.anotacaoDevolucao.getDescricaoAnotacao() != null) {
			anotacaoDevolucaoBO.salvarAnotacaoDevolucao(this.anotacaoDevolucao);
		}

		this.devolucaoCalculoCompleto.setListaAnotacaoDevolucao(anotacaoDevolucaoBO.listaTodasPorDevolucao(this.devolucaoCalculoCompleto.getDevolucao()));

		cancelarInclusaoAnotacaoDevolucao();
	}

	public void limparObjetosTemporarios() {

	}

	public void salvarListaDocumentoDevolucaoVisaoItem() {

		for (DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItem : this.listaDocumentoDevolucaoVisaoItem) {

			DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItemPesq = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorCodigo(documentoDevolucaoVisaoItem.getCodigo());

			if (!documentoDevolucaoVisaoItemPesq.getIndicativoMarcado().equals(documentoDevolucaoVisaoItem.getIndicativoMarcado())) {

				// Marcando a data de marcação do documento.
				if (documentoDevolucaoVisaoItem.getIndicativoMarcado().equals("S")) {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(new Date());
				} else {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(null);
				}

				documentoDevolucaoVisaoItemPesq.setIndicativoMarcado(documentoDevolucaoVisaoItem.getIndicativoMarcado());
				documentoDevolucaoVisaoItemPesq.setNomeUsuarioAlteracao(loginTemporariaDTO.getIdentificacaoUsuario());
				documentoDevolucaoVisaoItemBO.salvarDocumentoDevolucaoVisaoItem(documentoDevolucaoVisaoItemPesq);
			}

		}

		Devolucao devolucaoInterno = new Devolucao();

		if (this.listaDocumentoDevolucaoVisaoItem.size() > 0) {
			devolucaoInterno = this.listaDocumentoDevolucaoVisaoItem.get(0).getDocumentoDevolucaoVisao().getDevolucao();
		}

		verificarDocumentosDevolucao(devolucaoInterno);

	}

	public void verificarDocumentosDevolucao(Devolucao devolucao) {

		String descricaoPendenciasLocal = new String();

		descricaoPendenciasLocal = "Não existe(m) documento(s)";

		if (devolucao == null) {
			this.setPossuiDocumentoDevolucao(false);
			this.setPossuiDocumentoDevolucaoPendente(false);
			this.setChamaPendenciasAberturaTela(false);
		} else {

			this.listaDocumentoDevolucaoVisaoItem = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorDevolucao(devolucao);

			this.setPossuiDocumentoDevolucaoPendente(false);
			this.setChamaPendenciasAberturaTela(false);

			if (this.listaDocumentoDevolucaoVisaoItem.size() > 0) {

				descricaoPendenciasLocal = "Não existe(m) documento(s) pendente(s)";

				this.setPossuiDocumentoDevolucao(true);

				if (documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemPendentePorDevolucao(devolucao)) {
					this.setPossuiDocumentoDevolucaoPendente(true);
					descricaoPendenciasLocal = "Existe(m) documento(s) Pendende(s)";
				}

			} else {
				descricaoPendenciasLocal = "Não existe(m) documento(s)";
				this.setPossuiDocumentoDevolucao(false);

			}

			// Somente chamar pendencia de forma automática se vier da tela de
			// pesquisa.
			if (this.getVariavelRetorno().equals("pesquisa")) {

				if (this.isPossuiDocumentoDevolucaoPendente()) {
					this.setChamaPendenciasAberturaTela(true);
				}

			}

		}

		this.setDescricaoPendencias(descricaoPendenciasLocal);

	}

	/**
	 * Método encarregado de mostrar o relatório de Processo de Retenção em PDF
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 12/04/2017
	 * @param {@link
	 * 			Devolucao}
	 */
	public void mostrarRelatorioProcessoRetencao(Devolucao devolucao) {
		try {
			ProcessoRetencaoDTO processoRetencaoDTO = new ProcessoRetencaoDTO();

			processoRetencaoDTO = this.devolucaoBO.montarRelatorioProcessoRetencao(devolucao);

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = UtilSession.getRealPath("imagens/logoBBPrevidencia.jpg");

			parametros.put("logo", logo);

			List<ProcessoRetencaoDTO> relatorioProcessoRetencao = new ArrayList<ProcessoRetencaoDTO>();
			relatorioProcessoRetencao.add(processoRetencaoDTO);
			String nomeArquivo = relatorioUtil.gerarRelatorio("processoRetencao", relatorioProcessoRetencao, parametros);
			relatorioUtil.abrirPoupUp(nomeArquivo);

			// JRBeanCollectionDataSource dataSource = new
			// JRBeanCollectionDataSource(relatorioProcessoRetencao);
			// GerenciaRelatorioUtil.geraRelatorioPDF(parametros,
			// "processoRetencao", dataSource);

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}
	}

	/**
	 * Método encarregado de mostrar o relatório da Súmula em PDF
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 07/11/2017
	 * @param {@link
	 * 			Devolucao}
	 */
	public void mostrarRelatorioSumula(Devolucao devolucao) {
		try {
			SumulaDevolucaoDTO sumulaDevolucaoDTO = new SumulaDevolucaoDTO();
			sumulaDevolucaoDTO = this.devolucaoBO.montarRelatorioSumulaDevolucao(devolucao);

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = UtilSession.getRealPath("imagens/logoBBPrevidencia.jpg");

			parametros.put("logo", logo);

			//parametros.put("listaDocumentos", sumulaDevolucaoDTO.getDadosPortabilidadeContaSumula());

			parametros.put("recebedoresResgateSumula", sumulaDevolucaoDTO.getRecebedoresResgateSumula());

			List<SumulaDevolucaoDTO> relatorioSumulaDevolucao = new ArrayList<SumulaDevolucaoDTO>();
			relatorioSumulaDevolucao.add(sumulaDevolucaoDTO);
			String nomeArquivo = relatorioUtil.gerarRelatorio("sumulaDevolucao", relatorioSumulaDevolucao, parametros);
			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	/**
	 * Método encarregado de retorna msn de acordo com a tela de retorno.
	 * 
	 * @author BBPF0170 - Magson DiAS
	 * @since 17/05/2017
	 * @param {@link
	 * 			String}
	 */

	public void paginaRetornoMessage(String msn) {
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, new FacesMessage("Consultar", "Tela de consulta: " + msn));
		PrimeFaces.current().ajax().update(":pgPesquisa");
	}

	// Getters And Setters

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public boolean isPatrocinadoraEditavel() {
		return patrocinadoraEditavel;
	}

	public void setPatrocinadoraEditavel(boolean patrocinadoraEditavel) {
		this.patrocinadoraEditavel = patrocinadoraEditavel;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public boolean isCadastrarNovaDevolucao() {
		return cadastrarNovaDevolucao;
	}

	public void setCadastrarNovaDevolucao(boolean cadastrarNovaDevolucao) {
		this.cadastrarNovaDevolucao = cadastrarNovaDevolucao;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public Integer getNumTotalParcelas() {
		return numTotalParcelas;
	}

	public void setNumTotalParcelas(Integer numTotalParcelas) {
		this.numTotalParcelas = numTotalParcelas;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public ValorCotaPlano getValorCotaPlano() {
		return valorCotaPlano;
	}

	public void setValorCotaPlano(ValorCotaPlano valorCotaPlano) {
		this.valorCotaPlano = valorCotaPlano;
	}

	public List<SelectItem> getListaIndicadorFormaPagamentoContribCarencia() {
		return listaIndicadorFormaPagamentoContribCarencia;
	}

	public void setListaIndicadorFormaPagamentoContribCarencia(List<SelectItem> listaIndicadorFormaPagamentoContribCarencia) {
		this.listaIndicadorFormaPagamentoContribCarencia = listaIndicadorFormaPagamentoContribCarencia;
	}

	public String getIndicadorFormaPagamentoContribCarencia() {
		return indicadorFormaPagamentoContribCarencia;
	}

	public void setIndicadorFormaPagamentoContribCarencia(String indicadorFormaPagamentoContribCarencia) {
		this.indicadorFormaPagamentoContribCarencia = indicadorFormaPagamentoContribCarencia;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public DevolucaoCompletoDTO getDevolucaoCalculoCompleto() {
		return devolucaoCalculoCompleto;
	}

	public void setDevolucaoCalculoCompleto(DevolucaoCompletoDTO devolucaoCalculoCompleto) {
		this.devolucaoCalculoCompleto = devolucaoCalculoCompleto;
	}

	public boolean isProcessoCalculoConcluido() {
		return processoCalculoConcluido;
	}

	public void setProcessoCalculoConcluido(boolean processoCalculoConcluido) {
		this.processoCalculoConcluido = processoCalculoConcluido;
	}

	public CalculoDevolucaoBaseVisao getCalculoDevolucaoTela() {
		if (calculoDevolucaoTela == null) {
			calculoDevolucaoTela = new CalculoDevolucaoBaseVisao();
		}

		return calculoDevolucaoTela;
	}

	public void setCalculoDevolucaoTela(CalculoDevolucaoBaseVisao calculoDevolucaoTela) {
		this.calculoDevolucaoTela = calculoDevolucaoTela;
	}

	public int getColunaOrdenadaContasDevolucao() {
		return colunaOrdenadaContasDevolucao;
	}

	public void setColunaOrdenadaContasDevolucao(int colunaOrdenadaContasDevolucao) {
		this.colunaOrdenadaContasDevolucao = colunaOrdenadaContasDevolucao;
	}

	public int getColunaOrdenadaParcelasContasDevolucao() {
		return colunaOrdenadaParcelasContasDevolucao;
	}

	public void setColunaOrdenadaParcelasContasDevolucao(int colunaOrdenadaParcelasContasDevolucao) {
		this.colunaOrdenadaParcelasContasDevolucao = colunaOrdenadaParcelasContasDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isProcessoSalvo() {
		return processoSalvo;
	}

	public void setProcessoSalvo(boolean processoSalvo) {
		this.processoSalvo = processoSalvo;
	}

	public AnotacaoDevolucao getAnotacaoDevolucao() {
		if (this.anotacaoDevolucao == null) {
			this.anotacaoDevolucao = new AnotacaoDevolucao();
		}
		return anotacaoDevolucao;
	}

	public void setAnotacaoDevolucao(AnotacaoDevolucao anotacaoDevolucao) {
		this.anotacaoDevolucao = anotacaoDevolucao;
	}

	public String getUrlRetorno() {
		return urlRetorno;
	}

	public void setUrlRetorno(String urlRetorno) {
		this.urlRetorno = urlRetorno;
	}

	public String getVariavelRetorno() {
		return variavelRetorno;
	}

	public void setVariavelRetorno(String variavelRetorno) {
		this.variavelRetorno = variavelRetorno;
	}

	public double getPercentualOpcao() {
		return percentualOpcao;
	}

	public void setPercentualOpcao(double percentualOpcao) {
		this.percentualOpcao = percentualOpcao;
	}

	public boolean isAlteraPercentual() {
		return alteraPercentual;
	}

	public void setAlteraPercentual(boolean alteraPercentual) {
		this.alteraPercentual = alteraPercentual;
	}

	public boolean isPermiteSalvarProcessoCalculado() {
		return permiteSalvarProcessoCalculado;
	}

	public void setPermiteSalvarProcessoCalculado(boolean permiteSalvarProcessoCalculado) {
		this.permiteSalvarProcessoCalculado = permiteSalvarProcessoCalculado;
	}

	public String getMensagemAntesSalvar() {
		return mensagemAntesSalvar;
	}

	public void setMensagemAntesSalvar(String mensagemAntesSalvar) {
		this.mensagemAntesSalvar = mensagemAntesSalvar;
	}

	public boolean isPossueEmprestimo() {
		return possueEmprestimo;
	}

	public void setPossueEmprestimo(boolean possueEmprestimo) {
		this.possueEmprestimo = possueEmprestimo;
	}

	public double getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(double valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public List<DocumentoDevolucaoVisaoItem> getListaDocumentoDevolucaoVisaoItem() {
		return listaDocumentoDevolucaoVisaoItem;
	}

	public void setListaDocumentoDevolucaoVisaoItem(List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem) {
		this.listaDocumentoDevolucaoVisaoItem = listaDocumentoDevolucaoVisaoItem;
	}

	public boolean isPossuiDocumentoDevolucao() {
		return possuiDocumentoDevolucao;
	}

	public void setPossuiDocumentoDevolucao(boolean possuiDocumentoDevolucao) {
		this.possuiDocumentoDevolucao = possuiDocumentoDevolucao;
	}

	public boolean isPossuiDocumentoDevolucaoPendente() {
		return possuiDocumentoDevolucaoPendente;
	}

	public void setPossuiDocumentoDevolucaoPendente(boolean possuiDocumentoDevolucaoPendente) {
		this.possuiDocumentoDevolucaoPendente = possuiDocumentoDevolucaoPendente;
	}

	public boolean isChamaPendenciasAberturaTela() {
		return chamaPendenciasAberturaTela;
	}

	public void setChamaPendenciasAberturaTela(boolean chamaPendenciasAberturaTela) {
		this.chamaPendenciasAberturaTela = chamaPendenciasAberturaTela;
	}

	public String getDescricaoPendencias() {
		return descricaoPendencias;
	}

	public void setDescricaoPendencias(String descricaoPendencias) {
		this.descricaoPendencias = descricaoPendencias;
	}

	public Double getTotalSaldoReserva() {
		return totalSaldoReserva;
	}

	public void setTotalSaldoReserva(Double totalSaldoReserva) {
		this.totalSaldoReserva = totalSaldoReserva;
	}

	public boolean isPossuiAcessoConsulta() {
		return possuiAcessoConsulta;
	}

	public void setPossuiAcessoConsulta(boolean possuiAcessoConsulta) {
		this.possuiAcessoConsulta = possuiAcessoConsulta;
	}

	public boolean isDevolucaoManual() {
		return devolucaoManual;
	}

	public void setDevolucaoManual(boolean devolucaoManual) {
		this.devolucaoManual = devolucaoManual;
	}

	public List<SituacaoDevolucao> getListaSituacaoDevolucao() {
		return listaSituacaoDevolucao;
	}

	public void setListaSituacaoDevolucao(List<SituacaoDevolucao> listaSituacaoDevolucao) {
		this.listaSituacaoDevolucao = listaSituacaoDevolucao;
	}

	public SituacaoDevolucao getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public Date getDataRequerimentoAte() {
		return dataRequerimentoAte;
	}

	public void setDataRequerimentoAte(Date dataRequerimentoAte) {
		this.dataRequerimentoAte = dataRequerimentoAte;
	}

	public Date getDataRequerimentoDesde() {
		return dataRequerimentoDesde;
	}

	public void setDataRequerimentoDesde(Date dataRequerimentoDesde) {
		this.dataRequerimentoDesde = dataRequerimentoDesde;
	}

	public List<DevolucaoAntigoDTO> getListaDevolucaoAntigoDTO() {
		return listaDevolucaoAntigoDTO;
	}

	public void setListaDevolucaoAntigoDTO(List<DevolucaoAntigoDTO> listaDevolucaoAntigoDTO) {
		this.listaDevolucaoAntigoDTO = listaDevolucaoAntigoDTO;
	}

	public List<DevolucaoAntigoDTO> getListaDevolucaoAntigoDTOSelecionados() {
		return listaDevolucaoAntigoDTOSelecionados;
	}

	public void setListaDevolucaoAntigoDTOSelecionados(List<DevolucaoAntigoDTO> listaDevolucaoAntigoDTOSelecionados) {
		this.listaDevolucaoAntigoDTOSelecionados = listaDevolucaoAntigoDTOSelecionados;
	}
}
