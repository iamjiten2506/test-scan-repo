package br.com.bbprevidencia.devolucao.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class AnexoDTO {

	private String nome;
	private String extensao;
	private String base64;

}