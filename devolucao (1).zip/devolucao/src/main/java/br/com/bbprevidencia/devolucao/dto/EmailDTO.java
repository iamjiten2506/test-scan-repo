package br.com.bbprevidencia.devolucao.dto;

import java.util.List;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class EmailDTO {

	private String remetente;
	private String destinatario;
	private String assunto;
	private String mensagem;
	private List<AnexoDTO> anexos;

}
