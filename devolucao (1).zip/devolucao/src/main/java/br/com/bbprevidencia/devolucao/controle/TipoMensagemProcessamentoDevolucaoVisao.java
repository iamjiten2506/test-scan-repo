package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.TipoMensagemProcessoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.TipoMensagemProcessoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter os Tipos de Mensagens de processamento
 * 
 * @author  BBPF0152 - Thiago de Castro Xavier
 * @since 03/02/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("tipoMensagemProcessamentoDevolucaoVisao")
public class TipoMensagemProcessamentoDevolucaoVisao {

	private static String FW_TIPO_MSG_PROC_DEV = "/paginas/tipoMensagemProcessamentoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private TipoMensagemProcessoDevolucaoBO tipoMensagemProcessoDevolucaoBO;

	private List<TipoMensagemProcessoDevolucao> listaTipoMensagemProcessoDevolucao;

	private List<TipoMensagemProcessoDevolucao> listaFiltrada;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página dos tipos de mensagens de processamento
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 03/02/2017
	 * @return {@link String}
	 */
	public String inciciarTipoMensagemProcessamentoDevolucao() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		this.listarStatus = true;

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("tipoMensagemProcessamentoDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.listarStatus = true;

		this.listaTipoMensagemProcessoDevolucao = null;

		this.listaTipoMensagemProcessoDevolucao = new ArrayList<TipoMensagemProcessoDevolucao>(tipoMensagemProcessoDevolucaoBO.listarTodos());

		return FW_TIPO_MSG_PROC_DEV;
	}

	public TipoMensagemProcessoDevolucaoBO getTipoMensagemProcessoDevolucaoBO() {
		return tipoMensagemProcessoDevolucaoBO;
	}

	public void setTipoMensagemProcessoDevolucaoBO(TipoMensagemProcessoDevolucaoBO tipoMensagemProcessoDevolucaoBO) {
		this.tipoMensagemProcessoDevolucaoBO = tipoMensagemProcessoDevolucaoBO;
	}

	public List<TipoMensagemProcessoDevolucao> getListaTipoMensagemProcessoDevolucao() {
		return listaTipoMensagemProcessoDevolucao;
	}

	public void setListaTipoMensagemProcessoDevolucao(List<TipoMensagemProcessoDevolucao> listaTipoMensagemProcessoDevolucao) {
		this.listaTipoMensagemProcessoDevolucao = listaTipoMensagemProcessoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public static String getFwTipoMsgProcDev() {
		return FW_TIPO_MSG_PROC_DEV;
	}

	public static void setFwTipoMsgProcDev(String fwTipoMsgProcDev) {
		FW_TIPO_MSG_PROC_DEV = fwTipoMsgProcDev;
	}

	public List<TipoMensagemProcessoDevolucao> getListaFiltrada() {
		return listaFiltrada;
	}

	public void setListaFiltrada(List<TipoMensagemProcessoDevolucao> listaFiltrada) {
		this.listaFiltrada = listaFiltrada;
	}

}
