package br.com.bbprevidencia.devolucao.dto;

public class RelatorioConclusaoPortabilidadeDTO {

	/* Dados do participante*/
	private String nomeParticipante;

	private String sexoParticipante;

	private String cpfParticipante;

	private String matriculaParticipante;

	private String logradouroParticipante;

	private String numeroLogradouroParticipante;

	private String complementoParticipante;

	private String bairroParticipante;

	private String cidadeParticipante;

	private String ufParticipante;

	private String cepParticipante;

	/* Dados do Entidade Origem*/
	private String nomeCurtoEntidadeOrigem;

	private String nomeLongoEntidadeOrigem;

	private String planoGuardaChuvaOrigem;

	private String dataAdesaoOrigem;

	private String partePlanoOrigem;

	private String tipoPlanoOrigem;

	private String tipoRegimeTributacaoOrigem;

	private String tipoFundo;

	private String cnpjOrigem;

	private String cnpbOrigem;

	private String logradouroOrigem;

	private String numeroLogradouroOrigem;

	private String complementoOrigem;

	private String bairroOrigem;

	private String cidadeOrigem;

	private String ufOrigem;

	private String cepOrigem;

	/* Dados do Entidade Destino*/
	private String nomeCurtoEntidadeDestino;

	private String nomeLongoEntidadeDestino;

	private String planoGuardaChuvaDestino;

	private String tipoPlanoDestino;

	private String tipoRegimeTributacaoDestino;

	private String dataAdesaoDestino;

	private String cnpjDestino;

	private String logradouroDestino;

	private String numeroLogradouroDestino;

	private String complementoDestino;

	private String bairroDestino;

	private String cidadeDestino;

	private String ufDestino;

	private String cepDestino;

	private String codigoBancoDestino;

	private String nomeBancoDestino;

	private String codigoAgenciaBancariaDestino;

	private String nomeAgenciaBancariaDestino;

	private String contaCorrenteDestino;

	private String matriculaDestino;

	private String codigoOrgaoDestino;

	/* Dados dos Valores*/

	private String valorPagoPortabilidade;

	private String dataPagamento;

	private String dataSolicitacaoPortabilidade;

	private String codigoAprovPlanoOrigemOrgaoRegulador;

	private String valorEmprestimo;

	private String valorIrEmprestimo;

	private String valorLiquidoPortavel;

	/* Título do Relatório */

	private String tituloRelatorio;

	/*Getters and Setters*/

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getCpfParticipante() {
		return cpfParticipante;
	}

	public void setCpfParticipante(String cpfParticipante) {
		this.cpfParticipante = cpfParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getLogradouroParticipante() {
		return logradouroParticipante;
	}

	public void setLogradouroParticipante(String logradouroParticipante) {
		this.logradouroParticipante = logradouroParticipante;
	}

	public String getNumeroLogradouroParticipante() {
		return numeroLogradouroParticipante;
	}

	public void setNumeroLogradouroParticipante(String numeroLogradouroParticipante) {
		this.numeroLogradouroParticipante = numeroLogradouroParticipante;
	}

	public String getComplementoParticipante() {
		return complementoParticipante;
	}

	public void setComplementoParticipante(String complementoParticipante) {
		this.complementoParticipante = complementoParticipante;
	}

	public String getBairroParticipante() {
		return bairroParticipante;
	}

	public void setBairroParticipante(String bairroParticipante) {
		this.bairroParticipante = bairroParticipante;
	}

	public String getCidadeParticipante() {
		return cidadeParticipante;
	}

	public void setCidadeParticipante(String cidadeParticipante) {
		this.cidadeParticipante = cidadeParticipante;
	}

	public String getUfParticipante() {
		return ufParticipante;
	}

	public void setUfParticipante(String ufParticipante) {
		this.ufParticipante = ufParticipante;
	}

	public String getCepParticipante() {
		return cepParticipante;
	}

	public void setCepParticipante(String cepParticipante) {
		this.cepParticipante = cepParticipante;
	}

	public String getNomeCurtoEntidadeOrigem() {
		return nomeCurtoEntidadeOrigem;
	}

	public void setNomeCurtoEntidadeOrigem(String nomeCurtoEntidadeOrigem) {
		this.nomeCurtoEntidadeOrigem = nomeCurtoEntidadeOrigem;
	}

	public String getNomeLongoEntidadeOrigem() {
		return nomeLongoEntidadeOrigem;
	}

	public void setNomeLongoEntidadeOrigem(String nomeLongoEntidadeOrigem) {
		this.nomeLongoEntidadeOrigem = nomeLongoEntidadeOrigem;
	}

	public String getPlanoGuardaChuvaOrigem() {
		return planoGuardaChuvaOrigem;
	}

	public void setPlanoGuardaChuvaOrigem(String planoGuardaChuvaOrigem) {
		this.planoGuardaChuvaOrigem = planoGuardaChuvaOrigem;
	}

	public String getDataAdesaoOrigem() {
		return dataAdesaoOrigem;
	}

	public void setDataAdesaoOrigem(String dataAdesaoOrigem) {
		this.dataAdesaoOrigem = dataAdesaoOrigem;
	}

	public String getPartePlanoOrigem() {
		return partePlanoOrigem;
	}

	public void setPartePlanoOrigem(String partePlanoOrigem) {
		this.partePlanoOrigem = partePlanoOrigem;
	}

	public String getTipoPlanoOrigem() {
		return tipoPlanoOrigem;
	}

	public void setTipoPlanoOrigem(String tipoPlanoOrigem) {
		this.tipoPlanoOrigem = tipoPlanoOrigem;
	}

	public String getTipoRegimeTributacaoOrigem() {
		return tipoRegimeTributacaoOrigem;
	}

	public void setTipoRegimeTributacaoOrigem(String tipoRegimeTributacaoOrigem) {
		this.tipoRegimeTributacaoOrigem = tipoRegimeTributacaoOrigem;
	}

	public String getTipoFundo() {
		return tipoFundo;
	}

	public void setTipoFundo(String tipoFundo) {
		this.tipoFundo = tipoFundo;
	}

	public String getCnpjOrigem() {
		return cnpjOrigem;
	}

	public void setCnpjOrigem(String cnpjOrigem) {
		this.cnpjOrigem = cnpjOrigem;
	}

	public String getCnpbOrigem() {
		return cnpbOrigem;
	}

	public void setCnpbOrigem(String cnpbOrigem) {
		this.cnpbOrigem = cnpbOrigem;
	}

	public String getLogradouroOrigem() {
		return logradouroOrigem;
	}

	public void setLogradouroOrigem(String logradouroOrigem) {
		this.logradouroOrigem = logradouroOrigem;
	}

	public String getNumeroLogradouroOrigem() {
		return numeroLogradouroOrigem;
	}

	public void setNumeroLogradouroOrigem(String numeroLogradouroOrigem) {
		this.numeroLogradouroOrigem = numeroLogradouroOrigem;
	}

	public String getComplementoOrigem() {
		return complementoOrigem;
	}

	public void setComplementoOrigem(String complementoOrigem) {
		this.complementoOrigem = complementoOrigem;
	}

	public String getBairroOrigem() {
		return bairroOrigem;
	}

	public void setBairroOrigem(String bairroOrigem) {
		this.bairroOrigem = bairroOrigem;
	}

	public String getCidadeOrigem() {
		return cidadeOrigem;
	}

	public void setCidadeOrigem(String cidadeOrigem) {
		this.cidadeOrigem = cidadeOrigem;
	}

	public String getUfOrigem() {
		return ufOrigem;
	}

	public void setUfOrigem(String ufOrigem) {
		this.ufOrigem = ufOrigem;
	}

	public String getCepOrigem() {
		return cepOrigem;
	}

	public void setCepOrigem(String cepOrigem) {
		this.cepOrigem = cepOrigem;
	}

	public String getNomeCurtoEntidadeDestino() {
		return nomeCurtoEntidadeDestino;
	}

	public void setNomeCurtoEntidadeDestino(String nomeCurtoEntidadeDestino) {
		this.nomeCurtoEntidadeDestino = nomeCurtoEntidadeDestino;
	}

	public String getNomeLongoEntidadeDestino() {
		return nomeLongoEntidadeDestino;
	}

	public void setNomeLongoEntidadeDestino(String nomeLongoEntidadeDestino) {
		this.nomeLongoEntidadeDestino = nomeLongoEntidadeDestino;
	}

	public String getPlanoGuardaChuvaDestino() {
		return planoGuardaChuvaDestino;
	}

	public void setPlanoGuardaChuvaDestino(String planoGuardaChuvaDestino) {
		this.planoGuardaChuvaDestino = planoGuardaChuvaDestino;
	}

	public String getTipoPlanoDestino() {
		return tipoPlanoDestino;
	}

	public void setTipoPlanoDestino(String tipoPlanoDestino) {
		this.tipoPlanoDestino = tipoPlanoDestino;
	}

	public String getTipoRegimeTributacaoDestino() {
		return tipoRegimeTributacaoDestino;
	}

	public void setTipoRegimeTributacaoDestino(String tipoRegimeTributacaoDestino) {
		this.tipoRegimeTributacaoDestino = tipoRegimeTributacaoDestino;
	}

	public String getDataAdesaoDestino() {
		return dataAdesaoDestino;
	}

	public void setDataAdesaoDestino(String dataAdesaoDestino) {
		this.dataAdesaoDestino = dataAdesaoDestino;
	}

	public String getCnpjDestino() {
		return cnpjDestino;
	}

	public void setCnpjDestino(String cnpjDestino) {
		this.cnpjDestino = cnpjDestino;
	}

	public String getLogradouroDestino() {
		return logradouroDestino;
	}

	public void setLogradouroDestino(String logradouroDestino) {
		this.logradouroDestino = logradouroDestino;
	}

	public String getNumeroLogradouroDestino() {
		return numeroLogradouroDestino;
	}

	public void setNumeroLogradouroDestino(String numeroLogradouroDestino) {
		this.numeroLogradouroDestino = numeroLogradouroDestino;
	}

	public String getComplementoDestino() {
		return complementoDestino;
	}

	public void setComplementoDestino(String complementoDestino) {
		this.complementoDestino = complementoDestino;
	}

	public String getBairroDestino() {
		return bairroDestino;
	}

	public void setBairroDestino(String bairroDestino) {
		this.bairroDestino = bairroDestino;
	}

	public String getCidadeDestino() {
		return cidadeDestino;
	}

	public void setCidadeDestino(String cidadeDestino) {
		this.cidadeDestino = cidadeDestino;
	}

	public String getUfDestino() {
		return ufDestino;
	}

	public void setUfDestino(String ufDestino) {
		this.ufDestino = ufDestino;
	}

	public String getCepDestino() {
		return cepDestino;
	}

	public void setCepDestino(String cepDestino) {
		this.cepDestino = cepDestino;
	}

	public String getContaCorrenteDestino() {
		return contaCorrenteDestino;
	}

	public void setContaCorrenteDestino(String contaCorrenteDestino) {
		this.contaCorrenteDestino = contaCorrenteDestino;
	}

	public String getValorPagoPortabilidade() {
		return valorPagoPortabilidade;
	}

	public void setValorPagoPortabilidade(String valorPagoPortabilidade) {
		this.valorPagoPortabilidade = valorPagoPortabilidade;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getSexoParticipante() {
		return sexoParticipante;
	}

	public void setSexoParticipante(String sexoParticipante) {
		this.sexoParticipante = sexoParticipante;
	}

	public String getCodigoBancoDestino() {
		return codigoBancoDestino;
	}

	public void setCodigoBancoDestino(String codigoBancoDestino) {
		this.codigoBancoDestino = codigoBancoDestino;
	}

	public String getNomeBancoDestino() {
		return nomeBancoDestino;
	}

	public void setNomeBancoDestino(String nomeBancoDestino) {
		this.nomeBancoDestino = nomeBancoDestino;
	}

	public String getCodigoAgenciaBancariaDestino() {
		return codigoAgenciaBancariaDestino;
	}

	public void setCodigoAgenciaBancariaDestino(String codigoAgenciaBancariaDestino) {
		this.codigoAgenciaBancariaDestino = codigoAgenciaBancariaDestino;
	}

	public String getNomeAgenciaBancariaDestino() {
		return nomeAgenciaBancariaDestino;
	}

	public void setNomeAgenciaBancariaDestino(String nomeAgenciaBancariaDestino) {
		this.nomeAgenciaBancariaDestino = nomeAgenciaBancariaDestino;
	}

	public String getMatriculaDestino() {
		return matriculaDestino;
	}

	public void setMatriculaDestino(String matriculaDestino) {
		this.matriculaDestino = matriculaDestino;
	}

	public String getCodigoOrgaoDestino() {
		return codigoOrgaoDestino;
	}

	public void setCodigoOrgaoDestino(String codigoOrgaoDestino) {
		this.codigoOrgaoDestino = codigoOrgaoDestino;
	}

	public String getDataSolicitacaoPortabilidade() {
		return dataSolicitacaoPortabilidade;
	}

	public void setDataSolicitacaoPortabilidade(String dataSolicitacaoPortabilidade) {
		this.dataSolicitacaoPortabilidade = dataSolicitacaoPortabilidade;
	}

	public String getCodigoAprovPlanoOrigemOrgaoRegulador() {
		return codigoAprovPlanoOrigemOrgaoRegulador;
	}

	public void setCodigoAprovPlanoOrigemOrgaoRegulador(String codigoAprovPlanoOrigemOrgaoRegulador) {
		this.codigoAprovPlanoOrigemOrgaoRegulador = codigoAprovPlanoOrigemOrgaoRegulador;
	}

	public String getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(String valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public String getValorLiquidoPortavel() {
		return valorLiquidoPortavel;
	}

	public void setValorLiquidoPortavel(String valorLiquidoPortavel) {
		this.valorLiquidoPortavel = valorLiquidoPortavel;
	}

	public String getTituloRelatorio() {
		return tituloRelatorio;
	}

	public void setTituloRelatorio(String tituloRelatorio) {
		this.tituloRelatorio = tituloRelatorio;
	}

	public String getValorIrEmprestimo() {
		return valorIrEmprestimo;
	}

	public void setValorIrEmprestimo(String valorIrEmprestimo) {
		this.valorIrEmprestimo = valorIrEmprestimo;
	}

}
