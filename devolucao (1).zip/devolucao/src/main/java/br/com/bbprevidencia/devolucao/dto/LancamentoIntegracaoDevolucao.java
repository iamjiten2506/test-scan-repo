package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.folha.dto.Consignatario;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;

/**
 * Classe de persistência para tabela LAN_INT_DEV.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * 
 */
@Entity
@Table(name = "LAN_INT_DEV", schema = "OWN_DCR")
@NamedQuery(name = "LancamentoIntegracaoDevolucao.findAll", query = "SELECT q FROM LancamentoIntegracaoDevolucao q")
public class LancamentoIntegracaoDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "LAN_INT_DEV_GER", sequenceName = "S_LID_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LAN_INT_DEV_GER")
	@Column(name = "NUM_SEQ_LAN_INT_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CRO_DEV")
	private CronogramaDevolucao cronogramaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPER_INT")
	private OperacaoInterna operacaoInterna;

	@Column(name = "IND_TIP_INT_DEV")
	private String indicadorTipoIntegracaoDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PERFIL_INVEST")
	private PerfilInvestimento perfilInvestimento;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RECEBEDOR")
	private Recebedor recebedor;

	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "COD_PESSOA"), @JoinColumn(name = "COD_AREA_ATUA") })
	private AtuacaoPessoa atuacaoPessoa;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_MOV_INT")
	private Date dataMovimentoIntegracao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV")
	private RubricaDevolucao rubricaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_CONSIGNATARIO")
	private Consignatario consignatario;

	@Column(name = "VAL_INT")
	private Double valorIntegracao;

	@Column(name = "COD_SEQ_MOV_LOTE")
	private long codigoSequencialMovimentoLote;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private boolean lancamentoIntegracaoInternaPlanos;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PAR_PLA_ENT_DEST")
	private ParticipantePlano participantePlanoDestino;

	public LancamentoIntegracaoDevolucao() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LancamentoIntegracaoDevolucao(CronogramaDevolucao cronogramaDevolucao, Devolucao devolucao, OperacaoInterna operacaoInterna, String indicadorTipoIntegracaoDevolucao,
			PerfilInvestimento perfilInvestimento, Recebedor recebedor, AtuacaoPessoa atuacaoPessoa, Date dataMovimentoIntegracao, RubricaDevolucao rubricaDevolucao, Consignatario consignatario,
			Double valorIntegracao, Date dataInclusao, String nomeUsuarioInclusao, long codigoSequencialMovimentoLote) {
		super();
		this.cronogramaDevolucao = cronogramaDevolucao;
		this.devolucao = devolucao;
		this.operacaoInterna = operacaoInterna;
		this.indicadorTipoIntegracaoDevolucao = indicadorTipoIntegracaoDevolucao;
		this.perfilInvestimento = perfilInvestimento;
		this.recebedor = recebedor;
		this.atuacaoPessoa = atuacaoPessoa;
		this.dataMovimentoIntegracao = dataMovimentoIntegracao;
		this.rubricaDevolucao = rubricaDevolucao;
		this.consignatario = consignatario;
		this.valorIntegracao = valorIntegracao;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
		this.codigoSequencialMovimentoLote = codigoSequencialMovimentoLote;
	}

	public LancamentoIntegracaoDevolucao(CronogramaDevolucao cronogramaDevolucao, Devolucao devolucao, OperacaoInterna operacaoInterna, String indicadorTipoIntegracaoDevolucao,
			PerfilInvestimento perfilInvestimento, Recebedor recebedor, AtuacaoPessoa atuacaoPessoa, Date dataMovimentoIntegracao, RubricaDevolucao rubricaDevolucao, Consignatario consignatario,
			Double valorIntegracao, Date dataInclusao, String nomeUsuarioInclusao, long codigoSequencialMovimentoLote, ParticipantePlano participantePlano) {
		super();
		this.cronogramaDevolucao = cronogramaDevolucao;
		this.devolucao = devolucao;
		this.operacaoInterna = operacaoInterna;
		this.indicadorTipoIntegracaoDevolucao = indicadorTipoIntegracaoDevolucao;
		this.perfilInvestimento = perfilInvestimento;
		this.recebedor = recebedor;
		this.atuacaoPessoa = atuacaoPessoa;
		this.dataMovimentoIntegracao = dataMovimentoIntegracao;
		this.rubricaDevolucao = rubricaDevolucao;
		this.consignatario = consignatario;
		this.valorIntegracao = valorIntegracao;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
		this.codigoSequencialMovimentoLote = codigoSequencialMovimentoLote;
		this.participantePlanoDestino = participantePlano;
	}

	public LancamentoIntegracaoDevolucao(CronogramaDevolucao cronogramaDevolucao, Devolucao devolucao, OperacaoInterna operacaoInterna, String indicadorTipoIntegracaoDevolucao,
			PerfilInvestimento perfilInvestimento, Recebedor recebedor, AtuacaoPessoa atuacaoPessoa, Date dataMovimentoIntegracao, RubricaDevolucao rubricaDevolucao, Consignatario consignatario,
			Double valorIntegracao, Date dataInclusao, String nomeUsuarioInclusao, long codigoSequencialMovimentoLote, boolean lancamentoIntegracaoInternaPlanos) {
		super();
		this.cronogramaDevolucao = cronogramaDevolucao;
		this.devolucao = devolucao;
		this.operacaoInterna = operacaoInterna;
		this.indicadorTipoIntegracaoDevolucao = indicadorTipoIntegracaoDevolucao;
		this.perfilInvestimento = perfilInvestimento;
		this.recebedor = recebedor;
		this.atuacaoPessoa = atuacaoPessoa;
		this.dataMovimentoIntegracao = dataMovimentoIntegracao;
		this.rubricaDevolucao = rubricaDevolucao;
		this.consignatario = consignatario;
		this.valorIntegracao = valorIntegracao;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
		this.codigoSequencialMovimentoLote = codigoSequencialMovimentoLote;
		this.lancamentoIntegracaoInternaPlanos = lancamentoIntegracaoInternaPlanos;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public OperacaoInterna getOperacaoInterna() {
		return operacaoInterna;
	}

	public void setOperacaoInterna(OperacaoInterna operacaoInterna) {
		this.operacaoInterna = operacaoInterna;
	}

	public String getIndicadorTipoIntegracaoDevolucao() {
		return indicadorTipoIntegracaoDevolucao;
	}

	public void setIndicadorTipoIntegracaoDevolucao(String indicadorTipoIntegracaoDevolucao) {
		this.indicadorTipoIntegracaoDevolucao = indicadorTipoIntegracaoDevolucao;
	}

	public PerfilInvestimento getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(PerfilInvestimento perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public Date getDataMovimentoIntegracao() {
		return dataMovimentoIntegracao;
	}

	public void setDataMovimentoIntegracao(Date dataMovimentoIntegracao) {
		this.dataMovimentoIntegracao = dataMovimentoIntegracao;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	public Consignatario getConsignatario() {
		return consignatario;
	}

	public void setConsignatario(Consignatario consignatario) {
		this.consignatario = consignatario;
	}

	public Double getValorIntegracao() {
		return valorIntegracao;
	}

	public void setValorIntegracao(Double valorIntegracao) {
		this.valorIntegracao = valorIntegracao;
	}

	public long getCodigoSequencialMovimentoLote() {
		return codigoSequencialMovimentoLote;
	}

	public void setCodigoSequencialMovimentoLote(long codigoSequencialMovimentoLote) {
		this.codigoSequencialMovimentoLote = codigoSequencialMovimentoLote;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public boolean isLancamentoIntegracaoInternaPlanos() {
		return lancamentoIntegracaoInternaPlanos;
	}

	public void setLancamentoIntegracaoInternaPlanos(boolean lancamentoIntegracaoInternaPlanos) {
		this.lancamentoIntegracaoInternaPlanos = lancamentoIntegracaoInternaPlanos;
	}

	public ParticipantePlano getParticipantePlanoDestino() {
		return participantePlanoDestino;
	}

	public void setParticipantePlanoDestino(ParticipantePlano participantePlanoDestino) {
		this.participantePlanoDestino = participantePlanoDestino;
	}

	public boolean isParticipantePlanoDestinoPreenchido() {
		return this.participantePlanoDestino != null && this.participantePlanoDestino.getCodigo() > 0;
	}

}
