package br.com.bbprevidencia.devolucao.dto;

public class ProcessoRetencaoDTO {

	private String nomePlano;

	private String nomeParticipante;

	private String matriculaParticipante;

	private String situacaoPlano;

	private String participanteFundador;

	private String dataAdmisaoEmpresa;

	private String dataInscricaoPlano;

	private String dataDesligamentoEmpresa;

	private String tipoTributacao;

	private String participanteElegivel;

	private String perdaPartePatronal;

	private String passivoIntegralizar;

	private Double saldoResgatavel;

	private String tipoDevolucao;

	private String telefones;

	private Integer idParticipante;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getSituacaoPlano() {
		return situacaoPlano;
	}

	public void setSituacaoPlano(String situacaoPlano) {
		this.situacaoPlano = situacaoPlano;
	}

	public String getParticipanteFundador() {
		return participanteFundador;
	}

	public void setParticipanteFundador(String participanteFundador) {
		this.participanteFundador = participanteFundador;
	}

	public String getDataAdmisaoEmpresa() {
		return dataAdmisaoEmpresa;
	}

	public void setDataAdmisaoEmpresa(String dataAdmisaoEmpresa) {
		this.dataAdmisaoEmpresa = dataAdmisaoEmpresa;
	}

	public String getDataInscricaoPlano() {
		return dataInscricaoPlano;
	}

	public void setDataInscricaoPlano(String dataInscricaoPlano) {
		this.dataInscricaoPlano = dataInscricaoPlano;
	}

	public String getDataDesligamentoEmpresa() {
		return dataDesligamentoEmpresa;
	}

	public void setDataDesligamentoEmpresa(String dataDesligamentoEmpresa) {
		this.dataDesligamentoEmpresa = dataDesligamentoEmpresa;
	}

	public String getTipoTributacao() {
		return tipoTributacao;
	}

	public void setTipoTributacao(String tipoTributacao) {
		this.tipoTributacao = tipoTributacao;
	}

	public String getParticipanteElegivel() {
		return participanteElegivel;
	}

	public void setParticipanteElegivel(String participanteElegivel) {
		this.participanteElegivel = participanteElegivel;
	}

	public String getPerdaPartePatronal() {
		return perdaPartePatronal;
	}

	public void setPerdaPartePatronal(String perdaPartePatronal) {
		this.perdaPartePatronal = perdaPartePatronal;
	}

	public String getPassivoIntegralizar() {
		return passivoIntegralizar;
	}

	public void setPassivoIntegralizar(String passivoIntegralizar) {
		this.passivoIntegralizar = passivoIntegralizar;
	}

	public Double getSaldoResgatavel() {
		return saldoResgatavel;
	}

	public void setSaldoResgatavel(Double saldoResgatavel) {
		this.saldoResgatavel = saldoResgatavel;
	}

	public String getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(String tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public String getTelefones() {
		return telefones;
	}

	public void setTelefones(String telefones) {
		this.telefones = telefones;
	}

	public Integer getIdParticipante() {
		return idParticipante;
	}

	public void setIdParticipante(Integer idParticipante) {
		this.idParticipante = idParticipante;
	}

}
