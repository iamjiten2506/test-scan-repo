package br.com.bbprevidencia.devolucao.controle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.MimetypesFileTypeMap;
import javax.faces.component.UIOutput;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.Criptografia;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ExtratoPrevBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoGuardaChuvaBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.ExtratoPrev;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.cotas.bo.ValorCotaPlanoBO;
import br.com.bbprevidencia.cotas.dto.ValorCotaPlano;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.GerenciaRelatorioUtil;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.interno.bo.ArquivoAnexoBO;
import br.com.bbprevidencia.interno.bo.ArquivoAnexoItemBO;
import br.com.bbprevidencia.interno.dto.ArquivoAnexo;
import br.com.bbprevidencia.interno.dto.ArquivoAnexoItem;
import br.com.bbprevidencia.seguranca.bo.ParmSistemBO;
import br.com.bbprevidencia.seguranca.dto.ParmSistem;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0170 - Magson
 * @since   04/09/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("emissaoExtratoPrevidenciarioVisao")
public class EmissaoExtratoPrevidenciarioVisao {

	private static String FW_PROCESSO_EXTRATO_PREVIDENCIARIO = "/paginas/emissaoExtratoPrevidenciario.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(EmissaoExtratoPrevidenciarioVisao.class);

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoGuardaChuvaBO planoGuardaChuvaBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private ExtratoPrevBO extratoPrevBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ValorCotaPlanoBO valorCotaPlanoBO;

	@Autowired
	private ParmSistemBO parmSistemBO;

	@Autowired
	private AmbienteServico ambienteServico;

	@Autowired
	private ArquivoAnexoBO arquivoAnexoBO;

	@Autowired
	private ArquivoAnexoItemBO arquivoAnexoItemBO;

	private ParmSistem parmSistem;
	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean listarStatus;
	private Participante participante;
	private PlanoPrevidencia planoPrevidencia;
	private EntidadeParticipante entidadeParticipante;
	private ExtratoPrev extratoPrev;
	private ValorCotaPlano valorCotaPlano;
	private Date dataCota;
	private Date dataAtual;
	private List<Participante> listaParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private String url;
	private boolean btImprimir;
	private ArquivoAnexo arquivoAnexo;
	private StreamedContent arquivoAnexoStreamed;
	private List<StreamedContent> listaArquivoAnexo;

	@Value("#{propriedades['sistema.caminhoSalvarExtrato']}")
	private String caminhoSalvarArquivos;

	StreamedContent arquivoRecuperado;

	File file;

	FileInputStream streamRetorno;

	String nomeArquivo;

	/**
	 * Método para iniciar a tela Emissão Extrato Previdenciário.
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.url = null;
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.extratoPrev = new ExtratoPrev();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("emissaoExtratoPrevidenciario");
		} else {
			this.possuiAcessoTotal = false;
		}

		limpar();

		this.listaEntidadeParticipante = entidadeParticipanteBO.listarEntidadeParticipante();
		return FW_PROCESSO_EXTRATO_PREVIDENCIARIO;
	}

	/**
	 * Método para listar os planos por patrocinadora.
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 * @return {@link String}
	 * @param {@link AjaxBehaviorEvent}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {
		if (this.entidadeParticipante == null) {
			this.setListaPlanoPrevidencia(new ArrayList<PlanoPrevidencia>());
		} else {
			try {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante()));
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}
		return FW_PROCESSO_EXTRATO_PREVIDENCIARIO;
	}

	/**
	 * Método para carregar um plano de previdencia. 
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 * @param {@link AjaxBehaviorEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Método para carregar um participante.
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 * @param {@link AjaxBehaviorEvent}
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (!UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("participante", getParticipante());
		} else {
			setParticipante(new Participante());
		}

		this.valorCotaPlano = this.valorCotaPlanoBO.pesquisarCotaParticipantePlano(this.getDataAtual(), participantePlanoBO.consultparPorParticipanteEPlano(this.participante, this.planoPrevidencia));
		this.dataCota = this.valorCotaPlano.getChavePrimaria().getDataPosicaoCota();

	}

	/**
	 * Método para listar os participante por nome que estaja na situação para emitir extrato Previdenciário.
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 * @param {@link String}
	 * @return {@link List<Participante>}
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		List<Participante> listaParticipante = new ArrayList<Participante>();
		if (this.planoPrevidencia.getCodigo() != null) {
			listaParticipante = this.participanteBO.listarParticipantesPorNomePlanoENomeParticipanteExtrato(nome, this.getPlanoPrevidencia());
		} else {
			Mensagens.addMsgErro("Favor selecione um plano.");
		}
		return listaParticipante;
	}

	/**
	 * Método para limpar os obejtos. 
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 */
	public void limpar() {
		this.listarStatus = true;
		this.entidadeParticipante = new EntidadeParticipante();
		this.planoPrevidencia = new PlanoPrevidencia();
		this.participante = new Participante();
		this.dataCota = null;
		this.extratoPrev = new ExtratoPrev();
	}

	/**
	 * Método para para salvar um extratoPrev, e executar a função extrato. 
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 * @return {@link String}
	 */
	public String emitirRelatorio() {
		this.url = null;
		this.parmSistem = this.parmSistemBO.retornoParmSistem();
		String resultado = "";
		ExtratoPrev extratoExcutarFuncao = new ExtratoPrev();
		boolean insercao = false;
		if (this.planoPrevidencia.getCodigo() == null) {
			Mensagens.addMsgErro("Plano: Campo obrigatório.");
			insercao = true;
		}
		if (this.participante.getCodigo() == null) {
			Mensagens.addMsgErro("Participante: Campo obrigatório.");
			insercao = true;
		}
		if (this.dataCota == null) {
			Mensagens.addMsgErro("Data da Cota: Campo obrigatório.");
			insercao = true;
		}

		if (insercao) {
			return "";
		} else {
			this.extratoPrev.setParticipante(this.participante);
			this.extratoPrev.setPlanoGuardaChuva(this.planoPrevidencia.getPlanoGuardaChuva());
			this.extratoPrev.setDatEmissaoExtrato(this.getDataAtual());
			this.extratoPrev.setDatBase(this.dataCota);
			this.extratoPrev.setDatCota(this.dataCota);
			this.extratoPrev.setDatIncl(this.getDataAtual());
			this.extratoPrev.setNomUsuIncl(this.loginTemporariaDTO.getIdentificacaoUsuario());
			this.extratoPrev.setIndValido("N");
			this.extratoPrev.setIndAutomatico("N");
			this.extratoPrev.setIndElegivelBenef("N");
			//this.extratoPrev.setArquivoAnexo(this.arquivoAnexo);

			try {
				extratoExcutarFuncao = this.extratoPrevBO.salva(extratoPrev);
				if (extratoExcutarFuncao != null) {
					resultado = this.extratoPrevBO.executarFuncaoExtrato(extratoExcutarFuncao);
					if (StringUtils.isNotBlank(resultado)) {
						Mensagens.addMsgErro(resultado);
						log.error(resultado);
					} else {

						Mensagens.addMsgInfo("Extrato Inserido com sucesso!");
						this.setUrl("http://" + this.parmSistem.getNomSrvApl() + ":" + this.parmSistem.getNumPortSrvApl() + "/reports/rwservlet?report=SDRPR426.rep" + "&userid="
								+ this.parmSistem.getNomeUsuarioRelatoriRep() + "/" + Criptografia.descriptografar(this.parmSistem.getPassUsuarioRelatorioRep()) + "@"
								+ this.parmSistem.getNomBancoDesenv() + "&server=" + this.parmSistem.getNomServdoRelat() + "&desformat=pdf&destype=cache&p_num_seq_extrato_prev="
								+ extratoExcutarFuncao.getCodigo());
						this.listarStatus = false;

						sendPostRequest();
						preencheArquivoAnexo();
					}
				}
			} catch (Exception e) {
				throw new PrevidenciaException("Erro ao busca inserir extrato. Erro: ", e.getMessage());
			} finally {
				this.extratoPrev.setArquivoAnexo(this.arquivoAnexo);
				this.extratoPrevBO.salva(this.extratoPrev);
			}
		}
		return FW_PROCESSO_EXTRATO_PREVIDENCIARIO;
	}

	/**
	 * Método para imprimir o extrato emitido. 
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 */
	public void imprimirExtrato() throws IOException {
		File file = new File(this.getCaminhoSalvarArquivos() + this.arquivoAnexo.getListaArquivoAnexoItem().get(0).getNomeArquivoSerie());
		GerenciaRelatorioUtil.baixarArquivo(file, this.arquivoAnexo.getListaArquivoAnexoItem().get(0).getNomeArquivo());
	}

	/**
	 * Método para salva o arquivo em pdf do extrato.  
	 * @author bbpf0170 - Magson Dias
	 * @since Date 04/09/2017
	 */
	public void sendPostRequest() {
		try {
			InputStream inputStream = new URL(this.url).openStream();
			this.file = File.createTempFile("extrato_revidenciario", ".pdf");
			FileOutputStream outputStream = new FileOutputStream(this.file);

			byte[] buffer = new byte[1024];
			int length;

			while (true) {
				length = inputStream.read(buffer);
				if (length < 0) {
					break;
				}

				outputStream.write(buffer, 0, length);
				outputStream.flush();
			}

			outputStream.close();
			inputStream.close();

		} catch (MalformedURLException e) {
			log.error(e);
			throw new PrevidenciaException(e.getMessage());
		} catch (IOException e) {
			log.error(e);
			throw new PrevidenciaException(e.getMessage());
		}

	}

	/**
	 * @author  
	 * @throws FileNotFoundException 
	 * @since 03/07/2017
	 */
	public void preencheArquivoAnexo() {
		try {
			this.arquivoAnexo = new ArquivoAnexo();
			this.arquivoAnexo.setCodigoChaveOrigem("EXTR");
			this.arquivoAnexo.setCodigoUsuInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			this.arquivoAnexo.setDataInclusao(new Date());
			// itens
			ArquivoAnexoItem item = new ArquivoAnexoItem();
			item.setArquivoAnexo(this.arquivoAnexo);
			item.setCodigoUsuInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			item.setDataInclusao(new Date());
			item.setNomeArquivo("extrato_previdenciario.pdf");
			item.setDescricaoArquivo("Extrato Previdenciário");
			item.setNomeArquivoSerie(arquivoAnexoBO.geraHashArquivo(item.getNomeArquivo()) + item.getNomeArquivo().substring(item.getNomeArquivo().lastIndexOf('.')));
			this.arquivoAnexo.getListaArquivoAnexoItem().add(item);
			this.nomeArquivo = item.getNomeArquivo();
			this.arquivoAnexoBO.salvarArquivoAnexo(this.arquivoAnexo);

			this.arquivoRecuperado = new DefaultStreamedContent(new FileInputStream(this.file), new MimetypesFileTypeMap().getContentType(this.file), item.getNomeArquivo());
			List<StreamedContent> listaArquivos = new ArrayList<StreamedContent>();
			listaArquivos.add(this.arquivoRecuperado);
			this.arquivoAnexoItemBO.salvarListaArquivoAnexoItem(this.arquivoAnexo.getListaArquivoAnexoItem(), listaArquivos, this.getCaminhoSalvarArquivos());
		} catch (FileNotFoundException e) {
			throw new PrevidenciaException(e.getMessage());
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}

	public Date getDataAtual() {
		if (dataAtual == null)
			dataAtual = new Date();
		return dataAtual;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public ExtratoPrev getExtratoPrev() {
		return extratoPrev;
	}

	public void setExtratoPrev(ExtratoPrev extratoPrev) {
		this.extratoPrev = extratoPrev;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public ValorCotaPlano getValorCotaPlano() {
		return valorCotaPlano;
	}

	public void setValorCotaPlano(ValorCotaPlano valorCotaPlano) {
		this.valorCotaPlano = valorCotaPlano;
	}

	public ParmSistem getParmSistem() {
		return parmSistem;
	}

	public void setParmSistem(ParmSistem parmSistem) {
		this.parmSistem = parmSistem;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean isBtImprimir() {
		return btImprimir;
	}

	public void setBtImprimir(boolean btImprimir) {
		this.btImprimir = btImprimir;
	}

	public String getCaminhoSalvarArquivos() {
		return caminhoSalvarArquivos;
	}

	public void setCaminhoSalvarArquivos(String caminhoSalvarArquivos) {
		this.caminhoSalvarArquivos = caminhoSalvarArquivos;
	}

	public StreamedContent getArquivoRecuperado() {
		return arquivoRecuperado;
	}

	public void setArquivoRecuperado(StreamedContent arquivoRecuperado) {
		this.arquivoRecuperado = arquivoRecuperado;
	}

	public ArquivoAnexo getArquivoAnexo() {
		return arquivoAnexo;
	}

	public void setArquivoAnexo(ArquivoAnexo arquivoAnexo) {
		this.arquivoAnexo = arquivoAnexo;
	}

	public StreamedContent getArquivoAnexoStreamed() {
		return arquivoAnexoStreamed;
	}

	public void setArquivoAnexoStreamed(StreamedContent arquivoAnexoStreamed) {
		this.arquivoAnexoStreamed = arquivoAnexoStreamed;
	}

	public List<StreamedContent> getListaArquivoAnexo() {
		return listaArquivoAnexo;
	}

	public void setListaArquivoAnexo(List<StreamedContent> listaArquivoAnexo) {
		this.listaArquivoAnexo = listaArquivoAnexo;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

}
