package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   28/11/2016
 * Classe de persistência para tabela REGRA_DEVOLUCAO.
 */
@Entity
@Table(name = "REGRA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "RegraDevolucao.findAll", query = "SELECT q FROM RegraDevolucao q")
public class RegraDevolucao implements Serializable, BaseEntity, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REGRA_DEVOLUCAO_GER", sequenceName = "S_RDV_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REGRA_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_REG_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLA_VIG_DEV")
	private PlanoVigenciaDevolucao planoVigenciaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SIT_REGRA_DEV")
	private SituacaoRegraDevolucao situacaoRegraDevolucao;

	/*
	@Column(name = "NUM_MES_CAR_RES")
	private Long mesesCarenciaResgate;

	@Column(name = "NUM_MES_CAR_POR")
	private Long mesesCarenciaPortabilidade;
	 */

	@Column(name = "DAT_ENT_PRO")
	private Date dataEntradaEmProd;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "regraDevolucao", targetEntity = RegraCalculoDevolucao.class, fetch = FetchType.EAGER, orphanRemoval = true)
	private List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public PlanoVigenciaDevolucao getPlanoVigenciaDevolucao() {
		return planoVigenciaDevolucao;
	}

	public void setPlanoVigenciaDevolucao(PlanoVigenciaDevolucao planoVigenciaDevolucao) {
		this.planoVigenciaDevolucao = planoVigenciaDevolucao;
	}

	/*
	public Long getMesesCarenciaResgate() {
		return mesesCarenciaResgate;
	}

	public void setMesesCarenciaResgate(Long mesesCarenciaResgate) {
		this.mesesCarenciaResgate = mesesCarenciaResgate;
	}

	public Long getMesesCarenciaPortabilidade() {
		return mesesCarenciaPortabilidade;
	}

	public void setMesesCarenciaPortabilidade(Long mesesCarenciaPortabilidade) {
		this.mesesCarenciaPortabilidade = mesesCarenciaPortabilidade;
	}
	 */

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDataEntradaEmProd() {
		return dataEntradaEmProd;
	}

	public void setDataEntradaEmProd(Date dataEntradaEmProd) {
		this.dataEntradaEmProd = dataEntradaEmProd;
	}

	public SituacaoRegraDevolucao getSituacaoRegraDevolucao() {
		return situacaoRegraDevolucao;
	}

	public void setSituacaoRegraDevolucao(SituacaoRegraDevolucao situacaoRegraDevolucao) {
		this.situacaoRegraDevolucao = situacaoRegraDevolucao;
	}

	public List<RegraCalculoDevolucao> getListaRegraCalculoDevolucao() {
		return listaRegraCalculoDevolucao;
	}

	public void setListaRegraCalculoDevolucao(List<RegraCalculoDevolucao> listaRegraCalculoDevolucao) {
		this.listaRegraCalculoDevolucao = listaRegraCalculoDevolucao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegraDevolucao other = (RegraDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RegraDevolucao [codigo=" + codigo + ", planoVigenciaDevolucao=" + planoVigenciaDevolucao + ", situacaoRegraDevolucao=" + situacaoRegraDevolucao + ", dataEntradaEmProd="
				+ dataEntradaEmProd + ", dataAlteracao=" + dataAlteracao + ", dataInclusao=" + dataInclusao + ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao="
				+ nomeUsuarioInclusao + "]";
	}

	@Override
	public RegraDevolucao clone() throws CloneNotSupportedException {
		RegraDevolucao regraDevolucao = (RegraDevolucao) super.clone();

		regraDevolucao.setCodigo(null);
		regraDevolucao.setDataEntradaEmProd(null);

		List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

		for (RegraCalculoDevolucao regraCalculoDevolucao : regraDevolucao.getListaRegraCalculoDevolucao()) {
			//regraCalculoDevolucao.clone();
			listaRegraCalculoDevolucao.add(regraCalculoDevolucao.clone());
		}

		for (RegraCalculoDevolucao regraCalculoDevolucao : listaRegraCalculoDevolucao) {
			regraCalculoDevolucao.setCodigo(null);
			regraCalculoDevolucao.setRegraDevolucao(regraDevolucao);
		}

		regraDevolucao.setListaRegraCalculoDevolucao(listaRegraCalculoDevolucao);

		return regraDevolucao;
	}

}