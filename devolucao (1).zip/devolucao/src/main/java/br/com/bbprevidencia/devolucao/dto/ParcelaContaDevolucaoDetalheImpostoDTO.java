package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 29/12/2016 Classe de persistência para tabela PAR_CON_DEV_DET_IMP.
 */
public class ParcelaContaDevolucaoDetalheImpostoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private ParcelaContaDevolucaoDetalhe parcelaContaDevolucaoDetalhe;
	private CronogramaDevolucao cronogramaDevolucao;
	private Recebedor recebedor;
	private AtuacaoPessoa atuacaoPessoa;
	private Date dataBaseInicioIdade;
	private Date dataBaseFinalIdade;
	private Double tempo;
	private Double qtdTotalContrib;
	private Double qtdTotalJurosContrib;
	private Double qtdTotalMultaContrib;
	private Double qtdToTalCorrecaoContrib;
	private Double numeroPercentualIrrf;
	private Double valorTotalDeducaoFaixa;
	private Double valorTotalDependente;
	private Double valorTotalIsencao;
	private Double valorTotalBruto;
	private Double valorTotalIrrf;
	private Double valorTotalLiquido;
	private Double valorTotalSaldoIsento;
	private List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevolucaoDetalheImposto = new ArrayList<>();

	public ParcelaContaDevolucaoDetalheImpostoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ParcelaContaDevolucaoDetalheImpostoDTO(ParcelaContaDevolucaoDetalhe parcelaContaDevolucaoDetalhe,
			Date dataBaseInicioIdade, Date dataBaseFinalIdade, Double numeroPercentualIrrf, Double tempo) {
		super();
		this.parcelaContaDevolucaoDetalhe = parcelaContaDevolucaoDetalhe;
		this.dataBaseInicioIdade = dataBaseInicioIdade;
		this.dataBaseFinalIdade = dataBaseFinalIdade;
		this.numeroPercentualIrrf = numeroPercentualIrrf;	
		this.tempo = tempo;
	}

	public ParcelaContaDevolucaoDetalhe getParcelaContaDevolucaoDetalhe() {
		return parcelaContaDevolucaoDetalhe;
	}

	public void setParcelaContaDevolucaoDetalhe(ParcelaContaDevolucaoDetalhe parcelaContaDevolucaoDetalhe) {
		this.parcelaContaDevolucaoDetalhe = parcelaContaDevolucaoDetalhe;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public Date getDataBaseInicioIdade() {
		return dataBaseInicioIdade;
	}

	public void setDataBaseInicioIdade(Date dataBaseInicioIdade) {
		this.dataBaseInicioIdade = dataBaseInicioIdade;
	}

	public Date getDataBaseFinalIdade() {
		return dataBaseFinalIdade;
	}

	public void setDataBaseFinalIdade(Date dataBaseFinalIdade) {
		this.dataBaseFinalIdade = dataBaseFinalIdade;
	}

	public Double getQtdTotalContrib() {
		return qtdTotalContrib;
	}

	public void setQtdTotalContrib(Double qtdTotalContrib) {
		this.qtdTotalContrib = qtdTotalContrib;
	}

	public Double getQtdTotalJurosContrib() {
		return qtdTotalJurosContrib;
	}

	public void setQtdTotalJurosContrib(Double qtdTotalJurosContrib) {
		this.qtdTotalJurosContrib = qtdTotalJurosContrib;
	}

	public Double getQtdTotalMultaContrib() {
		return qtdTotalMultaContrib;
	}

	public void setQtdTotalMultaContrib(Double qtdTotalMultaContrib) {
		this.qtdTotalMultaContrib = qtdTotalMultaContrib;
	}

	public Double getQtdToTalCorrecaoContrib() {
		return qtdToTalCorrecaoContrib;
	}

	public void setQtdToTalCorrecaoContrib(Double qtdToTalCorrecaoContrib) {
		this.qtdToTalCorrecaoContrib = qtdToTalCorrecaoContrib;
	}

	public Double getNumeroPercentualIrrf() {
		return numeroPercentualIrrf;
	}

	public void setNumeroPercentualIrrf(Double numeroPercentualIrrf) {
		this.numeroPercentualIrrf = numeroPercentualIrrf;
	}

	public Double getValorTotalDeducaoFaixa() {
		return valorTotalDeducaoFaixa;
	}

	public void setValorTotalDeducaoFaixa(Double valorTotalDeducaoFaixa) {
		this.valorTotalDeducaoFaixa = valorTotalDeducaoFaixa;
	}

	public Double getValorTotalDependente() {
		return valorTotalDependente;
	}

	public void setValorTotalDependente(Double valorTotalDependente) {
		this.valorTotalDependente = valorTotalDependente;
	}

	public Double getValorTotalIsencao() {
		return valorTotalIsencao;
	}

	public void setValorTotalIsencao(Double valorTotalIsencao) {
		this.valorTotalIsencao = valorTotalIsencao;
	}

	public Double getValorTotalBruto() {
		return valorTotalBruto;
	}

	public void setValorTotalBruto(Double valorTotalBruto) {
		this.valorTotalBruto = valorTotalBruto;
	}

	public Double getValorTotalIrrf() {
		return valorTotalIrrf;
	}

	public void setValorTotalIrrf(Double valorTotalIrrf) {
		this.valorTotalIrrf = valorTotalIrrf;
	}

	public Double getValorTotalLiquido() {
		return valorTotalLiquido;
	}

	public void setValorTotalLiquido(Double valorTotalLiquido) {
		this.valorTotalLiquido = valorTotalLiquido;
	}

	public List<ParcelaContaDevolucaoDetalheImposto> getListaParcelaContaDevolucaoDetalheImposto() {
		return listaParcelaContaDevolucaoDetalheImposto;
	}

	public void setListaParcelaContaDevolucaoDetalheImposto(
			List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevolucaoDetalheImposto) {
		this.listaParcelaContaDevolucaoDetalheImposto = listaParcelaContaDevolucaoDetalheImposto;
	}

	public Double getTempo() {
		return tempo;
	}

	public void setTempo(Double tempo) {
		this.tempo = tempo;
	}

	public Double getValorTotalSaldoIsento() {
		return valorTotalSaldoIsento;
	}

	public void setValorTotalSaldoIsento(Double valorTotalSaldoIsento) {
		this.valorTotalSaldoIsento = valorTotalSaldoIsento;
	}

}