package br.com.bbprevidencia.devolucao.dto;

public class RelatorioQuantitativoDevolucaoDTO {

	private String nomePlanoGuardaChuva;
	private String mesAno;
	private Long quantidadeProcessos;

	public String getNomePlanoGuardaChuva() {
		return nomePlanoGuardaChuva;
	}

	public void setNomePlanoGuardaChuva(String nomePlanoGuardaChuva) {
		this.nomePlanoGuardaChuva = nomePlanoGuardaChuva;
	}

	public String getMesAno() {
		return mesAno;
	}

	public void setMesAno(String mesAno) {
		this.mesAno = mesAno;
	}

	public Long getQuantidadeProcessos() {
		return quantidadeProcessos;
	}

	public void setQuantidadeProcessos(Long quantidadeProcessos) {
		this.quantidadeProcessos = quantidadeProcessos;
	}

	@Override
	public String toString() {
		return "RelatorioQuantitativoDevolucaoDTO [nomePlanoGuardaChuva=" + nomePlanoGuardaChuva + ", mesAno=" + mesAno + ", quantidadeProcessos=" + quantidadeProcessos + "]";
	}

}
