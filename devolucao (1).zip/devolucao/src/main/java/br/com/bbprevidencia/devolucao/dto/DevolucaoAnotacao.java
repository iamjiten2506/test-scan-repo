package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   28/11/2016
 * Classe de persistência para tabela DEVOLUCAO_ANOTACAO.
 */
@Entity
@Table(name = "DEVOLUCAO_ANOTACAO", schema = "OWN_DCR")
@NamedQuery(name = "DevolucaoAnotacao.findAll", query = "SELECT q FROM DevolucaoAnotacao q")
public class DevolucaoAnotacao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DEVOLUCAO_ANOTACAO_GER", sequenceName = "S_DA_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DEVOLUCAO_ANOTACAO_GER")
	@Column(name = "NUM_SEQ_DEV_ANOTACAO")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ANO")
	private Date dataAnotacao;

	@Column(name = "DSC_ANO")
	private String descricaoAnotacao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public Date getDataAnotacao() {
		return dataAnotacao;
	}

	public void setDataAnotacao(Date dataAnotacao) {
		this.dataAnotacao = dataAnotacao;
	}

	public String getDescricaoAnotacao() {
		return descricaoAnotacao;
	}

	public void setDescricaoAnotacao(String descricaoAnotacao) {
		this.descricaoAnotacao = descricaoAnotacao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

}