package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   03/01/2017
 * Classe para utilização em filtragem de objetos de ParcelaContaDevolucao.
 */
public class ParcelaContaDevolucaoDataPagtoDTO implements Serializable, Comparable<ParcelaContaDevolucaoDataPagtoDTO> {

	private static final long serialVersionUID = 1L;

	private Date dataMinimaParcela;

	public ParcelaContaDevolucaoDataPagtoDTO(Date dataMinimaParcela) {
		super();
		this.dataMinimaParcela = dataMinimaParcela;
	}

	public Date getDataMinimaParcela() {
		return dataMinimaParcela;
	}

	public void setDataMinimaParcela(Date dataMinimaParcela) {
		this.dataMinimaParcela = dataMinimaParcela;
	}

	@Override
	public int compareTo(ParcelaContaDevolucaoDataPagtoDTO o) {
		if (o.getDataMinimaParcela().before(this.dataMinimaParcela)) {
			return 1;
		} else if (o.getDataMinimaParcela().after(this.dataMinimaParcela)) {
			return -1;
		} else {
			return 0;
		}
	}
}