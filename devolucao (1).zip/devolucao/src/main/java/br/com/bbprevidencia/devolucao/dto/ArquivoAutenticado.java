package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ArquivoAutenticado {

	private String nome;
	private String arquivoBase64;
	private String carimboBase64;
	private String cnCertificado;
	private String cnEmissor;
	private String hashCertificado;
	private Date dataCarimbo;

}
