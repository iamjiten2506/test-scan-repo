package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.TipoContribuicao;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
public class ContribuicaoValorizadaDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long codPartic;
	private Long codParticPlano;
	private String nomPlano;
	private Date dataDeposito;
	private Double fatorIndexado;
	private TipoContribuicao tipoContribuicao;
	private ParticipantePlano participantePlano;
	private Date dataReferencia;
	private Date dataCompetencia;
	private Long sequencialMesCompetencia;

	//Cotas Participante
	private Double qtdCotaContribuicaoPartic;
	private Double qtdCotaJurosPartic;
	private Double qtdCotaCorrecaoPartic;
	private Double qtdCotaMultaPartic;
	private Double qtdCotaTxContribPartic;

	//Cotas Patronal
	private Double qtdCotaContribuicaoEmp;
	private Double qtdCotaJurosEmp;
	private Double qtdCotaCorrecaoEmp;
	private Double qtdCotaMultaEmp;
	private Double qtdCotaTxContribEmp;

	//Cotas Patronal Participante
	private Double qtdCotaContribuicaoParticEmp;
	private Double qtdCotaJurosParticEmp;
	private Double qtdCotaCorrecaoParticEmp;
	private Double qtdCotaMultaParticEmp;
	private Double qtdCotaTxContribParticEmp;

	//Participante
	private Double vlrContribPartic;
	private Double vlrContribJurosPartic;
	private Double vlrContribCorrecaoPartic;
	private Double vlrContribMultaPartic;
	private Double vlrLiqPartic;
	private Double vlrAtualizacaoIndicePartic;
	private Double vlrAtualizadoPartic;
	private Double vlrTxContribPartic;

	//Patronal
	private Double vlrContribEmp;
	private Double vlrContribJurosEmp;
	private Double vlrContribCorrecaoEmp;
	private Double vlrContribMultaEmp;
	private Double vlrLiqEmp;
	private Double vlrAtualizacaoIndiceEmp;
	private Double vlrAtualizadoEmp;
	private Double vlrTxContrbEmp;

	//Patronal Participante
	private Double vlrContribParticEmp;
	private Double vlrContribJurosParticEmp;
	private Double vlrContribCorrecaoParticEmp;
	private Double vlrContribMultaParticEmp;
	private Double vlrLiqParticEmp;
	private Double vlrAtualizacaoIndiceParticEmp;
	private Double vlrAtualizadoParticEmp;
	private Double vlrTxContribParticEmp;

}
