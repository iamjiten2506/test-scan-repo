package br.com.bbprevidencia.devolucao.enumerador;

public enum SituacaoSolicitacaoOptOutEnum {

	REQUERIDO(1L, "REQUERIDO"),
	EM_DEFERIMENTO(2L, "EM DEFERIMENTO"),
	CONCEDIDO(3L, "CONCEDIDO"),
	INDEFERIDO(4L, "INDEFERIDO"),
	SUSPENSA(5L, "SUSPENSA"),
	CONCLUIDO(6L, "CONCLUIDO"),
	CANCELADO(7L, "CANCELADO"),
	CALCULADO(8L, "CALCULADO"),
	INTEGRADO(9L, "INTEGRADO"),
	CALCULO_INTEGRACAO(10L, "INTEGRAÇÃO CALCULADA"),
	CONFERIDO(11L, "CONFERIDO");

	private Long codigo;
	private String descricao;

	private SituacaoSolicitacaoOptOutEnum(Long codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return SituacaoDevolucaoEnum
	 */
	public static SituacaoSolicitacaoOptOutEnum getSituacaoDevolucaoEnum(Long codigo) {
		if (codigo != null) {
			for (SituacaoSolicitacaoOptOutEnum situacaoDevolucao : values()) {
				if (situacaoDevolucao.getCodigo().equals(codigo)) {
					return situacaoDevolucao;
				}
			}
		}
		return null;
	}

}