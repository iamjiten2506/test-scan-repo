package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InserirDevolucaoResponseDTO {

	private Long codigoProcessoDevolucao;

	private String mensagemErro;

}
