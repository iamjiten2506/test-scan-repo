package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.component.UIOutput;
import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoGuardaChuvaBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoGuardaChuva;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoConsolidadoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoPorParticipanteDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório Quantitativo Consolidado.
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 20/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioQuantitativoConsolidadoVisao")
public class RelatorioQuantitativoConsolidadoVisao {

	private static final String FW_RELATORIO_QUANTITATIVO_CONSOLIDADO = "/paginas/relatorioQuantitativoConsolidado.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioQuantitativoConsolidadoVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private PlanoGuardaChuvaBO planoGuardaChuvaBO;

	@Autowired
	ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;

	private List<PlanoGuardaChuva> listaPlanoGuardaChuva;
	private List<PlanoGuardaChuva> listaPlanoGuardaChuvaSelecionados;

	private Date dataInicio;
	private Date dataFim;

	private boolean selecionarPlano;
	private String relatorioSaida;

	/**
	 * Método encarregado de carregar a página incial de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 * @return
	 */
	public String iniciarRelatorioQuantitativoConsolidado() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		this.listaEntidadeParticipante = entidadeParticipanteBO.listarEntidadeParticipante();

		return FW_RELATORIO_QUANTITATIVO_CONSOLIDADO;
	}

	/**
	 * Setar valores iniciais na tela de pesquisa
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 * 
	 */
	public void setarValoresIniciais() {
		this.dataInicio = null;
		this.dataFim = null;
		this.selecionarPlano = false;
		this.relatorioSaida = "CO";
		this.listaEntidadeParticipanteSelecionadas = null;
		this.listaPlanoGuardaChuva = null;
		this.listaPlanoGuardaChuvaSelecionados = null;
		this.listaPlanoPrevidencia = null;
		this.listaPlanoPrevidenciaSelecionados = null;
	}

	/**
	 * Método encarregado de prencher informações necessárias na tela quando uma entidade participante é selecionada
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 */
	public void verificaListaPatrocinadora() {
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipanteSelecionadas)) {
			setarVisaoMultiEmpresa();
		} else {
			if (this.listaEntidadeParticipanteSelecionadas.size() == 1) {
				this.selecionarPlano = true;

				EntidadeParticipante entidadeParticipante = this.listaEntidadeParticipanteSelecionadas.get(0);
				this.listaPlanoPrevidencia = listarPlanoPrevidencia(entidadeParticipante);
				this.listaPlanoGuardaChuva = listarPlanoGuardaChuva(entidadeParticipante);
			} else {
				setarVisaoMultiEmpresa();
			}
		}
	}

	/**
	 * Pesquisar lista de planos Guarda chuva por entidade particopnate selecionada.
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 * @param {@link EntidadeParticipante}
	 * @return
	 */
	private List<PlanoGuardaChuva> listarPlanoGuardaChuva(EntidadeParticipante entidadeParticipante) {
		try {
			this.planoGuardaChuvaBO.listarPorEntidadeParticipante(entidadeParticipante);
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
		return null;
	}

	/**
	 * Método encarregado de setar valores padrão para quando é selecionada mais de uma empresa ou várias
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 */
	public void setarVisaoMultiEmpresa() {
		this.selecionarPlano = false;
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoGuardaChuva = new ArrayList<PlanoGuardaChuva>();
		this.listaPlanoGuardaChuvaSelecionados = new ArrayList<PlanoGuardaChuva>();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link EntidadeParticipante}
	 * @return
	 */
	public List<PlanoPrevidencia> listarPlanoPrevidencia(EntidadeParticipante entidadeParticipante) {

		try {
			List<PlanoPrevidencia> listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(entidadeParticipante);

			return listaPlanoPrevidencia;
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * Método para capturar a data inicial escolhida com UI calendar
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 * @param {@link SelectEvent}
	 */
	public void trataDataInicialSelecionada(SelectEvent event) {
		if (event.getObject() instanceof Date) {
			setarPeriodoDePesquisa((Date) event.getObject());
		}
	}

	/**
	 * Método para capturar a data inicial digitada manualmente
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/03/2017
	 * @param {@link AjaxBehaviorEvent}
	 */
	public void trataDataInicialManual(AjaxBehaviorEvent event) {
		Date dataManual = (Date) ((UIOutput) event.getSource()).getValue();

		setarPeriodoDePesquisa(dataManual);

	}

	private void setarPeriodoDePesquisa(Date dataInicial) {
		this.dataInicio = UtilJava.getPrimeiroDiaDoMes(dataInicial);
		this.dataFim = UtilJava.getUltimoDiaUtilDoMes(dataInicial);
	}

	/**
	 * Método encarregado de emitir o relatório
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/03/2017
	 */
	public void exportarRelatorio(ActionEvent event) {
		try {
			List<RelatorioQuantitativoConsolidadoDTO> relatorioQuantitativoConsolidado = new ArrayList<RelatorioQuantitativoConsolidadoDTO>();
			List<RelatorioQuantitativoPorParticipanteDTO> relatorioQuantitativoPorParticipante = new ArrayList<RelatorioQuantitativoPorParticipanteDTO>();

			if (this.relatorioSaida.equalsIgnoreCase("CO")) {
				relatorioQuantitativoConsolidado.addAll(parcelaContaDevolucaoBO.pesquisarQuantitativoConsolidado(
						this.getDataInicio(),
						this.getDataFim(),
						this.listaEntidadeParticipanteSelecionadas,
						this.listaPlanoPrevidenciaSelecionados,
						this.listaPlanoGuardaChuvaSelecionados));
			} else {
				relatorioQuantitativoPorParticipante.addAll(parcelaContaDevolucaoBO.pesquisarQuantitativoPorParticipante(
						this.getDataInicio(),
						this.getDataFim(),
						this.listaEntidadeParticipanteSelecionadas,
						this.listaPlanoPrevidenciaSelecionados,
						this.listaPlanoGuardaChuvaSelecionados));
			}

			if (UtilJava.isColecaoVazia(this.relatorioSaida.equalsIgnoreCase("CO") ? relatorioQuantitativoConsolidado : relatorioQuantitativoPorParticipante)) {
				Mensagens.addMsgInfo("Não foram encontradas informações para estes parâmetros!");
			} else {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);
				parametros.put("dataInicio", UtilJava.formataDataPorPadrao(this.getDataInicio(), "dd/MM/yyyy"));
				parametros.put("dataFim", this.getDataFim() == null ? "Hoje" : UtilJava.formataDataPorPadrao(this.getDataFim(), "dd/MM/yyyy"));

				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(relatorioQuantitativoConsolidado);
				//GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "quantitativoConsolidado", dataSource);
				String nomeArquivo = relatorioUtil.gerarRelatorio(this.relatorioSaida.equalsIgnoreCase("CO") ? "quantitativoConsolidado" : "quantitativoPorParticipante", this.relatorioSaida
						.equalsIgnoreCase("CO") ? relatorioQuantitativoConsolidado : relatorioQuantitativoPorParticipante, parametros);
				relatorioUtil.abrirPoupUp(nomeArquivo);
			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro("Erro ao exportar relatório.");
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

	public List<PlanoGuardaChuva> getListaPlanoGuardaChuva() {
		return listaPlanoGuardaChuva;
	}

	public void setListaPlanoGuardaChuva(List<PlanoGuardaChuva> listaPlanoGuardaChuva) {
		this.listaPlanoGuardaChuva = listaPlanoGuardaChuva;
	}

	public List<PlanoGuardaChuva> getListaPlanoGuardaChuvaSelecionados() {
		return listaPlanoGuardaChuvaSelecionados;
	}

	public void setListaPlanoGuardaChuvaSelecionados(List<PlanoGuardaChuva> listaPlanoGuardaChuvaSelecionados) {
		this.listaPlanoGuardaChuvaSelecionados = listaPlanoGuardaChuvaSelecionados;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public String getRelatorioSaida() {
		return relatorioSaida;
	}

	public void setRelatorioSaida(String relatorioSaida) {
		this.relatorioSaida = relatorioSaida;
	}

}
