package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.SituacaoRegraBO;
import br.com.bbprevidencia.devolucao.dto.SituacaoRegraDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter a Situação da Regra de Devolução
 * 
 * @author  BBPF0415 - Yanisley Mora  Ritchie
 * @since 25/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("situacaoRegraVisao")
public class SituacaoRegraVisao {

	private static final String FW_SITUACAO_REGRA = "/paginas/situacaoRegra.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private SituacaoRegraBO situacaoRegraBO;

	private List<SituacaoRegraDevolucao> listaSituacaoRegra;

	private SituacaoRegraDevolucao situacaoRegraDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página da Situação da Regra de Devolução
	 * @author  BBPF0415 - Yanisley Mora  Ritchie
	 * @since 25/01/2017
	 * @return {@link String}
	 */
	public String iniciarSituacaoRegra() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("situacaoRegra");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.situacaoRegraDevolucao = null;

		this.listarStatus = true;

		listaSituacaoRegra = new ArrayList<SituacaoRegraDevolucao>(situacaoRegraBO.listarSituacaoRegra());

		return FW_SITUACAO_REGRA;
	}

	public List<SituacaoRegraDevolucao> getListaSituacaoRegra() {
		return listaSituacaoRegra;
	}

	public void setListaSituacaoRegra(List<SituacaoRegraDevolucao> listaSituacaoRegra) {
		this.listaSituacaoRegra = listaSituacaoRegra;
	}

	public SituacaoRegraDevolucao getSituacaoRegraDevolucao() {
		return situacaoRegraDevolucao;
	}

	public void setSituacaoRegraDevolucao(SituacaoRegraDevolucao situacaoRegraDevolucao) {
		this.situacaoRegraDevolucao = situacaoRegraDevolucao;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

}
