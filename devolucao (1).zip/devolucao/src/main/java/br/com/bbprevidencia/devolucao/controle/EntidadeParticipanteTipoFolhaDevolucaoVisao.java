package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.EntidadeParticipanteTipoFolhaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoFolhaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.EntidadeParticipanteTipoFolhaDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoFolhaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

@Scope("session")
@Component("entidadeParticipanteTipoFolhaDevolucaoVisao")
public class EntidadeParticipanteTipoFolhaDevolucaoVisao {

	private static String FW_ENTIDADE_PARTIC_TIPO_FOLHA_DEV = "/paginas/entidadeParticipanteTipoFolhaDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private EntidadeParticipanteTipoFolhaDevolucaoBO entidadeParticipanteTipoFolhaDevolucaoBo;

	@Autowired
	private TipoFolhaDevolucaoBO tipoFolhaDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	private List<EntidadeParticipanteTipoFolhaDevolucao> listaEntidadeParticipanteTipoFolhaDevolucao;

	private List<EntidadeParticipanteTipoFolhaDevolucao> listaFiltrada;

	private List<TipoFolhaDevolucao> listaTipoFolhaDevolucao;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private EntidadeParticipanteTipoFolhaDevolucao entidadeParticipanteTipoFolhaDevolucao;

	private EntidadeParticipante entidadeParticipante;

	private TipoFolhaDevolucao tipoFolhaDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página.
	 * @author  BBPF00170 - Magson 
	 * @since   08/02/2017
	 * @return {@link String}
	 */
	public String iniciarEntidadeParticipanteTipoFolhaDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("entidadeParticipanteTipoFolhaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
		this.listarStatus = true;

		this.listaEntidadeParticipanteTipoFolhaDevolucao = new ArrayList<EntidadeParticipanteTipoFolhaDevolucao>(entidadeParticipanteTipoFolhaDevolucaoBo
				.listarTodosEntidadeParticipanteTipoFolhaDevolucao());
		this.listaTipoFolhaDevolucao = new ArrayList<TipoFolhaDevolucao>(tipoFolhaDevolucaoBO.listarTodosTipoFolhaDevolucao());
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(entidadeParticipanteBO.listarEntidadeParticipante());

		return FW_ENTIDADE_PARTIC_TIPO_FOLHA_DEV;
	}

	/**
	 * Método que controla o modo de visualização e edição/inserção da página.
	 * @author  BBPF00170 - Magson
	 * @since   08/02/2017
	 * 
	 */
	public void controlarEdicaoEntidadeParticipanteTipoFolhaDevolucao() {
		if (isListarStatus()) {

			entidadeParticipante = new EntidadeParticipante();
			tipoFolhaDevolucao = new TipoFolhaDevolucao();
			listaEntidadeParticipanteTipoFolhaDevolucao = new ArrayList<EntidadeParticipanteTipoFolhaDevolucao>(entidadeParticipanteTipoFolhaDevolucaoBo
					.listarTodosEntidadeParticipanteTipoFolhaDevolucao());
		}

		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método que controlar edição 
	 * 
	 * @author  BBPF0170 MAGSON
	 * @since   08/02/2017
	 * @param 	{@link - EntidadeParticipanteTipoFolhaDevolucao}
	 */
	public void editarEntidadeParticipanteTipoFolhaDevolucao(EntidadeParticipanteTipoFolhaDevolucao entidadeParticipanteTipoFolhaDevolucao) {
		entidadeParticipanteTipoFolhaDevolucao.setDataAlteracao(new Date());
		entidadeParticipanteTipoFolhaDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

		setEntidadeParticipanteTipoFolhaDevolucao(entidadeParticipanteTipoFolhaDevolucao);
		controlarEdicaoEntidadeParticipanteTipoFolhaDevolucao();
	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da página
	 * 
	 * @author  BBPF0170 - Magson
	 * @since 	08/02/2017
	 * @return  void
	 */
	public void limparPesquisa() {
		listaEntidadeParticipanteTipoFolhaDevolucao = new ArrayList<EntidadeParticipanteTipoFolhaDevolucao>(entidadeParticipanteTipoFolhaDevolucaoBo
				.listarTodosEntidadeParticipanteTipoFolhaDevolucao());
	}

	/**
	 * Método encarregado de deletar um registro. 
	 * @author  BBPF0170 - Magson
	 * @since 08/02/2017
	 * @param {@link @EntidadeParticipanteTipoFolhaDevolucao }
	 * @return {@link String}
	 */

	public String deletarEntidadeParticipanteTipoFolhaDevolucao(EntidadeParticipanteTipoFolhaDevolucao entidadeParticipanteTipoFolhaDevolucao) {
		try {

			entidadeParticipanteTipoFolhaDevolucaoBo.apagarEntidadeParticipanteTipoFolhaDevolucao(entidadeParticipanteTipoFolhaDevolucao);
			listaEntidadeParticipanteTipoFolhaDevolucao = entidadeParticipanteTipoFolhaDevolucaoBo.listarTodosEntidadeParticipanteTipoFolhaDevolucao();
			Mensagens.addMsgInfo("Entidade Participante por tipo de folha de Devolução excluído com sucesso!");
			return FW_ENTIDADE_PARTIC_TIPO_FOLHA_DEV;
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar Entidade Participante por tipo de folha de Devolução.");
			return "";
		}
	}

	/**
	 * Método 
	 * @author  BBPF0170 -  Magson
	 * @since   08/02/2017
	 */
	public void cadastrarNovoEntidadeParticipanteTipoFolhaDevolucao() {
		entidadeParticipanteTipoFolhaDevolucao = new EntidadeParticipanteTipoFolhaDevolucao();
		controlarEdicaoEntidadeParticipanteTipoFolhaDevolucao();
	}

	/**
	 * Método para salvar uma Entidade Participante Tipo de Folha   
	 * 
	 * @author  BBPF0170 - Magson
	 * @since   08/02/2017
	 * @return {@link String}
	 */
	public String salvarEntidadeParticipanteTipoFolhaDevolucao() {
		try {
			if (entidadeParticipanteTipoFolhaDevolucao.getCodigo() == null) {
				this.entidadeParticipanteTipoFolhaDevolucao.setDataInclusao(new Date());
				this.entidadeParticipanteTipoFolhaDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			}

			entidadeParticipanteTipoFolhaDevolucaoBo.salvarEntidadeParticipanteTipoFolhaDevolucao(entidadeParticipanteTipoFolhaDevolucao);
			controlarEdicaoEntidadeParticipanteTipoFolhaDevolucao();
			if (entidadeParticipanteTipoFolhaDevolucao.getCodigo() == null) {
				Mensagens.addMessage("DEV_VMSG018", "salvo");

			} else {
				Mensagens.addMessage("DEV_VMSG018", "atualizado");
			}
			//Mensagens.addMessage("DEV_VMSG018", entidadeParticipanteTipoFolhaDevolucao.getCodigo() == null ? "salva" : "atualizado");
			listaEntidadeParticipanteTipoFolhaDevolucao = entidadeParticipanteTipoFolhaDevolucaoBo.listarTodosEntidadeParticipanteTipoFolhaDevolucao();
			return "";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar");
			return "";
		}

	}

	public EntidadeParticipanteTipoFolhaDevolucaoBO getEntidadeParticipanteTipoFolhaDevolucaoBo() {
		return entidadeParticipanteTipoFolhaDevolucaoBo;
	}

	public void setEntidadeParticipanteTipoFolhaDevolucaoBo(EntidadeParticipanteTipoFolhaDevolucaoBO entidadeParticipanteTipoFolhaDevolucaoBo) {
		this.entidadeParticipanteTipoFolhaDevolucaoBo = entidadeParticipanteTipoFolhaDevolucaoBo;
	}

	public EntidadeParticipanteTipoFolhaDevolucao getEntidadeParticipanteTipoFolhaDevolucao() {
		return entidadeParticipanteTipoFolhaDevolucao;
	}

	public void setEntidadeParticipanteTipoFolhaDevolucao(EntidadeParticipanteTipoFolhaDevolucao entidadeParticipanteTipoFolhaDevolucao) {
		this.entidadeParticipanteTipoFolhaDevolucao = entidadeParticipanteTipoFolhaDevolucao;
	}

	public List<EntidadeParticipanteTipoFolhaDevolucao> getListaEntidadeParticipanteTipoFolhaDevolucao() {
		return listaEntidadeParticipanteTipoFolhaDevolucao;
	}

	public void setListaEntidadeParticipanteTipoFolhaDevolucao(List<EntidadeParticipanteTipoFolhaDevolucao> listaEntidadeParticipanteTipoFolhaDevolucao) {
		this.listaEntidadeParticipanteTipoFolhaDevolucao = listaEntidadeParticipanteTipoFolhaDevolucao;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public TipoFolhaDevolucaoBO getTipoFolhaDevolucaoBO() {
		return tipoFolhaDevolucaoBO;
	}

	public void setTipoFolhaDevolucaoBO(TipoFolhaDevolucaoBO tipoFolhaDevolucaoBO) {
		this.tipoFolhaDevolucaoBO = tipoFolhaDevolucaoBO;
	}

	public List<TipoFolhaDevolucao> getListaTipoFolhaDevolucao() {
		return listaTipoFolhaDevolucao;
	}

	public void setListaTipoFolhaDevolucao(List<TipoFolhaDevolucao> listaTipoFolhaDevolucao) {
		this.listaTipoFolhaDevolucao = listaTipoFolhaDevolucao;
	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public TipoFolhaDevolucao getTipoFolhaDevolucao() {
		return tipoFolhaDevolucao;
	}

	public void setTipoFolhaDevolucao(TipoFolhaDevolucao tipoFolhaDevolucao) {
		this.tipoFolhaDevolucao = tipoFolhaDevolucao;
	}

	public List<EntidadeParticipanteTipoFolhaDevolucao> getListaFiltrada() {
		return listaFiltrada;
	}

	public void setListaFiltrada(List<EntidadeParticipanteTipoFolhaDevolucao> listaFiltrada) {
		this.listaFiltrada = listaFiltrada;
	}

}
