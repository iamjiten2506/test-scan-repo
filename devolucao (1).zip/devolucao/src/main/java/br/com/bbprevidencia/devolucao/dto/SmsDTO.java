package br.com.bbprevidencia.devolucao.dto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class SmsDTO {

	private String numero;
	private String msg;

	public SmsDTO(String numero, String msg) {
		this.numero = numero;
		this.msg = msg;
	}
}
