package br.com.bbprevidencia.devolucao.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class RetornoEnvioSmsDTO {

	private boolean smsEnviado;
	private String msgRetorno;

	public RetornoEnvioSmsDTO(boolean smsEnviado, String msgRetorno) {
		this.smsEnviado = smsEnviado;
		this.msgRetorno = msgRetorno;
	}

	public boolean isSmsEnviado() {
		return smsEnviado;
	}

	public void setSmsEnviado(boolean smsEnviado) {
		this.smsEnviado = smsEnviado;
	}

	public String getMsgRetorno() {
		return msgRetorno;
	}

	public void setMsgRetorno(String msgRetorno) {
		this.msgRetorno = msgRetorno;
	}

}