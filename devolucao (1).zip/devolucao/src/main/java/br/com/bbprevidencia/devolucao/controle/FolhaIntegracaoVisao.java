package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.LancamentoIntegracaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.TipoIntegracaoEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   26/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("folhaIntegracaoVisao")
public class FolhaIntegracaoVisao {

	private static String FW_INTEGRACAO_FOLHA = "/paginas/folhaIntegracao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private IntegracaoFolhaDevolucao integracaoFolhaDevolucao;

	@Autowired
	private LancamentoIntegracaoDevolucaoBO lancamentoIntegracaoDevolucaoBO;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private CronogramaDevolucao cronogramaDevolucao;

	private boolean indicadorIntegraFinanRubricas;
	private boolean indicadorIntegraContabilidade;
	private boolean indicadorIntegraFinanLiquido;
	private boolean indicadorIntegraFinanConsignatario;
	private boolean indicadorIntegraFundoPrevidencial;
	private boolean indicadorIntegraCotas;
	private boolean indicativoNaoPodeIntegrar;

	private boolean finanRubricasIntegrado;
	private boolean finanLiquidoIntegrado;
	private boolean finanConsignatarioIntegrado;
	private boolean fundoPrevidencialIntegrado;
	private boolean cotasIntegrado;
	private boolean contabilidadeIntegrado;

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0333 - Daniel Martins
	 * @since   24/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("folhaIntegracao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.limpaSelecao();

		//Fazer cargas de listas de Combo.
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarCronogramaDevolucaoPermiteIntegracao());

		return FW_INTEGRACAO_FOLHA;
	}

	/**
	 * Método integração
	 *  
	 * @author  BBPF0351 - Marco Figueiredo
	 * @since   24/02/2017
	 * @return {@link String}
	 */
	public String integrar() {
		try {
			List<String> listaRetorno = new ArrayList<String>();

			listaRetorno = integracaoFolhaDevolucao.integrarFolhaDevolucao(
					this.cronogramaDevolucao,
					this.indicadorIntegraContabilidade,
					this.indicadorIntegraFinanConsignatario,
					this.indicadorIntegraFinanLiquido,
					this.indicadorIntegraFinanRubricas,
					this.indicadorIntegraCotas,
					this.indicadorIntegraFundoPrevidencial,
					this.loginTemporariaDTO);

			if (UtilJava.isColecaoDiferenteDeVazia(listaRetorno)) {
				this.concluirProcessamento();
				Mensagens.addMsgErro("Ocorreram erros de integração:");
				Mensagens.addMsgErro(listaRetorno);
			} else {
				CronogramaDevolucao cronogramaDevolucaoAtualizacao = this.cronogramaDevolucaoBO.pesquisarCronogramaDevolucaoPorCodigo(cronogramaDevolucao.getCodigo());
				cronogramaDevolucaoAtualizacao = this.cronogramaDevolucaoBO.atualizarCronograma(cronogramaDevolucaoAtualizacao, 21L, loginTemporariaDTO);
				this.cronogramaDevolucaoBO.salvarCronogramaDevolucao(cronogramaDevolucaoAtualizacao);
				this.gerarRelatorioEmprestimosIntegracaoFolha(cronogramaDevolucaoAtualizacao);
				this.limpaSelecaoIndicadores();
				this.verificarIntegracoes();

				Mensagens.addMsgInfo("Processo de Integração concluído com sucesso!");
			}

		} catch (Exception e) {
			this.concluirProcessamento();
			Mensagens.addError("Erro ao processar folha. Erro: " + e.getMessage());
		}

		return FW_INTEGRACAO_FOLHA;

	}

	public void gerarRelatorioEmprestimosIntegracaoFolha(CronogramaDevolucao cronogramaDevolucao) {

		this.movimentoCalculoPagamentoDevolucaoBO.gerarRelatorioEmprestimosIntegracaoFolhaCronograma(cronogramaDevolucao);

		//		this.historicoPagamentoDevolucaoBO.gerarRelatorioEmprestimosIntegracaoFolhaCronograma(cronogramaDevolucao);

	}

	/**
	 * Inativa a barra de progresso e aborta o processamento
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/06/2017
	 */
	private void concluirProcessamento() {
		PrimeFaces.current().executeScript("cancelPb()");
	}

	//Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   26/01/2017
	 */
	public void limpaSelecao() {
		this.setCronogramaDevolucao(null);
		this.setIndicadorIntegraContabilidade(false);
		this.setIndicadorIntegraFinanConsignatario(false);
		this.setIndicadorIntegraFinanLiquido(false);
		this.setIndicadorIntegraFinanRubricas(false);
		this.setIndicadorIntegraCotas(false);
		this.setIndicadorIntegraFundoPrevidencial(false);

		this.setContabilidadeIntegrado(false);
		this.setCotasIntegrado(false);
		this.setFinanConsignatarioIntegrado(false);

		this.setFinanLiquidoIntegrado(false);
		this.setFinanRubricasIntegrado(false);
		this.setFundoPrevidencialIntegrado(false);

		this.verificarSelecao("P");
	}

	public void verificarSelecao(String origem) {

		if (this.cronogramaDevolucao != null) {
			if (this.isIndicadorIntegraFinanRubricas() || this.isIndicadorIntegraContabilidade() || this.isIndicadorIntegraFinanConsignatario() || this.isIndicadorIntegraFinanLiquido()
					|| this.isIndicadorIntegraCotas() || this.isIndicadorIntegraFundoPrevidencial()) {
				this.setIndicativoNaoPodeIntegrar(false);
			} else {
				this.setIndicativoNaoPodeIntegrar(true);
			}

			if (origem.equalsIgnoreCase("I")) {
				this.verificarIntegracoes();
			}

		} else {
			this.setIndicativoNaoPodeIntegrar(true);
		}
	}

	private void verificarIntegracoes() {
		this.finanLiquidoIntegrado = this.lancamentoIntegracaoDevolucaoBO.pesquisarLancamentoIntegracaoPorCronogramaTipo(this.cronogramaDevolucao, TipoIntegracaoEnum.LIQUIDO);
		this.finanRubricasIntegrado = this.lancamentoIntegracaoDevolucaoBO.pesquisarLancamentoIntegracaoPorCronogramaTipo(this.cronogramaDevolucao, TipoIntegracaoEnum.RUBRICA);
		this.finanConsignatarioIntegrado = this.lancamentoIntegracaoDevolucaoBO.pesquisarLancamentoIntegracaoPorCronogramaTipo(this.cronogramaDevolucao, TipoIntegracaoEnum.CONSIGNATARIO);
		this.contabilidadeIntegrado = this.lancamentoIntegracaoDevolucaoBO.pesquisarLancamentoIntegracaoPorCronogramaTipo(this.cronogramaDevolucao, TipoIntegracaoEnum.CONTABILIDADE);
		this.fundoPrevidencialIntegrado = this.lancamentoIntegracaoDevolucaoBO.pesquisarLancamentoIntegracaoPorCronogramaTipo(this.cronogramaDevolucao, TipoIntegracaoEnum.FUNDOPREVIDENCIAL);
		this.cotasIntegrado = this.lancamentoIntegracaoDevolucaoBO.pesquisarLancamentoIntegracaoPorCronogramaTipo(this.cronogramaDevolucao, TipoIntegracaoEnum.COTAS);
	}

	public void limpaSelecaoIndicadores() {
		this.setIndicadorIntegraContabilidade(false);
		this.setIndicadorIntegraFinanConsignatario(false);
		this.setIndicadorIntegraFinanLiquido(false);
		this.setIndicadorIntegraFinanRubricas(false);
		this.setIndicadorIntegraCotas(false);
		this.setIndicadorIntegraFundoPrevidencial(false);
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public boolean isIndicadorIntegraFinanRubricas() {
		return indicadorIntegraFinanRubricas;
	}

	public void setIndicadorIntegraFinanRubricas(boolean indicadorIntegraFinanRubricas) {
		this.indicadorIntegraFinanRubricas = indicadorIntegraFinanRubricas;
	}

	public boolean isIndicadorIntegraContabilidade() {
		return indicadorIntegraContabilidade;
	}

	public void setIndicadorIntegraContabilidade(boolean indicadorIntegraContabilidade) {
		this.indicadorIntegraContabilidade = indicadorIntegraContabilidade;
	}

	public boolean isIndicadorIntegraFinanLiquido() {
		return indicadorIntegraFinanLiquido;
	}

	public void setIndicadorIntegraFinanLiquido(boolean indicadorIntegraFinanLiquido) {
		this.indicadorIntegraFinanLiquido = indicadorIntegraFinanLiquido;
	}

	public boolean isIndicadorIntegraFinanConsignatario() {
		return indicadorIntegraFinanConsignatario;
	}

	public void setIndicadorIntegraFinanConsignatario(boolean indicadorIntegraFinanConsignatario) {
		this.indicadorIntegraFinanConsignatario = indicadorIntegraFinanConsignatario;
	}

	public boolean isIndicativoNaoPodeIntegrar() {
		return indicativoNaoPodeIntegrar;
	}

	public void setIndicativoNaoPodeIntegrar(boolean indicativoNaoPodeIntegrar) {
		this.indicativoNaoPodeIntegrar = indicativoNaoPodeIntegrar;
	}

	public boolean isIndicadorIntegraFundoPrevidencial() {
		return indicadorIntegraFundoPrevidencial;
	}

	public void setIndicadorIntegraFundoPrevidencial(boolean indicadorIntegraFundoPrevidencial) {
		this.indicadorIntegraFundoPrevidencial = indicadorIntegraFundoPrevidencial;
	}

	public boolean isIndicadorIntegraCotas() {
		return indicadorIntegraCotas;
	}

	public void setIndicadorIntegraCotas(boolean indicadorIntegraCotas) {
		this.indicadorIntegraCotas = indicadorIntegraCotas;
	}

	public boolean isFinanRubricasIntegrado() {
		return finanRubricasIntegrado;
	}

	public void setFinanRubricasIntegrado(boolean finanRubricasIntegrado) {
		this.finanRubricasIntegrado = finanRubricasIntegrado;
	}

	public boolean isFinanLiquidoIntegrado() {
		return finanLiquidoIntegrado;
	}

	public void setFinanLiquidoIntegrado(boolean finanLiquidoIntegrado) {
		this.finanLiquidoIntegrado = finanLiquidoIntegrado;
	}

	public boolean isFinanConsignatarioIntegrado() {
		return finanConsignatarioIntegrado;
	}

	public void setFinanConsignatarioIntegrado(boolean finanConsignatarioIntegrado) {
		this.finanConsignatarioIntegrado = finanConsignatarioIntegrado;
	}

	public boolean isFundoPrevidencialIntegrado() {
		return fundoPrevidencialIntegrado;
	}

	public void setFundoPrevidencialIntegrado(boolean fundoPrevidencialIntegrado) {
		this.fundoPrevidencialIntegrado = fundoPrevidencialIntegrado;
	}

	public boolean isCotasIntegrado() {
		return cotasIntegrado;
	}

	public void setCotasIntegrado(boolean cotasIntegrado) {
		this.cotasIntegrado = cotasIntegrado;
	}

	public boolean isContabilidadeIntegrado() {
		return contabilidadeIntegrado;
	}

	public void setContabilidadeIntegrado(boolean contabilidadeIntegrado) {
		this.contabilidadeIntegrado = contabilidadeIntegrado;
	}

}
