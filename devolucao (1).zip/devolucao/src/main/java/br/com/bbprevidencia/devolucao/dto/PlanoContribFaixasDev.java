package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.TipoContribuicao;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   01/12/2016
 * Classe de persistência para tabela REG_PLA_CON_FAI_DEV.
 */
@Entity
@Table(name = "REG_PLA_CON_FAI_DEV", schema = "OWN_DCR")
@NamedQuery(name = "PlanoContribFaixasDev.findAll", query = "SELECT q FROM PlanoContribFaixasDev q")
public class PlanoContribFaixasDev implements Serializable, BaseEntity, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PLA_CON_FAIXAS_GER", sequenceName = "S_RPCFD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PLA_CON_FAIXAS_GER")
	@Column(name = "NUM_SEQ_REG_PLA_CON_FAI_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "COD_TIPO_CONTRI")
	private TipoContribuicao tipoContribuicao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLANO")
	private PlanoPrevidencia planoPrevidencia;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CON_DEV")
	private RegraDevolucaoContribuicao regraDevolucaoContribuicao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public TipoContribuicao getTipoContribuicao() {
		return tipoContribuicao;
	}

	public void setTipoContribuicao(TipoContribuicao tipoContribuicao) {
		this.tipoContribuicao = tipoContribuicao;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public RegraDevolucaoContribuicao getRegraDevolucaoContribuicao() {
		return regraDevolucaoContribuicao;
	}

	public void setRegraDevolucaoContribuicao(RegraDevolucaoContribuicao regraDevolucaoContribuicao) {
		this.regraDevolucaoContribuicao = regraDevolucaoContribuicao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public PlanoContribFaixasDev clone() throws CloneNotSupportedException {
		PlanoContribFaixasDev planoContribFaixasDev = (PlanoContribFaixasDev) super.clone();
		planoContribFaixasDev.setCodigo(null);
		return planoContribFaixasDev;
	}

}