package br.com.bbprevidencia.devolucao.util;

import java.util.ArrayList;
import java.util.List;

import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;

public class AsyncForm {
    
    private StringBuilder log = new StringBuilder();
    private List<DevolucaoCompletoDTO> devolucoes = new ArrayList<>();

    public AsyncForm() {
    }
    
    public AsyncForm(StringBuilder log) {
            this.log = log;
    }

    public void addLog(String s){
            this.log.append(s).append("<br>");
    }

    public void setDevolucoes(List<DevolucaoCompletoDTO> devolucoes) {
            this.devolucoes = devolucoes.subList(0, devolucoes.size());
    }

    public String getLog() {
            return log.toString();
    }

    public List<DevolucaoCompletoDTO> getDevolucoes() {
            return devolucoes;
    }
    
}
