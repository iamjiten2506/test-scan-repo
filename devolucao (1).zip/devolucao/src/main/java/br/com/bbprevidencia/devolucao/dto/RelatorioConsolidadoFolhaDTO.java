package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

public class RelatorioConsolidadoFolhaDTO implements Comparable<RelatorioConsolidadoFolhaDTO> {

	private String nomePlano;

	private String nomeRecebedor;

	private String cpfRecebedor;

	private Date dataPagamento;

	private Double valorBruto;

	private Double valorDesconto;

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomeRecebedor() {
		return nomeRecebedor;
	}

	public void setNomeRecebedor(String nomeRecebedor) {
		this.nomeRecebedor = nomeRecebedor;
	}

	public String getCpfRecebedor() {
		return cpfRecebedor;
	}

	public void setCpfRecebedor(String cpfRecebedor) {
		this.cpfRecebedor = cpfRecebedor;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Double getValorBruto() {
		return valorBruto;
	}

	public void setValorBruto(Double valorBruto) {
		this.valorBruto = valorBruto;
	}

	public Double getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(Double valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	@Override
	public int compareTo(RelatorioConsolidadoFolhaDTO o) {
		return this.nomePlano.compareToIgnoreCase(o.nomePlano);
	}

}
