package br.com.bbprevidencia.devolucao.listener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.plexus.util.StringUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastro.bo.EntidadeParticipanteEmailContatoBO;
import br.com.bbprevidencia.cadastro.dto.EntidadeParticipanteEmailContatoDTO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CarimboTempoBO;
import br.com.bbprevidencia.devolucao.bo.CloudDocsBO;
import br.com.bbprevidencia.devolucao.bo.LoginServiceBO;
import br.com.bbprevidencia.devolucao.bo.SolicitacaoOptOutBO;
import br.com.bbprevidencia.devolucao.dto.AnexoDTO;
import br.com.bbprevidencia.devolucao.dto.EmailDTO;
import br.com.bbprevidencia.devolucao.dto.EmailRetornoDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoRequisicaoAssinatura;
import br.com.bbprevidencia.devolucao.interceptor.HeaderRequestInterceptor;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

@Component
public class OptOutConsumer {
	private static Logger log = Logger.getLogger(OptOutConsumer.class);

	@Autowired
	private LoginServiceBO loginServiceBO;

	@Autowired
	private CarimboTempoBO carimboTempoBO;

	@Autowired
	private CloudDocsBO cloudDocsBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private ServletContext context;

	@Autowired
	private EntidadeParticipanteEmailContatoBO entidadeEmailContatoBO;

	@Autowired
	private SolicitacaoOptOutBO solicitacaoOptOutBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private AmbienteServico ambienteServico;

	private RestTemplate restTemplate;

	private String termoAnulacaoInscricaoBase64;

	@Value("#{propriedades['url.ambiente']}")
	private String urlAmbiente;

	@Value("#{propriedades['optout.termo.dir']}")
	private String pastaFichaCadastral;

	@Value("#{propriedades['optout.carimbo.dir']}")
	private String pastaCarimboFichaCadastral;

	@Value("#{propriedades['url.comunicacao.api']}")
	private String comunicacaoApiUrl;

	/**
	 * The function that consumes messages from the broker(RabbitMQ)
	 * 
	 * @param data
	 * @throws Exception 
	 * @throws ClassNotFoundException 
	 */
	@RabbitListener(queues = "optout.queue")
	public void backOfficeOptOut(Long idParticipante) throws Exception {
		Boolean etapaSolicitacaoRealizada = false;
		Boolean emailEnviado = false;
		Boolean cancelarBoleto = false;

		Participante participante = this.participanteBO.consultarParticipantePorCodigo(idParticipante);
		//Gerando Termo de Aceite
		log.info(">>> Gerando termo de anulação de inscrição, participante: " + participante.getNomeParticipante());
		this.termoAnulacaoInscricaoBase64 = this.montarTermoAceite(participante);
		if (!StringUtils.isBlank(termoAnulacaoInscricaoBase64)) {//Termo gerado com sucesso

			//Carimbar digitalmente o termo de anulação da inscrição
			log.info(">>> Gerando token JWT");
			String token = this.loginServiceBO.retornarToken();

			log.info(">>> Assinando Termo de Anulação de Inscrição");
			RetornoRequisicaoAssinatura retornoAssinatura = this.carimboTempoBO.carimbarDocumento("tempTermoAnulacaoInscricao", this.termoAnulacaoInscricaoBase64, token);

			this.termoAnulacaoInscricaoBase64 = retornoAssinatura.getArquivoAutenticado().getArquivoBase64();

			//Enviar e-mail de notificação
			log.info(">>> Enviar E-mails de notificação");
			emailEnviado = this.enviarEmailNotificacaoParticipante(participante, token);
			if (!emailEnviado)
				log.info(">>> Erro ao enviar e-mail de notificação");

			//cancelar os boletos em aberto
			log.info(">>> Cancelar boletos em aberto");
			cancelarBoleto = cancelarBoletoParticipante(participante);
			if (!cancelarBoleto)
				log.info(">>> Erro ao cancelar boletos");

			//Processar Termo Aceite
			log.info(">>> Enviar Termo para o Ged");
			etapaSolicitacaoRealizada = this.enviarTermoParaGed(this.termoAnulacaoInscricaoBase64, participante, token);
			if (!etapaSolicitacaoRealizada)
				log.info(">>> Erro ao enviar Termo para o ged");

		} else {
			log.info("Erro ao gerar o termo de anulação de inscrição.");
		}

	}

	public String montarTermoAceite(Participante participante) {
		String termoAceiteBase64 = "";

		try {

			log.info("Gerar o termo de aceite");
			// Gerar o termo de aceite
			try {

				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = context.getRealPath("/imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				String logoBbpb = context.getRealPath("/imagens/LogotiposExterno/BBPrevBrasil-01.png");

				parametros.put("logo", logo);
				parametros.put("logoBbpb", logoBbpb);
				parametros.put("nomePatrocinadora", participante.getEntidadeParticipante().getNomeAbreviadoEntidadeParticipante());
				parametros.put("cnpb", participante.getListaParticipantePlano().get(0).getPlanoPrevidencia().getPlanoGuardaChuva().getCnpb());

				parametros.put("nomeParticipante", participante.getNomeParticipante());
				parametros.put("cpf", UtilJava.formatarCPF(participante.getCpf()));

				parametros.put("email", participante.getEnderecoEmail() != null ? participante.getEnderecoEmail() : participante.getEnderecoEmailSec() != null ? participante.getEnderecoEmailSec()
						: "");

				parametros.put("matricula", participante.getNumeroMatriculaPatrocinadora());
				List<Participante> lista = new ArrayList<Participante>();
				lista.add(participante);

				String nomeRelatorio = relatorioUtil.gerarRelatorio("termoAnulacaoInscricao", lista, parametros);

				termoAceiteBase64 = this.retornarRelatorioBase64(nomeRelatorio);

			} catch (PrevidenciaException pEx) {
				log.error("Erro ao exportar relatório.", pEx);
				log.error(pEx.getMessage());

			} catch (Exception ex) {
				log.error(ex.getMessage());

			}

		} catch (Exception e) {

			log.error(e.getMessage());

		}

		return termoAceiteBase64;

	}

	public String retornarRelatorioBase64(String fileName) {
		String arquivoBase64 = "";
		try {
			File arquivo = new File(reportSourcePath() + fileName);
			InputStream finput = new FileInputStream(arquivo);
			byte[] imageBytes = new byte[(int) arquivo.length()];
			finput.read(imageBytes, 0, imageBytes.length);
			finput.close();
			arquivoBase64 = Base64.encodeBase64String(imageBytes);

		} catch (FileNotFoundException e) {
			log.error(e);
			throw new PrevidenciaException(e);

		} catch (IOException ie) {
			log.error(ie);
			throw new PrevidenciaException(ie);

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException(e);

		}

		return arquivoBase64;

	}

	/**
	 * Retorna caminho onde os relatórios (.jasper e .jrxml e tmps) ficam
	 * armazenados
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * */
	private String reportSourcePath() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance().getExternalContext().getRealPath("/relatorios/") + "/";
		} else {
			return context.getRealPath("/relatorios/") + "/";
		}
	}

	private Boolean enviarEmailNotificacaoParticipante(Participante participante, String token) {

		Boolean emailNotificacaoEnviado = false;

		try {
			String mensagemParticipante = "</p>Prezado(a) " + participante.getNomeParticipante().toUpperCase() + ",</p>"
					+ "<p>Recebemos sua solicitação de desistência do plano, favor aguardar o contato da nossa de equipe de relacionamento com o cliente.</p>";

			String mensagemAreas = "</p>Prezados,</p>"
					+ "<p>No dia " + UtilJava.formataDataPorPadrao(new Date(), "dd/MM/yyyy") + 
					" recebemos a solicitação de desistência do plano do participante " + participante.getNomeParticipante().toUpperCase()  + ".</p>";

			List<EntidadeParticipanteEmailContatoDTO> listaContatos = this.entidadeEmailContatoBO.listarEmailContatoEntidade();

			String contatoPatrocinadora = listaContatos.stream()
						.filter(a -> a.getCodigoEntidade().equals(participante.getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante()))
						.findFirst().orElse(null).getEmailContatoPrincipal();
			
			String toAreas = null;
			String to = null;
			
			toAreas = (contatoPatrocinadora == null ? "" : contatoPatrocinadora + ",") +
						"relacionamento@bbprevidencia.com.br,devolucao@bbprevidencia.com.br";
				
			to = participante.getEnderecoEmail() != null ? participante.getEnderecoEmail() : 
					participante.getEnderecoEmailSec() != null ? participante.getEnderecoEmailSec() : "";
			
//			toAreas = "thiago.cavalcante@bbprevidencia.com.br,thallita@bbprevidencia.com.br";
//				
//			to = "thiago.cavalcante@bbprevidencia.com.br,thallita@bbprevidencia.com.br";
				
			String assunto = "Solicitação de Anulação de Inscrição - " + participante.getNomeParticipante().toUpperCase();

			restTemplate = new RestTemplate();
			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
			interceptors.add(new HeaderRequestInterceptor("AuthToken", token));
			restTemplate.setInterceptors(interceptors);

			AnexoDTO anexo = AnexoDTO.builder().base64(this.termoAnulacaoInscricaoBase64).nome("TERMO_ANULACAO_INSCRICAO_" + participante.getNomeParticipante().replace(" ", "_")).extensao(".pdf")
					.build();

			List<AnexoDTO> anexos = Arrays.asList(anexo);

			EmailDTO emailParticipante = EmailDTO.builder().anexos(anexos).assunto(assunto).destinatario(to).mensagem(mensagemParticipante).remetente("bbprevidencia@bbprevidencia.com.br").build();

			EmailDTO emailAreas = EmailDTO.builder().anexos(anexos).assunto(assunto).destinatario(toAreas).mensagem(mensagemAreas).remetente("bbprevidencia@bbprevidencia.com.br").build();

			String url = this.comunicacaoApiUrl + "/email/enviarEmail";

			EmailRetornoDTO emailRetornoParticipante = restTemplate.postForObject(url, emailParticipante, EmailRetornoDTO.class);
			
			EmailRetornoDTO emailRetornoAreas = restTemplate.postForObject(url, emailAreas, EmailRetornoDTO.class);

			emailNotificacaoEnviado = emailRetornoParticipante.getEmailEnviado();

		} catch (Exception e) {

			log.error(e.getMessage());

		}

		return emailNotificacaoEnviado;

	}

	private boolean cancelarBoletoParticipante(Participante participante) {
		boolean boletoCancelado = false;
		try {
			for (ParticipantePlano a : participante.getListaParticipantePlano()) {
				boletoCancelado = this.solicitacaoOptOutBO.cancelarBoletoParticipante(a);
			}
		} catch (Exception e) {
			log.error(e);
		}

		return boletoCancelado;
	}

	private boolean enviarTermoParaGed(String arquivoBase64, Participante participante, String token) {
		log.info("Enviando Temo de Anulação da Inscrição");

		boolean retornoProcessamento = false;
		try {
			if (!StringUtils.isBlank(token)) {
				log.info("Preparando UPLOAD Termo Anulação de Inscrição");
				retornoProcessamento = this.cloudDocsBO.enviarArquivoWiz("termoAnulacaoInscricao", arquivoBase64, "TERMO DE ANULAÇÃO DE INSCRIÇÃO (OPT-OUT)", participante, token);
			} else {
				log.error("Erro ao obter token de acesso.");
				return false;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		return retornoProcessamento;

	}

}
