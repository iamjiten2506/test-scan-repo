package br.com.bbprevidencia.devolucao.dto;

public class RelatorioCreditoBancarioAnaliticoDTO implements Comparable<RelatorioCreditoBancarioAnaliticoDTO> {

	private String nomePatrocinadora;

	private String nomeParticipante;

	private String nomeRealParticipante;

	private String nomePlanoDestino;

	private String matriculaParticipante;

	private String cpfParticipante;

	private String nomeBanco;

	private String tipoPagamentoConta;

	private String codigoBanco;

	private String codigoAgencia;

	private String numeroConta;

	private Double valorPago;

	public String getNomePatrocinadora() {
		return nomePatrocinadora;
	}

	public void setNomePatrocinadora(String nomePatrocinadora) {
		this.nomePatrocinadora = nomePatrocinadora;
	}

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public String getTipoPagamentoConta() {
		return tipoPagamentoConta;
	}

	public void setTipoPagamentoConta(String tipoPagamentoConta) {
		this.tipoPagamentoConta = tipoPagamentoConta;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getCpfParticipante() {
		return cpfParticipante;
	}

	public void setCpfParticipante(String cpfParticipante) {
		this.cpfParticipante = cpfParticipante;
	}

	public String getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public String getCodigoAgencia() {
		return codigoAgencia;
	}

	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public Double getValorPago() {
		return valorPago;
	}

	public void setValorPago(Double valorPago) {
		this.valorPago = valorPago;
	}

	public String getNomeRealParticipante() {
		return nomeRealParticipante;
	}

	public void setNomeRealParticipante(String nomeRealParticipante) {
		this.nomeRealParticipante = nomeRealParticipante;
	}

	public String getNomePlanoDestino() {
		return nomePlanoDestino;
	}

	public void setNomePlanoDestino(String nomePlanoDestino) {
		this.nomePlanoDestino = nomePlanoDestino;
	}

	@Override
	public int compareTo(RelatorioCreditoBancarioAnaliticoDTO o) {
		int valor = this.nomePatrocinadora.compareTo(o.nomePatrocinadora) * 1;

		if (valor == 0) {
			valor = this.nomeBanco.compareTo(o.nomeBanco) * 1;

			if (valor == 0) {
				valor = this.tipoPagamentoConta.compareTo(o.tipoPagamentoConta);
			}
		}

		return valor;
	}

}
