package br.com.bbprevidencia.devolucao.dto;

public class RelatorioQuantitativoConsolidadoDTO {

	private String nomeEmpresa;

	private String nomePlano;

	private String nomePlanoGuardaChuva;

	private String nomeTipoDevolucao;

	private String ano;

	private String mes;

	private Integer quantidade;

	private Double valor;

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomePlanoGuardaChuva() {
		return nomePlanoGuardaChuva;
	}

	public void setNomePlanoGuardaChuva(String nomePlanoGuardaChuva) {
		this.nomePlanoGuardaChuva = nomePlanoGuardaChuva;
	}

	public String getNomeTipoDevolucao() {
		return nomeTipoDevolucao;
	}

	public void setNomeTipoDevolucao(String nomeTipoDevolucao) {
		this.nomeTipoDevolucao = nomeTipoDevolucao;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

}
