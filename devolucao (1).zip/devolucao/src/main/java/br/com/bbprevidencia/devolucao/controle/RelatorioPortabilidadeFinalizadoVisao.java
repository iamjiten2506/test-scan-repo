package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioPortabilidadeFinalizadoDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.pessoa.bo.PessoaEntidadeBO;
import br.com.bbprevidencia.pessoa.dto.PessoaEntidade;

/**
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 250/01/2018
 *
 */
@Scope("session")
@Component("relatorioPortabilidadeFinalizadoVisao")
public class RelatorioPortabilidadeFinalizadoVisao {

	private static final Logger log = Logger.getLogger(RelatorioPortabilidadeFinalizadoVisao.class);

	private static String FW_RELATORIO_PORTABILIDADE_FINALIZADO = "/paginas/relatorioPortabilidadeFinalizado.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private PessoaEntidadeBO pessoaEntidadeBO;

	private List<RelatorioPortabilidadeFinalizadoDTO> listaRelatorioPortabilidadeFinalizado;

	private List<PessoaEntidade> listaPessoaEntidade;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private PessoaEntidade pessoaEntidade;

	private CronogramaDevolucao cronogramaDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	/**
	 * Inicia a tela
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 25/01/2018
	 * @return
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		this.listaPessoaEntidade = this.pessoaEntidadeBO.listarTodosPessoaEntidadeAreaAtuacao();
		this.listaCronogramaDevolucao = this.cronogramaDevolucaoBO.listarCronogramaDescendente();
		limparPesquisa();

		return FW_RELATORIO_PORTABILIDADE_FINALIZADO;
	}

	/**
	 * Limpa as informações de pesquisa que estiver na tela
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 25/01/2018
	 */
	public void limparPesquisa() {
		this.pessoaEntidade = new PessoaEntidade();
		this.cronogramaDevolucao = new CronogramaDevolucao();
		this.listaRelatorioPortabilidadeFinalizado = new ArrayList<RelatorioPortabilidadeFinalizadoDTO>();
	}

	/**
	 * Pesquisa as informações baseadas nos parâmetros de pesquisa
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 25/01/2018
	 */
	public void pesquisar() {
		try {
			this.listaRelatorioPortabilidadeFinalizado = new ArrayList<RelatorioPortabilidadeFinalizadoDTO>(this.devolucaoBO.extrairRelatorioPortabilidadeFinalizado(
					this.cronogramaDevolucao == null ? null : this.cronogramaDevolucao.getCodigo(),
					this.pessoaEntidade == null ? null : this.pessoaEntidade.getCodigo()));

			if (UtilJava.isColecaoVazia(this.listaRelatorioPortabilidadeFinalizado)) {
				Mensagens.addMsgWarn("Não foram encontradas portabiliades para os parâmetros informados!");
			}
		} catch (Exception e) {
			throw new PrevidenciaException(e.getMessage());
		}
	}

	/************  GETTER AND SETTER ********************/
	public List<RelatorioPortabilidadeFinalizadoDTO> getListaRelatorioPortabilidadeFinalizado() {
		return listaRelatorioPortabilidadeFinalizado;
	}

	public void setListaRelatorioPortabilidadeFinalizado(List<RelatorioPortabilidadeFinalizadoDTO> listaRelatorioPortabilidadeFinalizado) {
		this.listaRelatorioPortabilidadeFinalizado = listaRelatorioPortabilidadeFinalizado;
	}

	public List<PessoaEntidade> getListaPessoaEntidade() {
		return listaPessoaEntidade;
	}

	public void setListaPessoaEntidade(List<PessoaEntidade> listaPessoaEntidade) {
		this.listaPessoaEntidade = listaPessoaEntidade;
	}

	public PessoaEntidade getPessoaEntidade() {
		return pessoaEntidade;
	}

	public void setPessoaEntidade(PessoaEntidade pessoaEntidade) {
		this.pessoaEntidade = pessoaEntidade;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

}
