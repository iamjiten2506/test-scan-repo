package br.com.bbprevidencia.devolucao.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.LoteProcessamentoDevolucao;
import br.com.bbprevidencia.infra.repository.JpaDao;

/**
 * Classe de acesso aos dados de Lote Processamento Devolução
 *
 * @author  BBPF0351 - Marco Figueiredo
 * @since   23/01/2017
 * 
 *Copyright notice (c) 2016 BBPrevidência S/A
 */
@Repository
@Qualifier("loteProcessamentoDao")
@Scope(proxyMode = ScopedProxyMode.NO, value = "prototype")
public class LoteProcessamentoDevolucaoDAO extends JpaDao<LoteProcessamentoDevolucao> implements Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(LoteProcessamentoDevolucaoDAO.class);

	/**
	 * Salva ou altera um lote processamento devolução correspondente. Salva se o mesmo já contenha
	 * id na sessao do provedor de persistência, ou insere se nao há id
	 * correspondente.
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 23/01/2017
	 * @param {@link LoteProcessamentoDevolucao}
	 * @throws PrevidenciaException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void salvarLoteProcessamentoDevolucao(LoteProcessamentoDevolucao loteProcessamentoDevolucao) throws PrevidenciaException {

		if (loteProcessamentoDevolucao == null) {
			throw new PrevidenciaException("O lote processamento devolução deve estar inicializado para inserçao ou alteraçao.");
		} else {

			try {
				if (loteProcessamentoDevolucao.getCodigo() != null) {
					update(loteProcessamentoDevolucao);
				} else {
					save(loteProcessamentoDevolucao);
				}
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Exclui lote de processamento devoluçao.
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since  23/01/2017
	 * @param  {@link LoteProcessamentoDevolucao}
	 * @throws PrevidenciaException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void apagarLoteProcessamentoDevolucao(LoteProcessamentoDevolucao loteProcessamentoDevolucao) throws PrevidenciaException {

		if (loteProcessamentoDevolucao == null) {
			throw new PrevidenciaException("O lote processamento devolução deve estar preenchida.");
		} else {

			try {
				delete(loteProcessamentoDevolucao.getCodigo());
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Método responsável por pesquisar lote processamento devolução por código
	 * 
	 * @author BBPF0351 - Marco Figueiredo
	 * @since  23/01/2017
	 * @param  Long
	 * @return {@link LoteProcessamentoDevolucao}
	 * @throws PrevidenciaException
	 */
	public LoteProcessamentoDevolucao pesquisarLoteProcessamentoDevolucaoPorCodigo(Long numero) throws PrevidenciaException {

		try {

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT FUS ");
			sql.append("   from LoteProcessamentoDevolucao FUS ");
			sql.append("  WHERE FUS.codigo =  ? ");

			return (LoteProcessamentoDevolucao) getEntityManager().createQuery(sql.toString()).setParameter(1, numero).getSingleResult();

		} catch (NoResultException ex) {
			log.error(ex);
			throw new PrevidenciaException("Não encontrada mensagem lote processamento devolucao solicitado");
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * Método responsável por listar lotes processamento devolução por CronogramaDevolucao
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   01/02/2017
	 * @param   cronogramaDevolucao
	 * @return  {@link List<LoteProcessamentoDevolucao>}
	 * @throws  PrevidenciaException
	 */
	public List<LoteProcessamentoDevolucao> listarLoteProcessamentoDevolucaoPorCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) throws PrevidenciaException {

		try {

			List<LoteProcessamentoDevolucao> listaLoteProcessamentoDevolucao = new ArrayList<LoteProcessamentoDevolucao>();

			StringBuilder sql = new StringBuilder();

			sql.append(" SELECT FUS ");
			sql.append("   from LoteProcessamentoDevolucao FUS ");
			sql.append("  WHERE FUS.cronogramaDevolucao =  ? ");
			sql.append("  ORDER BY dataLoteProcessamento desc");

			listaLoteProcessamentoDevolucao = getEntityManager().createQuery(sql.toString()).setParameter(1, cronogramaDevolucao).getResultList();

			return listaLoteProcessamentoDevolucao;

		} catch (NoResultException ex) {
			log.error(ex);
			throw new PrevidenciaException("Não encontrada mensagem lote processamento devolucao para cronograma solicitado");
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * Método responsável por listar lotes processamento devolução de tipo processamento  por CronogramaDevolucao
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   01/02/2017
	 * @param   cronogramaDevolucao
	 * @return  {@link List<LoteProcessamentoDevolucao>}
	 * @throws  PrevidenciaException
	 */
	public List<LoteProcessamentoDevolucao> listarLoteProcessamentoDevolucaoTipoProcessamentoPorCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) throws PrevidenciaException {

		try {

			List<LoteProcessamentoDevolucao> listaLoteProcessamentoDevolucao = new ArrayList<LoteProcessamentoDevolucao>();

			for (LoteProcessamentoDevolucao loteProcessamentoDevolucao : listarLoteProcessamentoDevolucaoPorCronogramaDevolucao(cronogramaDevolucao)) {

				if (loteProcessamentoDevolucao.getTipoProcessamento().equals("P")) {
					listaLoteProcessamentoDevolucao.add(loteProcessamentoDevolucao);
				}
			}

			return listaLoteProcessamentoDevolucao;

		} catch (NoResultException ex) {
			log.error(ex);
			throw new PrevidenciaException("Não encontrada mensagem lote processamento devolucao do tipo processamento para cronograma solicitado");
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

	/**
	 * Método responsável por listar lotes processamento devolução de tipo integracao  por CronogramaDevolucao
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   01/02/2017
	 * @param   cronogramaDevolucao
	 * @return  {@link List<LoteProcessamentoDevolucao>}
	 * @throws  PrevidenciaException
	 */
	public List<LoteProcessamentoDevolucao> listarLoteProcessamentoDevolucaoTipoIntegracaoPorCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) throws PrevidenciaException {

		try {

			List<LoteProcessamentoDevolucao> listaLoteProcessamentoDevolucao = new ArrayList<LoteProcessamentoDevolucao>();

			for (LoteProcessamentoDevolucao loteProcessamentoDevolucao : listarLoteProcessamentoDevolucaoPorCronogramaDevolucao(cronogramaDevolucao)) {

				if (loteProcessamentoDevolucao.getTipoProcessamento().equals("I")) {
					listaLoteProcessamentoDevolucao.add(loteProcessamentoDevolucao);
				}
			}

			return listaLoteProcessamentoDevolucao;

		} catch (NoResultException ex) {
			log.error(ex);
			throw new PrevidenciaException("Não encontrada mensagem lote processamento devolucao do tipo integração para cronograma solicitado");
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e);
		}

	}

}
