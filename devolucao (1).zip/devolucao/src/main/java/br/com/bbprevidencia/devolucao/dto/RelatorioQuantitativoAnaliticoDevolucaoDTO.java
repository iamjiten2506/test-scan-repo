package br.com.bbprevidencia.devolucao.dto;

public class RelatorioQuantitativoAnaliticoDevolucaoDTO {

	private String nomePlano;
	private String mesAno;
	private String nomeParticipante;
	private String matricula;
	private String cpfParticipante;

	public String getMesAno() {
		return mesAno;
	}

	public void setMesAno(String mesAno) {
		this.mesAno = mesAno;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCpfParticipante() {
		return cpfParticipante;
	}

	public void setCpfParticipante(String cpfParticipante) {
		this.cpfParticipante = cpfParticipante;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	@Override
	public String toString() {
		return "RelatorioQuantitativoAnaliticoDevolucaoDTO [nomePlano=" + nomePlano + ", mesAno=" + mesAno + ", matricula=" + matricula + ", cpfParticipante=" + cpfParticipante
				+ ", nomeParticipante=" + nomeParticipante + "]";
	}

}
