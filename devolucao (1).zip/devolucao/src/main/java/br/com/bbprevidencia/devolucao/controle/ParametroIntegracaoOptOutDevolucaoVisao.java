package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.contabilidade.bo.OperacaoInternaBO;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.devolucao.bo.ParametroIntegracaoOptOutDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RubricaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.ParametroIntegracaoOptOutDevolucao;
import br.com.bbprevidencia.devolucao.dto.RubricaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Classe controller que manipula as requisições do Parâmetro de Integração OptOut.
 * 
 * @author Carlos Wallace
 * @since 04/08/2020
 * 
 * Copyright notice (c) 2020 BBPrevidência S/A
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
@Scope("session")
@Component("parametroIntegracaoOptOutDevolucaoVisao")
public class ParametroIntegracaoOptOutDevolucaoVisao {
	private static String FW_PARAMETRO_INTEGRACAO_OPTOUT_DEV = "/paginas/parametroIntegracaoOptOutDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private ParametroIntegracaoOptOutDevolucaoBO parametroIntegracaoOptOutDevolucaoBO;

	@Autowired
	private RubricaDevolucaoBO rubricaDevolucaoBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private OperacaoInternaBO operacaoInternaBO;

	private List<ParametroIntegracaoOptOutDevolucao> listaParametroIntegracaoOptOutDevolucao;

	private List<RubricaDevolucao> listaRubricaDevolucao;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<OperacaoInterna> listaOperacaoInternaEstContribCustPartic;

	private List<OperacaoInterna> listaOperacaoInternaEstContribCustPatron;

	private List<OperacaoInterna> listaOperacaoInternaTaxaCarregPartic;

	private List<OperacaoInterna> listaOperacaoInternaTaxaCarregPatron;

	private List<OperacaoInterna> listaOperacaoInternaDevRecPartic;

	private List<OperacaoInterna> listaOperacaoInternaDevRecPatron;

	private ParametroIntegracaoOptOutDevolucao parametroIntegracaoOptOutDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private RubricaDevolucao rubricaDevolucao;
	private PlanoPrevidencia planoPrevidencia;
	private OperacaoInterna operacaoInternaEstContribCustPartic;
	private OperacaoInterna operacaoInternaEstContribCustPatron;
	private OperacaoInterna operacaoInternaTaxaCarregPartic;
	private OperacaoInterna operacaoInternaTaxaCarregPatron;
	private OperacaoInterna operacaoInternaDevRecPartic;
	private OperacaoInterna operacaoInternaDevRecPatron;

	private OperacaoInterna operacaoInternaSobante;
	private OperacaoInterna operacaoInternaFaltante;
	private OperacaoInterna operacaoInternaDevAtualizacaoPartic;
	private OperacaoInterna operacaoInternaDevAtualizacaoPatron;

	private Date dataInicioVigencia;

	private Date dataTerminoVigencia;

	private String nomeIndice;

	public String iniciarParametroIntegracaoOptOutDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("parametroIntegracaoContabilFinanceiraDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
		this.listarStatus = true;
		this.limparTela();

		this.listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBO.listarRubricaDevolucao());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanoPrevidencia());

		this.listaOperacaoInternaEstContribCustPartic = new ArrayList<OperacaoInterna>(this.operacaoInternaBO.listarTodasOperacaoInterna());
		this.listaOperacaoInternaEstContribCustPatron = this.listaOperacaoInternaEstContribCustPartic;
		this.listaOperacaoInternaTaxaCarregPartic = this.listaOperacaoInternaEstContribCustPartic;
		this.listaOperacaoInternaTaxaCarregPatron = this.listaOperacaoInternaEstContribCustPartic;
		this.listaOperacaoInternaDevRecPartic = this.listaOperacaoInternaEstContribCustPartic;
		this.listaOperacaoInternaDevRecPatron = this.listaOperacaoInternaEstContribCustPartic;

		this.listaParametroIntegracaoOptOutDevolucao = new ArrayList<ParametroIntegracaoOptOutDevolucao>(this.parametroIntegracaoOptOutDevolucaoBO.listarParametroIntegracaoOptOutDevolucao());
		return FW_PARAMETRO_INTEGRACAO_OPTOUT_DEV;
	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da página
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since 	11/08/2020
	 * 
	 */
	public void limparTela() {
		this.rubricaDevolucao = null;
		this.planoPrevidencia = null;
		this.operacaoInternaEstContribCustPartic = null;
		this.operacaoInternaEstContribCustPatron = null;
		this.operacaoInternaTaxaCarregPartic = null;
		this.operacaoInternaTaxaCarregPatron = null;
		this.operacaoInternaDevRecPartic = null;
		this.operacaoInternaDevRecPatron = null;
		this.operacaoInternaSobante = null;
		this.operacaoInternaFaltante = null;
		this.operacaoInternaDevAtualizacaoPartic = null;
		this.operacaoInternaDevAtualizacaoPatron = null;
		this.listaParametroIntegracaoOptOutDevolucao = new ArrayList<ParametroIntegracaoOptOutDevolucao>(this.parametroIntegracaoOptOutDevolucaoBO.listarParametroIntegracaoOptOutDevolucao());
	}

	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since 11/08/2020
	 */
	public void controlarEdicaoVisualizacao() {
		if (isListarStatus()) {
			rubricaDevolucao = new RubricaDevolucao();
			planoPrevidencia = new PlanoPrevidencia();
			this.operacaoInternaEstContribCustPartic = new OperacaoInterna();
			this.operacaoInternaEstContribCustPatron = new OperacaoInterna();
			this.operacaoInternaTaxaCarregPartic = new OperacaoInterna();
			this.operacaoInternaTaxaCarregPatron = new OperacaoInterna();
			this.operacaoInternaDevRecPartic = new OperacaoInterna();
			this.operacaoInternaDevRecPatron = new OperacaoInterna();
			this.operacaoInternaSobante = new OperacaoInterna();
			this.operacaoInternaFaltante = new OperacaoInterna();
			this.operacaoInternaDevAtualizacaoPartic = new OperacaoInterna();
			this.operacaoInternaDevAtualizacaoPatron = new OperacaoInterna();
			this.listaParametroIntegracaoOptOutDevolucao = new ArrayList<ParametroIntegracaoOptOutDevolucao>(this.parametroIntegracaoOptOutDevolucaoBO.listarParametroIntegracaoOptOutDevolucao());
		}
		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método que seleciona um Parâmetro de Integração OptOut, e a colocar em modo de edição. 
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since 11/08/2020
	 * @param {@link ParametroIntegracaoOptOutDevolucao}
	 */
	public void editarParamIntOptOut(ParametroIntegracaoOptOutDevolucao parametroIntegracaoOptOutDevolucao) {
		System.out.println(parametroIntegracaoOptOutDevolucao.toString());
		parametroIntegracaoOptOutDevolucao.setDataAlteracao(new Date());
		parametroIntegracaoOptOutDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
		setParametroIntegracaoOptOutDevolucao(parametroIntegracaoOptOutDevolucao);
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método que chama a tela para um novo cadastro de Parâmetro de Integração OptOut.
	 * @author BBPF0468	- Carlos Wallace
	 * @since 11/08/2020
	 */
	public void cadastrarNovoParametroIntegracaoOptOut() {
		this.parametroIntegracaoOptOutDevolucao = new ParametroIntegracaoOptOutDevolucao();
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método para salvar ou atualizar um Parâmetro Integracao OptOut
	 * 
	 * @author BBPF0468
	 * @since 11/08/2020
	 */
	public String salvarParametroIntegracaoOptOut() {
		try {
			if (this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaEstContribCustPartic() == null && this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaEstContribCustPatron() == null
					&& this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaTaxaCarregPartic() == null && this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaTaxaCarregPatron() == null
					&& this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaDevRecPartic() == null && this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaDevRecPatron() == null
					&& this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaDevAtualizacaoPartic() == null
					&& this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaDevAtualizacaoPatron() == null && this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaFaltante() == null
					&& this.parametroIntegracaoOptOutDevolucao.getOperacaoInternaSobrante() == null) {
				throw new PrevidenciaException("As Operações Internas devem ser selecionadas antes de salvar.");
			}

			if (this.parametroIntegracaoOptOutDevolucao.getCodigo() == null) {
				this.parametroIntegracaoOptOutDevolucao.setDataInclusao(new Date());
				this.parametroIntegracaoOptOutDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			} else {
				this.parametroIntegracaoOptOutDevolucao.setDataAlteracao(new Date());
				this.parametroIntegracaoOptOutDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			}

			this.parametroIntegracaoOptOutDevolucaoBO.salvarParametroIntegracaoContabilFinanceiraDevolucao(this.parametroIntegracaoOptOutDevolucao);
			controlarEdicaoVisualizacao();

			this.listaParametroIntegracaoOptOutDevolucao = new ArrayList<ParametroIntegracaoOptOutDevolucao>(this.parametroIntegracaoOptOutDevolucaoBO.listarParametroIntegracaoOptOutDevolucao());

			Mensagens.addMsgInfo("Parâmetro " + (this.parametroIntegracaoOptOutDevolucao.getCodigo() == null ? "salvo" : "atualizado") + " com sucesso!");
			return "FW_PARAMETRO_INTEGRACAO_CONTABIL_FINANCEIRA_DEV";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar Parâmetro Integração OptOut.");
			return "";
		}

	}

	/**
	 * Método encarregado de deletar um registro Parâmetro de Integração OptOut.
	 * 
	 * @author  BBPF0468 - Carlos Wallace 
	 * @since 10/08/2020
	 * @param {@link ParametroIntegracaoOptOutDevolucao}
	 * @return {@link String}
	 */
	public String deletarParametroIntegracaoOptOut(ParametroIntegracaoOptOutDevolucao parametroIntegracaoOptOutDevolucao) {
		try {
			this.parametroIntegracaoOptOutDevolucaoBO.apagarParametroIntegracaoContabilFinanceiraDevolucao(parametroIntegracaoOptOutDevolucao);
			this.listaParametroIntegracaoOptOutDevolucao = new ArrayList<ParametroIntegracaoOptOutDevolucao>(this.parametroIntegracaoOptOutDevolucaoBO.listarParametroIntegracaoOptOutDevolucao());
			Mensagens.addMsgInfo("Parâmetro excluído com sucesso!");
			return "FW_PARAMETRO_INTEGRACAO_CONTABIL_FINANCEIRA_DEV";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar o Parâmetro");
			return "";
		}
	}

	/**
	 * Método para retornar a Lista de Parâmetros Integração Contábil e finaceiro, que atenda os critérios de pesquisa.
	 * 
	 * @author  BBPF0468 -  Carlos Wallace
	 * @since 	11/08/2020
	 * @return  List<{@link }>
	 */
	public void filtrarListaParametroInterno() {
		if (this.planoPrevidencia != null) {

			this.listaParametroIntegracaoOptOutDevolucao = new ArrayList<ParametroIntegracaoOptOutDevolucao>(this.parametroIntegracaoOptOutDevolucaoBO.filtrarListaParametroIntegracaoOptOutDevolucao(
					this.planoPrevidencia,
					dataInicioVigencia,
					dataTerminoVigencia));

		} else {
			this.listaParametroIntegracaoOptOutDevolucao = new ArrayList<ParametroIntegracaoOptOutDevolucao>(this.parametroIntegracaoOptOutDevolucaoBO.listarParametroIntegracaoOptOutDevolucao());
		}
	}

}
