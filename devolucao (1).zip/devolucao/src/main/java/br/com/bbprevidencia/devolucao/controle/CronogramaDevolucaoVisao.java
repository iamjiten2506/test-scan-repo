package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoFolhaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoFolhaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.folha.bo.SituacaoFolhaBO;
import br.com.bbprevidencia.folha.dto.SituacaoFolha;
import br.com.bbprevidencia.folha.enumerador.SituacaoFolhaEnum;
import br.com.bbprevidencia.utils.data.UtilData;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter os Cronogramas de Devolução
 * 
 * @author  BBPF0152 - Thiago de Castro Xavier
 * @since 06/02/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("cronogramaDevolucaoVisao")
public class CronogramaDevolucaoVisao {

	private static String FW_CRONOGRAMA_DEVOLUCAO = "/paginas/cronogramaDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private TipoFolhaDevolucaoBO tipoFolhaDevolucaoBO;

	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	private TipoFolhaDevolucao tipoFolhaDevolucao;

	private List<TipoFolhaDevolucao> listaTipoFolhaDevolucao;

	@Autowired
	private SituacaoFolhaBO situacaoFolhaBO;

	private SituacaoFolha situacaoFolha;

	private List<SituacaoFolha> listaSituacaoFolha = new ArrayList<SituacaoFolha>();

	private Long codigoTipoSituacaoFolha;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private List<CronogramaDevolucao> listaFiltrada;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private CronogramaDevolucao cronogramaDevolucao;

	private SituacaoDevolucao situacaoDevolucao;

	private boolean edicao = false;

	/**
	 * Método encarregado por iniciar a página dos cronogramas de devolução
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 06/02/2017
	 * @return {@link String}
	 */
	public String inciciarCronogramaDevolucao() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("cronogramaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.listarStatus = true;

		cronogramaDevolucao = new CronogramaDevolucao();

		this.listaCronogramaDevolucao = null;

		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarTodosCronogramaDevolucao());

		this.listaTipoFolhaDevolucao = new ArrayList<TipoFolhaDevolucao>(tipoFolhaDevolucaoBO.listarTodosTipoFolhaDevolucao());

		//Pesquisa folha somente para abertura
		this.listaSituacaoFolha.add(situacaoFolhaBO.pesquisarSituacaoFolhaCodigo(SituacaoFolhaEnum.ABERTA.getCodigo()));

		return FW_CRONOGRAMA_DEVOLUCAO;
	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da página
	 * 
	 * @author  BBPF0415 - Thiago de Castro Xavier
	 * @since 	06/02/2017
	 * 
	 */
	public void limparPesquisa() {

		this.tipoFolhaDevolucao = null;

		listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarTodosCronogramaDevolucao());
	}

	/**
	 * Método que coloca a pagina em modo de edição
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 19/01/2017
	 */
	public void cadastrarNovoCronogramaDevolucao() {
		this.edicao = false;
		cronogramaDevolucao = new CronogramaDevolucao();

		this.situacaoFolha = situacaoFolhaBO.pesquisarSituacaoFolhaCodigo(SituacaoFolhaEnum.ABERTA.getCodigo());

		cronogramaDevolucao.setSituacaoFolha(this.situacaoFolha);
		controlarEdicaoVisualizacao();
	}

	//Métodos de funcionamento da página
	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * 
	 * @author  BBPF0415 - Thiago de Castro Xavier
	 * @since 106/02/2017
	 */
	public void controlarEdicaoVisualizacao() {
		if (isListarStatus()) {
			tipoFolhaDevolucao = new TipoFolhaDevolucao();
			situacaoDevolucao = new SituacaoDevolucao();
		}

		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarTodosCronogramaDevolucao());

		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método para salvar ou atualizar um Cronograma Devolução
	 * 
	 * @author  BBPF0415 - Thiago de Castro Xavier
	 * @since 06/02/2017
	 * 
	 */
	public String salvarCronogramaDevolucao() {
		try {
			if (UtilData.isDataMenor(this.cronogramaDevolucao.getDataPagamento(), getDataAtual())) {
				Mensagens.addMsgErro("Data de pagamento não pode ser inferior à data atual.");

				return "";
			}

			//Verificar Cronogramas abertos para o tipo de Folha
			if (!this.cronogramaDevolucaoBO.permiteAbrirNovoCronogramaPorTipoDeFolha(this.cronogramaDevolucao)) {
				Mensagens.addMsgErro("Para o tipo de folha " + this.cronogramaDevolucao.getTipoFolhaDevolucao().getNomeTipoFolha() + " existe(m) cronograma(s) em aberto. Favor verificar!");
				return "";
			}

			Long codigo = cronogramaDevolucao.getCodigo();

			if (cronogramaDevolucao.getIndicadorPagarParceladosReferencia() == null) {
				Mensagens.addMsgErro("Indicador de pagamento de parcela é de preenchimento obrigatório");
				return "";
			}

			cronogramaDevolucaoBO.salvarCronogramaDevolucao(cronogramaDevolucao);
			controlarEdicaoVisualizacao();

			Mensagens.addMessage("DEV_VMSG025", codigo == null ? "salvo" : "atualizada");
			return FW_CRONOGRAMA_DEVOLUCAO;
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar a Cronograma de Devolução");
			return "";
		}

	}

	/**
	 * Método que seleciona um cronograma devolução e coloca em modo de edição
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 07/02/2017
	 * @param {@link CronogramaDevolucao}
	 */
	public void editarCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.edicao = true;
		setCronogramaDevolucao(cronogramaDevolucao);
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método encarregado de deletar um Cronograma Devolução
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 25/01/2017
	 * @param {@link CronogramaDevolucao}
	 * @return {@link String}
	 */
	public String apagarCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		try {
			this.edicao = false;

			if (UtilJava.isColecaoDiferenteDeVazia(this.movimentoCalculoPagamentoDevolucaoBO.pesquisarMovimentoCalculoPagamentoDevolucaoPorCronograma(cronogramaDevolucao))
					| UtilJava.isColecaoDiferenteDeVazia(this.historicoPagamentoDevolucaoBO.pesquisarHistoricoPagamentoDevolucaoPorCronograma(cronogramaDevolucao))) {
				Mensagens.addMsgErro("Cronograma já possui cálculo, não pode se excluído");
				return FW_CRONOGRAMA_DEVOLUCAO;
			}

			cronogramaDevolucaoBO.apagarCronogramaDevolucao(cronogramaDevolucao);
			this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarTodosCronogramaDevolucao());

			Mensagens.addMsgInfo("Cronograma Devolução excluído com sucesso!");

			return FW_CRONOGRAMA_DEVOLUCAO;
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return FW_CRONOGRAMA_DEVOLUCAO;
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar a Cronograma de Devolução");
			return FW_CRONOGRAMA_DEVOLUCAO;
		}
	}

	public Date getDataAtual() {
		return new Date();
	}

	public SituacaoFolhaBO getSituacaoFolhaBO() {
		return situacaoFolhaBO;
	}

	public void setSituacaoFolhaBO(SituacaoFolhaBO situacaoFolhaBO) {
		this.situacaoFolhaBO = situacaoFolhaBO;
	}

	public SituacaoFolha getSituacaoFolha() {
		return situacaoFolha;
	}

	public void setSituacaoFolha(SituacaoFolha situacaoFolha) {
		this.situacaoFolha = situacaoFolha;
	}

	public List<SituacaoFolha> getListaSituacaoFolha() {
		return listaSituacaoFolha;
	}

	public void setListaSituacaoFolha(List<SituacaoFolha> listaSituacaoFolha) {
		this.listaSituacaoFolha = listaSituacaoFolha;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public SituacaoDevolucao getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public TipoFolhaDevolucaoBO getTipoFolhaDevolucaoBO() {
		return tipoFolhaDevolucaoBO;
	}

	public void setTipoFolhaDevolucaoBO(TipoFolhaDevolucaoBO tipoFolhaDevolucaoBO) {
		this.tipoFolhaDevolucaoBO = tipoFolhaDevolucaoBO;
	}

	public TipoFolhaDevolucao getTipoFolhaDevolucao() {
		return tipoFolhaDevolucao;
	}

	public void setTipoFolhaDevolucao(TipoFolhaDevolucao tipoFolhaDevolucao) {
		this.tipoFolhaDevolucao = tipoFolhaDevolucao;
	}

	public List<TipoFolhaDevolucao> getListaTipoFolhaDevolucao() {
		return listaTipoFolhaDevolucao;
	}

	public void setListaTipoFolhaDevolucao(List<TipoFolhaDevolucao> listaTipoFolhaDevolucao) {
		this.listaTipoFolhaDevolucao = listaTipoFolhaDevolucao;
	}

	public Long getCodigoTipoSituacaoFolha() {
		return codigoTipoSituacaoFolha;
	}

	public void setCodigoTipoSituacaoFolha(Long codigoTipoSituacaoFolha) {
		this.codigoTipoSituacaoFolha = codigoTipoSituacaoFolha;
	}

	public CronogramaDevolucaoBO getCronogramaDevolucaoBO() {
		return cronogramaDevolucaoBO;
	}

	public void setCronogramaDevolucaoBO(CronogramaDevolucaoBO cronogramaDevolucaoBO) {
		this.cronogramaDevolucaoBO = cronogramaDevolucaoBO;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public boolean isEdicao() {
		return edicao;
	}

	public void setEdicao(boolean edicao) {
		this.edicao = edicao;
	}

	public List<CronogramaDevolucao> getListaFiltrada() {
		return listaFiltrada;
	}

	public void setListaFiltrada(List<CronogramaDevolucao> listaFiltrada) {
		this.listaFiltrada = listaFiltrada;
	}

}
