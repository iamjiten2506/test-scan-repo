package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoContaDevolucaoEnum {

	RESGATAVEL(1L, "Conta com valores resgatáveis de devolução, na data de cálculo da devolução."),
	REVERSAO(2L, "Conta com valores revertidos para o plano na devolução, na data do cálculo da devolução. Não resgtável."),
	REMANESCENTE(3L, "Conta com valores remanescente para pagamento após da data de cálculo da devolução. Carência de contribuição."),
	NAO_RESGATAVEL(4L, "Conta com valores não resgatável, não revertidos para o plano.");

	private Long codigo;
	private String descricao;

	private TipoContaDevolucaoEnum(Long codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public static TipoContaDevolucaoEnum geTipoDocumentoEnum(Long codigo) {
		if (codigo != null) {
			for (TipoContaDevolucaoEnum tipoDocumentoEnum : values()) {
				if (tipoDocumentoEnum.getCodigo().equals(codigo)) {
					return tipoDocumentoEnum;
				}
			}
		}
		return null;

	}

}
