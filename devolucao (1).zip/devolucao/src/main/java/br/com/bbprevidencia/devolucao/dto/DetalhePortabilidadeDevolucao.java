package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PlanoGuardaChuva;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.devolucao.enumerador.TipoDevolucaoInternaEnum;
import br.com.bbprevidencia.devolucao.enumerador.TipoEntidadePortabilidadeEnum;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;
import lombok.Builder;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   23/01/2017
 * Classe de persistência para tabela DET_POR_DEV.
 */
@Entity
@Table(name = "DET_POR_DEV", schema = "OWN_DCR")
@NamedQuery(name = "DetalhePortabilidadeDevolucao.findAll", query = "SELECT q FROM DetalhePortabilidadeDevolucao q")
public class DetalhePortabilidadeDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DET_POR_DEV_GER", sequenceName = "S_DPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DET_POR_DEV_GER")
	@Column(name = "NUM_SEQ_DET_POR_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "COD_PESSOA"), @JoinColumn(name = "COD_AREA_ATUA") })
	private AtuacaoPessoa atuacaoPessoa;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_PLA_DES_POR_DEV")
	private TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidadeDevolucao;

	@Column(name = "NOM_PLA_DES")
	private String nomePlanoDestino;

	@Column(name = "COD_REG_PAR_ENT_DES")
	private String codigoParticEntidadeDestino;

	@Column(name = "COD_REG_PLA_DES")
	private String codigoPlanoEntidadeDestino;

	@Column(name = "DAT_ADE_PLA_DES")
	private Date dataAdesaoPlanoDestino;

	@Column(name = "IND_OPCAO_IMP_REN_DES")
	private String indicadorOpcaoImpostoRendaDestino;

	@Column(name = "COD_APR_PRO_PLA_ORI_ORG_REG")
	private String codigoAprovPlanoOrigemOrgaoRegulador;

	@Column(name = "DAT_APR_PRO_PLA_ORI_ORG_REG")
	private Date dataAprovPlanoOrigemOrgaoRegulador;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLANO")
	private PlanoPrevidencia planoPrevidencia;

	@Transient
	private Integer qtd;

	@Transient
	private PlanoGuardaChuva planoGuardaChuva;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public TipoPlanoDestinoPortabilidadeDevolucao getTipoPlanoDestinoPortabilidadeDevolucao() {
		return tipoPlanoDestinoPortabilidadeDevolucao;
	}

	public void setTipoPlanoDestinoPortabilidadeDevolucao(TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidadeDevolucao) {
		this.tipoPlanoDestinoPortabilidadeDevolucao = tipoPlanoDestinoPortabilidadeDevolucao;
	}

	public String getNomePlanoDestino() {
		return nomePlanoDestino;
	}

	public void setNomePlanoDestino(String nomePlanoDestino) {
		this.nomePlanoDestino = nomePlanoDestino;
	}

	public String getCodigoParticEntidadeDestino() {
		return codigoParticEntidadeDestino;
	}

	public void setCodigoParticEntidadeDestino(String codigoParticEntidadeDestino) {
		this.codigoParticEntidadeDestino = codigoParticEntidadeDestino;
	}

	public String getCodigoPlanoEntidadeDestino() {
		return codigoPlanoEntidadeDestino;
	}

	public void setCodigoPlanoEntidadeDestino(String codigoPlanoEntidadeDestino) {
		this.codigoPlanoEntidadeDestino = codigoPlanoEntidadeDestino;
	}

	public Date getDataAdesaoPlanoDestino() {
		return dataAdesaoPlanoDestino;
	}

	public void setDataAdesaoPlanoDestino(Date dataAdesaoPlanoDestino) {
		this.dataAdesaoPlanoDestino = dataAdesaoPlanoDestino;
	}

	public String getIndicadorOpcaoImpostoRendaDestino() {
		return indicadorOpcaoImpostoRendaDestino;
	}

	public void setIndicadorOpcaoImpostoRendaDestino(String indicadorOpcaoImpostoRendaDestino) {
		this.indicadorOpcaoImpostoRendaDestino = indicadorOpcaoImpostoRendaDestino;
	}

	public String getCodigoAprovPlanoOrigemOrgaoRegulador() {
		return codigoAprovPlanoOrigemOrgaoRegulador;
	}

	public void setCodigoAprovPlanoOrigemOrgaoRegulador(String codigoAprovPlanoOrigemOrgaoRegulador) {
		this.codigoAprovPlanoOrigemOrgaoRegulador = codigoAprovPlanoOrigemOrgaoRegulador;
	}

	public Date getDataAprovPlanoOrigemOrgaoRegulador() {
		return dataAprovPlanoOrigemOrgaoRegulador;
	}

	public void setDataAprovPlanoOrigemOrgaoRegulador(Date dataAprovPlanoOrigemOrgaoRegulador) {
		this.dataAprovPlanoOrigemOrgaoRegulador = dataAprovPlanoOrigemOrgaoRegulador;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DetalhePortabilidadeDevolucao other = (DetalhePortabilidadeDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Transient
	public boolean isAberta() {

		if (this.getTipoPlanoDestinoPortabilidadeDevolucao().getTipoEntidadePortabilidadeEnum().equals(TipoEntidadePortabilidadeEnum.A)) {
			return true;
		} else {
			return false;
		}

	}

	@Transient
	public TipoDevolucaoInternaEnum getTipoDevolucaoInternaPorPlano() {

		if (this.devolucao != null) {

			if (this.devolucao.getParticipantePlano().getPlanoPrevidencia().getPlanoGuardaChuva().getCnpb().equals(this.codigoPlanoEntidadeDestino.replace(".", "").replace("-", ""))) {
				return TipoDevolucaoInternaEnum.PORT_INTERNA_MATRICULA;
			}

			if (this.atuacaoPessoa != null) {

				if (this.qtd != null && this.qtd > 0)
					return TipoDevolucaoInternaEnum.PORT_INTERNA_PLANOS;
			}
		}

		return TipoDevolucaoInternaEnum.PORT_EXTERNA;

	}

	public Integer getQtd() {
		return qtd;
	}

	public void setQtd(Integer qtd) {
		this.qtd = qtd;
	}

	public String getMatriculaPatrocinadora() {
		return UtilJava.adicionaZeroEquerda(9, Integer.parseInt(this.codigoParticEntidadeDestino));
	}

	public String getCnpb() {
		return this.codigoPlanoEntidadeDestino.replace(".", "").replace("-", "");
	}

	public PlanoGuardaChuva getPlanoGuardaChuva() {
		return planoGuardaChuva;
	}

	public void setPlanoGuardaChuva(PlanoGuardaChuva planoGuardaChuva) {
		this.planoGuardaChuva = planoGuardaChuva;
	}

	public String getCpfParticipanteDevolucao() {
		return this.devolucao != null ? this.devolucao.getParticipantePlano().getParticipante().getCpf() : "";
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

}
