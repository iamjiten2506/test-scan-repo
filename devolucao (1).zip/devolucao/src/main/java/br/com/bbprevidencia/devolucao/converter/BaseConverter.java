package br.com.bbprevidencia.devolucao.converter;

import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import br.com.bbprevidencia.cadastroweb.dto.BaseModel;

/**
 * Esta classe fornece um conversor genérico para entidades que implementam a
 * interface BaseModel, onde o código é um String
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 17/02/2017
 *
 */
@FacesConverter(value = "baseConverter")
public class BaseConverter implements Converter {

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @return Object Retorna o objeto BaseModel
	 */
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if (value != null) {
			return this.getAttributesFrom(component).get(value);
		}
		return null;
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 * @return String Retorna o código do objeto do tipo BaseModel convertido em String.
	 */
	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {

		boolean resultado = false;

		if (value != null && !"".equals(value)) {
			BaseModel entity = (BaseModel) value;

			// armazena o objeto do tipo BaseModel no mapa de atributos.
			resultado = this.addAttribute(component, entity);

			String codigo = (String) entity.getCodigo();
			if (codigo != null) {
				return String.valueOf(codigo);
			}
		}

		if (resultado) {

			return (String) value;
		} else {
			return null;
		}

	}

	/**
	 * Adiciona o objeto BaseModel no mapa, sendo a chave o código da entidade.
	 * 
	 * @param component
	 * @param o objeto do tipo BaseModel
	 */
	protected boolean addAttribute(UIComponent component, BaseModel o) {

		String key = new String();
		boolean adicionou = false;

		if (!(o.getCodigo() == null)) {
			key = o.getCodigo().toString();
			this.getAttributesFrom(component).put(key, o);
			adicionou = true;
		}

		return adicionou;
	}

	/**
	 * Recupera o mapa de objetos BaseModel
	 * 
	 * @param component
	 * @return Map<String, Object>
	 */
	protected Map<String, Object> getAttributesFrom(UIComponent component) {
		return component.getAttributes();
	}

}