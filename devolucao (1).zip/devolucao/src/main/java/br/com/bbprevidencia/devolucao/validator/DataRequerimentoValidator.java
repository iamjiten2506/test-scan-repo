package br.com.bbprevidencia.devolucao.validator;

import java.text.ParseException;
import java.util.Date;

import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.apache.commons.lang.StringUtils;

import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.utils.data.UtilData;

/**
 * Classe encarregada de validada a data de requerimento do processo de devolução
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 30/01/2017
 *
 */
@FacesValidator(value = "DataRequerimentoValidator")
public class DataRequerimentoValidator implements Validator {

	Date dataRequerimento = null;

	@Override
	public void validate(FacesContext arg0, UIComponent arg1, Object arg2) throws ValidatorException {

		UIInput datReq = (UIInput) arg0.getViewRoot().findComponent((String) arg1.getAttributes().get("datReq"));

		Object datCaptura = datReq.getSubmittedValue();

		this.validarDataRequerimento(datCaptura);

	}

	/**
	 * Método responsável por validar a data do requerimento
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param dataRequerimento
	 * @throws ValidatorException
	 */
	public void validarDataRequerimento(Object dataRequerimento) throws ValidatorException {

		this.dataRequerimento = null;
		String strDtReq = (dataRequerimento == null) ? null : dataRequerimento.toString().trim();

		if (StringUtils.isBlank(strDtReq))
			return;

		try {
			this.dataRequerimento = UtilData.getDataValida(strDtReq);
		} catch (ParseException e) {
			return;
		}

		Date dataHoje = new Date();

		if (UtilData.isDataMaior(this.dataRequerimento, dataHoje)) {
			throw new ValidatorException(Mensagens.getFacesMessageErro("DEV_VMSG002"));
		}

	}
}
