package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ArquivoDTO {

	private String cpf;
	private String numeroPartic;
	private String pastaFTP;
	private String nome;
	private String matriculaParticipante;
	private String arquivoBase64;
	private String tipoDocumento;
	private String codigoProduto;
	private String codigoTipoDocumento;
	private String planoPatrociandora;
	private String unidadeGuardaChuva;
	private String produto;

}
