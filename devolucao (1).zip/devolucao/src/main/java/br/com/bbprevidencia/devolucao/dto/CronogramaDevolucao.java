package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.folha.dto.SituacaoFolha;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   29/12/2016
 * Classe de persistência para tabela PARCELA_CONTA_DEV.
 */
@Entity
@Table(name = "CRONOGRAMA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "CronogramaDevolucao.findAll", query = "SELECT q FROM CronogramaDevolucao q ORDER BY q.codigo DESC")
public class CronogramaDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = -1L;

	@Id
	@SequenceGenerator(name = "CRONOGRAMA_DEV_GER", sequenceName = "S_CRD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CRONOGRAMA_DEV_GER")
	@Column(name = "NUM_SEQ_CRO_DEV")
	private Long codigo;

	@Column(name = "DAT_PGT")
	private Date dataPagamento;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_FOLHA_DEV")
	private TipoFolhaDevolucao tipoFolhaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SIT_FOLHA")
	private SituacaoFolha situacaoFolha;

	@Column(name = "IND_PAG_PAR_REF")
	private String indicadorPagarParceladosReferencia;

	@Column(name = "DAT_INT")
	private Date dataIntegracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private String descricaoCronograma;

	@Transient
	private String descricaoCronogramaPorData;

	@Transient
	private String descricaoIndicadorParcelado;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public SituacaoFolha getSituacaoFolha() {
		return situacaoFolha;
	}

	public void setSituacaoFolha(SituacaoFolha situacaoFolha) {
		this.situacaoFolha = situacaoFolha;
	}

	public TipoFolhaDevolucao getTipoFolhaDevolucao() {
		return tipoFolhaDevolucao;
	}

	public void setTipoFolhaDevolucao(TipoFolhaDevolucao tipoFolhaDevolucao) {
		this.tipoFolhaDevolucao = tipoFolhaDevolucao;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Date getDataIntegracao() {
		return dataIntegracao;
	}

	public void setDataIntegracao(Date dataIntegracao) {
		this.dataIntegracao = dataIntegracao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	/**
	 * Método responsável verificar se o cronograma permite processamento
	 * @author  BBPF0333 - Daniel Martins
	 * @since   24/01/2017
	 */
	@Transient
	public boolean isPodeProcessar() {

		if (this.situacaoFolha.getIndicadorPermiteProcessamento() == "S") {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Método responsável verificar se o cronograma permite processamento
	 * @author  BBPF0333 - Daniel Martins
	 * @since   24/01/2017
	 */
	@Transient
	public boolean isPodeFechar() {

		if (this.situacaoFolha.getOrdemSituacaoFolha() >= 30 && this.situacaoFolha.getOrdemSituacaoFolha() <= 40) {
			return true;
		} else {
			return false;
		}
	}

	@Transient
	public boolean isFolhaAberta() {

		if (this.situacaoFolha.getOrdemSituacaoFolha() <= 40) {
			return true;
		} else {
			return false;
		}
	}

	public String getDescricaoIndicadorParcelado() {
		if (getIndicadorPagarParceladosReferencia().equals("S")) {
			descricaoIndicadorParcelado = "Sim";
		} else {
			descricaoIndicadorParcelado = "Não";
		}

		return descricaoIndicadorParcelado;
	}

	public String getIndicadorPagarParceladosReferencia() {
		return indicadorPagarParceladosReferencia;
	}

	public void setIndicadorPagarParceladosReferencia(String indicadorPagarParceladosReferencia) {
		this.indicadorPagarParceladosReferencia = indicadorPagarParceladosReferencia;
	}

	public String getDescricaoCronograma() {

		this.descricaoCronograma = "Tipo Folha: " + this.getTipoFolhaDevolucao().getNomeTipoFolha() + " - Data Pgto: " + UtilJava.formataDataPorPadrao(this.getDataPagamento(), "dd/MM/yyyy");

		return descricaoCronograma;
	}

	public void setDescricaoCronograma(String descricaoCronograma) {
		this.descricaoCronograma = descricaoCronograma;
	}

	public String getDescricaoCronogramaPorData() {

		this.descricaoCronograma = UtilJava.formataDataPorPadrao(this.getDataPagamento(), "dd/MM/yyyy") + " - " + "Tipo Folha: " + this.getTipoFolhaDevolucao().getNomeTipoFolha();

		return descricaoCronograma;
	}

	public void setDescricaoCronogramaPorData(String descricaoCronograma) {
		this.descricaoCronograma = descricaoCronograma;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CronogramaDevolucao other = (CronogramaDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CronogramaDevolucao [codigo=" + codigo + ", dataPagamento=" + dataPagamento + ", tipoFolhaDevolucao=" + tipoFolhaDevolucao + ", situacaoFolha=" + situacaoFolha
				+ ", indicadorPagarParceladosReferencia=" + indicadorPagarParceladosReferencia + ", dataIntegracao=" + dataIntegracao + ", dataAlteracao=" + dataAlteracao + ", dataInclusao="
				+ dataInclusao + ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + ", descricaoCronograma=" + descricaoCronograma
				+ ", descricaoCronogramaPorData=" + descricaoCronogramaPorData + ", descricaoIndicadorParcelado=" + descricaoIndicadorParcelado + "]";
	}

}