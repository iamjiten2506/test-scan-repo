package br.com.bbprevidencia.devolucao.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 29/12/2016 Classe de persistência para tabela TIPO_FOLHA_DEVOLUCAO.
 */
@Entity
@Table(name = "TIPO_FOLHA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "TipoFolhaDevolucao.findAll", query = "SELECT q FROM TipoFolhaDevolucao q")
public class TipoFolhaDevolucao implements BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TIPO_FOLHA_DEVOLUCAO_GER", sequenceName = "S_TFD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TIPO_FOLHA_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_TIP_FOLHA_DEV")
	private Long codigo;

	@Column(name = "NOM_TIP_FOLHA_DEV")
	private String nomeTipoFolha;

	@Column(name = "DSC_TIP_FOLHA_DEV")
	private String descricaoTipoFolha;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "tipoFolhaDevolucao", targetEntity = EntidadeParticipanteTipoFolhaDevolucao.class, fetch = FetchType.EAGER)
	private List<EntidadeParticipanteTipoFolhaDevolucao> listantidadeParticipanteTipoFolhaDevolucao = new ArrayList<EntidadeParticipanteTipoFolhaDevolucao>();

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "tipoFolhaDevolucao", targetEntity = TipoFolhaSituacaoDevolucao.class, fetch = FetchType.EAGER)
	private List<TipoFolhaSituacaoDevolucao> listaTipoFolhaSituacaoDevolucao = new ArrayList<TipoFolhaSituacaoDevolucao>();

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNomeTipoFolha() {
		return nomeTipoFolha;
	}

	public void setNomeTipoFolha(String nomeTipoFolha) {
		this.nomeTipoFolha = nomeTipoFolha;
	}

	public String getDescricaoTipoFolha() {
		return descricaoTipoFolha;
	}

	public void setDescricaoTipoFolha(String descricaoTipoFolha) {
		this.descricaoTipoFolha = descricaoTipoFolha;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public List<EntidadeParticipanteTipoFolhaDevolucao> getListantidadeParticipanteTipoFolhaDevolucao() {
		return listantidadeParticipanteTipoFolhaDevolucao;
	}

	public void setListantidadeParticipanteTipoFolhaDevolucao(List<EntidadeParticipanteTipoFolhaDevolucao> listantidadeParticipanteTipoFolhaDevolucao) {
		this.listantidadeParticipanteTipoFolhaDevolucao = listantidadeParticipanteTipoFolhaDevolucao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoFolhaDevolucao other = (TipoFolhaDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TipoFolhaDevolucao [codigo=" + codigo + ", nomeTipoFolha=" + nomeTipoFolha + ", descricaoTipoFolha=" + descricaoTipoFolha + ", dataAlteracao=" + dataAlteracao + ", dataInclusao="
				+ dataInclusao + ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + ", listantidadeParticipanteTipoFolhaDevolucao="
				+ listantidadeParticipanteTipoFolhaDevolucao + "]";
	}

	public List<TipoFolhaSituacaoDevolucao> getListaTipoFolhaSituacaoDevolucao() {
		return listaTipoFolhaSituacaoDevolucao;
	}

	public void setListaTipoFolhaSituacaoDevolucao(List<TipoFolhaSituacaoDevolucao> listaTipoFolhaSituacaoDevolucao) {
		this.listaTipoFolhaSituacaoDevolucao = listaTipoFolhaSituacaoDevolucao;
	}

}