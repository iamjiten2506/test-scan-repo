package br.com.bbprevidencia.devolucao.enumerador;

public enum SituacaoDevolucaoEnum {

	REQUERIDO(1L, "REQUERIDO"),
	ATUALIZADO(2L, "ATUALIZADO"),
	CONFERIDO(3L, "CONFERIDO"),
	EM_DEFERIMENTO(4L, "EM DEFERIMENTO"),
	CONCEDIDO(5L, "CONCEDIDO"),
	EM_PARCELAMENTO(6L, "EM PARCELAMENTO"),
	PAGO(7L, "PAGO"),
	INDEFERIDO(8L, "INDEFERIDO"),
	CANCELADO(9L, "CANCELADO");

	private Long codigo;
	private String descricao;

	private SituacaoDevolucaoEnum(Long codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return SituacaoDevolucaoEnum
	 */
	public static SituacaoDevolucaoEnum getSituacaoDevolucaoEnum(Long codigo) {
		if (codigo != null) {
			for (SituacaoDevolucaoEnum situacaoDevolucao : values()) {
				if (situacaoDevolucao.getCodigo().equals(codigo)) {
					return situacaoDevolucao;
				}
			}
		}
		return null;
	}

}