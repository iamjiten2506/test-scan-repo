package br.com.bbprevidencia.devolucao.controle;

import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.TipoDocumentoEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * Documento Devolução
 * 
 * @author  BBPF0170 - Magson Dias
 * @since 19/04/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

/**
 * @author  BBPF0170 - Magson Dias
 *
 */
@Scope("session")
@Component("documentoDevolucaoVisao")
public class DocumentoDevolucaoVisao {
	private static final String FW_DOCUMENTO_DEVOLUCAO = "/paginas/documentoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private DocumentoDevolucaoBO documentoDevolucaoBO;

	private DocumentoDevolucao documentoDevolucao;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean possuiAcessoTotal;
	private boolean listarStatus;
	private String mensagem;

	private List<DocumentoDevolucao> listarDocumentoDevolucao;

	private List<DocumentoDevolucao> listaFiltrada;

	/**
	 * Método responsalveu por iniciar  manutenção dos documentos de devolução. 
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 20/04/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("documentoDevolucao");
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.possuiAlgumaFuncionalidade("documentoDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
		this.listarStatus = true;
		this.listarDocumentoDevolucao = this.documentoDevolucaoBO.listarTodosDocumentoDevolucao();
		this.documentoDevolucao = new DocumentoDevolucao();

		//		retorna para pagina inicial. 
		return FW_DOCUMENTO_DEVOLUCAO;
	}

	/**
	 * Método responsalveu por salvar um novo documento de devolução. 
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since  20/04/2017
	 * @return {@link String}
	 */
	public String salvarDocumentoDevolucacao() {
		try {
			if (this.documentoDevolucao.getCodigo() == null) {
				this.documentoDevolucao.setDataInclusao(new Date());
				this.documentoDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Documento de devolução salvo com sucesso!";
			} else if (this.documentoDevolucao.getClass() != null) {
				this.documentoDevolucao.setDataAlteracao(new Date());
				this.documentoDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Documento de devolução atualizado com sucesso!";
			}
			if (validaCampos()) {
				return "";
			}
			documentoDevolucaoBO.salvarDocumentoDevolucao(this.documentoDevolucao);
			limpa();
			Mensagens.addMsgInfo(mensagem);
			return FW_DOCUMENTO_DEVOLUCAO;
		} catch (PrevidenciaException pEx) {
			Mensagens.addError(pEx.getLocalizedMessage());
			return "";
		} catch (Exception e) {
			Mensagens.addError(e.getMessage());
			return "";
		}
	}

	/**
	 * Método responsalveu por habilitar a tela de um novo cadastro de documento de devolução. 
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 	20/04/2017
	 * @return {@link String}
	 */
	public void cadastrarNovaDocumentoDevolucao() {
		this.documentoDevolucao = new DocumentoDevolucao();
		controlerEditarDocumentoDevolucao();

	}

	/**
	 * Método responsalveu por colocar um DocumentoDevolucao em modo de edição.  
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 	20/04/2017
	 * @return {@link String}
	 * @param {@link DocumentoDevolucao}
	 */
	public void editarDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		this.setDocumentoDevolucao(new DocumentoDevolucao());
		this.setDocumentoDevolucao(documentoDevolucaoBO.pesquisarDocumentoDevolucaoPorCodigo(documentoDevolucao.getCodigo()));
		controlerEditarDocumentoDevolucao();

	}

	/**
	 * Método responsalveu por deletar um documento de devolução.
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 31/03/2017
	 * @param {@link DocumentoDevolucao}
	 * @return {@link String}
	 */
	public String deletarDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		try {
			this.documentoDevolucaoBO.apagarDocumentoDevolucao(documentoDevolucao);
			limpa();
		} catch (PrevidenciaException pEx) {
			Mensagens.addError(pEx.getMessage());
			return "";
		} catch (Exception e) {
			Mensagens.addError(e.getMessage());
			return "";
		}
		return FW_DOCUMENTO_DEVOLUCAO;
	}

	/**
	 * Método responsalveu por controla a edição/salva um documento de devolução. 
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 31/03/2017
	 * @return {@link String}
	 */
	public void controlerEditarDocumentoDevolucao() {
		if (isListarStatus()) {
			this.listarDocumentoDevolucao = documentoDevolucaoBO.listarTodosDocumentoDevolucao();
		}
		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método responsalveu por limpar objetos apos ação.
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 31/03/2017
	 */
	public void limpa() {
		this.documentoDevolucao = new DocumentoDevolucao();
		this.listarDocumentoDevolucao = this.documentoDevolucaoBO.listarTodosDocumentoDevolucao();
		listarStatus = true;
	}

	/**
	 * Método para validar campos
	 * @author bbpf0170 - Magson Dias
	 * @return {@link boolean}
	 */

	private boolean validaCampos() {
		boolean res = false;
		if (StringUtils.isEmpty(this.documentoDevolucao.getNome())) {
			addMsgErro("Campo nome é de preenchimento obrigatório!");
			res = true;
		}
		if (StringUtils.isEmpty(this.documentoDevolucao.getIndicativoTipoDocumento())) {
			addMsgErro("Campo tipo de documento é de seleção obrigatória!");
			res = true;
		}
		if (StringUtils.isEmpty(this.documentoDevolucao.getDescricaoSolicitacao01())) {
			addMsgErro("Campo descrição 01 é de preenchimento obrigatório!");
			res = true;
		}
		return res;
	}

	/**
	 * Método para adiciona a mensage de erro no faces.
	 * @author  BBPF0170 - MAGSON 
	 * @param {@link String mensagem}
	 */
	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

	//	Abaixo segue os getters e setters
	public DocumentoDevolucao getDocumentoDevolucao() {
		return documentoDevolucao;
	}

	public void setDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		this.documentoDevolucao = documentoDevolucao;
	}

	public List<DocumentoDevolucao> getListarDocumentoDevolucao() {
		return listarDocumentoDevolucao;
	}

	public void setListarDocumentoDevolucao(List<DocumentoDevolucao> listarDocumentoDevolucao) {
		this.listarDocumentoDevolucao = listarDocumentoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	// Lista de tipo de documentos gerados no enum - TipoDocumentoEnum
	public TipoDocumentoEnum[] getListaTipoDocumentos() {
		return TipoDocumentoEnum.values();
	}

	public List<DocumentoDevolucao> getListaFiltrada() {
		return listaFiltrada;
	}

	public void setListaFiltrada(List<DocumentoDevolucao> listaFiltrada) {
		this.listaFiltrada = listaFiltrada;
	}

}
