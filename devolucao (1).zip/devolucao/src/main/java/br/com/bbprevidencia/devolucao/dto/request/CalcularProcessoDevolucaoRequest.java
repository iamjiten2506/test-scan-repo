package br.com.bbprevidencia.devolucao.dto.request;

import br.com.bbprevidencia.cadastroweb.dto.RegraGeral;
import br.com.bbprevidencia.cadastroweb.dto.SaldoHistoricoFinanceiroPagoDTO;
import br.com.bbprevidencia.devolucao.dto.ContaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.DetalhePortabilidadeRequestDTO;
import br.com.bbprevidencia.devolucao.dto.ParamSistemaDTO;
import br.com.bbprevidencia.devolucao.dto.RecebedorDepDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CalcularProcessoDevolucaoRequest {

    private Boolean homologacao;

    private Long codSolicitacao;
    private String indicadorEmprestimo;
    private Double valorEmprestimo;
    private Long codigoTipoDevolucao;
    private Integer numTotalparcelas;
    private String indicadorFormaPamamentoContribCarencia;
    private Double percentualOpcao;
    private Long codDevolucao;
    private String mensagemRecalculo;
    private Boolean instituido;

    private Long codResponsavel;
    private Long codigoParticipante;
    private Long codigoParticipantePlano;
    private String nomeParticipante;
    private String sexoParticipante;
    private String cpfParticipante;
    private Date dtNascimentoParticipante;

    private Long codBanco;
    private String nomeBanco;
    private Long codAgencia;
    private String digAgencia;
    private String codConta;
    private String tipoConta;

    private Long codigoEntidadeParticipante;
    private Long codigoPlanoPrevidencia;

    private Date dataPosicaoCota;
    private Date dataRequerimento;


    private Long codPerfilInvest;
    private List<LocalDate> listaValorCotaPlano;
    private ParamSistemaDTO paramSistema;
    private Long codFundPrev;

    private Date dataUltimoProcessamento;
    private Date dataUltimoLancamentoFicha;
    private List<ContaDevolucaoDTO> listaContaDevolucao;
    private SaldoHistoricoFinanceiroPagoDTO saldoHistoricoFinanceiroPagoDTO;
    private RegraGeral regraGeral;
    private Double impostoDevolucao;
    private String banco;
    private List<RecebedorDepDTO> listaRecebedor = new ArrayList<>();
    private DetalhePortabilidadeRequestDTO detalhePortabilidade;
    private boolean portabilidadePenseFuturo;

    private List<String> tratamentoMensagens = new ArrayList<>();
    private String tipoTributacao;

}