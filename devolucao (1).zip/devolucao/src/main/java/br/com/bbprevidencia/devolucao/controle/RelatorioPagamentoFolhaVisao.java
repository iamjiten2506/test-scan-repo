package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteEnderecoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipanteEndereco;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipantePK;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioConsolidadoFolhaDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioConsolidadoFolhaSinteticoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioPagamentoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioPagamentoFolhaDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioValoresDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar os relatórios de pagamento de Folha
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 23/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioPagamentoFolhaVisao")
public class RelatorioPagamentoFolhaVisao {

	private static final String FW_RELATORIO_PAGAMENTO_FOLHA = "/paginas/relatoriosPagamentoFolha.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioPagamentoFolhaVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;
	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;
	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;
	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private EntidadeParticipanteEnderecoBO entidadeParticipanteEnderecoBO;
	@Autowired
	RelatorioUtil relatorioUtil;

	private CronogramaDevolucao cronogramaDevolucao;
	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private EntidadeParticipante entidadeParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;
	private List<TipoDevolucao> listaTipoDevolucao;
	private List<TipoDevolucao> listaTipoDevolucaoSelecionados;

	private String relatorioSaida;
	private boolean selecionarPlano;
	private boolean mostraValorLimite;

	private boolean ativarIntervaloDatas;

	private Long valorLimitePagamento;

	private Date dataInicioPagamento, dataFimPagamento;

	private String variavelTipoImpressao;

	/**
	 * Método encarregado de chamar a página de preenchimento de parâmetros
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 230/03/2017
	 * @return
	 */
	public String iniciarRelatoriosPagamentoFolha() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_PAGAMENTO_FOLHA;
	}

	/**
	 * Método encarregado de preencher as informações iniciais para a página
	 * funcionar
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 23/03/2017
	 * @return
	 */
	private void setarValoresIniciais() {
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(this.cronogramaDevolucaoBO.listarCronogramaDescendente());
		this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBO.listarTodosTipoDevolucao());
		this.cronogramaDevolucao = null;
		this.relatorioSaida = "RF";
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>();
		this.listaEntidadeParticipanteSelecionadas = new ArrayList<EntidadeParticipante>();
		this.valorLimitePagamento = 50000L;
		this.mostraValorLimite = false;
		this.dataInicioPagamento = null;
		this.dataFimPagamento = null;
		this.ativarIntervaloDatas = true;
		setarVisaoMultiEmpresa();
	}

	/**
	 * Método encarregado de pesquisar as entidades participantes que participaram
	 * do cáculo de determinado cronograma
	 */
	public void listarPatrocinadoraPorCronograma() {
		// Situação do cronograma como fechado
		if (this.cronogramaDevolucao != null) {
			this.ativarIntervaloDatas = false;
			this.dataInicioPagamento = null;
			this.dataFimPagamento = null;
			if (this.cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
				this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.historicoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
			} else {
				this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.movimentoCalculoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
			}
		} else {
			this.dataInicioPagamento = null;
			this.dataFimPagamento = null;
			this.ativarIntervaloDatas = true;
		}

	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/03/2017
	 */
	public void verificaListaPatrocinadora() {
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipanteSelecionadas)) {
			setarVisaoMultiEmpresa();
		} else {
			if (this.listaEntidadeParticipanteSelecionadas.size() == 1) {
				this.selecionarPlano = true;

				EntidadeParticipante entidadeParticipante = this.listaEntidadeParticipanteSelecionadas.get(0);
				this.listaPlanoPrevidencia = listarPlanoPrevidencia(entidadeParticipante);

			} else {
				setarVisaoMultiEmpresa();
			}
		}
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link EntidadeParticipante}
	 * @return
	 */
	public List<PlanoPrevidencia> listarPlanoPrevidencia(EntidadeParticipante entidadeParticipante) {

		try {
			List<PlanoPrevidencia> listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(entidadeParticipante);

			return listaPlanoPrevidencia;
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	private void setarVisaoMultiEmpresa() {
		this.selecionarPlano = false;
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
	}

	/**
	 * Método encarregado de emitir o relatório
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/03/2017
	 */
	@SuppressWarnings("unchecked")
	public void exportarRelatorio(ActionEvent event) {
		try {
			// String nomeBotao = event.getComponent().getId();
			if (event.getComponent().getId().equals("btEmitirExcel")) {
				this.variavelTipoImpressao = "XLS";
			} else {
				this.variavelTipoImpressao = "PDF";
			}

			List<RelatorioPagamentoFolhaDTO> relatorioPagamentoFolha = new ArrayList<RelatorioPagamentoFolhaDTO>();

			List<RelatorioConsolidadoFolhaDTO> relatorioConsolidadoFolha = new ArrayList<RelatorioConsolidadoFolhaDTO>();
			List<RelatorioValoresDevolucaoDTO> listaRelatorioValoresDevolucaoDTO = new ArrayList<RelatorioValoresDevolucaoDTO>();
			List<RelatorioPagamentoDevolucaoDTO> listaRelatorioPagamentoDevolucaoDTO = new ArrayList<RelatorioPagamentoDevolucaoDTO>();

			if ((this.getRelatorioSaida().equalsIgnoreCase("RF") || this.getRelatorioSaida().equalsIgnoreCase("DP")
					|| this.getRelatorioSaida().equalsIgnoreCase("VT")) && this.cronogramaDevolucao == null) {
				throw new Exception("Deve selecionar um cronograma antes de emitir o relatório selecionado!");
			}

			if (this.getRelatorioSaida().equalsIgnoreCase("RF") || this.getRelatorioSaida().equalsIgnoreCase("DP")) {
				if (this.cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
					relatorioPagamentoFolha.addAll(this.historicoPagamentoDevolucaoBO.pesquisaHistoricoPagamentoFolha(
							this.getCronogramaDevolucao(), this.listaEntidadeParticipanteSelecionadas,
							this.listaPlanoPrevidenciaSelecionados, this.listaTipoDevolucaoSelecionados));
				} else {
					relatorioPagamentoFolha
							.addAll(this.movimentoCalculoPagamentoDevolucaoBO.pesquisaHistoricoPagamentoFolha(
									this.getCronogramaDevolucao(), this.listaEntidadeParticipanteSelecionadas,
									this.listaPlanoPrevidenciaSelecionados, this.listaTipoDevolucaoSelecionados));
				}

			} else if (this.getRelatorioSaida().equalsIgnoreCase("VT")) {
				listaRelatorioValoresDevolucaoDTO.addAll(this.movimentoCalculoPagamentoDevolucaoBO
						.pesquisarValoresRelatorioTesouraria(cronogramaDevolucao));

			} else if (this.getRelatorioSaida().equalsIgnoreCase("PG")) {

				if (this.cronogramaDevolucao.isFolhaAberta()) {
					listaRelatorioPagamentoDevolucaoDTO
							.addAll(this.movimentoCalculoPagamentoDevolucaoBO.pesquisaRelatorioPagamentoPorParametros(
									this.getCronogramaDevolucao(), this.listaEntidadeParticipanteSelecionadas,
									this.listaPlanoPrevidenciaSelecionados, this.listaTipoDevolucaoSelecionados,
									this.dataInicioPagamento, this.dataFimPagamento));
				} else {
					listaRelatorioPagamentoDevolucaoDTO
							.addAll(this.historicoPagamentoDevolucaoBO.pesquisaRelatorioPagamentoPorParametros(
									this.getCronogramaDevolucao(), this.listaEntidadeParticipanteSelecionadas,
									this.listaPlanoPrevidenciaSelecionados, this.listaTipoDevolucaoSelecionados,
									this.dataInicioPagamento, this.dataFimPagamento));
				}

			} else {
				if (this.cronogramaDevolucao == null && this.dataInicioPagamento == null) {
					throw new Exception(
							"Deve selecionar o cronograma ou um intervalo de datas antes de emitir o relatório selecionado!");
				}

				// if (this.cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
				relatorioConsolidadoFolha.addAll(this.historicoPagamentoDevolucaoBO.relatorioCosolidadoFolha(
						this.getCronogramaDevolucao(), this.listaEntidadeParticipanteSelecionadas,
						this.listaPlanoPrevidenciaSelecionados, this.listaTipoDevolucaoSelecionados,
						this.getValorLimitePagamento().doubleValue(), this.dataInicioPagamento, this.dataFimPagamento));
				/*
				 * } else {
				 * relatorioConsolidadoFolha.addAll(this.movimentoCalculoPagamentoDevolucaoBO.
				 * relatorioCosolidadoFolha( this.getCronogramaDevolucao(),
				 * this.listaEntidadeParticipanteSelecionadas,
				 * this.listaPlanoPrevidenciaSelecionados, this.listaTipoDevolucaoSelecionados,
				 * this.getValorLimitePagamento().doubleValue(), this.dataInicioPagamento,
				 * this.dataFimPagamento)); }
				 */
			}

			if (((this.getRelatorioSaida().equalsIgnoreCase("RF") || this.getRelatorioSaida().equalsIgnoreCase("DP"))
					&& UtilJava.isColecaoVazia(relatorioPagamentoFolha))
					|| ((this.getRelatorioSaida().equalsIgnoreCase("IN")
							|| this.getRelatorioSaida().equalsIgnoreCase("PS"))
							&& UtilJava.isColecaoVazia(relatorioConsolidadoFolha))
					|| (this.getRelatorioSaida().equalsIgnoreCase("VT")
							&& UtilJava.isColecaoVazia(listaRelatorioValoresDevolucaoDTO))
					|| (this.getRelatorioSaida().equalsIgnoreCase("PG")
							&& UtilJava.isColecaoVazia(listaRelatorioPagamentoDevolucaoDTO))) {
				Mensagens.addMsgInfo("Não foram encontradas informações para estes parâmetros!");
			} else {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);

				/*
				 * Demanda 35916 - Yanisley Mora Ritchie Para os casos de IN e PS, serão
				 * preenchias duas listas, a analítica e a sintética
				 */
				if (this.getRelatorioSaida().equalsIgnoreCase("IN")
						|| this.getRelatorioSaida().equalsIgnoreCase("PS")) {
					parametros.put("tipoRelatorio", this.getRelatorioSaida());
					parametros.put("valorLimite", UtilJava.formataNumero(this.getValorLimitePagamento(), 2));

					if (this.cronogramaDevolucao != null) {
						parametros.put("dataCredito", UtilJava
								.formataDataPorPadrao(this.cronogramaDevolucao.getDataPagamento(), "dd/MM/yyyy"));
					} else {
						parametros.put("dataCredito",
								"Desde: " + UtilJava.formataDataPorPadrao(this.dataInicioPagamento, "dd/MM/yyyy")
										+ " - Ate: "
										+ UtilJava.formataDataPorPadrao(
												(this.dataFimPagamento == null ? new Date() : this.dataFimPagamento),
												"dd/MM/yyyy"));
					}

					parametros.put("listaAnalitica", relatorioConsolidadoFolha);

					// Preecher a lista Sintética
					String ultimoPlanoProcesado = "";
					List<RelatorioConsolidadoFolhaSinteticoDTO> relatorioConsolidadoFolhaSintetico = new ArrayList<RelatorioConsolidadoFolhaSinteticoDTO>();

					List<RelatorioConsolidadoFolhaDTO> listaAnaliticaProcessar = new ArrayList<RelatorioConsolidadoFolhaDTO>();
					listaAnaliticaProcessar.addAll(relatorioConsolidadoFolha);

					Collections.sort(listaAnaliticaProcessar);

					for (RelatorioConsolidadoFolhaDTO item : listaAnaliticaProcessar) {
						final String planoAtual = item.getNomePlano();

						Iterable<RelatorioConsolidadoFolhaDTO> listaFiltradaPlano = CollectionUtils
								.select(listaAnaliticaProcessar, new Predicate() {
									@Override
									public boolean evaluate(Object arg0) {
										RelatorioConsolidadoFolhaDTO consolidadoFolha = (RelatorioConsolidadoFolhaDTO) arg0;
										return consolidadoFolha.getNomePlano().equalsIgnoreCase(planoAtual);
									}
								});

						if (planoAtual.equalsIgnoreCase(ultimoPlanoProcesado)) {
							continue;
						} else {
							RelatorioConsolidadoFolhaSinteticoDTO folhaSinteticoDTO = new RelatorioConsolidadoFolhaSinteticoDTO();
							Double totalBruto = 0D;
							Double totalDesconto = 0D;

							for (RelatorioConsolidadoFolhaDTO itemPlano : listaFiltradaPlano) {
								totalBruto += itemPlano.getValorBruto();
								totalDesconto += itemPlano.getValorDesconto();
							}

							folhaSinteticoDTO.setNomePlano(planoAtual);
							folhaSinteticoDTO.setValorBruto(totalBruto);
							folhaSinteticoDTO.setValorDesconto(totalDesconto);
							relatorioConsolidadoFolhaSintetico.add(folhaSinteticoDTO);
							ultimoPlanoProcesado = planoAtual;
						}
					}

					parametros.put("listaSintetica", relatorioConsolidadoFolhaSintetico);

				}

				if (this.getRelatorioSaida().equalsIgnoreCase("RF")) {
					
					
					Collections.sort(relatorioPagamentoFolha);

					imprimirRelatorio("resumoFolha", relatorioPagamentoFolha, parametros);
					
				} else if (this.getRelatorioSaida().equalsIgnoreCase("DP")) {
					EntidadeParticipantePK chavePrimaria = new EntidadeParticipantePK();
					chavePrimaria.setCodigoEntidadeParticipante(10002L);
					chavePrimaria.setCodigoFundoPrevidencia(1L);

					EntidadeParticipante entidadeParticipante = entidadeParticipanteBO
							.consultarPorChavePrimaria(chavePrimaria);

					EntidadeParticipanteEndereco entidadeParticipanteEnd = entidadeParticipanteEnderecoBO
							.pesquisarEntidadeParticipanteEnderecoPorEntidadeParticipante(entidadeParticipante);

					String enderecoBbp = entidadeParticipanteEnd.getNomeLogradouro()
							+ entidadeParticipanteEnd.getNumeroLogradouro() + ", "
							+ entidadeParticipanteEnd.getComplementoLogradouro() + ", "
							+ entidadeParticipanteEnd.getBairro();

					String cidadeBbp = entidadeParticipanteEnd.getCidade() + " - " + entidadeParticipanteEnd.getUf();

					String cepBbp = UtilJava.formatarCep(
							entidadeParticipanteEnd.getCep() + entidadeParticipanteEnd.getCepComplemento());

					parametros.put("enderecoBbp", enderecoBbp);
					parametros.put("cidadeBbp", cidadeBbp);
					parametros.put("cepBbp", cepBbp);

					// GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "demonstrativoPagamento",
					// dataSource);
					imprimirRelatorio("demonstrativoPagamento", relatorioPagamentoFolha, parametros);
				} else if (this.getRelatorioSaida().equalsIgnoreCase("IN")
						|| this.getRelatorioSaida().equalsIgnoreCase("PS")) {
					/*
					 * Demanda 35916 - Yanisley Mora Ritchie Alterado o relatório de saída,
					 * substituído por um Relatório com subreport para soportar analítico e
					 * sintético
					 */
					imprimirRelatorio("pagamentoLimiteValor", new ArrayList<>(), parametros);
				} else if (this.getRelatorioSaida().equalsIgnoreCase("VT")) {
					imprimirRelatorio("relatorioValoresDevolucao", listaRelatorioValoresDevolucaoDTO, parametros);
				} else if (this.getRelatorioSaida().equalsIgnoreCase("PG")) {
					imprimirRelatorio("relatorioDescritivoPagamento", listaRelatorioPagamentoDevolucaoDTO, parametros);
				}
			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro("Erro ao exportar relatório.");
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param relatorio
	 * @param dados
	 * @param param
	 */
	public void imprimirRelatorio(String relatorio, List<?> dados, Map<String, Object> parametros) {
		try {
			String nomeArquivo = "";

			switch (this.variavelTipoImpressao) {
			case "PDF":

				nomeArquivo = relatorioUtil.gerarRelatorio(relatorio, dados, parametros);
				break;

			case "XLS":

				nomeArquivo = relatorioUtil.gerarRelatorioXls(relatorio, dados, parametros);
				break;

			default:
				break;
			}

			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (Exception e) {
			log.error("Erro ao exportar relatório.", e);
			throw new PrevidenciaException(e);
		}
	}

	/**
	 * Método encarregado de inativar ou ativar o slider do valor limite
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * 
	 */
	public void verificarTipoSaida() {
		if (this.getRelatorioSaida().equals("PS")) {
			this.mostraValorLimite = true;
		} else {
			this.mostraValorLimite = false;
			this.valorLimitePagamento = 50000L;
		}
	}

	/**
	 * Método encarregado de limpar os parâmetros de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 */
	public void limparPesquisa() {
		this.setarValoresIniciais();
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

	public String getRelatorioSaida() {
		return relatorioSaida;
	}

	public void setRelatorioSaida(String relatorioSaida) {
		this.relatorioSaida = relatorioSaida;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public List<TipoDevolucao> getListaTipoDevolucaoSelecionados() {
		return listaTipoDevolucaoSelecionados;
	}

	public void setListaTipoDevolucaoSelecionados(List<TipoDevolucao> listaTipoDevolucaoSelecionados) {
		this.listaTipoDevolucaoSelecionados = listaTipoDevolucaoSelecionados;
	}

	public Long getValorLimitePagamento() {
		return valorLimitePagamento;
	}

	public void setValorLimitePagamento(Long valorLimitePagamento) {
		this.valorLimitePagamento = valorLimitePagamento;
	}

	public boolean isMostraValorLimite() {
		return mostraValorLimite;
	}

	public void setMostraValorLimite(boolean mostraValorLimite) {
		this.mostraValorLimite = mostraValorLimite;
	}

	public Date getDataInicioPagamento() {
		return dataInicioPagamento;
	}

	public void setDataInicioPagamento(Date dataInicioPagamento) {
		this.dataInicioPagamento = dataInicioPagamento;
	}

	public Date getDataFimPagamento() {
		return dataFimPagamento;
	}

	public void setDataFimPagamento(Date dataFimPagamento) {
		this.dataFimPagamento = dataFimPagamento;
	}

	public boolean isAtivarIntervaloDatas() {
		return ativarIntervaloDatas;
	}

	public void setAtivarIntervaloDatas(boolean ativarIntervaloDatas) {
		this.ativarIntervaloDatas = ativarIntervaloDatas;
	}

	public String getVariavelTipoImpressao() {
		return variavelTipoImpressao;
	}

	public void setVariavelTipoImpressao(String variavelTipoImpressao) {
		this.variavelTipoImpressao = variavelTipoImpressao;
	}

}