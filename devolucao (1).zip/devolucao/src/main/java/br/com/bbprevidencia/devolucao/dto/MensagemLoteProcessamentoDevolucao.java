package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.folha.dto.Recebedor;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * Classe de persistência para tabela MSG_LOT_PRO_DEV.
 */
@Entity
@Table(name = "MSG_LOT_PRO_DEV", schema = "OWN_DCR")
@NamedQuery(name = "MensagemLoteProcessamentoDevolucao.findAll", query = "SELECT q FROM MensagemLoteProcessamentoDevolucao q")
public class MensagemLoteProcessamentoDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MSG_LOT_PRO_DEV_GER", sequenceName = "S_MLPD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MSG_LOT_PRO_DEV_GER")
	@Column(name = "NUM_SEQ_MSG_LOT_PRO_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_LOT_PRO_DEV")
	private LoteProcessamentoDevolucao loteProcessamentoDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_MSG_PRO_DEV")
	private TipoMensagemProcessoDevolucao tipoMensagemProcessoDevolucao;

	@Column(name = "DSC_MSG_LOT_PRO_DEV_PRI")
	private String mensagemLoteProcessamentoDevPrimario;

	@Column(name = "DSC_MSG_LOT_PRO_DEV_COM")
	private String mensagemLoteProcessamentoDevComplementar;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RECEBEDOR")
	private Recebedor recebedor;

	@ManyToOne
	@JoinColumns( { @JoinColumn(name = "COD_PESSOA"), @JoinColumn(name = "COD_AREA_ATUA") })
	private AtuacaoPessoa atuacaoPessoa;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV")
	private RubricaDevolucao rubricaDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PERFIL_INVEST")
	private PerfilInvestimento perfilInvestimento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Transient
	private String dataInclusaoCompleta;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public LoteProcessamentoDevolucao getLoteProcessamentoDevolucao() {
		return loteProcessamentoDevolucao;
	}

	public void setLoteProcessamentoDevolucao(LoteProcessamentoDevolucao loteProcessamentoDevolucao) {
		this.loteProcessamentoDevolucao = loteProcessamentoDevolucao;
	}

	public TipoMensagemProcessoDevolucao getTipoMensagemProcessoDevolucao() {
		return tipoMensagemProcessoDevolucao;
	}

	public void setTipoMensagemProcessoDevolucao(TipoMensagemProcessoDevolucao tipoMensagemProcessoDevolucao) {
		this.tipoMensagemProcessoDevolucao = tipoMensagemProcessoDevolucao;
	}

	public String getMensagemLoteProcessamentoDevPrimario() {
		return mensagemLoteProcessamentoDevPrimario;
	}

	public void setMensagemLoteProcessamentoDevPrimario(String mensagemLoteProcessamentoDevPrimario) {
		this.mensagemLoteProcessamentoDevPrimario = mensagemLoteProcessamentoDevPrimario;
	}

	public String getMensagemLoteProcessamentoDevComplementar() {
		return mensagemLoteProcessamentoDevComplementar;
	}

	public void setMensagemLoteProcessamentoDevComplementar(String mensagemLoteProcessamentoDevComplementar) {
		this.mensagemLoteProcessamentoDevComplementar = mensagemLoteProcessamentoDevComplementar;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public Recebedor getRecebedor() {
		return recebedor;
	}

	public void setRecebedor(Recebedor recebedor) {
		this.recebedor = recebedor;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	public PerfilInvestimento getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(PerfilInvestimento perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getDataInclusaoCompleta() {
		dataInclusaoCompleta = UtilJava.formataDataPorPadrao(this.dataInclusao, "dd/MM/yyyy - HH:mm:ss");
		return dataInclusaoCompleta;
	}

	public void setDataInclusaoCompleta(String dataInclusaoCompleta) {
		this.dataInclusaoCompleta = dataInclusaoCompleta;
	}

	//

}
