package br.com.bbprevidencia.devolucao.enumerador;

/**
 * Enum com os indicadores de Tipo de Imposto Progressivo
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 09/02/2017
 *
 */
public enum IndicadorTipoImpostoProgressivoEnum {

	PROG_15("15", "I.R. PROG. 15%", "I.R. PROGRESSIVO FIXO DE 15%", "5"),
	PROG_NORMAL("TN", "I.R. PROG. NORM.", "I.R. PROGRESSIVO VIA TABELA NORMAL", "3");

	private String codigo;
	private String descricaoCurta;
	private String descricaoLonga;
	private String codigoIRRF;

	private IndicadorTipoImpostoProgressivoEnum(String codigo, String descricaoCurta, String descricaoLonga, String codigoIRRF) {
		this.codigo = codigo;
		this.descricaoCurta = descricaoCurta;
		this.descricaoLonga = descricaoLonga;
		this.codigoIRRF = codigoIRRF;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricaoCurta() {
		return descricaoCurta;
	}

	public void setDescricaoCurta(String descricaoCurta) {
		this.descricaoCurta = descricaoCurta;
	}

	public String getDescricaoLonga() {
		return descricaoLonga;
	}

	public void setDescricaoLonga(String descricaoLonga) {
		this.descricaoLonga = descricaoLonga;
	}

	public String getCodigoIRRF() {
		return codigoIRRF;
	}

	public void setCodigoIRRF(String codigoIRRF) {
		this.codigoIRRF = codigoIRRF;
	}

	/**
	 * Método estático que retorna uma Enum pelo código
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 09/02/2017
	 * @param codigo
	 * @return {@link IndicadorTipoImpostoProgressivoEnum}
	 */
	public static IndicadorTipoImpostoProgressivoEnum getIndicadorTipoImpostoProgressivoEnum(String codigo) {
		if (codigo != null) {
			for (IndicadorTipoImpostoProgressivoEnum indicadorTipoImpostoProgressivoEnum : values()) {
				if (indicadorTipoImpostoProgressivoEnum.getCodigo().equals(codigo)) {
					return indicadorTipoImpostoProgressivoEnum;
				}
			}
		}
		return null;
	}

}
