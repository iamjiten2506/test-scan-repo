package br.com.bbprevidencia.devolucao.controle;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO.PARAMETROS;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.ParametroGeral;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.enumerador.TipoTelefoneEnum;
import br.com.bbprevidencia.cadastroweb.exception.EmailException;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.cadastroweb.servico.EmailServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.contabilidade.bo.DataRecolhimentoBO;
import br.com.bbprevidencia.contabilidade.dto.DataRecolhimento;
import br.com.bbprevidencia.cotas.dto.IntegracaoCotasDTO;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DetalhePortabilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.LancamentoIntegracaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.LoteProcessamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MensagemLoteProcessamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParametroIntegracaoContabilFinanceiraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParametroIntegracaoFinanceiraDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.DetalhePortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.FiltroIntegracaoConsignatarioDTO;
import br.com.bbprevidencia.devolucao.dto.LancamentoIntegracaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.LiquidoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.LoteProcessamentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.MensagemLoteProcessamentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.MovimentoCalculoPagamentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.ParametroIntegracaoContabilFinanceiraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RetornoEnvioSmsDTO;
import br.com.bbprevidencia.devolucao.dto.SmsDTO;
import br.com.bbprevidencia.devolucao.enumerador.TipoIntegracaoEnum;
import br.com.bbprevidencia.devolucao.enumerador.TipoLoteProcessamentoEnum;
import br.com.bbprevidencia.devolucao.enumerador.TipoMensagensProcessamentoEnum;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RestUtil;
import br.com.bbprevidencia.folha.bo.RecebedorBO;
import br.com.bbprevidencia.folha.dto.Consignatario;
import br.com.bbprevidencia.folha.dto.RepresentanteRecebedor;
import br.com.bbprevidencia.folha.dto.TelefoneRecebedor;
import br.com.bbprevidencia.fundo.dto.IntegracaoFundoPrevidenciario;
import br.com.bbprevidencia.interno.bo.CadastroSmsBO;
import br.com.bbprevidencia.interno.dto.CadastroSms;
import br.com.bbprevidencia.tesouraria.bo.IntegracaoTesourariaBO;
import br.com.bbprevidencia.utils.arquivo.UtilTemplates;
import br.com.bbprevidencia.utils.exception.InfraException;

/**
 * Classe controller que manipula as requisições de cálculo de folha de
 * devolução
 *
 * @author Marco Figueiredo
 * @since 25/01/2017
 * <p>
 * Copyright notice (c) 2016 BBPrevidência S/A
 */
@Component("integracaoFolhaDevolucao")
public class IntegracaoFolhaDevolucao {

	public static Logger log = Logger.getLogger(IntegracaoFolhaDevolucao.class);
	public static int TOTALPROCESSAMENTO = 0;
	public static int REGISTROPROCESSAMENTO = 0;
	private static final Double VALORZERO = 0D;

	@Autowired
	private LoteProcessamentoDevolucaoBO loteProcessamentoDevolucaoBO;

	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;

	@Autowired
	private ParametroIntegracaoFinanceiraDevolucaoBO parametroIntegracaoFinanceiraDevolucaoBO;

	@Autowired
	private MensagemLoteProcessamentoDevolucaoBO mensagemLoteProcessamentoDevolucaoBO;

	@Autowired
	private LancamentoIntegracaoDevolucaoBO lancamentoIntegracaoDevolucaoBO;

	@Autowired
	private IntegracaoTesourariaBO integracaoTesourariaBO;

	@Autowired
	private ParametroIntegracaoContabilFinanceiraDevolucaoBO parametroIntegracaoContabilFinanceiraDevolucaoBO;

	@Autowired
	private DataRecolhimentoBO dataRecolhimentoBO;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;

	@Autowired
	private CadastroSmsBO cadastroSmsBO;

	@Autowired
	private EmailServico emailServico;

	@Autowired
	private ParametroGeralBO parametroGeralBO;

	@Autowired
	private AmbienteServico ambienteServico;

	@Autowired
	private RecebedorBO recebedorBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private DetalhePortabilidadeDevolucaoBO detalhePortabilidadeDevolucaoBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private RestUtil restUtil;

	private LoteProcessamentoDevolucao loteProcessamentoDevolucao;

	private LoginBBPrevWebDTO loginBBPrevWebDTOIntegracao;

	public static List<MensagemLoteProcessamentoDevolucao> listaMensagemLoteProcessamentoDevolucao = new ArrayList<MensagemLoteProcessamentoDevolucao>();
	private List<LancamentoIntegracaoDevolucao> listaLancamentoIntegracaoDevolucao = new ArrayList<LancamentoIntegracaoDevolucao>();
	private List<MovimentoCalculoPagamentoDevolucao> listaMovimentoCalculoPagamentoDevolucao = new ArrayList<MovimentoCalculoPagamentoDevolucao>();
	private List<IntegracaoFundoPrevidenciario> listaIntegracaoFundoPrevidenciario = new ArrayList<IntegracaoFundoPrevidenciario>();
	private List<IntegracaoCotasDTO> listaIntegracaoCotasDTO = new ArrayList<IntegracaoCotasDTO>();
	private List<AnotacaoDevolucao> listaAnotacao = new ArrayList<AnotacaoDevolucao>();
	private boolean indicadorIntegraContabilidade;
	private boolean indicadorIntegraFinanConsignatario;
	private boolean indicadorIntegraFinanLiquido;
	private boolean indicadorIntegraFinanRubricas;
	private boolean indicadorIntegraCotas;
	private boolean indicadorIntegraFundoPrev;
	private String codigoRetornoSms;

	private static List<String> listaErrosIntegracao = new ArrayList<String>();

	/**
	 * Método responsável por calcular folha de devolução
	 *
	 * @param {@link CronogramaDevolucao}
	 * @param {@link EntidadeParticipante}
	 * @param {@link PlanoPrevidencia}
	 * @param {@link Participante}
	 * @param {@link LoginBBPrevWebDTO}
	 * @return {@link - String}
	 * @throws PrevidenciaException
	 * @author BBPF0351 - Marco Figueiredo
	 * @since 27/01/2017
	 */
	// @Lock(LockType.READ)
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { PrevidenciaException.class })
	public List<String> integrarFolhaDevolucao(CronogramaDevolucao cronogramaDevolucao, boolean indicadorIntegraContabilidade, boolean indicadorIntegraFinanConsignatario,
			boolean indicadorIntegraFinanLiquido, boolean indicadorIntegraFinanRubricas, boolean indicadorIntegraCotas, boolean indicadorIntegraFundoPrev, LoginBBPrevWebDTO loginBBPrevWebDTO)
			throws PrevidenciaException {

		try {
			listarListaIntegracao();

			if (!indicadorIntegraContabilidade && !indicadorIntegraFinanConsignatario && !indicadorIntegraFinanLiquido && !indicadorIntegraFinanRubricas && !indicadorIntegraCotas
					&& !indicadorIntegraFundoPrev) {

				throw new PrevidenciaException("Nenhuma integração foi selecionada");
			}

			// Seta usuário logado que solicitou o cálculo
			setLoginBBPrevWebDTOIntegracao(loginBBPrevWebDTO);

			setIndicadorIntegraContabilidade(indicadorIntegraContabilidade);
			setIndicadorIntegraFinanConsignatario(indicadorIntegraFinanConsignatario);
			setIndicadorIntegraFinanLiquido(indicadorIntegraFinanLiquido);
			setIndicadorIntegraFinanRubricas(indicadorIntegraFinanRubricas);
			setIndicadorIntegraCotas(indicadorIntegraCotas);
			setIndicadorIntegraFundoPrev(indicadorIntegraFundoPrev);
			listaErrosIntegracao.clear();

			// Verifica se cronograma está preenchido
			if (cronogramaDevolucao == null) {
				throw new PrevidenciaException("Cronograma é de Preenchimento Obrigatório");
			}

			// Gera lote de processamento
			this.loteProcessamentoDevolucao = this.loteProcessamentoDevolucaoBO.carregarLoteProcessamento(cronogramaDevolucao, loginBBPrevWebDTO, TipoLoteProcessamentoEnum.INTEGRACAO);
			// Independende do que acontecer gera lote
			this.loteProcessamentoDevolucaoBO.salvarLoteProcessamentoDevolucao(loteProcessamentoDevolucao);

			listaMovimentoCalculoPagamentoDevolucao = pesquisarMovimentoPorCronograma();

			if (UtilJava.isColecaoVazia(this.listaMovimentoCalculoPagamentoDevolucao)) {
				throw new PrevidenciaException("Não há movimento para integração");
			}

			for (int i = 1; i <= 7; i++) {

				TipoIntegracaoEnum tipoIntegracaoEnum = TipoIntegracaoEnum.getTipoIntegracaoEnum(Integer.toString(i));

				processarIntegracao(loteProcessamentoDevolucao, loginBBPrevWebDTO, listaMovimentoCalculoPagamentoDevolucao, tipoIntegracaoEnum);

			}

			return listaErrosIntegracao;

		} catch (PrevidenciaException ex) {
			log.error(ex);
			throw ex;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi possível realizar está operaçao", e);
		}

	}

	private void listarListaIntegracao() {
		listaAnotacao.clear();
	}

	private void apagarProcessamentoAnterior(LoteProcessamentoDevolucao loteProcessamentoDevolucao, TipoIntegracaoEnum tipoIntegracaoEnum) {
		try {

			List<LancamentoIntegracaoDevolucao> lancIntegracaoExclusao = new ArrayList<LancamentoIntegracaoDevolucao>();

			lancIntegracaoExclusao = this.lancamentoIntegracaoDevolucaoBO.pesquisarLancamentoIntegracaoDevolucaoPorCronogramaTipo(
					loteProcessamentoDevolucao.getCronogramaDevolucao(),
					tipoIntegracaoEnum);

			for (LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao : lancIntegracaoExclusao) {
				this.lancamentoIntegracaoDevolucaoBO.apagarLancamentoIntegracaoDevolucao(lancamentoIntegracaoDevolucao);
			}

		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi possível realizar está operaçao", e);
		}

	}

	private void inserelistaMensagem() {

		if (UtilJava.isColecaoDiferenteDeVazia(listaMensagemLoteProcessamentoDevolucao)) {
			this.mensagemLoteProcessamentoDevolucaoBO.salvarListaMensagemLoteProcessamentoDevolucao(listaMensagemLoteProcessamentoDevolucao);
		}

		listaMensagemLoteProcessamentoDevolucao.clear();

	}

	private boolean processarIntegracao(LoteProcessamentoDevolucao loteProcessamentoDevolucao, LoginBBPrevWebDTO loginBBPrevWebDTO, List<MovimentoCalculoPagamentoDevolucao> listaMovimento,
			TipoIntegracaoEnum tipoIntegracaoEnum) throws PrevidenciaException {

		try {
			List<FiltroIntegracaoConsignatarioDTO> listaFiltroIntegracaoConsignatarioDTO = new ArrayList<FiltroIntegracaoConsignatarioDTO>();

			this.listaLancamentoIntegracaoDevolucao.clear();

			switch (tipoIntegracaoEnum.getCodigo()) {
			case "1":

				if (isIndicadorIntegraFinanLiquido()) {
					// Exclui movimento anterior de integração.
					apagarProcessamentoAnterior(loteProcessamentoDevolucao, tipoIntegracaoEnum);

					if (processarIntegracaoFinanceiraLiquido(loteProcessamentoDevolucao, loginBBPrevWebDTO, listaMovimentoCalculoPagamentoDevolucao, tipoIntegracaoEnum)) {
						listaErrosIntegracao.add("Ocorreram erros ao processar integração financeira - " + tipoIntegracaoEnum.getDescricao());
					}

					break;

				} else {
					return false;
				}

			case "2":

				if (isIndicadorIntegraFinanRubricas()) {
					// Exclui movimento anterior de integração.
					apagarProcessamentoAnterior(loteProcessamentoDevolucao, tipoIntegracaoEnum);

					if (processarIntegracaoFinanceiraRubricas(loteProcessamentoDevolucao, loginBBPrevWebDTO, listaMovimentoCalculoPagamentoDevolucao, TipoIntegracaoEnum.RUBRICA)) {
						listaErrosIntegracao.add("Ocorreram erros ao processar integração financeira - " + tipoIntegracaoEnum.getDescricao());
					}

					break;
				} else {
					return false;
				}

			case "3":

				if (isIndicadorIntegraFinanConsignatario()) {
					// Exclui movimento anterior de integração.
					apagarProcessamentoAnterior(loteProcessamentoDevolucao, tipoIntegracaoEnum);

					listaFiltroIntegracaoConsignatarioDTO = processarIntegracaoFinanceiraConsignatario(
							loteProcessamentoDevolucao,
							loginBBPrevWebDTO,
							listaMovimentoCalculoPagamentoDevolucao,
							TipoIntegracaoEnum.CONSIGNATARIO);

					break;
				} else {
					return false;
				}

			case "4":

				if (isIndicadorIntegraContabilidade()) {
					// Exclui movimento anterior de integração.
					apagarProcessamentoAnterior(loteProcessamentoDevolucao, tipoIntegracaoEnum);

					if (processarIntegracaoContabilidade(loteProcessamentoDevolucao, loginBBPrevWebDTO, listaMovimentoCalculoPagamentoDevolucao, TipoIntegracaoEnum.CONTABILIDADE)) {
						listaErrosIntegracao.add("Ocorreram erros ao processar integração contábil - " + tipoIntegracaoEnum.getDescricao());
					}

					break;
				} else {
					return false;
				}

			case "6":

				if (isIndicadorIntegraCotas()) {
					// Exclui movimento anterior de integração.
					apagarProcessamentoAnterior(loteProcessamentoDevolucao, tipoIntegracaoEnum);

					if (processarIntegracaoCotas(loteProcessamentoDevolucao, listaMovimentoCalculoPagamentoDevolucao, loginBBPrevWebDTO, TipoIntegracaoEnum.COTAS)) {
						listaErrosIntegracao.add("Ocorreram erros ao processar integração contábil - " + tipoIntegracaoEnum.getDescricao());
					}

					break;
				} else {
					return false;
				}

			case "7":

				if (isIndicadorIntegraFundoPrev()) {
					// Exclui movimento anterior de integração.
					apagarProcessamentoAnterior(loteProcessamentoDevolucao, tipoIntegracaoEnum);

					if (processarIntegracaoFundoPrevidencial(loteProcessamentoDevolucao, listaMovimentoCalculoPagamentoDevolucao, loginBBPrevWebDTO, TipoIntegracaoEnum.FUNDOPREVIDENCIAL)) {
						listaErrosIntegracao.add("Ocorreram erros ao processar integração contábil - " + tipoIntegracaoEnum.getDescricao());
					}

					break;
				} else {
					return false;
				}

			default:
				break;
			}

			if (UtilJava.isColecaoDiferenteDeVazia(this.listaLancamentoIntegracaoDevolucao)) {

				this.lancamentoIntegracaoDevolucaoBO.salvarListaLancamentoIntegracaoDevolucaoInBatch(this.listaLancamentoIntegracaoDevolucao);

				// Se for integração financeira
				if ((tipoIntegracaoEnum == TipoIntegracaoEnum.CONSIGNATARIO || tipoIntegracaoEnum == TipoIntegracaoEnum.LIQUIDO || tipoIntegracaoEnum == TipoIntegracaoEnum.RUBRICA)
						&& UtilJava.isColecaoVazia(listaMensagemLoteProcessamentoDevolucao)) {
					this.lancamentoIntegracaoDevolucaoBO.gerarMovimentoIntegracaoTesouraria(listaLancamentoIntegracaoDevolucao, listaFiltroIntegracaoConsignatarioDTO);
				}

				// Se for integração Contábil
				if (tipoIntegracaoEnum == TipoIntegracaoEnum.CONTABILIDADE && UtilJava.isColecaoVazia(listaMensagemLoteProcessamentoDevolucao)) {
					this.lancamentoIntegracaoDevolucaoBO.gerarMovimentoIntegracaoContabilidade(listaLancamentoIntegracaoDevolucao);
				}

				// Se for integração com Cotas
				if (tipoIntegracaoEnum == TipoIntegracaoEnum.COTAS && UtilJava.isColecaoVazia(listaMensagemLoteProcessamentoDevolucao)) {
					this.lancamentoIntegracaoDevolucaoBO.gerarMovimentoCotas(listaIntegracaoCotasDTO);
				}

				// Se for integração com Cotas
				if (tipoIntegracaoEnum == TipoIntegracaoEnum.FUNDOPREVIDENCIAL && UtilJava.isColecaoVazia(listaMensagemLoteProcessamentoDevolucao)) {
					this.lancamentoIntegracaoDevolucaoBO.gerarMovimentoFundoPrev(listaIntegracaoFundoPrevidenciario);
				}

				// so enviar email ou sma quando for liquidade.
				// Apenas enviar email se não for desenvolvimento
				/*if (this.ambienteServico.getAmbiente().equals("PRODUCAO") || this.ambienteServico.getAmbiente().equals("PROD")) {
					if (tipoIntegracaoEnum == TipoIntegracaoEnum.LIQUIDO) {
						for (LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao : listaLancamentoIntegracaoDevolucao) {
							if (lancamentoIntegracaoDevolucao.getRecebedor() != null && !lancamentoIntegracaoDevolucao.getDevolucao().isPortabilidade()) {
								try {
									enviarSms(lancamentoIntegracaoDevolucao, loginBBPrevWebDTO);
									enviarEmail(lancamentoIntegracaoDevolucao);
								} catch (InfraException e) {
									e.printStackTrace();
								}
							}
						}

						insereListaAnotacao();
					}
				}*/
			}

			inserelistaMensagem();

			return false;

		} catch (Exception e) {
			throw e;
		}
	}

	private void insereListaAnotacao() {
		if (UtilJava.isColecaoDiferenteDeVazia(this.listaAnotacao)) {
			this.anotacaoDevolucaoBO.salvarListaAnotacaoDevolucao(this.listaAnotacao);
		}
	}

	/**
	 * Método encarregado de enviar email.
	 *
	 * @param LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao
	 * @author BBPF0170 - MAGSON
	 * @since 06/11/2017
	 */
	private void enviarEmail(LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao) throws InfraException {
		try {
			ParametroGeral templateEmailDeferimento = this.parametroGeralBO.consultarParametro(PARAMETROS.TEMPLATE_EMAIL_DEFERIMENTO);
			String assuntoEmail = "Recebimento de documentação.";
			if (templateEmailDeferimento != null) {
				if (lancamentoIntegracaoDevolucao.getRecebedor() != null) {
					if (!UtilJava.isStringVazia(lancamentoIntegracaoDevolucao.getRecebedor().getEmail())) {
						Map<String, Object> contexto = new HashMap<String, Object>();
						contexto.put("recebedor", StringUtils.upperCase(lancamentoIntegracaoDevolucao.getRecebedor().getNome()));
						SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
						contexto.put("data", formatador.format(lancamentoIntegracaoDevolucao.getCronogramaDevolucao().getDataPagamento()));
						String textoEmail = UtilTemplates.executarTemplate(templateEmailDeferimento.getDescricaoPatrametro(), contexto);
						String[] destinatarios = new String[] { lancamentoIntegracaoDevolucao.getRecebedor().getEmail() };
						this.emailServico.enviarEmail(destinatarios, assuntoEmail, textoEmail);

						gerarAnotacao(lancamentoIntegracaoDevolucao.getDevolucao(), "Enviado Email de crédito para o participante. Email Cadastrado: "
								+ lancamentoIntegracaoDevolucao.getRecebedor().getEmail());
					}
				}

			}

		} catch (EmailException e) {
			log.error("Exceção lançada ao enviar e-mail:", e);
			Mensagens.addMsgWarn(e.getMessage());

		} catch (InfraException e) {
			log.error("Exceção lançada ao enviar e-mail:", e);
			Mensagens.addMsgWarn(e.getMessage());

		} catch (Exception e) {
			log.warn("Exceção lançada ao enviar e-mail:", e);

		}
	}

	/**
	 * Método encarregado de enviar Sms.
	 *
	 * @param LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao
	 * @param LoginBBPrevWebDTO             loginBBPrevWebDTO
	 * @author BBPF0170 - MAGSON
	 * @since 06/11/2017
	 */
	private void enviarSms(LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao, LoginBBPrevWebDTO loginBBPrevWebDTO) {
		try {

			ParametroGeral templateSmsDeferimento = this.parametroGeralBO.consultarParametro(PARAMETROS.ENVIA_SMS_DEFERIMENTO);

			if (templateSmsDeferimento != null) {

				if (lancamentoIntegracaoDevolucao.getRecebedor() != null) {

					// incio telefone recebedor
					if (UtilJava.isColecaoDiferenteDeVazia(lancamentoIntegracaoDevolucao.getRecebedor().getListaTelefoneRecebedor())) {
						for (TelefoneRecebedor telefone : lancamentoIntegracaoDevolucao.getRecebedor().getListaTelefoneRecebedor()) {

							Map<String, Object> contexto = new HashMap<String, Object>();

							if (telefone.getTipoTelefone().getDescricao().equals(TipoTelefoneEnum.CELULAR.getDescricao())) {
								if (!UtilJava.isStringVazia(telefone.getNumeroDDD()) && !UtilJava.isStringVazia(telefone.getNumeroTelefone())) {

									/* Fernanda Lopes - 29/08/2024 
									 * Novo serviço de envio de SMS */
									String contato = telefone.getNumeroDDD().replaceAll("[^0-9]", "").trim() + telefone.getNumeroTelefone().replaceAll("[^0-9]", "").trim();

									SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
									String data = formatador.format(lancamentoIntegracaoDevolucao.getCronogramaDevolucao().getDataPagamento());
									String mensagem = "Prezado participante: seu pedido de resgate foi aprovado. O pagamento esta previsto para o dia " + data + ". BB Previdencia";

									SmsDTO smsDTO = new SmsDTO(contato, mensagem);

									RetornoEnvioSmsDTO response = restUtil.post("comunicacao-api", "sms/enviarSms", smsDTO, RetornoEnvioSmsDTO.class);

									if (response == null || !response.isSmsEnviado()) {
										log.error("Erro ao enviar SMS:" + this.codigoRetornoSms);
									} else {
										// Daniel Martins - 14/12/2017 - Demanda
										// 333519 - Tratamento de inserção de
										// SMS
										try {
											CadastroSms cadastroSms = new CadastroSms();
											cadastroSms.setDataAgendamento(new Date());
											cadastroSms.setCodigoSituacaoSms((long) 3);
											cadastroSms.setNumeroDDD(Long.parseLong(telefone.getNumeroDDD().replaceAll("[^0-9]", "").trim()));
											cadastroSms.setNumeroTelefone(Long.parseLong(telefone.getNumeroTelefone().replaceAll("[^0-9]", "").trim())); // Limitar

											if (cadastroSms.getNumeroTelefone().toString().length() > 10) {
												cadastroSms.setNumeroTelefone(Long.parseLong(cadastroSms.getNumeroTelefone().toString().substring(0, 10)));
											}
											cadastroSms.setDescricaoSms("ENVIA_SMS_DEFERIMENTO");
											cadastroSms.setDescricaoInformacaoControle(String.valueOf(lancamentoIntegracaoDevolucao.getRecebedor().getCodigo()));
											cadastroSms.setDescricaoTipoControle("NUM_SEQ_RECEBEDOR");
											cadastroSms.setNomeUsuarioInclusao(loginBBPrevWebDTO.getUsuarioSessao().getDescricaoLogin());
											cadastroSms.setDataInclusao(new Date());
											cadastroSmsBO.salvarSms(cadastroSms);

											gerarAnotacao(lancamentoIntegracaoDevolucao.getDevolucao(), "Enviado SMS de crédito para o participante. Telefone: " + cadastroSms.getNumeroTelefone());
										} catch (Exception e) {
											log.error("Erro ao tentar salvar registro na tabela CadastroSms. Erro: " + e);
										}

									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e.getMessage());
		}
	}

	private void gerarAnotacao(Devolucao devolucao, String mensagem) {
		AnotacaoDevolucao anotacao = this.anotacaoDevolucaoBO.gerarAnotacaoDevolucao(devolucao, mensagem, new Date(), this.loginBBPrevWebDTOIntegracao);
		this.listaAnotacao.add(anotacao);
	}

	private boolean processarIntegracaoFinanceiraLiquido(LoteProcessamentoDevolucao loteProcessamentoDevolucao, LoginBBPrevWebDTO loginBBPrevWebDTO,
			List<MovimentoCalculoPagamentoDevolucao> listaMovimento, TipoIntegracaoEnum tipoIntegracaoEnum) {
		try {

			List<LiquidoDevolucaoDTO> listaLiquidoDevolucaoDTO = new ArrayList<LiquidoDevolucaoDTO>();

			// Efetua agrupamento de valores
			listaLiquidoDevolucaoDTO = this.movimentoCalculoPagamentoDevolucaoBO.calcularLiquidoMovimento(listaMovimento, loteProcessamentoDevolucao);

			// Efetua pesquisa de operação interna
			listaLiquidoDevolucaoDTO = this.parametroIntegracaoFinanceiraDevolucaoBO.carregarParametroIntegracaoFinanceiraDevolucaoPorPlano(listaLiquidoDevolucaoDTO, loteProcessamentoDevolucao);

			// Se a lista estiver vazia retorna com erro ou se tiver erro na
			// integração
			if (UtilJava.isColecaoVazia(listaLiquidoDevolucaoDTO) || UtilJava.isColecaoDiferenteDeVazia(listaMensagemLoteProcessamentoDevolucao)) {
				return true;
			}

			// Busca sequence de integração
			long codigoLoteMovimento = this.integracaoTesourariaBO.consultarProximoSequencialIntegracao();

			// Insere lista de lançamentos de integração
			for (LiquidoDevolucaoDTO liquidoDevolucaoDTO : listaLiquidoDevolucaoDTO) {

				// Adiciona na tabela de valores de integração

				// Pesquisa se o recebedor tem um representante legal
				if (liquidoDevolucaoDTO.getDevolucao().isResgate()) {

					RepresentanteRecebedor repRecebedor = this.recebedorBO.pesquisarRepresentanteRecebedorPorCodigoRecebedor(liquidoDevolucaoDTO.getRecebedor().getCodigo());

					if (repRecebedor != null) {
						liquidoDevolucaoDTO.setRecebedor(repRecebedor.getRecebedorRepresentante());
					}
				}

				LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao = new LancamentoIntegracaoDevolucao(loteProcessamentoDevolucao.getCronogramaDevolucao(),
						liquidoDevolucaoDTO.getDevolucao(), liquidoDevolucaoDTO.getOperacaoInterna(), tipoIntegracaoEnum.getCodigo(), liquidoDevolucaoDTO.getPerfilInvestimento(), liquidoDevolucaoDTO
								.getRecebedor(), liquidoDevolucaoDTO.getAtuacaoPessoa(), loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento(), null, null, liquidoDevolucaoDTO
								.getValorLiquido(), new Date(), loginBBPrevWebDTO.getUsuarioSessao().getDescricaoLogin(), codigoLoteMovimento, liquidoDevolucaoDTO.getParticipantePortabilidaeInterna());

				if (!SeForExponencial(liquidoDevolucaoDTO.getValorLiquido())) {
					this.listaLancamentoIntegracaoDevolucao.add(lancamentoIntegracaoDevolucao);
				}

			}

			return false;
		} catch (Exception e) {
			log.error("Erro ao processar integração liquido financeiro. " + e);
			throw e;
		}

	}

	private boolean processarIntegracaoFinanceiraRubricas(LoteProcessamentoDevolucao loteProcessamentoDevolucao, LoginBBPrevWebDTO loginBBPrevWebDTO,
			List<MovimentoCalculoPagamentoDevolucao> listaMovimento, TipoIntegracaoEnum tipoIntegracaoEnum) {
		try {
			// Lista de parametros integração por rubrica
			List<ParametroIntegracaoContabilFinanceiraDevolucao> listaParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>();

			for (MovimentoCalculoPagamentoDevolucao movimentoCalculoPagamentoDevolucao : listaMovimento) {

				// Se a rubrica tiver consignatario
				if (movimentoCalculoPagamentoDevolucao.getRubricaDevolucao().getConsignatario() != null) {
					continue;
				}

				// Verifica lista de parametros para integração financeira
				listaParametroIntegracaoContabilFinanceiraDevolucao = this.parametroIntegracaoContabilFinanceiraDevolucaoBO.pesquisarParametroIntegracaoFinanceiraDevolucaoParaTesouraria(
						movimentoCalculoPagamentoDevolucao.getDevolucao().getParticipantePlano().getPlanoPrevidencia(),
						movimentoCalculoPagamentoDevolucao.getRubricaDevolucao(),
						tipoIntegracaoEnum,
						null);

				// Busca sequence de integração
				long codigoLoteMovimento = this.integracaoTesourariaBO.consultarProximoSequencialIntegracao();

				// Vare Lista e preenche objeto de integração
				for (ParametroIntegracaoContabilFinanceiraDevolucao parametroIntegracaoContabilFinanceiraDevolucao : listaParametroIntegracaoContabilFinanceiraDevolucao) {

					// Adiciona na tabela de valores de integração
					LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao = new LancamentoIntegracaoDevolucao(loteProcessamentoDevolucao.getCronogramaDevolucao(),
							movimentoCalculoPagamentoDevolucao.getDevolucao(), parametroIntegracaoContabilFinanceiraDevolucao.getOperacaoInternaTesouraria(), tipoIntegracaoEnum.getCodigo(),
							movimentoCalculoPagamentoDevolucao.getPerfilInvestimento(), movimentoCalculoPagamentoDevolucao.getRecebedor(), movimentoCalculoPagamentoDevolucao.getAtuacaoPessoa(),
							loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento(), null, null, movimentoCalculoPagamentoDevolucao.getValorRubrica(), new Date(), loginBBPrevWebDTO
									.getUsuarioSessao().getDescricaoLogin(), codigoLoteMovimento);

					this.listaLancamentoIntegracaoDevolucao.add(lancamentoIntegracaoDevolucao);

				}

			}

			return false;
		} catch (Exception e) {
			log.error("Erro ao processar integração liquido financeiro. " + e);
			throw e;
		}
	}

	private boolean processarIntegracaoContabilidade(LoteProcessamentoDevolucao loteProcessamentoDevolucao, LoginBBPrevWebDTO loginBBPrevWebDTO,
			List<MovimentoCalculoPagamentoDevolucao> listaMovimento, TipoIntegracaoEnum tipoIntegracaoEnum) {
		try {
			// Lista de parametros integração para contabilidade
			List<ParametroIntegracaoContabilFinanceiraDevolucao> listaParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>();

			// Busca sequence de integração
			long codigoLoteMovimento = this.integracaoTesourariaBO.consultarProximoSequencialIntegracao();

			for (MovimentoCalculoPagamentoDevolucao movimentoCalculoPagamentoDevolucao : listaMovimento) {

				// Se a rubrica tiver consignatario
				if (movimentoCalculoPagamentoDevolucao.getRubricaDevolucao().getIndicadorExigeApropContabil().equals("N")) {
					continue;
				}

				// Verifica lista de parametros para integração financeira
				listaParametroIntegracaoContabilFinanceiraDevolucao = this.parametroIntegracaoContabilFinanceiraDevolucaoBO.pesquisarParametroIntegracaoFinanceiraDevolucaoParaContabilidade(
						movimentoCalculoPagamentoDevolucao.getDevolucao().getParticipantePlano().getPlanoPrevidencia(),
						movimentoCalculoPagamentoDevolucao.getRubricaDevolucao(),
						tipoIntegracaoEnum);

				// Não há parâmetro para integração
				if (UtilJava.isColecaoVazia(listaParametroIntegracaoContabilFinanceiraDevolucao)) {
					MensagemLoteProcessamentoDevolucao msg = new MensagemLoteProcessamentoDevolucao();
					msg = this.mensagemLoteProcessamentoDevolucaoBO.carregarMensagemLoteProcessamentoDevolucao(
							loteProcessamentoDevolucao,
							TipoMensagensProcessamentoEnum.MS0020,
							movimentoCalculoPagamentoDevolucao.getAtuacaoPessoa(),
							movimentoCalculoPagamentoDevolucao.getRecebedor(),
							movimentoCalculoPagamentoDevolucao.getDevolucao(),
							null,
							null,
							"Falta parametro de integração contábil para rubrica. " + movimentoCalculoPagamentoDevolucao.getRubricaDevolucao().getNome(),
							null);
					this.mensagemLoteProcessamentoDevolucaoBO.adicionarListaMensagemLoteProcessamentoDevolucao(loteProcessamentoDevolucao, msg);
				}

				// Vare Lista e preenche objeto de integração
				for (ParametroIntegracaoContabilFinanceiraDevolucao parametroIntegracaoContabilFinanceiraDevolucao : listaParametroIntegracaoContabilFinanceiraDevolucao) {

					// Adiciona na tabela de valores de integração
					LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao = new LancamentoIntegracaoDevolucao(loteProcessamentoDevolucao.getCronogramaDevolucao(),
							movimentoCalculoPagamentoDevolucao.getDevolucao(), parametroIntegracaoContabilFinanceiraDevolucao.getOperacaoInternaContabil(), tipoIntegracaoEnum.getCodigo(),
							movimentoCalculoPagamentoDevolucao.getPerfilInvestimento(), movimentoCalculoPagamentoDevolucao.getRecebedor(), movimentoCalculoPagamentoDevolucao.getAtuacaoPessoa(),
							loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento(), null, null, movimentoCalculoPagamentoDevolucao.getValorRubrica(), new Date(), loginBBPrevWebDTO
									.getUsuarioSessao().getDescricaoLogin(), codigoLoteMovimento);

					if (lancamentoIntegracaoDevolucao.isLancamentoIntegracaoInternaPlanos()) {
						DetalhePortabilidadeDevolucao detalhe = this.detalhePortabilidadeDevolucaoBO.pesquisarDetalhePortabilidadeDevolucaoPorDevolucao(lancamentoIntegracaoDevolucao.getDevolucao())
								.get(0);
						Participante participante = this.participanteBO.listarParticipantesPorPlanoEMatricula(detalhe.getMatriculaPatrocinadora(), detalhe.getPlanoPrevidencia()).get(0);

						lancamentoIntegracaoDevolucao.setParticipantePlanoDestino(participante.getListaParticipantePlano().get(0));
					}

					this.listaLancamentoIntegracaoDevolucao.add(lancamentoIntegracaoDevolucao);

				}

				if (movimentoCalculoPagamentoDevolucao.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getOperacaoInternaReversao() != null) {

					if (this.historicoPagamentoDevolucaoBO.pesquisarHistoricoPagamentoDevolucaoPorDevolucao(movimentoCalculoPagamentoDevolucao.getDevolucao()).size() > 0) {
						continue;
					}

					// Pesquisa valor por conta devolução
					Double qtdReversao = this.contaDevolucaoBO.totalPorContaDevolucao(this.contaDevolucaoBO.listarTodasPorDevolucao(movimentoCalculoPagamentoDevolucao.getDevolucao()), 2L);
					Double valorReversao = qtdReversao * movimentoCalculoPagamentoDevolucao.getValorIndiceAjusta();
					PerfilInvestimento perfilInvestimentoRecebido = movimentoCalculoPagamentoDevolucao.getDevolucao().getParticipantePlano().getListaModalidadePerfil().get(0).getChavePrimaria()
							.getPerfilInvestimento();

					if (valorReversao > 0) {

						// Adiciona na tabela de valores de integração
						LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao = new LancamentoIntegracaoDevolucao(loteProcessamentoDevolucao.getCronogramaDevolucao(),
								movimentoCalculoPagamentoDevolucao.getDevolucao(), movimentoCalculoPagamentoDevolucao.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao()
										.getOperacaoInternaReversao(), tipoIntegracaoEnum.getCodigo(), movimentoCalculoPagamentoDevolucao.getPerfilInvestimento(), movimentoCalculoPagamentoDevolucao
										.getRecebedor(), movimentoCalculoPagamentoDevolucao.getAtuacaoPessoa(), loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento(), null, null,
								movimentoCalculoPagamentoDevolucao.getValorRubrica(), new Date(), loginBBPrevWebDTO.getUsuarioSessao().getDescricaoLogin(), codigoLoteMovimento);

						this.listaLancamentoIntegracaoDevolucao.add(lancamentoIntegracaoDevolucao);
					}

				}

			}

			return false;
		} catch (Exception e) {
			log.error("Erro ao processar integração liquido financeiro. " + e);
			throw e;
		}
	}

	private List<FiltroIntegracaoConsignatarioDTO> processarIntegracaoFinanceiraConsignatario(LoteProcessamentoDevolucao loteProcessamentoDevolucao, LoginBBPrevWebDTO loginBBPrevWebDTO,
			List<MovimentoCalculoPagamentoDevolucao> listaMovimento, TipoIntegracaoEnum tipoIntegracaoEnum) {
		try {
			// Lista de parametros integração por rubrica
			List<ParametroIntegracaoContabilFinanceiraDevolucao> listaParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>();
			TreeSet<Consignatario> listaConsignatario = new TreeSet<Consignatario>();
			List<FiltroIntegracaoConsignatarioDTO> listaFiltroIntegracaoConsignatarioDTO = new ArrayList<FiltroIntegracaoConsignatarioDTO>();

			// Busca sequence de integração
			long codigoLoteMovimento = this.integracaoTesourariaBO.consultarProximoSequencialIntegracao();

			// Se lista retorna preenchida, agrupa valor para integração
			for (MovimentoCalculoPagamentoDevolucao movimentoCalculoPagamentoDevolucao : listaMovimento) {

				if (movimentoCalculoPagamentoDevolucao.getRubricaDevolucao().getConsignatario() == null) {
					continue;
				}

				listaParametroIntegracaoContabilFinanceiraDevolucao = this.parametroIntegracaoContabilFinanceiraDevolucaoBO.pesquisarParametroIntegracaoFinanceiraDevolucaoParaTesouraria(
						movimentoCalculoPagamentoDevolucao.getDevolucao().getParticipantePlano().getPlanoPrevidencia(),
						movimentoCalculoPagamentoDevolucao.getRubricaDevolucao(),
						tipoIntegracaoEnum,
						movimentoCalculoPagamentoDevolucao.getRubricaDevolucao().getConsignatario());

				for (ParametroIntegracaoContabilFinanceiraDevolucao parametroIntegracaoContabilFinanceiraDevolucao : listaParametroIntegracaoContabilFinanceiraDevolucao) {
					// Adiciona na tabela de valores de integração
					LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao = new LancamentoIntegracaoDevolucao(loteProcessamentoDevolucao.getCronogramaDevolucao(),
							movimentoCalculoPagamentoDevolucao.getDevolucao(), parametroIntegracaoContabilFinanceiraDevolucao.getOperacaoInternaTesouraria(), tipoIntegracaoEnum.getCodigo(),
							movimentoCalculoPagamentoDevolucao.getPerfilInvestimento(), movimentoCalculoPagamentoDevolucao.getRecebedor(), movimentoCalculoPagamentoDevolucao.getAtuacaoPessoa(),
							loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento(), null, movimentoCalculoPagamentoDevolucao.getRubricaDevolucao().getConsignatario(),
							movimentoCalculoPagamentoDevolucao.getValorRubrica(), new Date(), loginBBPrevWebDTO.getUsuarioSessao().getDescricaoLogin(), codigoLoteMovimento);

					this.listaLancamentoIntegracaoDevolucao.add(lancamentoIntegracaoDevolucao);

				}

				listaConsignatario.add(new Consignatario(movimentoCalculoPagamentoDevolucao.getRubricaDevolucao().getConsignatario()));

			}

			for (Consignatario consignatario : listaConsignatario) {

				lista: for (LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao : listaLancamentoIntegracaoDevolucao) {

					if (UtilJava.isColecaoVazia(listaFiltroIntegracaoConsignatarioDTO)) {
						listaFiltroIntegracaoConsignatarioDTO.add(new FiltroIntegracaoConsignatarioDTO(consignatario, lancamentoIntegracaoDevolucao.getDevolucao().getParticipantePlano()
								.getParticipante().getEntidadeParticipante(), lancamentoIntegracaoDevolucao.getDevolucao().getParticipantePlano().getPlanoPrevidencia(), lancamentoIntegracaoDevolucao
								.getPerfilInvestimento(), lancamentoIntegracaoDevolucao.getOperacaoInterna()));
					} else {

						for (FiltroIntegracaoConsignatarioDTO filtroIntegracaoConsignatarioDTO : listaFiltroIntegracaoConsignatarioDTO) {

							if (lancamentoIntegracaoDevolucao.getConsignatario().equals(filtroIntegracaoConsignatarioDTO.getConsignatario())
									&& lancamentoIntegracaoDevolucao.getDevolucao().getParticipantePlano().getPlanoPrevidencia().equals(filtroIntegracaoConsignatarioDTO.getPlanoPrevidencia())
									&& lancamentoIntegracaoDevolucao.getDevolucao().getParticipantePlano().getParticipante().getEntidadeParticipante().equals(
											filtroIntegracaoConsignatarioDTO.getEntidadeParticipante())
									&& lancamentoIntegracaoDevolucao.getPerfilInvestimento().equals(filtroIntegracaoConsignatarioDTO.getPerfilInvestimento())
									&& lancamentoIntegracaoDevolucao.getOperacaoInterna().equals(filtroIntegracaoConsignatarioDTO.getOperacaoInterna())) {
								continue lista;
							}
						}

						listaFiltroIntegracaoConsignatarioDTO.add(new FiltroIntegracaoConsignatarioDTO(consignatario, lancamentoIntegracaoDevolucao.getDevolucao().getParticipantePlano()
								.getParticipante().getEntidadeParticipante(), lancamentoIntegracaoDevolucao.getDevolucao().getParticipantePlano().getPlanoPrevidencia(), lancamentoIntegracaoDevolucao
								.getPerfilInvestimento(), lancamentoIntegracaoDevolucao.getOperacaoInterna()));

					}

				}

				List<LancamentoIntegracaoDevolucao> listaLancamentoIntegracaoDevolucaoFiltrada = new ArrayList<LancamentoIntegracaoDevolucao>();

				for (FiltroIntegracaoConsignatarioDTO filtroIntegracaoConsignatarioDTO : listaFiltroIntegracaoConsignatarioDTO) {

					listaLancamentoIntegracaoDevolucaoFiltrada = this.lancamentoIntegracaoDevolucaoBO.filtrarLancamentoIntegracaoDevolucaoPorConsigPlanoEmpresaPerfilOperacao(
							listaLancamentoIntegracaoDevolucao,
							filtroIntegracaoConsignatarioDTO);
					Double valorConsignado = VALORZERO;

					for (LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao : listaLancamentoIntegracaoDevolucaoFiltrada) {
						valorConsignado += lancamentoIntegracaoDevolucao.getValorIntegracao();
					}

					filtroIntegracaoConsignatarioDTO.setValorConsignatario(valorConsignado);
					filtroIntegracaoConsignatarioDTO.setDataMovimento(loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento());
					filtroIntegracaoConsignatarioDTO.setDataCompetencia(loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento());
					filtroIntegracaoConsignatarioDTO.setCodigoSequencialMovimentoLote(codigoLoteMovimento);

					if (consignatario.getTipoTributo() != null) {

						// Pesquisar data de Recolhimento para Tributo
						DataRecolhimento dataRecolhimento = this.dataRecolhimentoBO.pesquisarDataRecolhimentoPorTipoTributoEData(consignatario.getTipoTributo(), loteProcessamentoDevolucao
								.getCronogramaDevolucao().getDataPagamento());

						// Verificar se existe data de recolhimento e colocar na
						// mensagem de erro
						filtroIntegracaoConsignatarioDTO.setDataMovimento(dataRecolhimento.getDataRecolhimento());

					}

				}

			}

			return new ArrayList<FiltroIntegracaoConsignatarioDTO>(listaFiltroIntegracaoConsignatarioDTO);

		} catch (Exception e) {
			log.error("Erro ao processar integração liquido financeiro. " + e);
			throw e;
		}
	}

	private boolean processarIntegracaoFundoPrevidencial(LoteProcessamentoDevolucao loteProcessamentoDevolucao, List<MovimentoCalculoPagamentoDevolucao> listaMovimentoCalculoPagamentoDevolucao,
			LoginBBPrevWebDTO loginBBPrevWebDTO, TipoIntegracaoEnum tipoIntegracaoEnum) {

		try {
			List<Devolucao> listaDevolucoes = new ArrayList<Devolucao>();

			mov: for (MovimentoCalculoPagamentoDevolucao movimentoCalculoPagamentoDevolucao : listaMovimentoCalculoPagamentoDevolucao) {

				Devolucao dev = new Devolucao();

				dev = movimentoCalculoPagamentoDevolucao.getDevolucao();
				dev.setDataCotaPagamentoMes(movimentoCalculoPagamentoDevolucao.getDataCota());
				dev.setValorCotaPagamentoMes(movimentoCalculoPagamentoDevolucao.getValorCota());

				if (UtilJava.isColecaoDiferenteDeVazia(listaDevolucoes)) {

					for (Devolucao devolucao : listaDevolucoes) {

						if (movimentoCalculoPagamentoDevolucao.getDevolucao().getCodigo() == devolucao.getCodigo()) {
							continue mov;
						}

					}

				}

				listaDevolucoes.add(dev);

			}

			// Limpa tabela Integração
			this.listaIntegracaoFundoPrevidenciario.clear();

			// Varre lista de códigas para verificar existe histórico e em
			// seguida pesquisar dados das contas de devolução
			for (Devolucao devolucao : listaDevolucoes) {

				if (this.historicoPagamentoDevolucaoBO.pesquisarHistoricoPagamentoDevolucaoPorDevolucao(devolucao).size() > 0) {
					continue;
				}

				// Pesquisa valor por conta devolução
				Double qtdReversao = this.contaDevolucaoBO.totalPorContaDevolucao(this.contaDevolucaoBO.listarTodasPorDevolucao(devolucao), 2L);
				Double valorReversao = qtdReversao * devolucao.getValorCotaPagamentoMes();
				PerfilInvestimento perfilInvestimentoRecebido = devolucao.getParticipantePlano().getListaModalidadePerfil().get(0).getChavePrimaria().getPerfilInvestimento();

				if (valorReversao > 0 && devolucao.getRegraCalculoDevolucao().getCodigoMovimentoFundo() != null) {

					LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao = new LancamentoIntegracaoDevolucao(loteProcessamentoDevolucao.getCronogramaDevolucao(), devolucao, null,
							tipoIntegracaoEnum.getCodigo(), perfilInvestimentoRecebido, null, null, loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento(), null, null, valorReversao,
							new Date(), loginBBPrevWebDTO.getIdentificacaoUsuario(), 0L);

					this.listaLancamentoIntegracaoDevolucao.add(lancamentoIntegracaoDevolucao);

					IntegracaoFundoPrevidenciario integracaoFundoPrevidenciario = new IntegracaoFundoPrevidenciario(1L, devolucao.getRegraCalculoDevolucao().getCodigoMovimentoFundo(), devolucao
							.getParticipantePlano(), devolucao.getParticipantePlano().getPlanoPrevidencia(), devolucao.getCodigo(), null, null, "N", new Date(), valorReversao, qtdReversao, devolucao
							.getDataCotaPagamentoMes(), perfilInvestimentoRecebido, null, loginBBPrevWebDTO.getIdentificacaoUsuario(), new Date());

					this.listaIntegracaoFundoPrevidenciario.add(integracaoFundoPrevidenciario);

				}

			}

			return false;

		} catch (Exception e) {
			log.error("Erro ao processar integração fundo previdencial. " + e);
			throw e;
		}

	}

	private boolean processarIntegracaoCotas(LoteProcessamentoDevolucao loteProcessamentoDevolucao, List<MovimentoCalculoPagamentoDevolucao> listaMovimentoCalculoPagamentoDevolucao,
			LoginBBPrevWebDTO loginBBPrevWebDTO, TipoIntegracaoEnum tipoIntegracaoEnum) {

		try {
			List<Devolucao> listaDevolucoes = new ArrayList<Devolucao>();

			mov: for (MovimentoCalculoPagamentoDevolucao movimentoCalculoPagamentoDevolucao : listaMovimentoCalculoPagamentoDevolucao) {

				Devolucao dev = new Devolucao();

				dev = movimentoCalculoPagamentoDevolucao.getDevolucao();
				dev.setDataCotaPagamentoMes(movimentoCalculoPagamentoDevolucao.getDataCota());
				dev.setValorCotaPagamentoMes(movimentoCalculoPagamentoDevolucao.getValorIndiceAjusta());

				if (UtilJava.isColecaoDiferenteDeVazia(listaDevolucoes)) {

					for (Devolucao devolucao : listaDevolucoes) {

						if (movimentoCalculoPagamentoDevolucao.getDevolucao().getCodigo() == devolucao.getCodigo()) {
							continue mov;
						}

					}

				}

				listaDevolucoes.add(dev);

			}

			// Varre lista de códigas para verificar existe histórico e em
			// seguida pesquisar dados das contas de devolução
			for (Devolucao devolucao : listaDevolucoes) {

				if (this.historicoPagamentoDevolucaoBO.pesquisarHistoricoPagamentoDevolucaoPorDevolucao(devolucao).size() > 0) {
					continue;
				}

				// Pesquisa valor por conta devolução
				Double qtdReversao = this.contaDevolucaoBO.totalPorContaDevolucao(this.contaDevolucaoBO.listarTodasPorDevolucao(devolucao), 2L);
				Double qtdResgatavael = this.contaDevolucaoBO.totalPorContaDevolucao(this.contaDevolucaoBO.listarTodasPorDevolucao(devolucao), 1L);
				Double qtdRemanescente = this.contaDevolucaoBO.totalPorContaDevolucao(this.contaDevolucaoBO.listarTodasPorDevolucao(devolucao), 3L);

				Double qtdTotalDevolucao = qtdReversao + qtdResgatavael + qtdRemanescente;

				// Conforme demanda 39182 - Utilizar a cota e não indice
				// ajustado para integração.
				Double valorDevolucao = qtdTotalDevolucao * devolucao.getValorCotaPagamentoMes();
				PerfilInvestimento perfilInvestimentoRecebido = devolucao.getParticipantePlano().getListaModalidadePerfil().get(0).getChavePrimaria().getPerfilInvestimento();

				// Cotas Total Resgate
				if (qtdTotalDevolucao > 0) {

					LancamentoIntegracaoDevolucao lancamentoIntegracaoDevolucao = new LancamentoIntegracaoDevolucao(loteProcessamentoDevolucao.getCronogramaDevolucao(), devolucao, null,
							tipoIntegracaoEnum.getCodigo(), perfilInvestimentoRecebido, null, null, loteProcessamentoDevolucao.getCronogramaDevolucao().getDataPagamento(), null, null, valorDevolucao,
							new Date(), loginBBPrevWebDTO.getIdentificacaoUsuario(), 0L);

					this.listaLancamentoIntegracaoDevolucao.add(lancamentoIntegracaoDevolucao);

					IntegracaoCotasDTO integracaoCotasDTO = new IntegracaoCotasDTO(devolucao.getParticipantePlano().getParticipante().getEntidadeParticipante(), devolucao.getParticipantePlano(),
							devolucao.getParticipantePlano().getListaModalidadePerfil().get(0).getChavePrimaria().getModalidadePlano(), 2L, valorDevolucao, new Date(), "RESGATE DEVOLUÇÃO DE RESERVA",
							devolucao.getDataCotaPagamentoMes());

					this.listaIntegracaoCotasDTO.add(integracaoCotasDTO);

				}

				// Cotas Reversão
				if (qtdReversao > 0) {

					IntegracaoCotasDTO integracaoCotasDTO = new IntegracaoCotasDTO(devolucao.getParticipantePlano().getParticipante().getEntidadeParticipante(), devolucao.getParticipantePlano(),
							devolucao.getParticipantePlano().getListaModalidadePerfil().get(0).getChavePrimaria().getModalidadePlano(), 1L, valorDevolucao, new Date(), "RESGATE DEVOLUÇÃO DE RESERVA",
							devolucao.getDataCotaPagamentoMes());

					this.listaIntegracaoCotasDTO.add(integracaoCotasDTO);

				}

			}

			return false;

		} catch (Exception e) {
			log.error("Erro ao processar integração fundo previdencial. " + e);
			throw e;
		}
	}

	public List<MovimentoCalculoPagamentoDevolucao> pesquisarMovimentoPorCronograma() {
		// Pesquisa todos os movimentos de integração, retirando portabilidades
		// internas de matrícula.
		List<MovimentoCalculoPagamentoDevolucao> listaMovimento = this.movimentoCalculoPagamentoDevolucaoBO.pesquisarMovimentoCalculoPagamentoDevolucaoPorCronograma(loteProcessamentoDevolucao
				.getCronogramaDevolucao());
		return this.movimentoCalculoPagamentoDevolucaoBO.filtrarMovimentoParaIntegracao(listaMovimento);

	}

	public LoginBBPrevWebDTO getLoginBBPrevWebDTOIntegracao() {
		return loginBBPrevWebDTOIntegracao;
	}

	public void setLoginBBPrevWebDTOIntegracao(LoginBBPrevWebDTO loginBBPrevWebDTOIntegracao) {
		this.loginBBPrevWebDTOIntegracao = loginBBPrevWebDTOIntegracao;
	}

	public LoteProcessamentoDevolucao getLoteProcessamentoDevolucao() {
		return loteProcessamentoDevolucao;
	}

	public void setLoteProcessamentoDevolucao(LoteProcessamentoDevolucao loteProcessamentoDevolucao) {
		this.loteProcessamentoDevolucao = loteProcessamentoDevolucao;
	}

	public List<LancamentoIntegracaoDevolucao> getListaLancamentoIntegracaoDevolucao() {
		return listaLancamentoIntegracaoDevolucao;
	}

	public void setListaLancamentoIntegracaoDevolucao(List<LancamentoIntegracaoDevolucao> listaLancamentoIntegracaoDevolucao) {
		this.listaLancamentoIntegracaoDevolucao = listaLancamentoIntegracaoDevolucao;
	}

	public List<MovimentoCalculoPagamentoDevolucao> getListaMovimentoCalculoPagamentoDevolucao() {
		return listaMovimentoCalculoPagamentoDevolucao;
	}

	public void setListaMovimentoCalculoPagamentoDevolucao(List<MovimentoCalculoPagamentoDevolucao> listaMovimentoCalculoPagamentoDevolucao) {
		this.listaMovimentoCalculoPagamentoDevolucao = listaMovimentoCalculoPagamentoDevolucao;
	}

	public boolean isIndicadorIntegraContabilidade() {
		return indicadorIntegraContabilidade;
	}

	public void setIndicadorIntegraContabilidade(boolean indicadorIntegraContabilidade) {
		this.indicadorIntegraContabilidade = indicadorIntegraContabilidade;
	}

	public boolean isIndicadorIntegraFinanConsignatario() {
		return indicadorIntegraFinanConsignatario;
	}

	public void setIndicadorIntegraFinanConsignatario(boolean indicadorIntegraFinanConsignatario) {
		this.indicadorIntegraFinanConsignatario = indicadorIntegraFinanConsignatario;
	}

	public boolean isIndicadorIntegraFinanLiquido() {
		return indicadorIntegraFinanLiquido;
	}

	public void setIndicadorIntegraFinanLiquido(boolean indicadorIntegraFinanLiquido) {
		this.indicadorIntegraFinanLiquido = indicadorIntegraFinanLiquido;
	}

	public boolean isIndicadorIntegraFinanRubricas() {
		return indicadorIntegraFinanRubricas;
	}

	public void setIndicadorIntegraFinanRubricas(boolean indicadorIntegraFinanRubricas) {
		this.indicadorIntegraFinanRubricas = indicadorIntegraFinanRubricas;
	}

	public boolean isIndicadorIntegraCotas() {
		return indicadorIntegraCotas;
	}

	public void setIndicadorIntegraCotas(boolean indicadorIntegraCotas) {
		this.indicadorIntegraCotas = indicadorIntegraCotas;
	}

	public boolean isIndicadorIntegraFundoPrev() {
		return indicadorIntegraFundoPrev;
	}

	public void setIndicadorIntegraFundoPrev(boolean indicadorIntegraFundoPrev) {
		this.indicadorIntegraFundoPrev = indicadorIntegraFundoPrev;
	}

	public EmailServico getEmailServico() {
		return emailServico;
	}

	public void setEmailServico(EmailServico emailServico) {
		this.emailServico = emailServico;
	}

	public String getCodigoRetornoSms() {
		return codigoRetornoSms;
	}

	public void setCodigoRetornoSms(String codigoRetornoSms) {
		this.codigoRetornoSms = codigoRetornoSms;
	}

	public List<AnotacaoDevolucao> getListaAnotacao() {
		return listaAnotacao;
	}

	public void setListaAnotacao(List<AnotacaoDevolucao> listaAnotacao) {
		this.listaAnotacao = listaAnotacao;
	}

	public boolean SeForExponencial(Double valor) {
		String sValor = valor.toString();

		sValor = sValor.replace(".", "");
		sValor = sValor.replace(",", "");

		char[] c = sValor.toCharArray();

		for (int i = 0; i < c.length; i++) {

			// verifica se o char não é um dígito
			if (!Character.isDigit(c[i])) {
				return true;
			}
		}

		return false;

	}
}
