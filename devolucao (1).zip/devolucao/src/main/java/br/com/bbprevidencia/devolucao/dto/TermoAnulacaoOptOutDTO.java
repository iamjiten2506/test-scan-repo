package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class TermoAnulacaoOptOutDTO {
	private String nomePatrocinadora;
	private String cnpb;
	private String nomeParticipante;
	private String cpf;
	private String email;
	private String matricula;

}
