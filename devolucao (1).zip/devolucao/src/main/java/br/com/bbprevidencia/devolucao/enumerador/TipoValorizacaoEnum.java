package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoValorizacaoEnum {

	COTA_DISPONIVEL("COTA_DISPONIVEL", "Cota Disponivel"),
	COTA_DECIMO_DIA("COTA_DECIMO_DIA", "Cota do Decimo Dia Anterior"),
	META_ATUARIAL("META_ATUARIAL", "Meta Atuarial"),
	INDICE_PLANO("INDICE_PLANO", "Indice do Plano");

	private String codigo;
	private String descricao;

	private TipoValorizacaoEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return MantenedorEnum
	 */
	public static TipoValorizacaoEnum getMantenedorEnum(String codigo) {
		if (codigo != null) {
			for (TipoValorizacaoEnum mantenedor : values()) {
				if (mantenedor.getCodigo().equals(codigo)) {
					return mantenedor;
				}
			}
		}
		return null;
	}

}