package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.devolucao.enumerador.TipoValorizacaoEnum;
import br.com.bbprevidencia.fundo.dto.MovimentoFundoPrev;
import br.com.bbprevidencia.indice.dto.IndiceEconomico;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   28/11/2016
 * Classe de persistência para tabela REGRA_CALCULO_DEVOLUCAO.
 */
@Entity
@Table(name = "REGRA_CALCULO_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "RegraCalculoDevolucao.findAll", query = "SELECT q FROM RegraCalculoDevolucao q")
public class RegraCalculoDevolucao implements Serializable, BaseEntity, Cloneable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REGRA_CALCULO_DEVOLUCAO_GER", sequenceName = "S_RCDE_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REGRA_CALCULO_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_REG_CAL_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_DEV")
	private RegraDevolucao regraDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_DEV")
	private TipoDevolucao tipoDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CAL_TEM_EMP")
	private RegraCalculoTempoEmpresa regraCalculoTempoEmpresa;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CAL_TEM_PLA")
	private RegraCalculoTempoPlano regraCalculoTempoPlano;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CAL_TEM_IDA")
	private RegraCalculoTempoIdade regraCalculoTempoIdade;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CAL_TEM_CON")
	private RegraCalculoTempoContribuicao regraCalculoTempoContribuicao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INI")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FIM")
	private Date dataFim;

	@Column(name = "NUM_MAX_PAR")
	private Long numeroMaximoParcelas;

	@Column(name = "NUM_PER_JUROS")
	private Double percentualJuros;

	@Column(name = "IND_TIP_IMP_PRO")
	private String indicadorTipoImpostoProgressivo;

	@Enumerated(value = EnumType.STRING)
	@Column(name = "IND_TIP_VAL", nullable = false, length = 20, columnDefinition = "char(20)")
	private TipoValorizacaoEnum tipoValorizacaoEnum;

	@ManyToOne
	@JoinColumn(name = "COD_INDICE_ECONOM_UTI_PGT")
	private IndiceEconomico indiceEnconomicoUtilizadoPagamento;

	@Column(name = "COD_INDICE_ECONOM_MIN_PAR")
	private String indiceEconomicoMinimoParcela;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_MOV_FUNDO")
	private MovimentoFundoPrev codigoMovimentoFundo;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "regraCalculoDevolucao", targetEntity = RegraDevolucaoContribuicao.class, fetch = FetchType.EAGER, orphanRemoval = true)
	private List<RegraDevolucaoContribuicao> listaRegraDevolucaoContribuicao = new ArrayList<RegraDevolucaoContribuicao>();

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "regraCalculoDevolucao", targetEntity = RegraElegibilidadeDevolucao.class, fetch = FetchType.EAGER, orphanRemoval = true)
	private List<RegraElegibilidadeDevolucao> listaRegraElegibilidadeDevolucao = new ArrayList<RegraElegibilidadeDevolucao>();

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public RegraCalculoTempoEmpresa getRegraCalculoTempoEmpresaDev() {
		return regraCalculoTempoEmpresa;
	}

	public void setRegraCalculoTempoEmpresaDev(RegraCalculoTempoEmpresa regraCalculoTempoEmpresa) {
		this.regraCalculoTempoEmpresa = regraCalculoTempoEmpresa;
	}

	public RegraCalculoTempoPlano getRegraCalculoTempoPlanoDev() {
		return regraCalculoTempoPlano;
	}

	public void setRegraCalculoTempoPlanoDev(RegraCalculoTempoPlano regraCalculoTempoPlano) {
		this.regraCalculoTempoPlano = regraCalculoTempoPlano;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public Long getNumeroMaximoParcelas() {
		return numeroMaximoParcelas;
	}

	public void setNumeroMaximoParcelas(Long numeroMaximoParcelas) {
		this.numeroMaximoParcelas = numeroMaximoParcelas;
	}

	public Double getPercentualJuros() {
		return percentualJuros;
	}

	public void setPercentualJuros(Double percentualJuros) {
		this.percentualJuros = percentualJuros;
	}

	public String getIndicadorTipoImpostoProgressivo() {
		return indicadorTipoImpostoProgressivo;
	}

	public void setIndicadorTipoImpostoProgressivo(String indicadorTipoImpostoProgressivo) {
		this.indicadorTipoImpostoProgressivo = indicadorTipoImpostoProgressivo;
	}

	public TipoValorizacaoEnum getTipoValorizacaoEnum() {
		return tipoValorizacaoEnum;
	}

	public void setTipoValorizacaoEnum(TipoValorizacaoEnum tipoValorizacaoEnum) {
		this.tipoValorizacaoEnum = tipoValorizacaoEnum;
	}

	public RegraCalculoTempoEmpresa getRegraCalculoTempoEmpresa() {
		return regraCalculoTempoEmpresa;
	}

	public void setRegraCalculoTempoEmpresa(RegraCalculoTempoEmpresa regraCalculoTempoEmpresa) {
		this.regraCalculoTempoEmpresa = regraCalculoTempoEmpresa;
	}

	public RegraCalculoTempoPlano getRegraCalculoTempoPlano() {
		return regraCalculoTempoPlano;
	}

	public void setRegraCalculoTempoPlano(RegraCalculoTempoPlano regraCalculoTempoPlano) {
		this.regraCalculoTempoPlano = regraCalculoTempoPlano;
	}

	public String getIndiceEconomicoMinimoParcela() {
		return indiceEconomicoMinimoParcela;
	}

	public void setIndiceEconomicoMinimoParcela(String indiceEconomicoMinimoParcela) {
		this.indiceEconomicoMinimoParcela = indiceEconomicoMinimoParcela;
	}

	public MovimentoFundoPrev getCodigoMovimentoFundo() {
		return codigoMovimentoFundo;
	}

	public void setCodigoMovimentoFundo(MovimentoFundoPrev codigoMovimentoFundo) {
		this.codigoMovimentoFundo = codigoMovimentoFundo;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public List<RegraDevolucaoContribuicao> getListaRegraDevolucaoContribuicao() {
		return listaRegraDevolucaoContribuicao;
	}

	public void setListaRegraDevolucaoContribuicao(List<RegraDevolucaoContribuicao> listaRegraDevolucaoContribuicao) {
		this.listaRegraDevolucaoContribuicao = listaRegraDevolucaoContribuicao;
	}

	public List<RegraElegibilidadeDevolucao> getListaRegraElegibilidadeDevolucao() {
		return listaRegraElegibilidadeDevolucao;
	}

	public void setListaRegraElegibilidadeDevolucao(List<RegraElegibilidadeDevolucao> listaRegraElegibilidadeDevolucao) {
		this.listaRegraElegibilidadeDevolucao = listaRegraElegibilidadeDevolucao;
	}

	public RegraCalculoTempoIdade getRegraCalculoTempoIdade() {
		return regraCalculoTempoIdade;
	}

	public void setRegraCalculoTempoIdade(RegraCalculoTempoIdade regraCalculoTempoIdade) {
		this.regraCalculoTempoIdade = regraCalculoTempoIdade;
	}

	public IndiceEconomico getIndiceEnconomicoUtilizadoPagamento() {
		return indiceEnconomicoUtilizadoPagamento;
	}

	public void setIndiceEnconomicoUtilizadoPagamento(IndiceEconomico indiceEnconomicoUtilizadoPagamento) {
		this.indiceEnconomicoUtilizadoPagamento = indiceEnconomicoUtilizadoPagamento;
	}

	public RegraCalculoTempoContribuicao getRegraCalculoTempoContribuicao() {
		return regraCalculoTempoContribuicao;
	}

	public void setRegraCalculoTempoContribuicao(RegraCalculoTempoContribuicao regraCalculoTempoContribuicao) {
		this.regraCalculoTempoContribuicao = regraCalculoTempoContribuicao;
	}

	@Override
	public RegraCalculoDevolucao clone() throws CloneNotSupportedException {
		RegraCalculoDevolucao regraCalculoDevolucao = (RegraCalculoDevolucao) super.clone();

		regraCalculoDevolucao.setCodigo(null);

		//Lista de contribuições.
		List<RegraDevolucaoContribuicao> listaRegraDevolucaoContribuicao = new ArrayList<RegraDevolucaoContribuicao>();

		for (RegraDevolucaoContribuicao regraDevolucaoContribuicao : regraCalculoDevolucao.getListaRegraDevolucaoContribuicao()) {
			listaRegraDevolucaoContribuicao.add(regraDevolucaoContribuicao.clone());
		}

		for (RegraDevolucaoContribuicao regraDevolucaoContribuicao : listaRegraDevolucaoContribuicao) {
			regraDevolucaoContribuicao.setCodigo(null);
		}

		regraCalculoDevolucao.setListaRegraDevolucaoContribuicao(listaRegraDevolucaoContribuicao);

		//Lista de Elegibilidades
		List<RegraElegibilidadeDevolucao> listaRegraElegibilidadeDevolucao = new ArrayList<RegraElegibilidadeDevolucao>();

		for (RegraElegibilidadeDevolucao regraElegibilidadeDevolucao : regraCalculoDevolucao.getListaRegraElegibilidadeDevolucao()) {
			listaRegraElegibilidadeDevolucao.add(regraElegibilidadeDevolucao.clone());
		}

		for (RegraElegibilidadeDevolucao regraElegibilidadeDevolucao : listaRegraElegibilidadeDevolucao) {
			regraElegibilidadeDevolucao.setCodigo(null);
		}

		regraCalculoDevolucao.setListaRegraElegibilidadeDevolucao(listaRegraElegibilidadeDevolucao);

		return regraCalculoDevolucao;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegraCalculoDevolucao other = (RegraCalculoDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RegraCalculoDevolucao [codigo=" + codigo + ", regraDevolucao=" + regraDevolucao + ", tipoDevolucao=" + tipoDevolucao + ", regraCalculoTempoEmpresa=" + regraCalculoTempoEmpresa
				+ ", regraCalculoTempoPlano=" + regraCalculoTempoPlano + ", regraCalculoTempoIdade=" + regraCalculoTempoIdade + ", dataInicio=" + dataInicio + ", dataFim=" + dataFim
				+ ", numeroMaximoParcelas=" + numeroMaximoParcelas + ", percentualJuros=" + percentualJuros + ", indicadorTipoImpostoProgressivo=" + indicadorTipoImpostoProgressivo
				+ ", tipoValorizacaoEnum=" + tipoValorizacaoEnum + ", indiceEnconomicoUtilizadoPagamento=" + indiceEnconomicoUtilizadoPagamento + ", indiceEconomicoMinimoParcela="
				+ indiceEconomicoMinimoParcela + ", codigoMovimentoFundo=" + codigoMovimentoFundo + ", dataAlteracao=" + dataAlteracao + ", dataInclusao=" + dataInclusao + ", nomeUsuarioAlteracao="
				+ nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + ", listaRegraDevolucaoContribuicao=" + listaRegraDevolucaoContribuicao
				+ ", listaRegraElegibilidadeDevolucao=" + listaRegraElegibilidadeDevolucao + "]";
	}

}