package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ibm.icu.math.BigDecimal;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CalculoFolhaBO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   24/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("folhaCalculoVisao")
public class FolhaCalculoVisao {

	private static String FW_CALCULO_FOLHA = "/paginas/folhaCalculo.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private CalculoFolhaBO calculoFolha;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private CronogramaDevolucao cronogramaDevolucao;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private String numeroMatriculaPatrocinadora;

	private Integer progress;

	private boolean indicativoNaoPodeGerar;

	private String retornoProcessamento;

	private Participante participante;

	/**
	 * Calcula a Folha conforme parâmetros selecionados
	 * 
	 */
	public void calcular() {
		try {
			//Limpa Variáveis Para Barra de Progresso
			CalculoFolhaBO.REGISTROPROCESSAMENTO = 0;
			CalculoFolhaBO.TOTALPROCESSAMENTO = 0;

			this.retornoProcessamento = calculoFolha.calcularFolhaDevolucao(cronogramaDevolucao, entidadeParticipante, planoPrevidencia, participante, loginTemporariaDTO);
			Mensagens.addMsgInfo(this.retornoProcessamento);
		} catch (Exception e) {
			this.cancel();
			PrimeFaces.current().executeScript("cancelPb()");
			Mensagens.addError("Erro ao processar folha. Erro: " + e.getMessage());
		}
	}

	/**
	 * Calcula o progresso da Barra
	 * @return
	 */
	public Integer getProgress() {
		if (progress == null) {
			progress = 0;
		} else {
			int calculoPercentual = 0;
			double registro = 0;
			double total = 0;

			if (CalculoFolhaBO.REGISTROPROCESSAMENTO > 0) {

				registro = CalculoFolhaBO.REGISTROPROCESSAMENTO;
				total = CalculoFolhaBO.TOTALPROCESSAMENTO == 0 ? 1 : CalculoFolhaBO.TOTALPROCESSAMENTO;

				calculoPercentual = new BigDecimal((registro / total) * 100).intValue();
			}

			progress = calculoPercentual;

			if (progress >= 100) {
				this.limpaSelecao();
				progress = 100;
			}

		}

		return progress;
	}

	public void setProgress(Integer progress) {
		this.progress = progress;
	}

	/**
	 * Emite mensagem de final de processamento
	 */
	public void onComplete() {
		CalculoFolhaBO.REGISTROPROCESSAMENTO = 0;
		CalculoFolhaBO.TOTALPROCESSAMENTO = 0;

		if (this.retornoProcessamento.equalsIgnoreCase("Término Processamento")) {
			Mensagens.addMsgInfo("Processamento Completo.");
		}
	}

	public void cancel() {
		progress = null;
	}

	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());
	}

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0333 - Daniel Martins
	 * @since   24/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		CalculoFolhaBO.REGISTROPROCESSAMENTO = 0;
		CalculoFolhaBO.TOTALPROCESSAMENTO = 0;

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("folhaCalculo");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.limpaSelecao();

		//Fazer cargas de listas de Combo.
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarCronogramaDevolucaoPermitemProcessamento());
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(entidadeParticipanteBO.listarEntidadeParticipante());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanos());

		return FW_CALCULO_FOLHA;
	}

	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.planoPrevidencia != null && this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantePorNomeEPatrocinadoraEPlanoPrevidencia(nome, this.entidadeParticipante, this.planoPrevidencia);
		} else if (this.planoPrevidencia != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else if (this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			return new ArrayList<Participante>();
		}

	}

	//Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   26/01/2017
	 */
	public void limpaSelecao() {
		this.setCronogramaDevolucao(null);
		this.setEntidadeParticipante(null);
		this.setPlanoPrevidencia(null);
		this.setNumeroMatriculaPatrocinadora(null);
		this.cancel();
		this.verificarSelecao();
		this.retornoProcessamento = null;
		this.setParticipante(null);

	}

	/**
	 * Verifica se foi selecionado um cronograma de devolução
	 */
	public void verificarSelecao() {
		if (this.cronogramaDevolucao != null) {
			this.setIndicativoNaoPodeGerar(false);
		} else {
			this.setIndicativoNaoPodeGerar(true);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 23/06/2017
	 */
	public void filtrarListaPlanos() {
		try {
			if (this.entidadeParticipante != null) {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante));
			} else {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanos());
			}
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public String getNumeroMatriculaPatrocinadora() {
		return numeroMatriculaPatrocinadora;
	}

	public void setNumeroMatriculaPatrocinadora(String numeroMatriculaPatrocinadora) {
		this.numeroMatriculaPatrocinadora = numeroMatriculaPatrocinadora;
	}

	public boolean isIndicativoNaoPodeGerar() {
		return indicativoNaoPodeGerar;
	}

	public void setIndicativoNaoPodeGerar(boolean indicativoNaoPodeGerar) {
		this.indicativoNaoPodeGerar = indicativoNaoPodeGerar;
	}

	public String getRetornoProcessamento() {
		return retornoProcessamento;
	}

	public void setRetornoProcessamento(String retornoProcessamento) {
		this.retornoProcessamento = retornoProcessamento;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

}
