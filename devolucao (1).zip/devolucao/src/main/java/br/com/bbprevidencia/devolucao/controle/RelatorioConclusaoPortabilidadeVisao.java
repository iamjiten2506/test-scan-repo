package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.DetalhePortabilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.DetalhePortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioConclusaoPortabilidadeDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar os relatórios de conslusão de portabilidade
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 31/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioConclusaoPortabilidadeVisao")
public class RelatorioConclusaoPortabilidadeVisao {

	private static final String FW_RELATORIO_CONCLUSAO_PORTABILIDADE = "/paginas/relatorioConclusaoPortabilidade.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioConclusaoPortabilidadeVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private DevolucaoBO devolucaoBO;
	@Autowired
	DetalhePortabilidadeDevolucaoBO detalhePortabilidadeDevolucaoBO;
	@Autowired
	RelatorioUtil relatorioUtil;

	private boolean selecionarParticipante;
	private boolean selecionarPlano;

	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private EntidadeParticipante entidadeParticipante;
	private PlanoPrevidencia planoPrevidencia;
	private Participante participante;
	private List<Devolucao> listaDevolucao;
	private List<DetalhePortabilidadeDevolucao> listaDetalhePortabilidadeDevolucao;
	private String idEnviado;

	private String tipoRelatorio;

	/**
	 * Método encarregado de chamar a página de preenchimento de parâmetros
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 * @return
	 */
	public String iniciarRelatorioConclusaoPortabilidade() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_CONCLUSAO_PORTABILIDADE;
	}

	/**
	 * Setar os valores iniciais da Tela
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/07/2017
	 */
	private void setarValoresIniciais() {
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipante)) {
			this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.entidadeParticipanteBO.listarEntidadeParticipanteOrderByNome());
		}
		this.entidadeParticipante = null;
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.participante = new Participante();
		this.planoPrevidencia = new PlanoPrevidencia();
		this.setTipoRelatorio("CP");

		this.selecionarParticipante = false;
		this.selecionarPlano = false;
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/03/2017
	 */
	public void listarPlanoPrevidenciaPorPatrocinadora() {
		try {
			if (this.getEntidadeParticipante() != null) {
				this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante);
				this.selecionarPlano = true;
				this.selecionarParticipante = true;
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 */
	public void liberarParticipanteParaPesquisa() {
		try {
			if (this.getPlanoPrevidencia() != null) {
				this.selecionarParticipante = true;
			} else {
				this.selecionarParticipante = false;
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo digitado no autocomplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.getPlanoPrevidencia().getCodigo() != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.getEntidadeParticipante());
		}
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 30/03/2017
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() == null) {
			setParticipante(new Participante());
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/03/2017
	 * @param event
	 */
	public void limparPesquisa() {
		setarValoresIniciais();
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 31/03/2017
	 * @param event
	 */
	public void exportarRelatorio(ActionEvent event) {
		try {
			setIdEnviado(event.getComponent().getId());

			this.listaDevolucao = new ArrayList<Devolucao>(devolucaoBO.pesquisarDevolucaoPagaPorParticipantePlano(this.getParticipante().getListaParticipantePlano()));

			if (UtilJava.isColecaoVazia(this.listaDevolucao)) {
				Mensagens.addMsgInfo("Não foram encontradas devoluções para este participante!");
			} else {
				if (this.tipoRelatorio.equalsIgnoreCase("CP")) {
					for (Devolucao devolucao : this.listaDevolucao) {
						if (devolucao.getSituacaoDevolucao().getCodigo().longValue() != 7) {
							throw new PrevidenciaException("A Carta de Conclusão só poderá ser emitida apos realizado do pagamento.");
						}
					}
				}

				if (this.tipoRelatorio.equalsIgnoreCase("ET")) {
					for (Devolucao devolucao : this.listaDevolucao) {
						if (devolucao.getSituacaoDevolucao().getCodigo().longValue() == 7) {
							throw new PrevidenciaException("O Encaminhamento Tesouraria apenas poderá ser emitida antes realizado do pagamento.");
						}
					}
				}

				List<RelatorioConclusaoPortabilidadeDTO> relatorioConclusaoPortabilidade = new ArrayList<RelatorioConclusaoPortabilidadeDTO>();
				relatorioConclusaoPortabilidade = this.devolucaoBO.montarRelatorioDePortabilidade(this.listaDevolucao, this.getTipoRelatorio());

				//ERRO PROPOSITAL

				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

				parametros.put("logo", logo);

				String assinaturaGeseg = UtilSession.getRealPath("imagens/LogotiposExterno/assinaturaGeseg.jpg");

				if (this.tipoRelatorio.equalsIgnoreCase("CP")) {

					parametros.put("assinaturaGeseg", assinaturaGeseg);

					parametros.put("listaConclusaoPortabilidade", relatorioConclusaoPortabilidade);

					parametros.put("nomeLongoEntidadeOrigem", relatorioConclusaoPortabilidade.get(0).getNomeLongoEntidadeOrigem());
					parametros.put("logradouroOrigem", relatorioConclusaoPortabilidade.get(0).getLogradouroOrigem());
					parametros.put("numeroLogradouroOrigem", relatorioConclusaoPortabilidade.get(0).getNumeroLogradouroOrigem());
					parametros.put("complementoOrigem", relatorioConclusaoPortabilidade.get(0).getComplementoOrigem());
					parametros.put("bairroOrigem", relatorioConclusaoPortabilidade.get(0).getBairroOrigem());
					parametros.put("cidadeOrigem", relatorioConclusaoPortabilidade.get(0).getCidadeOrigem());
					parametros.put("ufOrigem", relatorioConclusaoPortabilidade.get(0).getUfOrigem());
					parametros.put("cepOrigem", relatorioConclusaoPortabilidade.get(0).getCepOrigem());

					RelatorioConclusaoPortabilidadeDTO meuDado = new RelatorioConclusaoPortabilidadeDTO();
					List<RelatorioConclusaoPortabilidadeDTO> minhaLista = new ArrayList<RelatorioConclusaoPortabilidadeDTO>();
					minhaLista.add(meuDado);

					imprimirRelatorio("conclusaoPortabilidade", minhaLista, parametros);
				} else if (this.tipoRelatorio.equalsIgnoreCase("ET")) {
					imprimirRelatorio("encaminhamentoTesouraria", relatorioConclusaoPortabilidade, parametros);
				} else if (this.tipoRelatorio.equalsIgnoreCase("CE")) {
					parametros.put("assinaturaGeseg", assinaturaGeseg);
					imprimirRelatorio("cartaPortabilidadeEntidade", relatorioConclusaoPortabilidade, parametros);
				} else if (this.tipoRelatorio.equalsIgnoreCase("TP")) {

					imprimirRelatorio("termoPortabilidade", relatorioConclusaoPortabilidade, parametros);
				}

			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param relatorio
	 * @param dados
	 * @param param
	 */
	public void imprimirRelatorio(String relatorio, List<RelatorioConclusaoPortabilidadeDTO> dados, Map<String, Object> parametros) {
		String nomeArquivo = "";
		try {

			if (getIdEnviado().equals("btEmitirPDF")) {
				nomeArquivo = relatorioUtil.gerarRelatorio(relatorio, dados, parametros);
			} else {
				nomeArquivo = relatorioUtil.gerarRelatorioDocx(relatorio, dados, parametros);
			}

			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (Exception e) {
			log.error("Erro ao exportar relatório.", e);
			throw new PrevidenciaException(e);
		}
	}

	public void abrirAba() {
		//PrimeFaces.current().executeScript("window.open('','_blank','width=screen.availWidth, height=screen.availHeight, dependent=yes, menubar=no, toolbar=no, resizable=yes')");
		String codigoExec = "abreNovaAba(" + null + ")";
		PrimeFaces.current().executeScript(codigoExec);

	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isSelecionarParticipante() {
		return selecionarParticipante;
	}

	public void setSelecionarParticipante(boolean selecionarParticipante) {
		this.selecionarParticipante = selecionarParticipante;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public String getTipoRelatorio() {
		return tipoRelatorio;
	}

	public void setTipoRelatorio(String tipoRelatorio) {
		this.tipoRelatorio = tipoRelatorio;
	}

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	public List<DetalhePortabilidadeDevolucao> getListaDetalhePortabilidadeDevolucao() {
		return listaDetalhePortabilidadeDevolucao;
	}

	public void setListaDetalhePortabilidadeDevolucao(List<DetalhePortabilidadeDevolucao> listaDetalhePortabilidadeDevolucao) {
		this.listaDetalhePortabilidadeDevolucao = listaDetalhePortabilidadeDevolucao;
	}

	public String getIdEnviado() {
		return idEnviado;
	}

	public void setIdEnviado(String idEnviado) {
		this.idEnviado = idEnviado;
	}

}
