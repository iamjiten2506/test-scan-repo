package br.com.bbprevidencia.devolucao.controle;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import br.bb.previdencia.seguranca.criptografia.Criptografia;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO.PARAMETROS;
import br.com.bbprevidencia.cadastroweb.bo.UsuarioBO;
import br.com.bbprevidencia.cadastroweb.dao.PerfilSistemaFuncionalidadeDAO;
import br.com.bbprevidencia.cadastroweb.dao.UsuarioDAO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.ParametroGeral;
import br.com.bbprevidencia.cadastroweb.dto.PerfilSistemaFuncionalidade;
import br.com.bbprevidencia.cadastroweb.dto.Usuario;
import br.com.bbprevidencia.cadastroweb.enumerador.TipoLogin;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.filtro.FiltroSessao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe controller que manipula as requisições de autenticação da patrocinadora/participante vindo do Login no Portal da BBPrevidência, 
 * do AdminSistemas e do acesso identificado. 
 * 
 * @author Marco Figueiredo
 * @since 26/09/2016
 * 
 * Copyright notice (c) 2016 BBPrevidência S/A
 */
@Controller
public class LoginDevolucaoController {

	public static Logger log = Logger.getLogger(LoginDevolucaoController.class);

	public static final String PAGINA_INICIAL = "redirect:/template/apresentacao.jsf";
	private static final String FW_APRESENTACAO = "/template/apresentacao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private ParametroGeralBO parametroGeralBO;

	@Autowired
	private UsuarioBO usuarioBO;

	@Autowired
	private UsuarioDAO usuarioDAO;

	@Autowired
	private AmbienteServico ambienteServico;

	@Autowired
	private PerfilSistemaFuncionalidadeDAO perfilSistemaFuncionalidadeDAO;

	/**
	 * Injeta o usuário na sessão.
	 * 
	 * @param request
	 * @param loginTemporario
	 * @param usuarioSessao
	 */
	private void manterDadosSessao(HttpServletRequest request, LoginBBPrevWebDTO loginTemporario, br.bb.previdencia.seguranca.dto.Usuario usuarioSessao) {
		//obtem a sessão do usuário.	
		HttpSession session = request.getSession(true);

		//verifica se o tipo do login é BBPrevidencia ou Patrocinadora.
		if (loginTemporario.isBBPrevidenciaOuPatrocinadora()) {
			session.setAttribute("logado", "OK");
		}
		session.setAttribute("usuario", usuarioSessao);
		session.setAttribute("loginTemporario", loginTemporario);
	}

	/**
	 * Valida o usuário logado no adminsistemas e gera as informações de sessão do usuário, para Sistema de Controle Férias.
	 * 
	 * @return
	 */
	@RequestMapping("/loginAdminSistemasDevolucao/{codigoUsuario}")
	public String loginAdminSistemasDevolucao(@PathVariable String codigoUsuario, HttpServletRequest request, HttpServletResponse response) {

		log.info("IP de quem acessou: " + request.getRemoteAddr());

		usuarioDAO.setPersistentClass(Usuario.class);
		perfilSistemaFuncionalidadeDAO.setPersistentClass(PerfilSistemaFuncionalidade.class);

		try {

			codigoUsuario = Criptografia.descriptografar(codigoUsuario);

			Usuario usuario = new Usuario();

			usuario = usuarioBO.pesquisarUsuarioAtivoPorCodigo(Long.parseLong(codigoUsuario));

			if (usuario != null) {

				br.bb.previdencia.seguranca.dto.Usuario usuarioSessao = new br.bb.previdencia.seguranca.dto.Usuario();

				usuarioSessao = new br.bb.previdencia.seguranca.dto.Usuario();
				usuarioSessao.setCodigo(usuario.getCodigo());
				usuarioSessao.setName(usuario.getPessoa().getNome());
				usuarioSessao.setDescricaoLogin(usuario.getLogin());

				// valor padrão para o código de sistema BBPrevWeb caso não esteja parametrizado na tabela PARAMETRO_GERAL
				Integer codigoSistema = 0;

				ParametroGeral parametroCodigoSistema = parametroGeralBO.consultarParametro(PARAMETROS.CODIGO_SISTEMA_DEVOLUCAO);

				if (parametroCodigoSistema != null) {
					try {
						codigoSistema = Integer.parseInt(parametroCodigoSistema.getDescricaoPatrametro());
					} catch (NumberFormatException e) {
						log.warn("Parametro CODIGO_SISTEMA_BBPREVWEB com valor não numérico! Assumindo valor padrão igual a " + codigoSistema);
					}
				} else {
					log.warn("Parametro CODIGO_SISTEMA_BBPREVWEB não cadastrado! Assumindo valor padrão igual a " + codigoSistema);
				}

				// obtem a lista de funcionalidades do usuário para o sistema BBPrevWeb
				List<PerfilSistemaFuncionalidade> listaPerfilSistemaFuncionalidade = perfilSistemaFuncionalidadeDAO.listarPerfilSistemaUsuario(usuario.getPessoa().getCodigo(), codigoSistema);

				if (listaPerfilSistemaFuncionalidade.isEmpty()) {
					log.warn("O usuário " + usuario.getLogin() + " não possui funcionalidades vinculadas!");
				}

				List<br.bb.previdencia.seguranca.dto.Funcionalidade> listaFuncionalidade = new ArrayList<br.bb.previdencia.seguranca.dto.Funcionalidade>();

				for (PerfilSistemaFuncionalidade perfilSistemaFuncionalidade : listaPerfilSistemaFuncionalidade) {
					br.bb.previdencia.seguranca.dto.Funcionalidade f = new br.bb.previdencia.seguranca.dto.Funcionalidade();
					f.setCodigo(perfilSistemaFuncionalidade.getPk().getFuncionalidade().getCodigo());
					f.setNome(perfilSistemaFuncionalidade.getPk().getFuncionalidade().getLiteral());// retorna a literal cadastrada 
					f.setTipoAcesso(perfilSistemaFuncionalidade.getTipoAcesso());

					log.info("Funcionalidade encontrada para o usuário " + usuario.getLogin() + ": " + perfilSistemaFuncionalidade.getPk().getFuncionalidade().getLiteral());

					listaFuncionalidade.add(f);
				}

				// seta a lista de funcionalidades para o usuário
				usuarioSessao.setListaFuncionalidade(listaFuncionalidade);

				LoginBBPrevWebDTO loginTemporariaDTO = new LoginBBPrevWebDTO();
				loginTemporariaDTO.setUsuarioSessao(usuarioSessao);
				loginTemporariaDTO.setTipoLogin(TipoLogin.USUARIO_SISTEMA_BBPREVIDENCIA);

				HttpSession session = request.getSession(true);
				session.setAttribute(FiltroSessao.TOKEN_SESSAO_VALIDADA, "OK");
				session.setAttribute("usuario", usuarioSessao);
				session.setAttribute("loginTemporario", loginTemporariaDTO);

				response.setHeader("Cache-Control", "no-store");
				response.setHeader("Pragma", "no-cache");
				response.setDateHeader("Expires", 0);

				UtilSession.adicionarCookie(response, UtilSession.COOKIE_TIPO_USUARIO, TipoLogin.USUARIO_SISTEMA_BBPREVIDENCIA.getCodigo().toString());
				return PAGINA_INICIAL;

			} else {
				log.info("Não foi possivel autenticar o usuário. Redirecionando para o admin sistemas");
				return this.ambienteServico.getUrlAdminsistemas();
			}
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi possível realizar está operação", e);
		}
	}

	/**
	 * Valida o usuário logado no adminsistemas e gera as informações de sessão do usuário, para Sistema de Controle Férias.
	 * 
	 * @return
	 */
	public LoginBBPrevWebDTO loginAdminSistemasDevolucaoExterno(String codigoUsuario) {

		usuarioDAO.setPersistentClass(Usuario.class);
		perfilSistemaFuncionalidadeDAO.setPersistentClass(PerfilSistemaFuncionalidade.class);

		try {
			LoginBBPrevWebDTO loginTemporariaDTO = new LoginBBPrevWebDTO();
			codigoUsuario = Criptografia.descriptografar(codigoUsuario);

			Usuario usuario = new Usuario();

			usuario = usuarioDAO.consultarUsuarioPorCodigo(new Long(codigoUsuario));

			if (usuario != null) {

				br.bb.previdencia.seguranca.dto.Usuario usuarioSessao = new br.bb.previdencia.seguranca.dto.Usuario();

				usuarioSessao = new br.bb.previdencia.seguranca.dto.Usuario();
				usuarioSessao.setCodigo(usuario.getCodigo());
				usuarioSessao.setName(usuario.getPessoa().getNome());
				usuarioSessao.setDescricaoLogin(usuario.getLogin());

				// valor padrão para o código de sistema BBPrevWeb caso não esteja parametrizado na tabela PARAMETRO_GERAL
				Integer codigoSistema = 0;

				ParametroGeral parametroCodigoSistema = parametroGeralBO.consultarParametro(PARAMETROS.CODIGO_SISTEMA_DEVOLUCAO);

				if (parametroCodigoSistema != null) {
					try {
						codigoSistema = Integer.parseInt(parametroCodigoSistema.getDescricaoPatrametro());
					} catch (NumberFormatException e) {
						log.warn("Parametro CODIGO_SISTEMA_BBPREVWEB com valor não numérico! Assumindo valor padrão igual a " + codigoSistema);
					}
				} else {
					log.warn("Parametro CODIGO_SISTEMA_BBPREVWEB não cadastrado! Assumindo valor padrão igual a " + codigoSistema);
				}

				// obtem a lista de funcionalidades do usuário para o sistema BBPrevWeb
				List<PerfilSistemaFuncionalidade> listaPerfilSistemaFuncionalidade = perfilSistemaFuncionalidadeDAO.listarPerfilSistemaUsuario(usuario.getPessoa().getCodigo(), codigoSistema);

				if (listaPerfilSistemaFuncionalidade.isEmpty()) {
					log.warn("O usuário " + usuario.getLogin() + " não possui funcionalidades vinculadas!");
				}

				List<br.bb.previdencia.seguranca.dto.Funcionalidade> listaFuncionalidade = new ArrayList<br.bb.previdencia.seguranca.dto.Funcionalidade>();

				for (PerfilSistemaFuncionalidade perfilSistemaFuncionalidade : listaPerfilSistemaFuncionalidade) {
					br.bb.previdencia.seguranca.dto.Funcionalidade f = new br.bb.previdencia.seguranca.dto.Funcionalidade();
					f.setCodigo(perfilSistemaFuncionalidade.getPk().getFuncionalidade().getCodigo());
					f.setNome(perfilSistemaFuncionalidade.getPk().getFuncionalidade().getLiteral());// retorna a literal cadastrada 
					f.setTipoAcesso(perfilSistemaFuncionalidade.getTipoAcesso());

					log.info("Funcionalidade encontrada para o usuário " + usuario.getLogin() + ": " + perfilSistemaFuncionalidade.getPk().getFuncionalidade().getLiteral());

					listaFuncionalidade.add(f);
				}

				// seta a lista de funcionalidades para o usuário
				usuarioSessao.setListaFuncionalidade(listaFuncionalidade);

				loginTemporariaDTO.setUsuarioSessao(usuarioSessao);
				loginTemporariaDTO.setTipoLogin(TipoLogin.USUARIO_SISTEMA_BBPREVIDENCIA);

			}

			return loginTemporariaDTO;
		} catch (Exception e) {
			log.error(e);
			throw new PrevidenciaException("Não foi possível realizar está operação", e);
		}
	}

	public String deslogarUsuario() {
		UtilSession.invalidarSessaoCorrente();
		return FW_APRESENTACAO;
	}

	/**
	 * Retorna a versão atual do sistema a partir do MANIFEST.MF gerado pelo maven, contendo a versão no pom.xml do projeto
	 * 
	 * @return
	 */
	public String getVersaoSistema() {
		try {
			InputStream inputStream = FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/META-INF/MANIFEST.MF");
			Manifest manifest = new Manifest(inputStream);
			Attributes attributes = manifest.getMainAttributes();
			return attributes.getValue("Implementation-Version");
		} catch (Exception e) {
			log.warn("Sem arquivo MANIFEST.MF para exibir versão do sistema: " + e.getMessage());
			return null;
		}
	}
}
