package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 23/10/2017 Classe de persistência para tabela DEVOLUCAO.
 */
@Entity
public class ConferenciaDevolucaoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@JoinColumn(name = "NUM_SEQ_PARTIC_PLANO")
	@ManyToOne(fetch = FetchType.LAZY)
	private ParticipantePlano participantePlano;

	@Column(name = "QTD_TOTAL")
	private Double totalCotas;

	@Column(name = "NOM_PARTIC")
	private String nomeParticipante;

	@Column(name = "NUM_MATRIC_PATROC")
	private String matricula;

	@Column(name = "DAT_REQ")
	private Date dataRequerimento;

	@Column(name = "VAL_IND_AJU")
	private Double valorAjustado;

	@Transient
	private boolean usuarioRequerimento;

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public ParticipantePlano getParticipantePlano() {
		return participantePlano;
	}

	public void setParticipantePlano(ParticipantePlano participantePlano) {
		this.participantePlano = participantePlano;
	}

	public Double getTotalCotas() {
		return totalCotas;
	}

	public void setTotalCotas(Double totalCotas) {
		this.totalCotas = totalCotas;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public Double getValorAjustado() {
		return valorAjustado;
	}

	public void setValorAjustado(Double valorAjustado) {
		this.valorAjustado = valorAjustado;
	}

	public boolean isUsuarioRequerimento() {
		return usuarioRequerimento;
	}

	public void setUsuarioRequerimento(boolean usuarioRequerimento) {
		this.usuarioRequerimento = usuarioRequerimento;
	}

}