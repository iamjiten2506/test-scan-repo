package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   05/12/2016
 * Classe de persistência para tabela HIS_SIT_REG_DEV.
 */
@Entity
@Table(name = "HST_SIT_REG_DEV", schema = "OWN_DCR")
@NamedQuery(name = "HistoricoSituacaoRegraDevolucao.findAll", query = "SELECT q FROM HistoricoSituacaoRegraDevolucao q")
public class HistoricoSituacaoRegraDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "HST_SIT_REG_DEV_GER", sequenceName = "S_HSRD_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "HST_SIT_REG_DEV_GER")
	@Column(name = "NUM_SEQ_HIS_REG_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SIT_REGRA_DEV")
	private SituacaoRegraDevolucao situacaoRegraDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_DEV")
	private RegraDevolucao regraDevolucao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_HST_SIT")
	private Date dataHistoricoSituacao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Column(name = "DSC_HST_REG_DEV")
	private String descricaoHistorico;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public SituacaoRegraDevolucao getSituacaoRegra() {
		return situacaoRegraDevolucao;
	}

	public void setSituacaoRegra(SituacaoRegraDevolucao situacaoRegraDevolucao) {
		this.situacaoRegraDevolucao = situacaoRegraDevolucao;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public Date getDataHistoricoSituacao() {
		return dataHistoricoSituacao;
	}

	public void setDataHistoricoSituacao(Date dataHistoricoSituacao) {
		this.dataHistoricoSituacao = dataHistoricoSituacao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getDescricaoHistorico() {
		return descricaoHistorico;
	}

	public void setDescricaoHistorico(String descricaoHistorico) {
		this.descricaoHistorico = descricaoHistorico;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HistoricoSituacaoRegraDevolucao other = (HistoricoSituacaoRegraDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}