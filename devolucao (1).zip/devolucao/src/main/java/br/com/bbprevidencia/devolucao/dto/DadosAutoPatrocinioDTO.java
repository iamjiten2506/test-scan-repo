package br.com.bbprevidencia.devolucao.dto;

public class DadosAutoPatrocinioDTO {

	private String partePlano;
	private String tipoContribuicao;
	private Double valorParticipante;
	private Double valorPatrocinadora;

	public String getPartePlano() {
		return partePlano;
	}

	public void setPartePlano(String partePlano) {
		this.partePlano = partePlano;
	}

	public String getTipoContribuicao() {
		return tipoContribuicao;
	}

	public void setTipoContribuicao(String tipoContribuicao) {
		this.tipoContribuicao = tipoContribuicao;
	}

	public Double getValorParticipante() {
		return valorParticipante;
	}

	public void setValorParticipante(Double valorParticipante) {
		this.valorParticipante = valorParticipante;
	}

	public Double getValorPatrocinadora() {
		return valorPatrocinadora;
	}

	public void setValorPatrocinadora(Double valorPatrocinadora) {
		this.valorPatrocinadora = valorPatrocinadora;
	}

}
