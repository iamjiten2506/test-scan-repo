package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.bb.previdencia.seguranca.criptografia.Criptografia;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipanteDevolucaoPosicionadaDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.LoteProcessamentoReferenciaCalcDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ReferenciaCalculoDevolucaoPosicionadoBO;
import br.com.bbprevidencia.devolucao.dto.DevolucaoPosicionadoDTO;
import br.com.bbprevidencia.devolucao.dto.LoteProcessamentoReferenciaCalcDevolucao;
import br.com.bbprevidencia.devolucao.dto.ReferenciaCalculoDevolucaoPosicionado;
import br.com.bbprevidencia.devolucao.execucao.TransactionParticipanteCalculo;
import br.com.bbprevidencia.devolucao.listener.Producer;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   24/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("calculoPosicionadorVisao")
public class CalculoPosicionadorVisao {

	private static String FW_POSIC_DEVOLUCAO = "/paginas/calculoPosicionadoResgate.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	
	@Autowired
	private CalculoDevolucaoWs calculoDevolucaoWs;
	
	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private LoteProcessamentoReferenciaCalcDevolucaoBO loteProcessamentoReferenciaCalcDevolucaoBO;
	
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	
	@Autowired
	private ReferenciaCalculoDevolucaoPosicionadoBO referenciaCalculoDevolucaoPosicionadoBO;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	
	private List<ReferenciaCalculoDevolucaoPosicionado> listaReferenciaCalculoDevolucaoPosicionado = new ArrayList<>(); 

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private String numeroMatriculaPatrocinadora;

	private boolean indicativoNaoPodeGerar;

	private String retornoProcessamento;
	
	private ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado;
	private Participante participante;
	
	@Autowired
	private Producer producer;
	
	/**
	 * Calcula a Folha conforme parâmetros selecionados
	 * 
	 */
	/*
	public void calcular() {
		try {
			
			if (this.referenciaCalculoDevolucaoPosicionado == null) {
				Mensagens.addError("Referência é parâmetro obrigatório.");
			}
			
			List<EntidadeParticipante> listaEntidade = new ArrayList<>();
			
			if (entidadeParticipante != null){
				listaEntidade.add(this.entidadeParticipante);
			}else{
				listaEntidade.addAll(this.listaEntidadeParticipante);
			}
			
			//Excluir processamento anterior
			this.referenciaCalculoDevolucaoPosicionadoBO.apagarReferenciaCalculoDevolucaoPosicionadoPorReferenciaEmpresaPlanoEParticipante(this.referenciaCalculoDevolucaoPosicionado, this.entidadeParticipante, this.planoPrevidencia, this.participante);
			
//			this.referenciaCalculoDevolucaoPosicionadoBO.deletarReferenciaCalculoDevolucaoPosicionadoPorReferenciaEmpresaPlanoEParticipa
			
			LoteProcessamentoReferenciaCalcDevolucao lote = geracaoLoteProcessamento();
			
			List<ParticipanteDevolucaoPosicionadaDTO> listaParticipante = pesquisarParticipantes();
			
			Future<List<ReferenciaCalculoDevPosicionadoValores>> promisse = this.calculoDevolucaoWs.calculoDevolucaoAssincronoDados(listaParticipante, lote, this.referenciaCalculoDevolucaoPosicionado, loginTemporariaDTO);
		
			this.retornoProcessamento = "Será enviado email ao término do Processo - Sistema poderá ser utilizado normalmente";
			Mensagens.addMsgInfo(this.retornoProcessamento);
			 
		} catch (Exception e) {
			Mensagens.addError("Erro ao processar folha. Erro: " + e.getMessage());
		}
	}*/
	

	//Rabbit MQ
	public void calcular() {
		try {
			
			if (this.referenciaCalculoDevolucaoPosicionado == null) {
				Mensagens.addError("Referência é parâmetro obrigatório.");
			}
			
			List<EntidadeParticipante> listaEntidade = new ArrayList<>();
			
			if (entidadeParticipante != null){
				listaEntidade.add(this.entidadeParticipante);
			}else{
				listaEntidade.addAll(this.listaEntidadeParticipante);
			}
			
			//Excluir processamento anterior
			this.referenciaCalculoDevolucaoPosicionadoBO.apagarReferenciaCalculoDevolucaoPosicionadoPorReferenciaEmpresaPlanoEParticipante(this.referenciaCalculoDevolucaoPosicionado, this.entidadeParticipante, this.planoPrevidencia, this.participante);
			
			LoteProcessamentoReferenciaCalcDevolucao lote = geracaoLoteProcessamento();
			
			List<ParticipanteDevolucaoPosicionadaDTO> listaParticipante = pesquisarParticipantes();
			
//			Future<List<ReferenciaCalculoDevPosicionadoValores>> promisse = this.calculoDevolucaoWs.calculoDevolucaoAssincronoDados(listaParticipante, lote, this.referenciaCalculoDevolucaoPosicionado, loginTemporariaDTO);
			List<TransactionParticipanteCalculo> listaNova = new ArrayList<>();
			long count = 0;
			for (ParticipanteDevolucaoPosicionadaDTO participanteDevolucaoPosicionadaDTO : listaParticipante) {
				listaNova.add(new TransactionParticipanteCalculo(count++, participanteDevolucaoPosicionadaDTO,
						referenciaCalculoDevolucaoPosicionado, loginTemporariaDTO, lote));
			}
			
			for (TransactionParticipanteCalculo transactionParticipanteCalculo : listaNova) {
				Long login = loginTemporariaDTO.getUsuarioSessao().getCodigo();
				String usuario = Criptografia.criptografar(login.toString());
				
				DevolucaoPosicionadoDTO devolucaoDTO = new DevolucaoPosicionadoDTO(
						transactionParticipanteCalculo.getParticipanteDevolucaoPosicionadaDTO().getChavePrimaria().getCodigoParticipante().toString(), 
						transactionParticipanteCalculo.getParticipanteDevolucaoPosicionadaDTO().getPlanoPrevidencia().getCodigo().toString(), 
						transactionParticipanteCalculo.getParticipanteDevolucaoPosicionadaDTO().getPlanoPrevidencia().getTipoResgatePadrao().toString(), 
						UtilJava.formataDataPorPadrao(referenciaCalculoDevolucaoPosicionado.getDataReferencia(),"dd/MM/yyyy"), 
						"R", 
						"S", 
						"1", 
						UtilJava.formataDataPorPadrao(referenciaCalculoDevolucaoPosicionado.getDataCota(), "dd/MM/yyyy"), 
						"F", 
						usuario,
						transactionParticipanteCalculo.getReferenciaCalculoDevolucaoPosicionado().getCodigo(),
						lote.getCodigo(),
						transactionParticipanteCalculo.getParticipanteDevolucaoPosicionadaDTO().getChavePrimaria().getCodigoParticipantePlano());
				
				this.producer.produce(devolucaoDTO);
			}
			
			this.retornoProcessamento = "Será enviado email ao término do Processo - Sistema poderá ser utilizado normalmente";
			Mensagens.addMsgInfo(this.retornoProcessamento);
			 
		} catch (Exception e) {
			Mensagens.addError("Erro ao processar folha. Erro: " + e.getMessage());
		}
	}

	private List<ParticipanteDevolucaoPosicionadaDTO> pesquisarParticipantes() {
		List<ParticipanteDevolucaoPosicionadaDTO> listaParticipante  = this.participanteBO.pesquisarParticipantesCalculoPosicionadoEFinanceira(referenciaCalculoDevolucaoPosicionado.getDataReferencia(), referenciaCalculoDevolucaoPosicionado.getFundoPrevidencia().getCodigo(), this.planoPrevidencia, this.entidadeParticipante, this.participante);
		return listaParticipante;
	}

	private LoteProcessamentoReferenciaCalcDevolucao geracaoLoteProcessamento() {
		
		//Salva Lote de processamento
		LoteProcessamentoReferenciaCalcDevolucao lote = new LoteProcessamentoReferenciaCalcDevolucao(
				                                            this.referenciaCalculoDevolucaoPosicionado, 
				                                            new Date(), 
				                                            new Date(),
				                                            UtilSession.getLoginSessao().getUsuarioSessao().getDescricaoLogin() 
				                                            );
		this.loteProcessamentoReferenciaCalcDevolucaoBO.salvarLoteProcessamentoReferenciaCalcDevolucao(lote);
		return lote;
		
	}
	
	/**
	 * Método para retornar os participantes por plano que incluam o no nome o
	 * texo digitado no autocomplete
	 * 
	 * @author  BBPF0351 - Marco Antonio Figueiredo
	 * @param {@link
	 * 			String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.planoPrevidencia != null && this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantePorNomeEPatrocinadoraEPlanoPrevidencia(nome, this.entidadeParticipante, this.planoPrevidencia);
		} else if (this.planoPrevidencia != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else if (this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			return new ArrayList<Participante>();
		}

	}
	
	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0333 - Daniel Martins
	 * @since   24/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("folhaCalculo");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.limpaSelecao();

		//Fazer cargas de listas de Combo.
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(entidadeParticipanteBO.listarEntidadeParticipante());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanos());
		this.listaReferenciaCalculoDevolucaoPosicionado = this.referenciaCalculoDevolucaoPosicionadoBO.listarTodasReferenciaCalculoDevolucaoPosicionadoAbertas();
		
		return FW_POSIC_DEVOLUCAO;
	
	}
	
	

	private void carregarCombos() {
		//Fazer cargas de listas de Combo.
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(entidadeParticipanteBO.listarEntidadeParticipante());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanos());
		this.listaReferenciaCalculoDevolucaoPosicionado = this.referenciaCalculoDevolucaoPosicionadoBO.listarTodasReferenciaCalculoDevolucaoPosicionado();
				
	}

	//Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   26/01/2017
	 */
	public void limpaSelecao() {
		this.setEntidadeParticipante(null);
		this.setPlanoPrevidencia(null);
		this.setNumeroMatriculaPatrocinadora(null);
		this.setReferenciaCalculoDevolucaoPosicionado(null);
		this.setParticipante (null);
		carregarCombos();
		this.retornoProcessamento = null;

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 23/06/2017
	 */
	public void filtrarListaPlanos() {
		try {
			if (this.entidadeParticipante != null) {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante));
			} else {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanos());
			}
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}
	
	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0351 - Marco Antonio Figueiredo
	 * @since 10/05/2018
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());
	}
	

	public void filtrarListaEntidadeValidas() {
		try {
			this.listaEntidadeParticipante = this.entidadeParticipanteBO.listaEntidadesResponsavelValidas(this.referenciaCalculoDevolucaoPosicionado.getDataReferencia());
		} catch (Exception ex) {
			throw new PrevidenciaException(ex.getMessage());
		}
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}
	
	public String getNumeroMatriculaPatrocinadora() {
		return numeroMatriculaPatrocinadora;
	}

	public void setNumeroMatriculaPatrocinadora(String numeroMatriculaPatrocinadora) {
		this.numeroMatriculaPatrocinadora = numeroMatriculaPatrocinadora;
	}

	public boolean isIndicativoNaoPodeGerar() {
		return indicativoNaoPodeGerar;
	}

	public void setIndicativoNaoPodeGerar(boolean indicativoNaoPodeGerar) {
		this.indicativoNaoPodeGerar = indicativoNaoPodeGerar;
	}

	public String getRetornoProcessamento() {
		return retornoProcessamento;
	}

	public void setRetornoProcessamento(String retornoProcessamento) {
		this.retornoProcessamento = retornoProcessamento;
	}

	public List<ReferenciaCalculoDevolucaoPosicionado> getListaReferenciaCalculoDevolucaoPosicionado() {
		return listaReferenciaCalculoDevolucaoPosicionado;
	}

	public void setListaReferenciaCalculoDevolucaoPosicionado(
			List<ReferenciaCalculoDevolucaoPosicionado> listaReferenciaCalculoDevolucaoPosicionado) {
		this.listaReferenciaCalculoDevolucaoPosicionado = listaReferenciaCalculoDevolucaoPosicionado;
	}

	public ReferenciaCalculoDevolucaoPosicionado getReferenciaCalculoDevolucaoPosicionado() {
		return referenciaCalculoDevolucaoPosicionado;
	}

	public void setReferenciaCalculoDevolucaoPosicionado(
			ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado) {
		this.referenciaCalculoDevolucaoPosicionado = referenciaCalculoDevolucaoPosicionado;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}
	
}

