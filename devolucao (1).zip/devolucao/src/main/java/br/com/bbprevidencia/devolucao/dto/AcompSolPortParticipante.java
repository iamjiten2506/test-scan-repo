package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.Participante;

/**
 * @author  BBPF0468 - Carlos Wallace
 * @since   31/07/2019
 * Classe de persistência para tabela ACO_SOL_POR_PAR.
 */
@Entity
@Table(name = "ACO_SOL_POR_PAR", schema = "OWN_DCR")
public class AcompSolPortParticipante implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	//Incluir coluna para RG/CPF e Desligamento

	@Id
	@SequenceGenerator(name = "aco_sol_por_par_ger", sequenceName = "OWN_DCR.S_ASPP_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "aco_sol_por_par_ger")
	@Column(name = "NUM_SEQ_ACO_SOL_POR_PAR")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PARTIC")
	private Participante participante;

	@Column(name = "IND_STS_TSP")
	private Boolean statusAguardandoTSP;

	@Column(name = "IND_STS_PEN_RG_CPF")
	private Boolean statusPendenciaRgCpf;

	@Column(name = "IND_STS_PEN_TRM_DSL")
	private Boolean statusPendenciaDeslig;

	@Column(name = "IND_STS_PRO")
	private Boolean statusAguardandoProcessamento;

	@Column(name = "IND_SOL_PROC")
	private Boolean solicitacaoProcessada;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Transient
	private Boolean exibirTSP;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public Boolean getStatusAguardandoTSP() {
		return statusAguardandoTSP;
	}

	public void setStatusAguardandoTSP(Boolean statusAguardandoTSP) {
		this.statusAguardandoTSP = statusAguardandoTSP;
	}

	public Boolean getStatusPendenciaRgCpf() {
		return statusPendenciaRgCpf;
	}

	public void setStatusPendenciaRgCpf(Boolean statusPendenciaRgCpf) {
		this.statusPendenciaRgCpf = statusPendenciaRgCpf;
	}

	public Boolean getStatusPendenciaDeslig() {
		return statusPendenciaDeslig;
	}

	public void setStatusPendenciaDeslig(Boolean statusPendenciaDeslig) {
		this.statusPendenciaDeslig = statusPendenciaDeslig;
	}

	public Boolean getStatusAguardandoProcessamento() {
		return statusAguardandoProcessamento;
	}

	public void setStatusAguardandoProcessamento(Boolean statusAguardandoProcessamento) {
		this.statusAguardandoProcessamento = statusAguardandoProcessamento;
	}

	public Boolean getSolicitacaoProcessada() {
		return solicitacaoProcessada;
	}

	public void setSolicitacaoProcessada(Boolean solicitacaoProcessada) {
		this.solicitacaoProcessada = solicitacaoProcessada;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public AcompSolPortParticipante(Long codigo, Participante participante, Boolean statusAguardandoTSP, Boolean statusPendenciaRgCpf, Boolean statusPendenciaDeslig,
			Boolean statusAguardandoProcessamento, Boolean solicitacaoProcessada, String nomeUsuarioInclusao, Date dataInclusao, String nomeUsuarioAlteracao, Date dataAlteracao) {
		super();
		this.codigo = codigo;
		this.participante = participante;
		this.statusAguardandoTSP = statusAguardandoTSP;
		this.statusPendenciaRgCpf = statusPendenciaRgCpf;
		this.statusPendenciaDeslig = statusPendenciaDeslig;
		this.statusAguardandoProcessamento = statusAguardandoProcessamento;
		this.solicitacaoProcessada = solicitacaoProcessada;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
		this.dataAlteracao = dataAlteracao;
	}

	public AcompSolPortParticipante() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Boolean getExibirTSP() {

		return (this.getParticipante().getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante() == 26
				|| this.getParticipante().getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante() == 10019
				|| this.getParticipante().getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante() == 22 || this.getParticipante().getEntidadeParticipante().getChavePrimaria()
				.getCodigoEntidadeParticipante() == 10003) ? true : false;

	}

	public void setExibirTSP(Boolean exibirTSP) {
		this.exibirTSP = exibirTSP;
	}

}