package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class SumulaOptOutDTO {

	private Date dataDeposito;

	private Double valorIndiceFator;

	private Double valorParticipante;

	private Double valorPatrocinadora;

	private Double valorTotalContribuicao;

	private Double valorTotalIndice;

	private Double valorTotalCota;

	private Double comparativoIndiceCota;

}
