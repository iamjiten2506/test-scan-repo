package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.TipoContribuicaoBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.TipoContribuicao;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoRegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.PlanoContribFaixasDevBO;
import br.com.bbprevidencia.devolucao.bo.PlanoVigenciaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoContribuicaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoEmpresaBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoIdadeBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoPlanoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoRegraBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoRegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.PlanoContribFaixasDev;
import br.com.bbprevidencia.devolucao.dto.PlanoVigenciaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoContribuicao;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoEmpresa;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoIdade;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoPlano;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucaoContribFaixas;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucaoContribuicao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucaoParametrizacaoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraElegibilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.IndicadorTipoImpostoProgressivoEnum;
import br.com.bbprevidencia.devolucao.enumerador.TipoValorizacaoEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.fundo.bo.MovimentoFundoPrevBO;
import br.com.bbprevidencia.fundo.dto.MovimentoFundoPrev;
import br.com.bbprevidencia.indice.bo.IndiceEconomicoBO;
import br.com.bbprevidencia.indice.dto.IndiceEconomico;
import br.com.bbprevidencia.utils.data.UtilData;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para manter as Regras de Devolução
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 08/02/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("regraDevolucaoVisao")
public class RegraDevolucaoVisao {

	private static final String FW_PESQUISA_REGRA_DEVOLUCAO = "/paginas/pesquisaRegraDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final String FW_CADASTRA_REGRA_DEVOLUCAO = "/paginas/cadastroRegraDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static Logger log = Logger.getLogger(RegraDevolucaoVisao.class);

	@Autowired
	private ParametrizaRegraDevolucao regraDevolucaoUtil;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoVigenciaDevolucaoBO planoVigenciaDevolucaoBO;

	@Autowired
	private RegraDevolucaoBO regraDevolucaoBO;

	@Autowired
	private PlanoContribFaixasDevBO planoContribFaixasDevBO;

	@Autowired
	private SituacaoRegraBO situacaoRegraBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private RegraCalculoTempoEmpresaBO regraCalculoTempoEmpresaBo;

	@Autowired
	private RegraCalculoTempoPlanoBO regraCalculoTempoPlanoBO;

	@Autowired
	private RegraCalculoTempoIdadeBO regraCalculoTempoIdadeBO;

	@Autowired
	private MovimentoFundoPrevBO movimentoFundoPrevBO;

	@Autowired
	private TipoContribuicaoBO tipoContribuicaoBO;

	@Autowired
	private HistoricoSituacaoRegraDevolucaoBO historicoSituacaoRegraDevolucaoBO;

	@Autowired
	private IndiceEconomicoBO indiceEconomicoBO;

	@Autowired
	private RegraCalculoTempoContribuicaoBO regraCalculoTempoContribuicaoBO;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private List<PlanoVigenciaDevolucao> listaPlanoVigenciaDevolucao;

	private List<TipoContribuicao> listaTipoContribuicaoSelecionada;

	private PlanoVigenciaDevolucao planoVigenciaDevolucao;

	private RegraDevolucaoParametrizacaoDTO regraDevolucaoCompleto;

	private boolean pesquisaStatus;

	private boolean mostrarOpcaoNovaRegra;

	private boolean mostrarCadastrarVigencia;

	private boolean existeRegraPlanoContribFaixasDev;

	private boolean regraClonada;

	private RegraCalculoDevolucao regraCalculoDevolucaoAntigo;

	private PlanoVigenciaDevolucao novoPlanoVigenciaDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	// Atributos de controle de edição
	private RegraCalculoDevolucao regraCalculoEditavel;

	private RegraDevolucaoContribuicao devolucaoContribuicaoEditavel;

	private RegraElegibilidadeDevolucao elegibilidadeDevolucaoEditavel;

	private RegraDevolucaoContribFaixas faixaContribuicaoEditavel;

	private PlanoContribFaixasDev planoContribFaixasDevEditavel;

	private List<SelectItem> listaIndicadorTipoImpostoProgressivo;

	private List<TipoDevolucao> listaTipoDevolucao;

	private List<RegraCalculoTempoEmpresa> listaRegraCalculoTempoEmpresa;

	private List<RegraCalculoTempoPlano> listaRegraCalculoTempoPlano;

	private List<RegraCalculoTempoIdade> listaRegraCalculoTempoIdade;

	private List<RegraCalculoTempoContribuicao> listaRegraCalculoTempoContribuicao;

	private List<MovimentoFundoPrev> listaMovimentoFundoPrev;

	private List<TipoContribuicao> listaTipoContribuicao;

	private List<IndiceEconomico> listaIndiceEconomico;

	private boolean editarRegraContribDevolucao;

	private boolean editarRegraElegibilidadeDevolucao;

	private boolean cancelarEditRegraContribDevolucao;

	private boolean cancelarEditRegraElegibilidadeDevolucao;

	private String indiceContribuicaoDevolucao;

	private String indiceElegibilidadeDevolucao;

	private String indiceCalculoDevolucao = "0";

	private String indiceFaixaContribuicao;

	private String indicePlanoContribFaixaDev;

	private boolean regraSalva;

	private String motivoIndeferimento;

	private RegraDevolucao regraDevolucaoIndeferir;

	private RegraDevolucao regraDevolucaoHist;

	private Date dataAtual;

	private RegraCalculoDevolucao regraCalculoDevolucaoItem;

	private List<HistoricoSituacaoRegraDevolucao> listaHistoricoSituacaoRegraDevolucao;

	private RegraDevolucaoContribuicao regraDevolucaoContribuicaoItem;

	// Controle de acesso ás funcionalidades
	private boolean usuarioPodeInserirRegraDev;
	private boolean usuarioPodeEnviarRegraDevParaHomolog;
	private boolean usuarioPodeHomolagarRegraDev;
	private boolean usuarioPodeAutorizarRegraDev;
	private boolean usuarioPodeIndeferirRegraDev;
	private boolean usuarioPodeRevogarRegraDev;
	private boolean validaIndicePagemento;

	/**
	 * Método encarregado de carregar a página incial de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 08/02/2017
	 * @return
	 */
	public String inciciarRegraDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
			this.usuarioPodeInserirRegraDev = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("inserirRegraDev");
			this.usuarioPodeEnviarRegraDevParaHomolog = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("enviarRegraDevParaHomolog");
			this.usuarioPodeHomolagarRegraDev = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("homolagarRegraDev");
			this.usuarioPodeAutorizarRegraDev = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("autorizarRegraDev");
			this.usuarioPodeIndeferirRegraDev = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("indeferirRegraDev");
			this.usuarioPodeRevogarRegraDev = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("revogarRegraDev");
		} else {
			this.possuiAcessoTotal = false;
			this.usuarioPodeInserirRegraDev = false;
			this.usuarioPodeEnviarRegraDevParaHomolog = false;
			this.usuarioPodeHomolagarRegraDev = false;
			this.usuarioPodeAutorizarRegraDev = false;
			this.usuarioPodeIndeferirRegraDev = false;
			this.usuarioPodeRevogarRegraDev = false;
		}

		regraDevolucaoCompleto = new RegraDevolucaoParametrizacaoDTO();
		this.listaPlanoPrevidencia = planoPrevidenciaBO.listarPlanos();
		this.setListaIndiceEconomico(indiceEconomicoBO.listarTodosIndiceEconomico());
		this.planoVigenciaDevolucao = null;
		this.listaPlanoVigenciaDevolucao = null;
		this.pesquisaStatus = true;
		this.mostrarOpcaoNovaRegra = false;
		// add 18/05/2017 por magson
		this.mostrarCadastrarVigencia = false;
		this.existeRegraPlanoContribFaixasDev = false;
		this.planoPrevidencia = null;
		this.setNovoPlanoVigenciaDevolucao(new PlanoVigenciaDevolucao());

		this.regraDevolucaoUtil.setListaRegraDevolucao(null);
		if (this.regraClonada) {
			// this.regraDevolucaoUtil.setListaRegraDevolucao(null);
			this.setRegraClonada(false);
		}

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método para retornar a lista de vigencias por Plano Previdencia
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @return
	 */
	public String pesquisarVigenciasPlano() {
		this.regraDevolucaoUtil.setListaRegraDevolucao(new ArrayList<RegraDevolucao>());
		this.mostrarOpcaoNovaRegra = false;
		// this.mostrarCadastrarVigencia = true;
		if (this.planoPrevidencia != null) {
			this.listaPlanoVigenciaDevolucao = new ArrayList<PlanoVigenciaDevolucao>(planoVigenciaDevolucaoBO.listarTodos(this.planoPrevidencia));

		} else {
			this.listaPlanoVigenciaDevolucao = new ArrayList<PlanoVigenciaDevolucao>();
		}

		if (UtilJava.isColecaoVazia(this.listaPlanoVigenciaDevolucao)) {
			this.mostrarOpcaoNovaRegra = false;
			this.setNovoPlanoVigenciaDevolucao(new PlanoVigenciaDevolucao());
		}
		// else {
		// this.mostrarOpcaoNovaRegra = true;
		// }
		this.listaEntidadeParticipante = this.entidadeParticipanteBO.listarEntidadeParticipantePorPlano(this.planoPrevidencia);

		this.getNovoPlanoVigenciaDevolucao().setPlanoPrevidencia(this.planoPrevidencia);
		this.mostrarCadastrarVigencia = true;
		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método para formatar a Data em dd/MM/yyyy
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param data
	 * @return
	 */
	public String formatarData(Date data) {
		return UtilJava.formataDataPorPadrao(data, "dd/MM/yyyy");
	}

	/**
	 * Método responsável de retornar toda a árvore de regras de devolução
	 * associadas a um PlanoVigenciaDevolucao
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 09/02/2017
	 * @return
	 */
	public String pesquisarRegrasDevolucao() {
		if (this.planoVigenciaDevolucao != null) {
			try {

				// Buscando regras por plano virgência.
				this.regraDevolucaoUtil.preencherListaRegraDevolucao(this.planoVigenciaDevolucao);

				// Criando lista.
				List<RegraDevolucao> listaRegraDevolucao = new ArrayList<RegraDevolucao>();

				// Buscando lista da pesquisa.
				listaRegraDevolucao = this.regraDevolucaoUtil.getListaRegraDevolucao();

				// Verifica se existe alguma regra.
				if (listaRegraDevolucao.size() == 0) {
					this.regraDevolucaoUtil.setListaRegraDevolucao(null);
					Mensagens.addMsgErro("Não existe regra devolução cadastrada");
				}

				this.mostrarOpcaoNovaRegra = true;
			} catch (PrevidenciaException pEx) {
				Mensagens.addMsgErro(pEx.getMessage());
			}

		}

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável de retornar a descrição longa do indicador do tipo de
	 * imposto progressivo
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 09/02/2017
	 * @param tipoImposto
	 * @return
	 */
	public String pesquisarIndicadorTipoImposto(String tipoImposto) {
		if (tipoImposto != null && !UtilJava.isStringVazia(tipoImposto)) {
			return IndicadorTipoImpostoProgressivoEnum.getIndicadorTipoImpostoProgressivoEnum(tipoImposto).getDescricaoLonga();
		} else {
			return null;
		}
	}

	/**
	 * Método responsável de retornar a descrição do tipo de Valorização
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 09/02/2017
	 * @param codigo
	 * @return
	 */
	public String pesquisarTipoValorizacao(String codigo) {
		return TipoValorizacaoEnum.getMantenedorEnum(codigo).getDescricao();
	}

	/**
	 * Método responsável por limapr os dados de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 10/02/2017
	 * @return
	 */
	public String limparDadosPesquisa() {
		this.setPlanoPrevidencia(null);
		this.listaPlanoVigenciaDevolucao = null;
		this.setPlanoVigenciaDevolucao(null);
		this.mostrarOpcaoNovaRegra = false;
		this.mostrarCadastrarVigencia = false;
		this.existeRegraPlanoContribFaixasDev = false;
		this.regraClonada = false;
		this.regraDevolucaoUtil.setListaRegraDevolucao(new ArrayList<RegraDevolucao>());
		this.setNovoPlanoVigenciaDevolucao(new PlanoVigenciaDevolucao());

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável por verificar a existência de Regras Planos Faixas
	 * Devolução por Regra Devolução Contribuição para que seja exibida ou não a
	 * tabela com estas informações
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 14/02/2017
	 * @return
	 */
	public boolean verficaRegraPlanoFaixasDev(RegraDevolucaoContribuicao regraDevolucaoContribuicao) {
		List<PlanoContribFaixasDev> listaPlanoContribFaixasDev = new ArrayList<PlanoContribFaixasDev>(planoContribFaixasDevBO
				.pesquisarPlanoContribFaixasDevPorRegraDevolucaoContribuicao(regraDevolucaoContribuicao));

		if (!UtilJava.isColecaoVazia(listaPlanoContribFaixasDev)) {
			return true;
		}

		return false;
	}

	/**
	 * Método responsável por clonar a Regra de Devolução e envia-la para a tela de
	 * Cadastro de Regras de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 14/02/2017
	 * @return
	 */
	public String duplicarRegraDevolucao(String regraIndex) {

		if (!UtilJava.isColecaoVazia(this.regraDevolucaoUtil.getListaRegraDevolucao())) {

			// Verfifica se é uma regra efetiva antes de Clonar
			if (this.regraDevolucaoUtil.getListaRegraDevolucao().get(Integer.parseInt(regraIndex)).getSituacaoRegraDevolucao().getCodigo() != 4L) {
				Mensagens.addMsgErro("Só poderá ser duplicada uma regra que estiver em produção!");
				return FW_PESQUISA_REGRA_DEVOLUCAO;
			}

			try {
				RegraDevolucao regraDevolucao = this.regraDevolucaoUtil.getListaRegraDevolucao().get(Integer.parseInt(regraIndex)).clone();
				RegraDevolucao regraDevolucao2 = this.regraDevolucaoUtil.getListaRegraDevolucao().get(Integer.parseInt(regraIndex)).clone();
				regraDevolucao.setSituacaoRegraDevolucao(situacaoRegraBO.pesquisarSituacaoRegraPorCodigo(1L));
				this.regraDevolucaoUtil.setNovaRegraDevolucao(regraDevolucao);
				this.regraDevolucaoUtil.setNovaRegraDevolucao2(regraDevolucao2);
				setarDadosInicias();
			} catch (CloneNotSupportedException e) {
				log.error("Erro ao Clonar Regra de Devolução.", e);
				throw new PrevidenciaException("Erro ao Clonar Regra de Devolução.", e);
			}

		}

		this.regraClonada = true;

		return FW_CADASTRA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável por preecher dados e listas necessárias no processo de
	 * cadastro da regra
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/02/2017
	 */
	public void setarDadosInicias() {
		this.setListaTipoDevolucao(this.tipoDevolucaoBO.listarTodosTipoDevolucao());
		this.setListaRegraCalculoTempoEmpresa(this.regraCalculoTempoEmpresaBo.listarRegraCalculoTempoEmpresa());
		this.setListaRegraCalculoTempoPlano(this.regraCalculoTempoPlanoBO.listarRegraCalculoTempoPlano());
		this.setListaRegraCalculoTempoIdade(this.regraCalculoTempoIdadeBO.listarRegraCalculoTempoIdade());
		this.setListaIndicadorTipoImpostoProgressivo(this.listarIndicadorTipoImpostoProgressivo());
		this.setListaMovimentoFundoPrev(movimentoFundoPrevBO.listarMovimentoFundoPrev());
		this.setListaTipoContribuicao(tipoContribuicaoBO.listarTipoContribuicao());
		this.regraCalculoEditavel = new RegraCalculoDevolucao();
		this.devolucaoContribuicaoEditavel = new RegraDevolucaoContribuicao();
		this.faixaContribuicaoEditavel = new RegraDevolucaoContribFaixas();
		this.planoContribFaixasDevEditavel = new PlanoContribFaixasDev();

		this.setListaRegraCalculoTempoContribuicao(this.regraCalculoTempoContribuicaoBO.listarRegraCalculoTempoContribuicao());
	}

	/**
	 * Método responsável por chamar o cadastro de uma nova regra de devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/02/2017
	 * @return
	 * @throws CloneNotSupportedException
	 */
	public String cadastrarNovaRegraDevolucao() throws CloneNotSupportedException {

		this.regraDevolucaoUtil.setNovaRegraDevolucao(new RegraDevolucao());
		this.regraDevolucaoUtil.getNovaRegraDevolucao().setSituacaoRegraDevolucao(situacaoRegraBO.pesquisarSituacaoRegraPorCodigo(1L));
		this.regraDevolucaoUtil.getNovaRegraDevolucao().setPlanoVigenciaDevolucao(this.planoVigenciaDevolucao);

		this.regraDevolucaoUtil.setNovaRegraDevolucao2(new RegraDevolucao());
		this.regraDevolucaoUtil.getNovaRegraDevolucao2().setSituacaoRegraDevolucao(situacaoRegraBO.pesquisarSituacaoRegraPorCodigo(1L));
		this.regraDevolucaoUtil.getNovaRegraDevolucao2().setPlanoVigenciaDevolucao(this.planoVigenciaDevolucao);

		setarDadosInicias();
		this.regraClonada = false;

		return FW_CADASTRA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável de buscar uma regra válida para duplicação
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/02/2017
	 * @return
	 */
	public String buscarRegraValidaParaDuplicar() {
		if (UtilJava.isColecaoVazia(this.regraDevolucaoUtil.getListaRegraDevolucao())) {
			Mensagens.addMsgErro("Não existem regras cadastradas para este plano!");

			return FW_PESQUISA_REGRA_DEVOLUCAO;
		} else {
			int index = 0;
			for (RegraDevolucao regraDevolucao : this.regraDevolucaoUtil.getListaRegraDevolucao()) {
				if (regraDevolucao.getSituacaoRegraDevolucao().getCodigo() == 4L) {
					return duplicarRegraDevolucao(Integer.toString(index));
				}
				index++;
			}
		}

		Mensagens.addMsgErro("Não existe regra em produção para realizar a operação!");

		return FW_PESQUISA_REGRA_DEVOLUCAO;

	}

	/**
	 * Método responsável por adicionar uma nova Regra Cálculo Devolução no Data
	 * Table
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/02/2017
	 * @param event
	 * @throws CloneNotSupportedException
	 */
	public void novaRegraCalculoDevolucaoEmBranco() throws CloneNotSupportedException {
		this.setRegraCalculoEditavel(new RegraCalculoDevolucao());
		this.indiceCalculoDevolucao = null;
		this.validaIndicePagemento = false;
		PrimeFaces.current().ajax().update(":frmEditarRegraCalculo");
		PrimeFaces.current().executeScript("PF('regraCalculoDialog').show()");

	}

	/**
	 * Método encarregado de adicionar uma nova Regra de Devolução Contribuição em
	 * branco
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 * @param {@link RegraCalculoDevolucao}
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 */
	public void novaRegraDevolucaoContribEmBranco(RegraCalculoDevolucao regraCalculoDevolucao, String indiceRc) throws NumberFormatException, CloneNotSupportedException {
		this.setRegraCalculoDevolucaoItem(regraCalculoDevolucao);
		this.indiceCalculoDevolucao = indiceRc;
		this.indiceContribuicaoDevolucao = null;
		removerTiposContribuicaoCadastrados();
		PrimeFaces.current().ajax().update(":frmEditarRegraContribuicao:regraContribuicaoDetalheCD");
		PrimeFaces.current().executeScript("PF('regraContribuicaoDialog').show()");
	}

	/**
	 * Método encarregado de adicionar uma nova Regra de Elegibilidade Devolução em
	 * branco
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 10/03/2017
	 * @param {@link RegraCalculoDevolucao}
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 */

	public void novaRegraElegibiidadeDevolucaoEmBranco(RegraCalculoDevolucao regraCalculoDevolucao, String indiceRc) throws NumberFormatException, CloneNotSupportedException {
		this.setRegraCalculoDevolucaoItem(regraCalculoDevolucao);
		this.indiceCalculoDevolucao = indiceRc;
		this.indiceElegibilidadeDevolucao = null;
		PrimeFaces.current().ajax().update(":frmEditarRegraElegibilidadeDevolucao:regraElegibilidadeDevolucaoDetalhe");
		PrimeFaces.current().executeScript("PF('regraElegibilidadeDevolucaoDialog').show()");

	}

	/**
	 * Método encarregado de adicionar uma nova Regra de Faixa Contribuição em
	 * branco
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 * @param {@link RegraDevolucaoContribuicao}
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 */

	public void novaFaixaContribuicaoEmBranco(RegraDevolucaoContribuicao regraDevolucaoContribuicao, String indiceRc, String indiceRdc) throws NumberFormatException, CloneNotSupportedException {
		this.setRegraDevolucaoContribuicaoItem(regraDevolucaoContribuicao);
		this.indiceCalculoDevolucao = indiceRc;
		this.indiceContribuicaoDevolucao = indiceRdc;
		this.indiceFaixaContribuicao = null;
		PrimeFaces.current().ajax().update(":frmEditarFaixasContribuicao:regraFaixasContribuicaoDetalhe");
		PrimeFaces.current().executeScript("PF('faixaContribuicaoDialog').show()");

	}

	/**
	 * Método encarregado de adicionar uma nova Regra de Plano Faixa Contribuição em
	 * branco
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 * @param {@link RegraDevolucaoContribuicao}
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 */
	public void novoPlanoContribFaixaDevEmBranco(RegraDevolucaoContribuicao regraDevolucaoContribuicao, String indiceRc, String indiceRdc) throws NumberFormatException, CloneNotSupportedException {

		this.setRegraDevolucaoContribuicaoItem(regraDevolucaoContribuicao);
		this.indiceCalculoDevolucao = indiceRc;
		this.indiceContribuicaoDevolucao = indiceRdc;
		this.planoContribFaixasDevEditavel.setPlanoPrevidencia(regraDevolucaoContribuicao.getRegraCalculoDevolucao().getRegraDevolucao().getPlanoVigenciaDevolucao().getPlanoPrevidencia());

		PrimeFaces.current().ajax().update(":frmEditarPlanoContribFaixasDev:planoContribFaixasDevDetalhe");
		PrimeFaces.current().executeScript("PF('planoContribFaixasDialog').show()");

	}

	/**
	 * Método responsável por deletar linhas no data table Regra Cálculo Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/02/2017
	 * @param {@link RegraCalculoDevolucao}
	 */
	public void excluirRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao, String index) {
		if (regraCalculoDevolucao != null) {

			this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().remove(Integer.parseInt(index));
			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().remove(Integer.parseInt(index));

		}
	}

	/**
	 * Método responsável por deletar linhas no data table Regra Devolução
	 * Contribuição
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 * @param {@link RegraCalculoDevolucao}
	 * @param index
	 */
	public void excluirRegraDevolucaoContribuicao(RegraCalculoDevolucao regraCalculoDevolucao, String indexRc, String indexRdc) {
		if (regraCalculoDevolucao != null) {
			regraCalculoDevolucao.getListaRegraDevolucaoContribuicao().remove(Integer.parseInt(indexRdc));

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indexRc)).getListaRegraDevolucaoContribuicao().remove(Integer.parseInt(indexRdc));

		}
	}

	/**
	 * Método responsável por deletar linhas no data table Regra Elegibilidade
	 * Devolução
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 10/03/2017
	 * @param {@link RegraCalculoDevolucao}
	 * @param index
	 */
	public void excluirRegraElegibilidadeDevolucao(RegraCalculoDevolucao regraCalculoDevolucao, String indexRc, String indexRed) {
		if (regraCalculoDevolucao != null) {
			regraCalculoDevolucao.getListaRegraElegibilidadeDevolucao().remove(Integer.parseInt(indexRed));

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indexRc)).getListaRegraElegibilidadeDevolucao().remove(Integer.parseInt(indexRed));

		}
	}

	/**
	 * Método responsável por deletar linhas no data table Faixa Devolução
	 * Contribuição
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 * @param {@link RegraCalculoDevolucao}
	 * @param index
	 */
	public void excluirRegraFaixaContribuicao(RegraCalculoDevolucao regraCalculoDevolucao, String indexRc, String indexRdc, String indexFc) {
		if (regraCalculoDevolucao != null) {
			regraCalculoDevolucao.getListaRegraDevolucaoContribuicao().get(Integer.parseInt(indexRdc)).getListaRegraDevolucaoContribFaixas().remove(Integer.parseInt(indexFc));

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indexRc)).getListaRegraDevolucaoContribuicao().get(Integer.parseInt(indexRdc))
					.getListaRegraDevolucaoContribFaixas().remove(Integer.parseInt(indexFc));

		}
	}

	/**
	 * Método responsável por deletar linhas no data table Planos Faixa Devolução
	 * Contribuição
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 * @param {@link RegraCalculoDevolucao}
	 * @param index
	 */
	public void excluirPlanoContribFaixaDev(RegraCalculoDevolucao regraCalculoDevolucao, String indexRc, String indexRdc, String indexPcfd) {
		if (regraCalculoDevolucao != null) {
			regraCalculoDevolucao.getListaRegraDevolucaoContribuicao().get(Integer.parseInt(indexRdc)).getListaPlanoContrtibFaixasDev().remove(Integer.parseInt(indexPcfd));

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indexRc)).getListaRegraDevolucaoContribuicao().get(Integer.parseInt(indexRdc))
					.getListaPlanoContrtibFaixasDev().remove(Integer.parseInt(indexPcfd));

		}
	}

	/**
	 * Método que retorna uma lista com os elementos contidos na
	 * IndicadorTipoImpostoProgressivoEnum
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/02/2017
	 * @return {@link IndicadorTipoImpostoProgressivoEnum}
	 */
	public List<SelectItem> listarIndicadorTipoImpostoProgressivo() {
		List<SelectItem> item = new ArrayList<SelectItem>();

		for (IndicadorTipoImpostoProgressivoEnum o : IndicadorTipoImpostoProgressivoEnum.values()) {
			item.add(new SelectItem(o.getCodigo(), o.getDescricaoLonga()));
		}

		return item;
	}

	/**
	 * Método que retorna um array com os elementos contidos na TipoValorizacaoEnum
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/02/2017
	 * @return {@link TipoValorizacaoEnum}
	 */
	public TipoValorizacaoEnum[] getTipoValorizacao() {
		return TipoValorizacaoEnum.values();
	}

	/**
	 * Método responsável por finalizar o preechimento em memória do objeto
	 * carregado no Dialog widgetVar="regraCalculoDialog"
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 17/02/2017
	 */

	public String salvarLinhaRegraCalculo() throws NumberFormatException, CloneNotSupportedException {
		// Atualizar o objeto de backup junto ao objeto que está sendo utilzado
		// na tela, mantendo referências diferentes regraCalculoEditavel.dataInicio
		if (this.indiceCalculoDevolucao == null) {
			this.regraCalculoEditavel.setRegraDevolucao(this.regraDevolucaoUtil.getNovaRegraDevolucao());

			// Validando linha a linha (data inicio e tipo de devolução não pode ser iguais)
			for (RegraCalculoDevolucao rcd : this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao()) {
				if ((UtilData.isDataIgual(rcd.getDataInicio(), this.regraCalculoEditavel.getDataInicio()))
						& (rcd.getTipoDevolucao().getCodigo().equals(this.regraCalculoEditavel.getTipoDevolucao().getCodigo()))) {
					Mensagens.addMsgErro("Já tem uma regra de cálculo com data inicial e tipo de devolução iguais.");
					PrimeFaces.current().ajax().update(":frmEditarRegraCalculo");
					return "";
				}
			}

			this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().add(this.regraCalculoEditavel);
			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().add(this.regraCalculoEditavel.clone());
		} else {

			RegraCalculoDevolucao regraCalculoDevolucao = this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao));
			// Validando linha a linha (data inicio e tipo de devolução não pode ser iguais)

			for (RegraCalculoDevolucao rcd : this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao()) {
				if (rcd != regraCalculoDevolucao) {
					if ((UtilData.isDataIgual(rcd.getDataInicio(), regraCalculoDevolucao.getDataInicio()))
							& (rcd.getTipoDevolucao().getCodigo().equals(regraCalculoDevolucao.getTipoDevolucao().getCodigo()))) {
						Mensagens.addMsgErro("Já tem uma regra de cálculo com data inicial e tipo de devolução iguais.");
						PrimeFaces.current().ajax().update(":frmEditarRegraCalculo");
						return "";
					}
				}
			}

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().set(Integer.parseInt(this.indiceCalculoDevolucao), regraCalculoDevolucao.clone());
		}

		this.validaIndicePagemento = false;
		this.regraCalculoEditavel = new RegraCalculoDevolucao();
		PrimeFaces.current().ajax().update(":ltRegrasCalculoDevolucao");
		PrimeFaces.current().executeScript("PF('regraCalculoDialog').hide()");
		return "";
	}

	/**
	 * Método responsável por finalizar o preechimento em memória do objeto
	 * carregado no Dialog widgetVar="regraContribuicaoDialog"
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 17/02/2017
	 */
	public void salvarLinhaRegraContribuicao() throws NumberFormatException, CloneNotSupportedException {
		if (this.indiceContribuicaoDevolucao == null) {
			RegraDevolucaoContribuicao regraDevolucaoContribuicao = this.getDevolucaoContribuicaoEditavel();
			regraDevolucaoContribuicao.setRegraCalculoDevolucao(this.regraCalculoDevolucaoItem);
			// RegraCalculoDevolucao regraCalculoDevolucao =
			// this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao));
			this.regraCalculoDevolucaoItem.getListaRegraDevolucaoContribuicao().add(regraDevolucaoContribuicao);
			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().add(
					regraDevolucaoContribuicao.clone());
		} else {
			// Atualizar o objeto de backup junto ao objeto que está sendo utilizado
			// na tela, mantendo referências diferentes
			RegraDevolucaoContribuicao regraDevolucaoContribuicaoEditar = this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(
					Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(Integer.parseInt(this.indiceContribuicaoDevolucao));
			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().set(
					Integer.parseInt(this.indiceContribuicaoDevolucao),
					regraDevolucaoContribuicaoEditar.clone());
		}
		PrimeFaces.current().executeScript("PF('regraContribuicaoDialog').hide()");

		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
	}

	/**
	 * Método responsável por finalizar o preechimento em memória do objeto
	 * carregado no Dialog widgetVar="regraContribuicaoDialog"
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 26/10/2017
	 */
	public void salvarLinhasRegraContribuicao() throws NumberFormatException, CloneNotSupportedException {
		if (UtilJava.isColecaoDiferenteDeVazia(this.getListaTipoContribuicaoSelecionada())) {
			for (TipoContribuicao tipoContribuicao : this.getListaTipoContribuicaoSelecionada()) {
				RegraDevolucaoContribuicao regraDevolucaoContribuicao = this.getDevolucaoContribuicaoEditavel().clone();
				regraDevolucaoContribuicao.setRegraCalculoDevolucao(this.regraCalculoDevolucaoItem);
				regraDevolucaoContribuicao.setTipoContribuicao(tipoContribuicao);
				this.regraCalculoDevolucaoItem.getListaRegraDevolucaoContribuicao().add(regraDevolucaoContribuicao);
				this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().add(
						regraDevolucaoContribuicao.clone());
			}

		} else {
			throw new PrevidenciaException("Não foram selecionadas Tipos de Contribuições");
		}

		PrimeFaces.current().executeScript("PF('regraContribuicaoDialogCD').hide()");

		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
	}

	/**
	 * Método responsável por finalizar o preechimento em memória do objeto
	 * carregado no Dialog widgetVar="regraElegibilidadeDevolucaoDialog"
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 10/03/2017
	 */
	public void salvarLinhaRegraElegibilidadeDevolucao() throws NumberFormatException, CloneNotSupportedException {
		if (this.indiceElegibilidadeDevolucao == null) {

			RegraElegibilidadeDevolucao regraElegibilidadeDevolucao = this.getElegibilidadeDevolucaoEditavel();
			// regraElegibilidadeDevolucao.setMesesIdade(0L);
			// regraElegibilidadeDevolucao.setMesesIdadeFundador(0L);
			// regraElegibilidadeDevolucao.setMesesPlano(0L);
			// regraElegibilidadeDevolucao.setMesesPlanoFundador(0L);
			// regraElegibilidadeDevolucao.setMesesEmpresa(0L);
			// regraElegibilidadeDevolucao.setMesesEmpresaFundador(0L);
			// regraElegibilidadeDevolucao.setQuantidadeContribuicao(0L);
			// regraElegibilidadeDevolucao.setQuantidadeContribuicaoFundador(0L);
			regraElegibilidadeDevolucao.setRegraCalculoDevolucao(this.regraCalculoDevolucaoItem);

			RegraCalculoDevolucao regraCalculoDevolucao = this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao));

			regraCalculoDevolucao.getListaRegraElegibilidadeDevolucao().add(regraElegibilidadeDevolucao);
			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraElegibilidadeDevolucao().add(
					regraElegibilidadeDevolucao.clone());
		} else {
			// Atualizar o objeto de backup junto ao objeto que está sendo utilzado
			// na tela, mantendo referências diferentes

			RegraElegibilidadeDevolucao regraElegibilidadeDevolucaoEditar = this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(
					Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraElegibilidadeDevolucao().get(Integer.parseInt(this.indiceElegibilidadeDevolucao));

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraElegibilidadeDevolucao().set(
					Integer.parseInt(this.indiceElegibilidadeDevolucao),
					regraElegibilidadeDevolucaoEditar.clone());
		}

		PrimeFaces.current().executeScript("PF('regraElegibilidadeDevolucaoDialog').hide()");

		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
	}

	/**
	 * Método responsável por finalizar o preechimento em memória do objeto
	 * carregado no Dialog widgetVar="regraContribuicaoDialog"
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 17/02/2017
	 */
	public void salvarLinhaFaixaContribuicao() throws NumberFormatException, CloneNotSupportedException {
		// Atualizar o objeto de backup junto ao objeto que está sendo utilzado
		// na tela, mantendo referências diferentes
		if (this.indiceFaixaContribuicao == null) {
			RegraDevolucaoContribFaixas devolucaoContribFaixas = this.getFaixaContribuicaoEditavel();

			devolucaoContribFaixas.setRegraDevolucaoContribuicao(this.regraDevolucaoContribuicaoItem);
			this.regraDevolucaoContribuicaoItem.getListaRegraDevolucaoContribFaixas().add(devolucaoContribFaixas);

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(
					Integer.parseInt(this.indiceContribuicaoDevolucao)).getListaRegraDevolucaoContribFaixas().add(devolucaoContribFaixas.clone());

		} else {
			RegraDevolucaoContribFaixas regraDevolucaoContribFaixas = this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao()
					.get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(Integer.parseInt(this.indiceContribuicaoDevolucao))
					.getListaRegraDevolucaoContribFaixas().get(Integer.parseInt(this.indiceFaixaContribuicao));

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(
					Integer.parseInt(this.indiceContribuicaoDevolucao)).getListaRegraDevolucaoContribFaixas().set(Integer.parseInt(this.indiceFaixaContribuicao), regraDevolucaoContribFaixas.clone());
		}
		PrimeFaces.current().executeScript("PF('faixaContribuicaoDialog').hide()");

		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		String codigoExpansaoContrib = "expandeLinhaContrib(" + this.indiceContribuicaoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
		PrimeFaces.current().executeScript(codigoExpansaoContrib);
	}

	/**
	 * Método responsável por finalizar o preechimento em memória do objeto
	 * carregado no Dialog widgetVar="planoContribFaixasDialog"
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 17/02/2017
	 */
	public void salvarLinhaPlanoContribFaixaDev() throws NumberFormatException, CloneNotSupportedException {
		// Atualizar o objeto de backup junto ao objeto que está sendo utilzado
		// na tela, mantendo referências diferentes

		if (this.indicePlanoContribFaixaDev == null) {

			PlanoContribFaixasDev planoContribFaixasDev = this.planoContribFaixasDevEditavel;
			planoContribFaixasDev.setRegraDevolucaoContribuicao(this.regraDevolucaoContribuicaoItem);
			planoContribFaixasDev.setPlanoPrevidencia(this.regraDevolucaoContribuicaoItem.getRegraCalculoDevolucao().getRegraDevolucao().getPlanoVigenciaDevolucao().getPlanoPrevidencia());

			this.regraDevolucaoContribuicaoItem.getListaPlanoContrtibFaixasDev().add(planoContribFaixasDev);
			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(
					Integer.parseInt(this.indiceContribuicaoDevolucao)).getListaPlanoContrtibFaixasDev().add(planoContribFaixasDev.clone());

		} else {

			PlanoContribFaixasDev planoContribFaixasDev = this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao))
					.getListaRegraDevolucaoContribuicao().get(Integer.parseInt(this.indiceContribuicaoDevolucao)).getListaPlanoContrtibFaixasDev().get(
							Integer.parseInt(this.indicePlanoContribFaixaDev));

			this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(
					Integer.parseInt(this.indiceContribuicaoDevolucao)).getListaPlanoContrtibFaixasDev().set(Integer.parseInt(this.indicePlanoContribFaixaDev), planoContribFaixasDev.clone());
		}

		this.planoContribFaixasDevEditavel = new PlanoContribFaixasDev();
		PrimeFaces.current().executeScript("PF('planoContribFaixasDialog').hide()");

		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		String codigoExpansaoContrib = "expandeLinhaContrib(" + this.indiceContribuicaoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
		PrimeFaces.current().executeScript(codigoExpansaoContrib);
	}

	/**
	 * Método responsável por limpar os objetos peenchidos via AjaxParameter desde a
	 * página usados nos Dialogs de preenchimento
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/02/2017
	 */
	public void limparObjetosTemporarios() {
		this.regraCalculoEditavel = new RegraCalculoDevolucao();
		this.elegibilidadeDevolucaoEditavel = new RegraElegibilidadeDevolucao();
		this.devolucaoContribuicaoEditavel = new RegraDevolucaoContribuicao();
		this.faixaContribuicaoEditavel = new RegraDevolucaoContribFaixas();
		this.planoContribFaixasDevEditavel = new PlanoContribFaixasDev();
		this.setListaTipoContribuicao(this.tipoContribuicaoBO.listarTipoContribuicao());
	}

	/**
	 * Método responsável por retornar os valores originais da Regra de Contribuição
	 * selecionada quando a edição for cancelada.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 20/02/2017
	 */
	public void cancelarEdicaoRegraContribuicao() throws NumberFormatException, CloneNotSupportedException {
		this.setDevolucaoContribuicaoEditavel(new RegraDevolucaoContribuicao());
		this.editarRegraContribDevolucao = false;
		if (indiceContribuicaoDevolucao != null) {
			RegraDevolucaoContribuicao devolucaoContribuicao = this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao))
					.getListaRegraDevolucaoContribuicao().get(Integer.parseInt(indiceContribuicaoDevolucao)).clone();

			this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().set(
					Integer.parseInt(indiceContribuicaoDevolucao),
					devolucaoContribuicao);
		}
		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
	}

	/**
	 * Método responsável por retornar os valores originais da Regra de
	 * Elegibilidade Devolucao selecionada quando a edição for cancelada.
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 10/03/2017
	 */
	public void cancelarEdicaoRegraElegibilidadeDevolucao() throws NumberFormatException, CloneNotSupportedException {
		this.setElegibilidadeDevolucaoEditavel(new RegraElegibilidadeDevolucao());
		this.editarRegraElegibilidadeDevolucao = false;
		if (indiceElegibilidadeDevolucao != null) {
			RegraElegibilidadeDevolucao regraElegibilidadeDevolucao = this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao))
					.getListaRegraElegibilidadeDevolucao().get(Integer.parseInt(indiceElegibilidadeDevolucao)).clone();

			this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao)).getListaRegraElegibilidadeDevolucao().set(
					Integer.parseInt(indiceElegibilidadeDevolucao),
					regraElegibilidadeDevolucao);
		}
		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
	}

	/**
	 * Método responsável por retornar os valores originais da Regra Faixa de
	 * Contribuição selecionada quando a edição for cancelada.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 20/02/2017
	 */
	public void cancelarEdicaoFaixaContribuicao() throws NumberFormatException, CloneNotSupportedException {
		this.setFaixaContribuicaoEditavel(new RegraDevolucaoContribFaixas());
		if (this.indiceFaixaContribuicao != null) {
			RegraDevolucaoContribFaixas regraDevolucaoContribFaixas = this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao))
					.getListaRegraDevolucaoContribuicao().get(Integer.parseInt(indiceContribuicaoDevolucao)).getListaRegraDevolucaoContribFaixas().get(Integer.parseInt(this.indiceFaixaContribuicao))
					.clone();

			this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(
					Integer.parseInt(this.indiceContribuicaoDevolucao)).getListaRegraDevolucaoContribFaixas().set(Integer.parseInt(this.indiceFaixaContribuicao), regraDevolucaoContribFaixas);
		}
		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		String codigoExpansaoContrib = "expandeLinhaContrib(" + this.indiceContribuicaoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
		PrimeFaces.current().executeScript(codigoExpansaoContrib);
	}

	/**
	 * Método responsável por retornar os valores originais da Regra de Cálculo
	 * Devolução selecionada quando a edição for cancelada.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 21/02/2017
	 * @throws NumberFormatException
	 * @throws CloneNotSupportedException
	 */
	public void cancelarEdicaoRegraCalculo() throws NumberFormatException, CloneNotSupportedException {
		if (this.indiceCalculoDevolucao != null) {
			RegraCalculoDevolucao regraCalculoDevolucao = this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)).clone();
			this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().set(Integer.parseInt(this.indiceCalculoDevolucao), regraCalculoDevolucao);
		}
		this.validaIndicePagemento = false;
		this.regraCalculoEditavel = new RegraCalculoDevolucao();

	}

	/**
	 * Método responsável por retornar os valores originais da Regra Plano Faixa de
	 * Contribuição selecionada quando a edição for cancelada.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @throws CloneNotSupportedException
	 * @throws NumberFormatException
	 * @since 20/02/2017
	 */
	public void cancelarEdicaoPlanoContribFaixaDev() throws NumberFormatException, CloneNotSupportedException {
		this.setPlanoContribFaixasDevEditavel(new PlanoContribFaixasDev());
		if (this.indicePlanoContribFaixaDev != null) {
			PlanoContribFaixasDev planoContribFaixasDev = this.regraDevolucaoUtil.getNovaRegraDevolucao2().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao))
					.getListaRegraDevolucaoContribuicao().get(Integer.parseInt(indiceContribuicaoDevolucao)).getListaPlanoContrtibFaixasDev().get(Integer.parseInt(this.indicePlanoContribFaixaDev))
					.clone();

			this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(indiceCalculoDevolucao)).getListaRegraDevolucaoContribuicao().get(
					Integer.parseInt(this.indiceContribuicaoDevolucao)).getListaPlanoContrtibFaixasDev().set(Integer.parseInt(this.indicePlanoContribFaixaDev), planoContribFaixasDev);
		}
		String codigoExpansaoCalculo = "expandeLinhaCalculo(" + this.indiceCalculoDevolucao + ")";

		String codigoExpansaoContrib = "expandeLinhaContrib(" + this.indiceContribuicaoDevolucao + ")";

		PrimeFaces.current().executeScript(codigoExpansaoCalculo);
		PrimeFaces.current().executeScript(codigoExpansaoContrib);
	}

	/**
	 * Método reponsável por
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/02/2017
	 */
	public void inciciarEditarRegraContribuicao() {
		this.editarRegraContribDevolucao = true;
	}

	/**
	 * Método encarregado de duplicar uma regra de contribuição devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/10/2017
	 */
	public void inciciarDuplicarRegraContribuicao(RegraDevolucaoContribuicao regraDevContrib) {
		this.editarRegraContribDevolucao = true;

		try {
			RegraDevolucaoContribuicao regraDevolucaoContribuicao = regraDevContrib.clone();
			regraDevolucaoContribuicao.setTipoContribuicao(null);
			this.setDevolucaoContribuicaoEditavel(new RegraDevolucaoContribuicao());
			this.setDevolucaoContribuicaoEditavel(regraDevolucaoContribuicao);
			this.indiceContribuicaoDevolucao = null;

			if (this.indiceCalculoDevolucao != null) {
				this.setRegraCalculoDevolucaoItem(this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao)));
			} else {
				this.setRegraCalculoDevolucaoItem(regraDevContrib.getRegraCalculoDevolucao());
			}

			removerTiposContribuicaoCadastrados();

		} catch (CloneNotSupportedException e) {
			log.error("Erro ao Clonar Regra de Devolução Contribuição.", e);
			throw new PrevidenciaException("Erro ao Clonar Regra de Devolução Contribuição.", e);
		}

	}

	/**
	 * Remove os tipos de contribuição que já foram cadastrados na Regra de Cálculo
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/10/2017
	 */
	public void removerTiposContribuicaoCadastrados() {
		this.listaTipoContribuicao = new ArrayList<TipoContribuicao>(this.tipoContribuicaoBO.listarTipoContribuicao());
		for (RegraDevolucaoContribuicao rDc : this.regraDevolucaoUtil.getNovaRegraDevolucao().getListaRegraCalculoDevolucao().get(Integer.parseInt(this.indiceCalculoDevolucao))
				.getListaRegraDevolucaoContribuicao()) {
			this.listaTipoContribuicao.remove(rDc.getTipoContribuicao());
		}
	}

	/**
	 * Método reponsável por
	 * 
	 * @author BBPF0333 - Daniel Martins
	 * @since 10/03/2017
	 */
	public void inciciarEditarRegraElegibilidadeDevolucao() {
		this.editarRegraElegibilidadeDevolucao = true;
	}

	/**
	 * Método responsável por salvar uma regra de devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/02/2017
	 * 
	 */
	public String salvarRegraDevolucao() {
		try {
			this.regraDevolucaoUtil.salvarRegraDevolucao();
			return this.retornaPesquisaRegraSalva();
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ao salvar a Regra de Devolulução.");
		}

		return FW_CADASTRA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável por retornar à página de pesquisa depois de salvar a regra
	 * devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 23/02/2017
	 * @return
	 */
	public String retornaPesquisaRegraSalva() {
		this.setMostrarOpcaoNovaRegra(true);

		pesquisarRegrasDevolucao();
		Mensagens.addMsgInfo("Regra de Devolução Salva comn Sucesso!");

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável de enviar uma regra para Homologação
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/0/2017
	 * @param {@link RegraDevolucao}
	 * @return
	 */
	public String enviarRegraParaHomologacao(RegraDevolucao regraDevolucao) {
		if (regraDevolucao != null) {
			try {
				this.regraDevolucaoUtil.enviarRegraParaHomologacao(regraDevolucao);
				Mensagens.addMsgInfo("A Regra de Devolução foi enviada para homologação!");
			} catch (PrevidenciaException pEx) {
				log.error(pEx);
				Mensagens.addMsgErro(pEx.getMessage());
			} catch (Exception ex) {
				log.error(ex);
				Mensagens.addMsgErro("Não foi possível enviar a regra para Homologação!");
			}
		} else {
			Mensagens.addMsgInfo("Não há regra para enviar ao processo de Homologação!");
		}

		this.regraDevolucaoUtil.preencherListaRegraDevolucao(this.planoVigenciaDevolucao);

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável por Homologar uma regra de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 24/0/2017
	 * @param {@link RegraDevolucao}
	 * @return
	 */
	public String homologarRegraDevolucao(RegraDevolucao regraDevolucao) {
		if (regraDevolucao != null) {
			try {
				this.regraDevolucaoUtil.homologarRegraDevolucao(regraDevolucao);
				Mensagens.addMsgInfo("A Regra de Devolução foi Homologada!");
			} catch (PrevidenciaException pEx) {
				log.error(pEx);
				Mensagens.addMsgErro(pEx.getMessage());
			} catch (Exception ex) {
				log.error(ex);
				Mensagens.addMsgErro("Não foi possível Homologar a Regra de Devolução!");
			}
		} else {
			Mensagens.addMsgInfo("Não há regra para Homologar!");
		}

		this.regraDevolucaoUtil.preencherListaRegraDevolucao(this.planoVigenciaDevolucao);

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método responsável por Autorizar uma regra de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param {@link RegraDevolucao}
	 * @return
	 */
	public String autorizarRegraDevolucao(RegraDevolucao regraDevolucao) {

		if (regraDevolucao != null) {
			try {
				this.regraDevolucaoUtil.autorizarRegraDevolucao(regraDevolucao, true);
				Mensagens.addMsgInfo("A Regra de Devolução foi Autorizada!");
			} catch (PrevidenciaException pEx) {
				log.error(pEx);
				Mensagens.addMsgErro(pEx.getMessage());
			} catch (Exception ex) {
				log.error(ex);
				Mensagens.addMsgErro("Não foi possível Autorizar a Regra de Devolução!");
			}
		} else {
			Mensagens.addMsgInfo("Não há regra para Autorizar!");
		}

		this.regraDevolucaoUtil.preencherListaRegraDevolucao(this.planoVigenciaDevolucao);

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método Responsável por Indeferir um regra de devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param regraDevolucao
	 * @return
	 */
	public String indeferirRegraDevolucao(RegraDevolucao regraDevolucao) {
		if (regraDevolucao != null) {
			try {
				this.regraDevolucaoUtil.indeferirRegraDevolucao(regraDevolucao, this.getMotivoIndeferimento());
				Mensagens.addMsgInfo("A Regra de Devolução foi Indeferida!");
			} catch (PrevidenciaException pEx) {
				log.error(pEx);
				Mensagens.addMsgErro(pEx.getMessage());
			} catch (Exception ex) {
				log.error(ex);
				Mensagens.addMsgErro("Não foi possível Indeferir a Regra de Devolução!");
			}
		} else {
			Mensagens.addMsgInfo("Não há regra para Indeferir!");
		}

		this.regraDevolucaoUtil.preencherListaRegraDevolucao(this.planoVigenciaDevolucao);

		this.regraDevolucaoIndeferir = null;
		this.motivoIndeferimento = null;

		return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método Responsável por Indeferir um regra de devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 01/03/2017
	 * @param regraDevolucao
	 * @return
	 */
	public void revogarRegraDevolucao(RegraDevolucao regraDevolucao) {
		if (regraDevolucao != null) {
			try {
				this.regraDevolucaoUtil.revogarRegraDevolucao(regraDevolucao, this.planoVigenciaDevolucao);
				Mensagens.addMsgInfo("A Regra de Devolução foi Revogada!");
			} catch (PrevidenciaException pEx) {
				log.error(pEx);
				Mensagens.addMsgErro(pEx.getMessage());
			} catch (Exception ex) {
				log.error(ex);
				Mensagens.addMsgErro("Não foi possível revogar a Regra de Devolução!");
			}
		} else {
			Mensagens.addMsgInfo("Não há regra para Revogar!");
		}

		this.regraDevolucaoUtil.preencherListaRegraDevolucao(this.planoVigenciaDevolucao);

		// return FW_PESQUISA_REGRA_DEVOLUCAO;
	}

	/**
	 * Método para retorna data Atual
	 * 
	 * @author bbpf0170 - Magson Dias
	 * @return {@link Date}
	 */
	public Date getDataAtual() {
		if (dataAtual == null)
			dataAtual = new Date();
		return dataAtual;
	}

	/**
	 * Método responsável por salvar um Plano Vigência de Devolução
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 02/03/2017
	 * @return
	 */
	public String salvarPlanoVigenciaDevolucao() {
		try {
			if (this.getNovoPlanoVigenciaDevolucao().getPlanoPrevidencia() == null) {
				this.getNovoPlanoVigenciaDevolucao().setPlanoPrevidencia(this.planoPrevidencia);
			}

			this.getNovoPlanoVigenciaDevolucao().setDataInclusao(new Date());
			this.getNovoPlanoVigenciaDevolucao().setNomeUsuarioInclusao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

			if (validaCampos()) {
				return "";
			}

			this.planoVigenciaDevolucaoBO.salvarPlanoVigenciaDevolucao(this.novoPlanoVigenciaDevolucao);

			// Salva regra anterior com data fim.
			this.planoVigenciaDevolucaoBO.salvarPlanoVigenciaDevolucao(this.planoVigenciaDevolucao);

		} catch (PrevidenciaException pEx) {
			log.error(pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex);
			Mensagens.addMsgErro("Não foi possível salvar o Plano de Vigência de Devolução!");
		}

		PrimeFaces.current().executeScript("PF('cadastroPlanoVigenciaDialog').hide()");

		this.setNovoPlanoVigenciaDevolucao(new PlanoVigenciaDevolucao());

		Mensagens.addMsgInfo("Plano de Vigência de Devolução salvo com sucesso!");

		return pesquisarVigenciasPlano();
	}

	/**
	 * Método para validar as data de um novo planoVigenciaDevolução.
	 * 
	 * @author bbpf0170 - Magson Dias
	 * @return {@link boolean}
	 */
	private boolean validaCampos() {
		boolean res = false;

		if (this.novoPlanoVigenciaDevolucao.getDataFim() != null) {
			Date dataFim = (Date) this.novoPlanoVigenciaDevolucao.getDataFim();
			if (this.novoPlanoVigenciaDevolucao.getDataInicio() != null && dataFim.before(this.novoPlanoVigenciaDevolucao.getDataInicio())) {
				Mensagens.addMsgErro("A data fim não pode ser anterior a data inicio.");
				res = true;
			}
		}

		if (this.planoPrevidencia != null) {
			this.listaPlanoVigenciaDevolucao = new ArrayList<PlanoVigenciaDevolucao>(planoVigenciaDevolucaoBO.listarTodos(this.planoPrevidencia));

			for (PlanoVigenciaDevolucao plVigenciaDev : this.listaPlanoVigenciaDevolucao) {

				if (this.planoPrevidencia.getCodigo().equals(plVigenciaDev.getPlanoPrevidencia().getCodigo())) {
					if (this.planoVigenciaDevolucao.getDataFim() == null) {
						this.planoVigenciaDevolucao.setDataFim(UtilJava.addDia(this.novoPlanoVigenciaDevolucao.getDataInicio(), -1));
					}
					continue;
				}

				if (plVigenciaDev.getDataFim() != null) {

					if (this.novoPlanoVigenciaDevolucao.getDataFim() != null) {
						if (!plVigenciaDev.getDataInicio().after(this.novoPlanoVigenciaDevolucao.getDataFim()) && !plVigenciaDev.getDataFim().before(this.novoPlanoVigenciaDevolucao.getDataFim())) {
							Mensagens.addMsgErro("Vigencia do plano com data fim ativa.");
							res = true;
						}
					}

					if (!plVigenciaDev.getDataInicio().after(this.novoPlanoVigenciaDevolucao.getDataInicio()) && !plVigenciaDev.getDataFim().before(this.novoPlanoVigenciaDevolucao.getDataInicio())) {
						Mensagens.addMsgErro("Vigencia do plano com data inicio ativa.");
						res = true;
					}

				} else if (plVigenciaDev.getDataFim() == null) {
					Mensagens.addMsgErro("Vigencia do plano ativa por tempo indeterminado.");
					res = true;
				}
			}

		}
		return res;
	}

	public void onEditIndicePagamentoChange() {
		validaIndicePagemento = false;
		if (this.regraCalculoEditavel.getTipoValorizacaoEnum() != null) {
			if (this.regraCalculoEditavel.getTipoValorizacaoEnum().getCodigo().equals(TipoValorizacaoEnum.INDICE_PLANO.getCodigo())) {
				validaIndicePagemento = true;
			}
		}
	}

	// getters and Setters

	public boolean isPesquisaStatus() {
		return pesquisaStatus;
	}

	public void setPesquisaStatus(boolean pesquisaStatus) {
		this.pesquisaStatus = pesquisaStatus;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public List<PlanoVigenciaDevolucao> getListaPlanoVigenciaDevolucao() {
		return listaPlanoVigenciaDevolucao;
	}

	public void setListaPlanoVigenciaDevolucao(List<PlanoVigenciaDevolucao> listaPlanoVigenciaDevolucao) {
		this.listaPlanoVigenciaDevolucao = listaPlanoVigenciaDevolucao;
	}

	public PlanoVigenciaDevolucao getPlanoVigenciaDevolucao() {
		return planoVigenciaDevolucao;
	}

	public void setPlanoVigenciaDevolucao(PlanoVigenciaDevolucao planoVigenciaDevolucao) {
		this.planoVigenciaDevolucao = planoVigenciaDevolucao;
	}

	public RegraDevolucaoParametrizacaoDTO getRegraDevolucaoCompleto() {
		return regraDevolucaoCompleto;
	}

	public void setRegraDevolucaoCompleto(RegraDevolucaoParametrizacaoDTO regraDevolucaoCompleto) {
		this.regraDevolucaoCompleto = regraDevolucaoCompleto;
	}

	public boolean isMostrarOpcaoNovaRegra() {
		return mostrarOpcaoNovaRegra;
	}

	public void setMostrarOpcaoNovaRegra(boolean mostrarRegrasDevolucao) {
		this.mostrarOpcaoNovaRegra = mostrarRegrasDevolucao;
	}

	public ParametrizaRegraDevolucao getRegraDevolucaoUtil() {
		if (this.regraDevolucaoUtil == null) {
			this.regraDevolucaoUtil = new ParametrizaRegraDevolucao();
		}
		return regraDevolucaoUtil;
	}

	public void setRegraDevolucaoUtil(ParametrizaRegraDevolucao regraDevolucaoUtil) {
		this.regraDevolucaoUtil = regraDevolucaoUtil;
	}

	public boolean isExisteRegraPlanoContribFaixasDev() {
		return existeRegraPlanoContribFaixasDev;
	}

	public void setExisteRegraPlanoContribFaixasDev(boolean existeRegraPlanoContribFaixasDev) {
		this.existeRegraPlanoContribFaixasDev = existeRegraPlanoContribFaixasDev;
	}

	public boolean isRegraClonada() {
		return regraClonada;
	}

	public void setRegraClonada(boolean regraClonada) {
		this.regraClonada = regraClonada;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucaoAntigo() {
		return regraCalculoDevolucaoAntigo;
	}

	public void setRegraCalculoDevolucaoAntigo(RegraCalculoDevolucao regraCalculoDevolucaoAntigo) {
		this.regraCalculoDevolucaoAntigo = regraCalculoDevolucaoAntigo;
	}

	public RegraCalculoDevolucao getRegraCalculoEditavel() {
		return regraCalculoEditavel;
	}

	public void setRegraCalculoEditavel(RegraCalculoDevolucao regraCalculoEditavel) {
		this.regraCalculoEditavel = regraCalculoEditavel;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public List<RegraCalculoTempoEmpresa> getListaRegraCalculoTempoEmpresa() {
		return listaRegraCalculoTempoEmpresa;
	}

	public void setListaRegraCalculoTempoEmpresa(List<RegraCalculoTempoEmpresa> listaRegraCalculoTempoEmpresa) {
		this.listaRegraCalculoTempoEmpresa = listaRegraCalculoTempoEmpresa;
	}

	public List<RegraCalculoTempoPlano> getListaRegraCalculoTempoPlano() {
		return listaRegraCalculoTempoPlano;
	}

	public void setListaRegraCalculoTempoPlano(List<RegraCalculoTempoPlano> listaRegraCalculoTempoPlano) {
		this.listaRegraCalculoTempoPlano = listaRegraCalculoTempoPlano;
	}

	public List<SelectItem> getListaIndicadorTipoImpostoProgressivo() {
		return listaIndicadorTipoImpostoProgressivo;
	}

	public void setListaIndicadorTipoImpostoProgressivo(List<SelectItem> listaIndicadorTipoImpostoProgressivo) {
		this.listaIndicadorTipoImpostoProgressivo = listaIndicadorTipoImpostoProgressivo;
	}

	public List<MovimentoFundoPrev> getListaMovimentoFundoPrev() {
		return listaMovimentoFundoPrev;
	}

	public void setListaMovimentoFundoPrev(List<MovimentoFundoPrev> listaMovimentoFundoPrev) {
		this.listaMovimentoFundoPrev = listaMovimentoFundoPrev;
	}

	public List<TipoContribuicao> getListaTipoContribuicao() {
		return listaTipoContribuicao;
	}

	public void setListaTipoContribuicao(List<TipoContribuicao> listaTipoContribuicao) {
		this.listaTipoContribuicao = listaTipoContribuicao;
	}

	public boolean isCancelarEditRegraContribDevolucao() {
		return cancelarEditRegraContribDevolucao;
	}

	public void setCancelarEditRegraContribDevolucao(boolean cancelarEditRegraContribDevolucao) {
		this.cancelarEditRegraContribDevolucao = cancelarEditRegraContribDevolucao;
	}

	public String getIndiceContribuicaoDevolucao() {
		return indiceContribuicaoDevolucao;
	}

	public void setIndiceContribuicaoDevolucao(String indiceContribuicaoDevolucao) {
		this.indiceContribuicaoDevolucao = indiceContribuicaoDevolucao;
	}

	public String getIndiceCalculoDevolucao() {
		return indiceCalculoDevolucao;
	}

	public void setIndiceCalculoDevolucao(String indiceCalculoDevolucao) {
		this.indiceCalculoDevolucao = indiceCalculoDevolucao;
	}

	public RegraDevolucaoContribFaixas getFaixaContribuicaoEditavel() {
		return faixaContribuicaoEditavel;
	}

	public void setFaixaContribuicaoEditavel(RegraDevolucaoContribFaixas faixaContribuicaoEditavel) {
		this.faixaContribuicaoEditavel = faixaContribuicaoEditavel;
	}

	public String getIndiceFaixaContribuicao() {
		return indiceFaixaContribuicao;
	}

	public void setIndiceFaixaContribuicao(String indiceFaixaContribuicao) {
		this.indiceFaixaContribuicao = indiceFaixaContribuicao;
	}

	public String getIndicePlanoContribFaixaDev() {
		return indicePlanoContribFaixaDev;
	}

	public void setIndicePlanoContribFaixaDev(String indicePlanoContribFaixaDev) {
		this.indicePlanoContribFaixaDev = indicePlanoContribFaixaDev;
	}

	public PlanoContribFaixasDev getPlanoContribFaixasDevEditavel() {
		return planoContribFaixasDevEditavel;
	}

	public void setPlanoContribFaixasDevEditavel(PlanoContribFaixasDev planoContribFaixasDevEditavel) {
		this.planoContribFaixasDevEditavel = planoContribFaixasDevEditavel;
	}

	public boolean isRegraSalva() {
		return regraSalva;
	}

	public void setRegraSalva(boolean regraSalva) {
		this.regraSalva = regraSalva;
	}

	public boolean isUsuarioPodeInserirRegraDev() {
		return usuarioPodeInserirRegraDev;
	}

	public void setUsuarioPodeInserirRegraDev(boolean usuarioPodeInserirRegraDev) {
		this.usuarioPodeInserirRegraDev = usuarioPodeInserirRegraDev;
	}

	public boolean isUsuarioPodeEnviarRegraDevParaHomolog() {
		return usuarioPodeEnviarRegraDevParaHomolog;
	}

	public void setUsuarioPodeEnviarRegraDevParaHomolog(boolean usuarioPodeEnviarRegraDevParaHomolog) {
		this.usuarioPodeEnviarRegraDevParaHomolog = usuarioPodeEnviarRegraDevParaHomolog;
	}

	public boolean isUsuarioPodeHomolagarRegraDev() {
		return usuarioPodeHomolagarRegraDev;
	}

	public void setUsuarioPodeHomolagarRegraDev(boolean usuarioPodeHomolagarRegraDev) {
		this.usuarioPodeHomolagarRegraDev = usuarioPodeHomolagarRegraDev;
	}

	public boolean isUsuarioPodeAutorizarRegraDev() {
		return usuarioPodeAutorizarRegraDev;
	}

	public void setUsuarioPodeAutorizarRegraDev(boolean usuarioPodeAutorizarRegraDev) {
		this.usuarioPodeAutorizarRegraDev = usuarioPodeAutorizarRegraDev;
	}

	public boolean isUsuarioPodeIndeferirRegraDev() {
		return usuarioPodeIndeferirRegraDev;
	}

	public void setUsuarioPodeIndeferirRegraDev(boolean usuarioPodeIndeferirRegraDev) {
		this.usuarioPodeIndeferirRegraDev = usuarioPodeIndeferirRegraDev;
	}

	public boolean isUsuarioPodeRevogarRegraDev() {
		return usuarioPodeRevogarRegraDev;
	}

	public void setUsuarioPodeRevogarRegraDev(boolean usuarioPodeRevogarRegraDev) {
		this.usuarioPodeRevogarRegraDev = usuarioPodeRevogarRegraDev;
	}

	public String getMotivoIndeferimento() {
		return motivoIndeferimento;
	}

	public void setMotivoIndeferimento(String motivoIndeferimento) {
		this.motivoIndeferimento = motivoIndeferimento;
	}

	public RegraDevolucao getRegraDevolucaoIndeferir() {
		return regraDevolucaoIndeferir;
	}

	public void setRegraDevolucaoIndeferir(RegraDevolucao regraDevolucaoIndeferir) {
		this.regraDevolucaoIndeferir = regraDevolucaoIndeferir;
	}

	public RegraDevolucao getRegraDevolucaoHist() {
		return regraDevolucaoHist;
	}

	public void setRegraDevolucaoHist(RegraDevolucao regraDevolucaoHist) {
		if (regraDevolucaoHist != null) {
			this.listaHistoricoSituacaoRegraDevolucao = new ArrayList<HistoricoSituacaoRegraDevolucao>(historicoSituacaoRegraDevolucaoBO.listarHistoricoPorRegraDevolucao(regraDevolucaoHist));
		}
		this.regraDevolucaoHist = regraDevolucaoHist;
	}

	public List<HistoricoSituacaoRegraDevolucao> getListaHistoricoSituacaoRegraDevolucao() {
		return listaHistoricoSituacaoRegraDevolucao;
	}

	public void setListaHistoricoSituacaoRegraDevolucao(List<HistoricoSituacaoRegraDevolucao> listaHistoricoSituacaoRegraDevolucao) {
		this.listaHistoricoSituacaoRegraDevolucao = listaHistoricoSituacaoRegraDevolucao;
	}

	public boolean isMostrarCadastrarVigencia() {
		return mostrarCadastrarVigencia;
	}

	public void setMostrarCadastrarVigencia(boolean mostrarCadastrarVigencia) {
		this.mostrarCadastrarVigencia = mostrarCadastrarVigencia;
	}

	public PlanoVigenciaDevolucao getNovoPlanoVigenciaDevolucao() {
		if (this.novoPlanoVigenciaDevolucao == null) {
			this.novoPlanoVigenciaDevolucao = new PlanoVigenciaDevolucao();
		}
		return novoPlanoVigenciaDevolucao;
	}

	public void setNovoPlanoVigenciaDevolucao(PlanoVigenciaDevolucao novoPlanoVigenciaDevolucao) {
		this.novoPlanoVigenciaDevolucao = novoPlanoVigenciaDevolucao;
	}

	public List<RegraCalculoTempoIdade> getListaRegraCalculoTempoIdade() {
		return listaRegraCalculoTempoIdade;
	}

	public void setListaRegraCalculoTempoIdade(List<RegraCalculoTempoIdade> listaRegraCalculoTempoIdade) {
		this.listaRegraCalculoTempoIdade = listaRegraCalculoTempoIdade;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public boolean isEditarRegraContribDevolucao() {
		return editarRegraContribDevolucao;
	}

	public void setEditarRegraContribDevolucao(boolean editarRegraContribDevolucao) {
		this.editarRegraContribDevolucao = editarRegraContribDevolucao;
	}

	public String getIndiceElegibilidadeDevolucao() {
		return indiceElegibilidadeDevolucao;
	}

	public void setIndiceElegibilidadeDevolucao(String indiceElegibilidadeDevolucao) {
		this.indiceElegibilidadeDevolucao = indiceElegibilidadeDevolucao;
	}

	public RegraDevolucaoContribuicao getDevolucaoContribuicaoEditavel() {
		return devolucaoContribuicaoEditavel;
	}

	public void setDevolucaoContribuicaoEditavel(RegraDevolucaoContribuicao devolucaoContribuicaoEditavel) {
		this.devolucaoContribuicaoEditavel = devolucaoContribuicaoEditavel;
	}

	public RegraElegibilidadeDevolucao getElegibilidadeDevolucaoEditavel() {
		return elegibilidadeDevolucaoEditavel;
	}

	public void setElegibilidadeDevolucaoEditavel(RegraElegibilidadeDevolucao elegibilidadeDevolucaoEditavel) {
		this.elegibilidadeDevolucaoEditavel = elegibilidadeDevolucaoEditavel;
	}

	public boolean isEditarRegraElegibilidadeDevolucao() {
		return editarRegraElegibilidadeDevolucao;
	}

	public void setEditarRegraElegibilidadeDevolucao(boolean editarRegraElegibilidadeDevolucao) {
		this.editarRegraElegibilidadeDevolucao = editarRegraElegibilidadeDevolucao;
	}

	public boolean isCancelarEditRegraElegibilidadeDevolucao() {
		return cancelarEditRegraElegibilidadeDevolucao;
	}

	public void setCancelarEditRegraElegibilidadeDevolucao(boolean cancelarEditRegraElegibilidadeDevolucao) {
		this.cancelarEditRegraElegibilidadeDevolucao = cancelarEditRegraElegibilidadeDevolucao;
	}

	public List<IndiceEconomico> getListaIndiceEconomico() {
		return listaIndiceEconomico;
	}

	public void setListaIndiceEconomico(List<IndiceEconomico> listaIndiceEconomico) {
		this.listaIndiceEconomico = listaIndiceEconomico;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucaoItem() {
		return regraCalculoDevolucaoItem;
	}

	public void setRegraCalculoDevolucaoItem(RegraCalculoDevolucao regraCalculoDevolucaoItem) {
		this.regraCalculoDevolucaoItem = regraCalculoDevolucaoItem;
	}

	public RegraDevolucaoContribuicao getRegraDevolucaoContribuicaoItem() {
		return regraDevolucaoContribuicaoItem;
	}

	public void setRegraDevolucaoContribuicaoItem(RegraDevolucaoContribuicao regraDevolucaoContribuicaoItem) {
		this.regraDevolucaoContribuicaoItem = regraDevolucaoContribuicaoItem;
	}

	public boolean isValidaIndicePagemento() {
		return validaIndicePagemento;
	}

	public void setValidaIndicePagemento(boolean validaIndicePagemento) {
		this.validaIndicePagemento = validaIndicePagemento;
	}

	public List<TipoContribuicao> getListaTipoContribuicaoSelecionada() {
		return listaTipoContribuicaoSelecionada;
	}

	public void setListaTipoContribuicaoSelecionada(List<TipoContribuicao> listaTipoContribuicaoSelecionada) {
		this.listaTipoContribuicaoSelecionada = listaTipoContribuicaoSelecionada;
	}

	public List<RegraCalculoTempoContribuicao> getListaRegraCalculoTempoContribuicao() {
		return listaRegraCalculoTempoContribuicao;
	}

	public void setListaRegraCalculoTempoContribuicao(List<RegraCalculoTempoContribuicao> listaRegraCalculoTempoContribuicao) {
		this.listaRegraCalculoTempoContribuicao = listaRegraCalculoTempoContribuicao;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

}