package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import br.com.bbprevidencia.beneficio.dto.FichaDevolucao;
import br.com.bbprevidencia.beneficio.dto.IdentificadorDevolucao;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 01/11/2017 Classe de persistência para tabela DEVOLUCAO Antigo (migração).
 */
@Entity
public class DevolucaoAntigoDTO implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "NUM_SEQ_PEDIDO")
	private Long codigo;

	@Column(name = "DSC_OBSERV")
	private String descricaoObservacao;

	@Column(name = "QTD_COTA_PARTIC_PREVIS")
	private Double qtdCotasParticipante;

	@Column(name = "QTD_COTA_PATRON_PREVIS")
	private Double qtdCotasPatrocinadora;

	@Column(name = "VAL_COTA_PREVIS")
	private Double valorCotaPrevisao;

	@Column(name = "VAL_IR_PREVIS")
	private Double valorIrrfPrevisto;

	@Column(name = "QTD_COTA_PARCEL_1_PREVIS")
	private Double qtdCotasTotalPrimeiraParcela;

	@Column(name = "VAL_IR_PARCEL_1_PREVIS")
	private Double valorIrrfPrimeiraPrevisto;

	@Column(name = "QTD_PARCEL")
	private Integer qtdParcela;

	@Column(name = "QTD_COTA_REVERSAO_PREVIS")
	private Double qtdCotasReversao;

	@Column(name = "QTD_COTA_REMANESC_PREVIS")
	private Double qtdCotasRemanescente;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PARTIC_PLANO")
	private ParticipantePlano participantePlano;

	@Column(name = "DAT_REQUERIMENTO")
	private Date dataRequerimento;

	@Column(name = "DAT_PAGTO_PARCEL_1")
	private Date dataPagtoParcelaUm;

	@Column(name = "DAT_INI_CONTRIB")
	private Date dataInicioContribuicao;

	@Column(name = "DAT_FIM_CONTRIB")
	private Date dataFimContribuicao;

	@Column(name = "NUM_QTD_DEP_IR")
	private int quantidadeDependenteIrrf;

	@Column(name = "NUM_QTD_DEP")
	private int quantidadeDependente;

	@Column(name = "DAT_COTA")
	private Date dataCota;

	@Column(name = "QTD_COTA_PARTIC_TOTAL")
	private Double qtdCotasTotalParticipante;

	@Column(name = "QTD_COTA_PATRON_TOTAL")
	private Double qtdCotasTotalPatronal;

	@Column(name = "IND_TP_RESGATE")
	private String indicadorTipoResgate;

	@Column(name = "IND_CARENCIA_INSTITUIDOR")
	private String indicadorCarenciaInstituidor;

	@Column(name = "QTD_COTA_REMANESC_INST")
	private Double qtdCotasRemanescenteInst;

	@Column(name = "IND_PORTABILIDADE")
	private String indicadorPortabilidade;

	@Column(name = "DSC_OBS_PAGTO")
	private String descricaoObservacaoPagto;

	@Column(name = "DAT_DSC_PAGTO")
	private Date dataDescricaoPagto;

	@Column(name = "IND_MANUAL")
	private String devolucaoManual;

	@Column(name = "VAL_EMPRESTIMO")
	private Double valorEmprestimo;

	@Column(name = "IND_PARCELADO_CARENCIA")
	private String indicadorParcelaCarencia;

	@Transient
	private List<FichaDevolucao> listaFichaDevolucao;

	@Transient
	private IdentificadorDevolucao identificadorDevolucao;

	@Transient
	private String descricao;

	@Transient
	private String descricaoDeferimento;

	@Transient
	private String motivoIndeferimento;

	@Transient
	private Double valorCotaPagamentoMes;

	@Transient
	private Double saldoResgatavel;

	@Transient
	private Date dataCotaPagamentoMes;

	@Transient
	private Double valorTotalImposto;

	@Transient
	private List<RecebedorDTO> listaRecebedorDTO;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public ParticipantePlano getParticipantePlano() {
		return participantePlano;
	}

	public void setParticipantePlano(ParticipantePlano participantePlano) {
		this.participantePlano = participantePlano;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String descricaoObservacao) {
		this.descricaoObservacao = descricaoObservacao;
	}

	public Double getQtdCotasParticipante() {
		return qtdCotasParticipante;
	}

	public void setQtdCotasParticipante(Double qtdCotasParticipante) {
		this.qtdCotasParticipante = qtdCotasParticipante;
	}

	public Double getQtdCotasPatrocinadora() {
		return qtdCotasPatrocinadora;
	}

	public void setQtdCotasPatrocinadora(Double qtdCotasPatrocinadora) {
		this.qtdCotasPatrocinadora = qtdCotasPatrocinadora;
	}

	public Double getValorCotaPrevisao() {
		return valorCotaPrevisao;
	}

	public void setValorCotaPrevisao(Double valorCotaPrevisao) {
		this.valorCotaPrevisao = valorCotaPrevisao;
	}

	public Double getValorIrrfPrevisto() {
		return valorIrrfPrevisto;
	}

	public void setValorIrrfPrevisto(Double valorIrrfPrevisto) {
		this.valorIrrfPrevisto = valorIrrfPrevisto;
	}

	public Double getQtdCotasTotalPrimeiraParcela() {
		return qtdCotasTotalPrimeiraParcela;
	}

	public void setQtdCotasTotalPrimeiraParcela(Double qtdCotasTotalPrimeiraParcela) {
		this.qtdCotasTotalPrimeiraParcela = qtdCotasTotalPrimeiraParcela;
	}

	public Double getValorIrrfPrimeiraPrevisto() {
		return valorIrrfPrimeiraPrevisto;
	}

	public void setValorIrrfPrimeiraPrevisto(Double valorIrrfPrimeiraPrevisto) {
		this.valorIrrfPrimeiraPrevisto = valorIrrfPrimeiraPrevisto;
	}

	public Integer getQtdParcela() {
		return qtdParcela;
	}

	public void setQtdParcela(Integer qtdParcela) {
		this.qtdParcela = qtdParcela;
	}

	public Double getQtdCotasReversao() {
		return qtdCotasReversao;
	}

	public void setQtdCotasReversao(Double qtdCotasReversao) {
		this.qtdCotasReversao = qtdCotasReversao;
	}

	public Double getQtdCotasRemanescente() {
		return qtdCotasRemanescente;
	}

	public void setQtdCotasRemanescente(Double qtdCotasRemanescente) {
		this.qtdCotasRemanescente = qtdCotasRemanescente;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public Date getDataPagtoParcelaUm() {
		return dataPagtoParcelaUm;
	}

	public void setDataPagtoParcelaUm(Date dataPagtoParcelaUm) {
		this.dataPagtoParcelaUm = dataPagtoParcelaUm;
	}

	public Date getDataInicioContribuicao() {
		return dataInicioContribuicao;
	}

	public void setDataInicioContribuicao(Date dataInicioContribuicao) {
		this.dataInicioContribuicao = dataInicioContribuicao;
	}

	public Date getDataFimContribuicao() {
		return dataFimContribuicao;
	}

	public void setDataFimContribuicao(Date dataFimContribuicao) {
		this.dataFimContribuicao = dataFimContribuicao;
	}

	public int getQuantidadeDependenteIrrf() {
		return quantidadeDependenteIrrf;
	}

	public void setQuantidadeDependenteIrrf(int quantidadeDependenteIrrf) {
		this.quantidadeDependenteIrrf = quantidadeDependenteIrrf;
	}

	public int getQuantidadeDependente() {
		return quantidadeDependente;
	}

	public void setQuantidadeDependente(int quantidadeDependente) {
		this.quantidadeDependente = quantidadeDependente;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Double getQtdCotasTotalParticipante() {
		return qtdCotasTotalParticipante;
	}

	public void setQtdCotasTotalParticipante(Double qtdCotasTotalParticipante) {
		this.qtdCotasTotalParticipante = qtdCotasTotalParticipante;
	}

	public Double getQtdCotasTotalPatronal() {
		return qtdCotasTotalPatronal;
	}

	public void setQtdCotasTotalPatronal(Double qtdCotasTotalPatronal) {
		this.qtdCotasTotalPatronal = qtdCotasTotalPatronal;
	}

	public String getIndicadorTipoResgate() {
		return indicadorTipoResgate;
	}

	public void setIndicadorTipoResgate(String indicadorTipoResgate) {
		this.indicadorTipoResgate = indicadorTipoResgate;
	}

	public String getIndicadorCarenciaInstituidor() {
		return indicadorCarenciaInstituidor;
	}

	public void setIndicadorCarenciaInstituidor(String indicadorCarenciaInstituidor) {
		this.indicadorCarenciaInstituidor = indicadorCarenciaInstituidor;
	}

	public Double getQtdCotasRemanescenteInst() {
		return qtdCotasRemanescenteInst;
	}

	public void setQtdCotasRemanescenteInst(Double qtdCotasRemanescenteInst) {
		this.qtdCotasRemanescenteInst = qtdCotasRemanescenteInst;
	}

	public String getIndicadorPortabilidade() {
		return indicadorPortabilidade;
	}

	public void setIndicadorPortabilidade(String indicadorPortabilidade) {
		this.indicadorPortabilidade = indicadorPortabilidade;
	}

	public String getDescricaoObservacaoPagto() {
		return descricaoObservacaoPagto;
	}

	public void setDescricaoObservacaoPagto(String descricaoObservacaoPagto) {
		this.descricaoObservacaoPagto = descricaoObservacaoPagto;
	}

	public Date getDataDescricaoPagto() {
		return dataDescricaoPagto;
	}

	public void setDataDescricaoPagto(Date dataDescricaoPagto) {
		this.dataDescricaoPagto = dataDescricaoPagto;
	}

	public String getDevolucaoManual() {
		return devolucaoManual;
	}

	public void setDevolucaoManual(String devolucaoManual) {
		this.devolucaoManual = devolucaoManual;
	}

	public Double getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(Double valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public String getIndicadorParcelaCarencia() {
		return indicadorParcelaCarencia;
	}

	public void setIndicadorParcelaCarencia(String indicadorParcelaCarencia) {
		this.indicadorParcelaCarencia = indicadorParcelaCarencia;
	}

	public List<FichaDevolucao> getListaFichaDevolucao() {
		return listaFichaDevolucao;
	}

	public void setListaFichaDevolucao(List<FichaDevolucao> listaFichaDevolucao) {
		this.listaFichaDevolucao = listaFichaDevolucao;
	}

	public IdentificadorDevolucao getIdentificadorDevolucao() {
		return identificadorDevolucao;
	}

	public void setIdentificadorDevolucao(IdentificadorDevolucao identificadorDevolucao) {
		this.identificadorDevolucao = identificadorDevolucao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricaoDeferimento() {
		return descricaoDeferimento;
	}

	public void setDescricaoDeferimento(String descricaoDeferimento) {
		this.descricaoDeferimento = descricaoDeferimento;
	}

	public String getMotivoIndeferimento() {
		return motivoIndeferimento;
	}

	public void setMotivoIndeferimento(String motivoIndeferimento) {
		this.motivoIndeferimento = motivoIndeferimento;
	}

	public Double getValorCotaPagamentoMes() {
		return valorCotaPagamentoMes;
	}

	public void setValorCotaPagamentoMes(Double valorCotaPagamentoMes) {
		this.valorCotaPagamentoMes = valorCotaPagamentoMes;
	}

	public Double getSaldoResgatavel() {
		return saldoResgatavel;
	}

	public void setSaldoResgatavel(Double saldoResgatavel) {
		this.saldoResgatavel = saldoResgatavel;
	}

	public Date getDataCotaPagamentoMes() {
		return dataCotaPagamentoMes;
	}

	public void setDataCotaPagamentoMes(Date dataCotaPagamentoMes) {
		this.dataCotaPagamentoMes = dataCotaPagamentoMes;
	}

	public Double getValorTotalImposto() {
		return valorTotalImposto;
	}

	public void setValorTotalImposto(Double valorTotalImposto) {
		this.valorTotalImposto = valorTotalImposto;
	}

	public List<RecebedorDTO> getListaRecebedorDTO() {
		return listaRecebedorDTO;
	}

	public void setListaRecebedorDTO(List<RecebedorDTO> listaRecebedorDTO) {
		this.listaRecebedorDTO = listaRecebedorDTO;
	}

	@Override
	public String toString() {
		return "DevolucaoAntigoDTO [codigo=" + codigo + ", descricaoObservacao=" + descricaoObservacao + ", qtdCotasParticipante=" + qtdCotasParticipante + ", qtdCotasPatrocinadora="
				+ qtdCotasPatrocinadora + ", valorCotaPrevisao=" + valorCotaPrevisao + ", valorIrrfPrevisto=" + valorIrrfPrevisto + ", qtdCotasTotalPrimeiraParcela=" + qtdCotasTotalPrimeiraParcela
				+ ", valorIrrfPrimeiraPrevisto=" + valorIrrfPrimeiraPrevisto + ", qtdParcela=" + qtdParcela + ", qtdCotasReversao=" + qtdCotasReversao + ", qtdCotasRemanescente="
				+ qtdCotasRemanescente + ", dataRequerimento=" + dataRequerimento + ", dataPagtoParcelaUm=" + dataPagtoParcelaUm + ", dataInicioContribuicao=" + dataInicioContribuicao
				+ ", dataFimContribuicao=" + dataFimContribuicao + ", quantidadeDependenteIrrf=" + quantidadeDependenteIrrf + ", quantidadeDependente=" + quantidadeDependente + ", dataCota="
				+ dataCota + ", qtdCotasTotalParticipante=" + qtdCotasTotalParticipante + ", qtdCotasTotalPatronal=" + qtdCotasTotalPatronal + ", indicadorTipoResgate=" + indicadorTipoResgate
				+ ", indicadorCarenciaInstituidor=" + indicadorCarenciaInstituidor + ", qtdCotasRemanescenteInst=" + qtdCotasRemanescenteInst + ", indicadorPortabilidade=" + indicadorPortabilidade
				+ ", descricaoObservacaoPagto=" + descricaoObservacaoPagto + ", dataDescricaoPagto=" + dataDescricaoPagto + ", devolucaoManual=" + devolucaoManual + ", valorEmprestimo="
				+ valorEmprestimo + ", indicadorParcelaCarencia=" + indicadorParcelaCarencia + ", listaFichaDevolucao=" + listaFichaDevolucao + ", identificadorDevolucao=" + identificadorDevolucao
				+ ", descricao=" + descricao + ", descricaoDeferimento=" + descricaoDeferimento + ", motivoIndeferimento=" + motivoIndeferimento + ", valorCotaPagamentoMes=" + valorCotaPagamentoMes
				+ ", saldoResgatavel=" + saldoResgatavel + ", dataCotaPagamentoMes=" + dataCotaPagamentoMes + ", valorTotalImposto=" + valorTotalImposto + ", listaRecebedorDTO=" + listaRecebedorDTO
				+ "]";
	}

}