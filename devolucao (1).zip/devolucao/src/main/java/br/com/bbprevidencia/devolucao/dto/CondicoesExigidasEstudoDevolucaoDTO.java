package br.com.bbprevidencia.devolucao.dto;

public class CondicoesExigidasEstudoDevolucaoDTO {

	private String nomeCondicao;

	private String textoCondicao;

	private String atendeCondicao;

	public String getNomeCondicao() {
		return nomeCondicao;
	}

	public void setNomeCondicao(String nomeCondicao) {
		this.nomeCondicao = nomeCondicao;
	}

	public String getTextoCondicao() {
		return textoCondicao;
	}

	public void setTextoCondicao(String textoCondicao) {
		this.textoCondicao = textoCondicao;
	}

	public String getAtendeCondicao() {
		return atendeCondicao;
	}

	public void setAtendeCondicao(String atendeCondicao) {
		this.atendeCondicao = atendeCondicao;
	}

}
