package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   05/12/2016
 * Classe de persistência para tabela HIS_SIT_REG_DEV.
 */
@Entity
@Table(name = "AUTORIZACAO_REGRA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "AutorizacaoRegraDevolucao.findAll", query = "SELECT q FROM AutorizacaoRegraDevolucao q")
public class AutorizacaoRegraDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "AUTORIZACAO_REGRA_DEVOLUCAO_GER", sequenceName = "S_ARD_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AUTORIZACAO_REGRA_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_AUT_REG_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_DEV")
	private RegraDevolucao regraDevolucao;

	@Column(name = "IND_AUT")
	private String indicadorAutorizacao;

	@Column(name = "DSC_OBS")
	private String observacao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public String getIndicadorAutorizacao() {
		return indicadorAutorizacao;
	}

	public void setIndicadorAutorizacao(String indicadorAutorizacao) {
		this.indicadorAutorizacao = indicadorAutorizacao;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

}