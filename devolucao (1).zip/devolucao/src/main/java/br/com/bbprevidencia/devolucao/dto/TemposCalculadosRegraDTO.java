package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

public class TemposCalculadosRegraDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer qtdMesesIdade;
	private Integer qtdMesesEmpresa;
	private Integer qtdMesesPlano;
	private Integer qtdMesesContribuicao;

	private RegraCalculoDevolucao regraCalculoDevolucao;

	public Integer getQtdMesesIdade() {
		return qtdMesesIdade;
	}

	public void setQtdMesesIdade(Integer qtdMesesIdade) {
		this.qtdMesesIdade = qtdMesesIdade;
	}

	public Integer getQtdMesesEmpresa() {
		return qtdMesesEmpresa;
	}

	public void setQtdMesesEmpresa(Integer qtdMesesEmpresa) {
		this.qtdMesesEmpresa = qtdMesesEmpresa;
	}

	public Integer getQtdMesesPlano() {
		return qtdMesesPlano;
	}

	public void setQtdMesesPlano(Integer qtdMesesPlano) {
		this.qtdMesesPlano = qtdMesesPlano;
	}

	public Integer getQtdMesesContribuicao() {
		return qtdMesesContribuicao;
	}

	public void setQtdMesesContribuicao(Integer qtdMesesContribuicao) {
		this.qtdMesesContribuicao = qtdMesesContribuicao;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

}
