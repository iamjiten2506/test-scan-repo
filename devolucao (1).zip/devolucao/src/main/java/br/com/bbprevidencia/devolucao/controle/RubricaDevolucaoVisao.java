package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.RubricaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RubricaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.folha.bo.CaracteristicaDirfBO;
import br.com.bbprevidencia.folha.bo.ConsignatarioBO;
import br.com.bbprevidencia.folha.bo.TipoRubricaBO;
import br.com.bbprevidencia.folha.dto.CaracteristicaDirf;
import br.com.bbprevidencia.folha.dto.Consignatario;
import br.com.bbprevidencia.folha.dto.TipoRubrica;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter as Rubricas de Devoluções
 * 
 * @author  BBPF0415 - Yanisley Mora  Ritchie
 * @since 13/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("rubricaDevolucaoVisao")
public class RubricaDevolucaoVisao {

	private static final String FW_RUBRUICA_DEVOLUCAO = "/paginas/rubricaDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private RubricaDevolucaoBO rubricaDevolucaoBo;

	@Autowired
	private TipoRubricaBO tipoRubricaBo;

	@Autowired
	private CaracteristicaDirfBO caracteristicaDirfBo;

	@Autowired
	private ConsignatarioBO consignatarioBo;

	private List<RubricaDevolucao> listaRubricaDevolucao;

	private List<SelectItem> listaPesquisaRubricaDevolucao;
	private Long codigoRubricaDevolucao;

	private List<TipoRubrica> listaTipoRubrica;
	private Long codigoTipoRubrica;

	private List<Consignatario> listaConsignatario;
	private Long codigoConsignatario;

	private List<CaracteristicaDirf> listaCaracteristicaDirf;
	private Long codigoCaracteristicaDirf;

	private RubricaDevolucao rubricaDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private Consignatario consignatario;

	private TipoRubrica tipoRubrica;

	private CaracteristicaDirf caracteristicaDirf;

	/**
	 * Método encarredado por iniciar a página da Rúbica de Devoluções
	 * @author  BBPF0415 - Yanisley Mora  Ritchie
	 * @since 13/01/2017
	 * @return {@link String}
	 */
	public String iniciarRubricaDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("rubricaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}

		rubricaDevolucao = new RubricaDevolucao();
		listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBo.listarRubricaDevolucao());

		this.listarStatus = true;

		this.listaPesquisaRubricaDevolucao = listarRubricaDevolucaoParaPesquisa();
		this.listaTipoRubrica = new ArrayList<TipoRubrica>(tipoRubricaBo.listarTipoRubrica());
		this.listaCaracteristicaDirf = new ArrayList<CaracteristicaDirf>(caracteristicaDirfBo.listarCaracteristicaDirf());
		this.listaConsignatario = new ArrayList<Consignatario>(consignatarioBo.listarConsignatario());

		return FW_RUBRUICA_DEVOLUCAO;
	}

	// Getters And Setters
	public List<RubricaDevolucao> getListaRubricaDevolucao() {
		return listaRubricaDevolucao;
	}

	public void setListaRubricaDevolucao(List<RubricaDevolucao> listaRubricaDevolucao) {
		this.listaRubricaDevolucao = listaRubricaDevolucao;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public List<SelectItem> getListaPesquisaRubricaDevolucao() {
		return listaPesquisaRubricaDevolucao;
	}

	public void setListaPesquisaRubricaDevolucao(List<SelectItem> listaPesquisaRubricaDevolucao) {
		this.listaPesquisaRubricaDevolucao = listaPesquisaRubricaDevolucao;
	}

	public Long getCodigoRubricaDevolucao() {
		return codigoRubricaDevolucao;
	}

	public void setCodigoRubricaDevolucao(Long codigoRubricaDevolucao) {
		this.codigoRubricaDevolucao = codigoRubricaDevolucao;
	}

	public Long getCodigoTipoRubrica() {
		return codigoTipoRubrica;
	}

	public void setCodigoTipoRubrica(Long codigoTipoRubrica) {
		this.codigoTipoRubrica = codigoTipoRubrica;
	}

	public Long getCodigoConsignatario() {
		return codigoConsignatario;
	}

	public void setCodigoConsignatario(Long codigoConsignatario) {
		this.codigoConsignatario = codigoConsignatario;
	}

	public Long getCodigoCaracteristicaDirf() {
		return codigoCaracteristicaDirf;
	}

	public void setCodigoCaracteristicaDirf(Long codigoCaracteristicaDirf) {
		this.codigoCaracteristicaDirf = codigoCaracteristicaDirf;
	}

	public Consignatario getConsignatario() {
		return consignatario;
	}

	public void setConsignatario(Consignatario consignatario) {
		this.consignatario = consignatario;
	}

	public TipoRubrica getTipoRubrica() {
		return tipoRubrica;
	}

	public void setTipoRubrica(TipoRubrica tipoRubrica) {
		this.tipoRubrica = tipoRubrica;
	}

	public CaracteristicaDirf getCaracteristicaDirf() {
		return caracteristicaDirf;
	}

	public void setCaracteristicaDirf(CaracteristicaDirf caracteristicaDirf) {
		this.caracteristicaDirf = caracteristicaDirf;
	}

	public List<TipoRubrica> getListaTipoRubrica() {
		return listaTipoRubrica;
	}

	public void setListaTipoRubrica(List<TipoRubrica> listaTipoRubrica) {
		this.listaTipoRubrica = listaTipoRubrica;
	}

	public List<Consignatario> getListaConsignatario() {
		return listaConsignatario;
	}

	public void setListaConsignatario(List<Consignatario> listaConsignatario) {
		this.listaConsignatario = listaConsignatario;
	}

	public List<CaracteristicaDirf> getListaCaracteristicaDirf() {
		return listaCaracteristicaDirf;
	}

	public void setListaCaracteristicaDirf(List<CaracteristicaDirf> listaCaracteristicaDirf) {
		this.listaCaracteristicaDirf = listaCaracteristicaDirf;
	}

	//Métodos de funcionamento da página
	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/01/2017
	 */
	public void controlarEdicaoVisualizacao() {

		if (isListarStatus()) {
			consignatario = new Consignatario();
			tipoRubrica = new TipoRubrica();
			caracteristicaDirf = new CaracteristicaDirf();

			listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBo.listarRubricaDevolucao());
		}

		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método que seleciona uma Rubrica d eDevolução e a coloca em modo de edição 
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/01/2017
	 * @param {@link RubricaDevolucao}
	 */
	public void editarRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		System.out.println(rubricaDevolucao.toString());
		setRubricaDevolucao(rubricaDevolucao);
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método que coloca a pagina em modo de edição
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/01/2017
	 */
	public void cadastrarNovaRubricaDevolucao() {
		rubricaDevolucao = new RubricaDevolucao();
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método para salvar ou atualizar uma Rubrica Devolução 
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 20/01/2017
	 * 
	 */
	public String salvarRubricaDevolucao() {
		try {

			this.listarStatus = true;

			Long codigo = rubricaDevolucao.getCodigo();

			rubricaDevolucaoBo.salvarRubricaDevolucao(rubricaDevolucao);
			controlarEdicaoVisualizacao();

			Mensagens.addMessage("DEV_VMSG001", codigo == null ? "salva" : "atualizada");
			return "";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar a Rubrica de Devolução");
			return "";
		}

	}

	/**
	 * Método para retornar a lista de Rubricas de Devolucao para preencher a lista de pesquisa ou edição/inserção 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/01/2017
	 * @return	{@link SelectItem}
	 * 
	 */
	public List<SelectItem> listarRubricaDevolucaoParaPesquisa() {
		List<SelectItem> itens = new ArrayList<SelectItem>();
		List<RubricaDevolucao> listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBo.listarRubricaDevolucao());
		if (!UtilJava.isColecaoVazia(listaRubricaDevolucao)) {
			for (RubricaDevolucao rubricaDevolucao : listaRubricaDevolucao) {
				itens.add(new SelectItem(rubricaDevolucao.getCodigo(), rubricaDevolucao.getNome()));
			}
		}
		return itens;
	}

	/**
	 * Método para retornar a Lista de Rubricas que atenda os criterios de pesquisa
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 	23/01/2017
	 * @return  List<{@link RubricaDevolucao}>
	 */
	public void filtrarListaRubricasDevolucao() {

		if (this.codigoRubricaDevolucao == null) {
			if (this.tipoRubrica != null || this.caracteristicaDirf != null || this.consignatario != null) {
				listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBo.filtrarListaRubricasDevolucao(tipoRubrica, caracteristicaDirf, consignatario));
			} else {
				listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBo.listarRubricaDevolucao());
			}
		} else {
			listaRubricaDevolucao = new ArrayList<RubricaDevolucao>();
			listaRubricaDevolucao.add(rubricaDevolucaoBo.pesquisarRubricaDevolucaoPorCodigo(this.codigoRubricaDevolucao));
		}
	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da página
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 	24/01/2017
	 * 
	 */
	public void limparPesquisa() {
		this.caracteristicaDirf = null;
		this.tipoRubrica = null;
		this.consignatario = null;
		this.codigoRubricaDevolucao = null;

		listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBo.listarRubricaDevolucao());
	}

	/**
	 * Método encarregado de deletar uma Rubrica Devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 25/01/2017
	 * @param {@link RubricaDevolucao}
	 * @return {@link String}
	 */
	public String deletarRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		try {
			rubricaDevolucaoBo.deletarRubricaDevolucao(rubricaDevolucao);
			listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBo.listarRubricaDevolucao());
			Mensagens.addMsgInfo("Rubrica Devolução excluído com sucesso!");
			return "";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar a Rubrica de Devolução");
			return "";
		}
	}

}
