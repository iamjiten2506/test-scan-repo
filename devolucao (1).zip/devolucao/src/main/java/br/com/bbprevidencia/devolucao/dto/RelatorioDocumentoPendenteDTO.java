package br.com.bbprevidencia.devolucao.dto;

import java.util.ArrayList;
import java.util.List;

public class RelatorioDocumentoPendenteDTO {

	private String nomeDestinatario;

	private String enderecoDestinatario;

	private String cidadeDestinatario;

	private String cepDestinatario;

	private String sexoRecebedor;

	private String dataSolicitacao;

	private String nomePlano;

	private String emailContato;

	private String telefoneContato;

	private String nomeEntidadeContato;

	private String enderecoContato;

	private String cepContato;

	private String cidadeContato;

	private String ufContato;

	private List<ListaStringUtil> listaDocumentoPendente = new ArrayList<ListaStringUtil>();

	private List<ListaStringUtil> listaDocumentoSolicitado = new ArrayList<ListaStringUtil>();

	//Classe Interna
	public static class ListaStringUtil {

		private String itemLista;

		public String getItemLista() {
			return itemLista;
		}

		public void setItemLista(String itemLista) {
			this.itemLista = itemLista;
		}
	}

	public String getNomeDestinatario() {
		return nomeDestinatario;
	}

	public void setNomeDestinatario(String nomeDestinatario) {
		this.nomeDestinatario = nomeDestinatario;
	}

	public String getEnderecoDestinatario() {
		return enderecoDestinatario;
	}

	public void setEnderecoDestinatario(String enderecoDestinatario) {
		this.enderecoDestinatario = enderecoDestinatario;
	}

	public String getCidadeDestinatario() {
		return cidadeDestinatario;
	}

	public void setCidadeDestinatario(String cidadeDestinatario) {
		this.cidadeDestinatario = cidadeDestinatario;
	}

	public String getCepDestinatario() {
		return cepDestinatario;
	}

	public void setCepDestinatario(String cepDestinatario) {
		this.cepDestinatario = cepDestinatario;
	}

	public String getDataSolicitacao() {
		return dataSolicitacao;
	}

	public void setDataSolicitacao(String dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getEmailContato() {
		return emailContato;
	}

	public void setEmailContato(String emailContato) {
		this.emailContato = emailContato;
	}

	public String getTelefoneContato() {
		return telefoneContato;
	}

	public void setTelefoneContato(String telefoneContato) {
		this.telefoneContato = telefoneContato;
	}

	public String getNomeEntidadeContato() {
		return nomeEntidadeContato;
	}

	public void setNomeEntidadeContato(String nomeEntidadeContato) {
		this.nomeEntidadeContato = nomeEntidadeContato;
	}

	public String getEnderecoContato() {
		return enderecoContato;
	}

	public void setEnderecoContato(String enderecoContato) {
		this.enderecoContato = enderecoContato;
	}

	public String getCepContato() {
		return cepContato;
	}

	public void setCepContato(String cepContato) {
		this.cepContato = cepContato;
	}

	public String getCidadeContato() {
		return cidadeContato;
	}

	public void setCidadeContato(String cidadeContato) {
		this.cidadeContato = cidadeContato;
	}

	public String getUfContato() {
		return ufContato;
	}

	public void setUfContato(String ufContato) {
		this.ufContato = ufContato;
	}

	public String getSexoRecebedor() {
		return sexoRecebedor;
	}

	public void setSexoRecebedor(String sexoRecebedor) {
		this.sexoRecebedor = sexoRecebedor;
	}

	public List<ListaStringUtil> getListaDocumentoPendente() {
		return listaDocumentoPendente;
	}

	public void setListaDocumentoPendente(List<ListaStringUtil> listaDocumentoPendente) {
		this.listaDocumentoPendente = listaDocumentoPendente;
	}

	public List<ListaStringUtil> getListaDocumentoSolicitado() {
		return listaDocumentoSolicitado;
	}

	public void setListaDocumentoSolicitado(List<ListaStringUtil> listaDocumentoSolicitado) {
		this.listaDocumentoSolicitado = listaDocumentoSolicitado;
	}

}
