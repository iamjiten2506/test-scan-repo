package br.com.bbprevidencia.devolucao.dto;

import java.util.ArrayList;
import java.util.List;

public class EstudoDevolucaoDTO {

	//Dados do participante
	private String nomePlano;

	private String nomeParticipante;

	private String matriculaParticipante;

	private String dataInscricaoPlano;

	private String dataAdmissaoEmpresa;

	private String dataNascimento;

	private String dataRequerimento;

	private String opcaoTributacao;

	private String cumplioMesesCarencia;

	private String dataRecisao;

	private Integer idadeAnos;

	private Integer idadeMeses;

	private Integer idadeDias;

	private Integer planoAnos;

	private Integer planoMeses;

	private Integer planoDias;

	private Integer empresaAnos;

	private Integer empresaMeses;

	private Integer empresaDias;

	private String nomeUsuarioSolicitante;

	private List<CondicoesExigidasEstudoDevolucaoDTO> listaCondicoes = new ArrayList<CondicoesExigidasEstudoDevolucaoDTO>();

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getDataInscricaoPlano() {
		return dataInscricaoPlano;
	}

	public void setDataInscricaoPlano(String dataInscricaoPlano) {
		this.dataInscricaoPlano = dataInscricaoPlano;
	}

	public String getDataAdmissaoEmpresa() {
		return dataAdmissaoEmpresa;
	}

	public void setDataAdmissaoEmpresa(String dataAdmissaoEmpresa) {
		this.dataAdmissaoEmpresa = dataAdmissaoEmpresa;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(String dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public String getOpcaoTributacao() {
		return opcaoTributacao;
	}

	public void setOpcaoTributacao(String opcaoTributacao) {
		this.opcaoTributacao = opcaoTributacao;
	}

	public String getCumplioMesesCarencia() {
		return cumplioMesesCarencia;
	}

	public void setCumplioMesesCarencia(String cumplioMesesCarencia) {
		this.cumplioMesesCarencia = cumplioMesesCarencia;
	}

	public String getDataRecisao() {
		return dataRecisao;
	}

	public void setDataRecisao(String dataRecisao) {
		this.dataRecisao = dataRecisao;
	}

	public String getNomeUsuarioSolicitante() {
		return nomeUsuarioSolicitante;
	}

	public void setNomeUsuarioSolicitante(String nomeUsuarioSolicitante) {
		this.nomeUsuarioSolicitante = nomeUsuarioSolicitante;
	}

	public Integer getIdadeAnos() {
		return idadeAnos;
	}

	public void setIdadeAnos(Integer idadeAnos) {
		this.idadeAnos = idadeAnos;
	}

	public Integer getIdadeMeses() {
		return idadeMeses;
	}

	public void setIdadeMeses(Integer idadeMeses) {
		this.idadeMeses = idadeMeses;
	}

	public Integer getIdadeDias() {
		return idadeDias;
	}

	public void setIdadeDias(Integer idadeDias) {
		this.idadeDias = idadeDias;
	}

	public Integer getPlanoAnos() {
		return planoAnos;
	}

	public void setPlanoAnos(Integer planoAnos) {
		this.planoAnos = planoAnos;
	}

	public Integer getPlanoMeses() {
		return planoMeses;
	}

	public void setPlanoMeses(Integer planoMeses) {
		this.planoMeses = planoMeses;
	}

	public Integer getPlanoDias() {
		return planoDias;
	}

	public void setPlanoDias(Integer planoDias) {
		this.planoDias = planoDias;
	}

	public Integer getEmpresaAnos() {
		return empresaAnos;
	}

	public void setEmpresaAnos(Integer empresaAnos) {
		this.empresaAnos = empresaAnos;
	}

	public Integer getEmpresaMeses() {
		return empresaMeses;
	}

	public void setEmpresaMeses(Integer empresaMeses) {
		this.empresaMeses = empresaMeses;
	}

	public Integer getEmpresaDias() {
		return empresaDias;
	}

	public void setEmpresaDias(Integer empresaDias) {
		this.empresaDias = empresaDias;
	}

	public List<CondicoesExigidasEstudoDevolucaoDTO> getListaCondicoes() {
		return listaCondicoes;
	}

	public void setListaCondicoes(List<CondicoesExigidasEstudoDevolucaoDTO> listaCondicoes) {
		this.listaCondicoes = listaCondicoes;
	}

}
