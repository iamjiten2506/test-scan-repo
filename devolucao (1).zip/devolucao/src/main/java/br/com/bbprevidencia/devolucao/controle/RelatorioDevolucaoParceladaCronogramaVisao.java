package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoPagtoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioDevolucaoParceladaCronogramaDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório de parcelas de devolução
 * 
 * @author BBPF0370 - Guilherme de Carvalho
 * @since 15/02/2019
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioDevolucaoParceladaCronogramaVisao")
public class RelatorioDevolucaoParceladaCronogramaVisao {

	private static final String FW_RELATORIO_PARCELA_DEVOLUCAO = "/paginas/relatorioDevolucaoParceladaCronograma.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioDevolucaoParceladaCronogramaVisao.class);

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;
	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;
	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;
	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;
	@Autowired
	private ParticipanteBO participanteBO;
	@Autowired
	private ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;
	@Autowired
	private ParcelaContaDevolucaoPagtoBO parcelaContaDevolucaoPgtoBO;
	@Autowired
	RelatorioUtil relatorioUtil;
	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;
	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	private boolean selecionarParticipante;

	private boolean selecionarPlano;

	private EntidadeParticipante entidadeParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipante;
	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;
	private List<PlanoPrevidencia> listaPlanoPrevidencia;
	private List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados;
	private List<TipoDevolucao> listaTipoDevolucaoSelecionados;

	private PlanoPrevidencia planoPrevidencia;
	private Participante participante;

	private CronogramaDevolucao cronogramaDevolucao;
	private List<CronogramaDevolucao> listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>();

	/**
	 * Método encarregado de chamar a página de preenchimento de parâmetros
	 * 
	 * @author  BBPF0370 - Guilherme de Carvalho
	 * @since 15/02/2019
	 * @return
	 */
	public String iniciarRelatorioDevolucaoParceladaCronograma() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		setarValoresIniciais();

		return FW_RELATORIO_PARCELA_DEVOLUCAO;
	}

	/**
	 * @author  BBPF0370 - Guilherme de Carvalho
	 * @since 15/02/2019
	 */
	private void setarValoresIniciais() {
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(this.cronogramaDevolucaoBO.listarCronogramaDescendente());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>();
		this.listaEntidadeParticipanteSelecionadas = new ArrayList<EntidadeParticipante>();
		this.cronogramaDevolucao = null;
		this.selecionarParticipante = false;
		this.selecionarPlano = false;

		setarVisaoMultiEmpresa();

	}

	private void setarVisaoMultiEmpresa() {
		this.selecionarPlano = false;
		this.selecionarParticipante = false;
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>();
		this.listaPlanoPrevidenciaSelecionados = new ArrayList<PlanoPrevidencia>();
		this.entidadeParticipante = null;
		this.planoPrevidencia = null;
		this.participante = null;
	}

	/**
	 * @author  BBPF0370 - Guilherme de Carvalho
	 * @since 15/02/2019
	 */
	public void verificaListaPatrocinadora() {
		try {
			if (UtilJava.isColecaoVazia(this.listaEntidadeParticipanteSelecionadas)) {
				setarVisaoMultiEmpresa();
			} else {
				if (this.listaEntidadeParticipanteSelecionadas.size() == 1) {
					this.selecionarPlano = true;

					this.entidadeParticipante = this.listaEntidadeParticipanteSelecionadas.get(0);
					this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante);
				} else {
					setarVisaoMultiEmpresa();
				}
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * @author  BBPF0370 - Guilherme de Carvalho
	 * @since 15/02/2019
	 */
	public void verificaListaPlano() {
		try {
			if (UtilJava.isColecaoVazia(this.listaPlanoPrevidenciaSelecionados)) {
				this.selecionarParticipante = false;
			} else {
				if (this.listaPlanoPrevidenciaSelecionados.size() == 1) {
					this.selecionarParticipante = true;

					this.planoPrevidencia = this.listaPlanoPrevidenciaSelecionados.get(0);
				} else {
					this.selecionarParticipante = false;
				}
			}
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}
	}

	/**
	 * Método para retornar os participantes por plano que incluam o nome o texo digitado no autocomplete
	 * 
	 * @author  BBPF0370 - Guilherme de Carvalho
	 * @param {@link String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0370 - Guilherme de Carvalho
	 * @since 15/02/2019
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() == null) {
			setParticipante(new Participante());
		}
	}

	public void limparPesquisa() {
		setarValoresIniciais();
	}

	public void exportarRelatorio(ActionEvent event) {
		try {

			if (this.cronogramaDevolucao == null) {
				throw new Exception("Deve selecionar um cronograma antes de emitir o relatório selecionado!");
			}

			List<RelatorioDevolucaoParceladaCronogramaDTO> ListaRelatorioDevolucaoParceladaCronogramaDTO = new ArrayList<RelatorioDevolucaoParceladaCronogramaDTO>();

			ListaRelatorioDevolucaoParceladaCronogramaDTO.addAll(this.parcelaContaDevolucaoPgtoBO.relatorioDevolucaoParceladaCronograma(
					this.cronogramaDevolucao,
					this.listaEntidadeParticipanteSelecionadas,
					this.listaPlanoPrevidenciaSelecionados,
					this.participante));

			if (UtilJava.isColecaoVazia(ListaRelatorioDevolucaoParceladaCronogramaDTO)) {
				Mensagens.addMsgInfo("Não foram encontradas informações para estes parâmetros!");
			} else {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
				parametros.put("logo", logo);

				String nomeArquivo = relatorioUtil.gerarRelatorio("relatorioDevolucaoParceladaCronograma", ListaRelatorioDevolucaoParceladaCronogramaDTO, parametros);
				relatorioUtil.abrirPoupUp(nomeArquivo);
			}

		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro("Erro ao exportar relatório.");
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro(ex.getMessage());
		}

	}

	public boolean isSelecionarParticipante() {
		return selecionarParticipante;
	}

	public void setSelecionarParticipante(boolean selecionarPatrocinadora) {
		this.selecionarParticipante = selecionarPatrocinadora;
	}

	public boolean isSelecionarPlano() {
		return selecionarPlano;
	}

	public void setSelecionarPlano(boolean selecionarPlano) {
		this.selecionarPlano = selecionarPlano;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidenciaSelecionados() {
		return listaPlanoPrevidenciaSelecionados;
	}

	public void setListaPlanoPrevidenciaSelecionados(List<PlanoPrevidencia> listaPlanoPrevidenciaSelecionados) {
		this.listaPlanoPrevidenciaSelecionados = listaPlanoPrevidenciaSelecionados;
	}

	public List<TipoDevolucao> getListaTipoDevolucaoSelecionados() {
		return listaTipoDevolucaoSelecionados;
	}

	public void setListaTipoDevolucaoSelecionados(List<TipoDevolucao> listaTipoDevolucaoSelecionados) {
		this.listaTipoDevolucaoSelecionados = listaTipoDevolucaoSelecionados;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	/**
	 * Método encarregado de pesquisar as entidades participantes que participaram do cáculo de determinado cronograma
	 */
	public void listarPatrocinadoraPorCronograma() {
		//Situação do cronograma como fechado
		if (this.cronogramaDevolucao != null) {

			if (this.cronogramaDevolucao.getSituacaoFolha().getCodigo() == 4L) {
				this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.historicoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
			} else {
				this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.movimentoCalculoPagamentoDevolucaoBO.listarEntidadeParticipantePorCronograma(this.cronogramaDevolucao));
			}
		}
	}

}
