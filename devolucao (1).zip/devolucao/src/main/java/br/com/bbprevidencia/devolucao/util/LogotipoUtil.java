package br.com.bbprevidencia.devolucao.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;

import org.primefaces.model.UploadedFile;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.utils.UtilJava;

/**
 * Classe utilitária responsável por realizar a importação e exportação de imagens.
 * 
 * @author helio.lima
 * @since 21/03/2012
 */

/* ATENÇAO: CLASSE AINDA EM TESE */
public abstract class LogotipoUtil {

	public static final String PATH_DA_APLICACAO = UtilSession.getRealPath("imagens") + "\\LogoTipos\\";
	public static final String PATH_EXTERNO = UtilSession.getRealPath("imagens") + "\\LogotiposExterno\\";

	/**
	 * Método responsável por SALVAR um arquivo em um diretório externo à aplicação web.
	 * 
	 * @param nomeArquivo
	 * @param data
	 * @param diretorio
	 * @throws PrevidenciaException
	 * @throws IOException 
	 */
	public static void exportarImagem(UploadedFile uploadedFile, String novoNome) throws PrevidenciaException, IOException {

		File arquivoSelecionado = new File(PATH_EXTERNO, novoNome);

		FileOutputStream fileOutStream = new FileOutputStream(arquivoSelecionado);

		fileOutStream.write(uploadedFile.getContents());

		fileOutStream.flush();

		fileOutStream.close();
	}

	/**
	 * Recupera o caminho da imagem no contexto da aplicação.
	 * 
	 * @param caminho
	 * @param nomeArquivo
	 * @return String
	 * @throws PrevidenciaException
	 */
	public static boolean importarImagem(String nomeArquivo) throws IOException {
		boolean booImportou = false;
		if (LogotipoUtil.existeImagemImportada(nomeArquivo)) {
			booImportou = true;
		} else {
			InputStream in = null;
			OutputStream out = null;
			try {
				in = new FileInputStream(PATH_EXTERNO + nomeArquivo);
				out = new FileOutputStream(PATH_DA_APLICACAO + nomeArquivo);
				while (true) {
					int data = in.read();
					if (data == -1) {
						break;
					}
					out.write(data);
				}
				in.close();
				out.close();
				booImportou = true;
			} finally {
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
			}
		}
		return booImportou;
	}

	/** Método responsável por verificar se um arquivo exite no diretório externo à aplicação.
	 * 
	 * @param uploadedFile
	 * @return
	 */
	public static boolean exiteImagemExportada(String nomeArquivo) {
		File arquivoSelecionado = new File(PATH_EXTERNO, nomeArquivo);
		return arquivoSelecionado.exists();
	}

	/** Método responsável por verificar se um arquivo exite no diretório interno à aplicação.
	 * 
	 * @param uploadedFile
	 * @return
	 */
	public static boolean existeImagemImportada(String fileName) {
		File arquivoSelecionado = new File(PATH_DA_APLICACAO, fileName);
		return arquivoSelecionado.exists();
	}

	public static String getNovoNomeArquivo(String nomeOriginalArquivo) {
		String novoNomeArquivo = null;
		String extensao = UtilJava.getExtensaoArquivo(nomeOriginalArquivo);
		novoNomeArquivo = getNomeArquivo() + "." + extensao;
		return novoNomeArquivo;
	}

	private static String getNomeArquivo() {
		String nomeArquivo = null;
		Calendar calendar = Calendar.getInstance();

		nomeArquivo = calendar.get(Calendar.YEAR) + "_" + calendar.get(Calendar.MONTH) + "_" + calendar.get(Calendar.DAY_OF_MONTH) + "_" + calendar.get(Calendar.HOUR) + "_"
				+ calendar.get(Calendar.MINUTE) + "_" + calendar.get(Calendar.SECOND) + "_" + calendar.get(Calendar.MILLISECOND);

		return nomeArquivo;
	}
}
