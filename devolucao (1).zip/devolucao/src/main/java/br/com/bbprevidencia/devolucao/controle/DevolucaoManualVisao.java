package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.CellEditEvent;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.BloqueioParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PerfilInvestimentoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.BloqueioParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.enumerador.MantenedorEnum;
import br.com.bbprevidencia.cadastroweb.enumerador.TipoBloqueioParticipante;
import br.com.bbprevidencia.cadastroweb.exception.RegistroNaoEncontradoException;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.cotas.bo.ValorCotaPlanoBO;
import br.com.bbprevidencia.cotas.dto.ValorCotaPlano;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.CalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoDetalheBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoDetalheImpostoBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraElegibilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.ContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.IndicadorFormaPagamentoContribCarencia;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para o Cálculo das Devoluções de forma manual
 * 
 * @author  BBPF0415 - Yanisley Mora  Ritchie
 * @since 16/05/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("devolucaoManualVisao")
public class DevolucaoManualVisao {

	private static final String FW_DEVOLUCAO_MANUAL_REQUERIMENTO = "/paginas/devolucaoManualRequerimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_DEVOLUCAO_MANUAL_CALCULO = "/paginas/devolucaoManualCálculo.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(DevolucaoManualVisao.class);

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private CalculoDevolucaoBO calculoDevolucao;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBo;

	@Autowired
	private PerfilInvestimentoBO perfilInvestimentoBO;

	@Autowired
	private ValorCotaPlanoBO valorCotaPlanoBO;

	@Autowired
	private RegraDevolucaoBO regraDevolucaoBO;

	@Autowired
	private RegraCalculoDevolucaoBO regraCalculoDevolucaoBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;

	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;

	@Autowired
	private ParcelaContaDevolucaoDetalheBO parcelaContaDevolucaoDetalheBO;

	@Autowired
	private ParcelaContaDevolucaoDetalheImpostoBO parcelaContaDevolucaoDetalheImpostoBO;

	@Autowired
	private RegraElegibilidadeDevolucaoBO regraElegibilidadeDevolucaoBO;

	@Autowired
	private TipoContaDevolucaoBO tipoContaDevolucaoBO;

	@Autowired
	private BloqueioParticipanteBO bloqueioParticipanteBO;

	@Autowired
	private DevolucaoVisao devolucaoVisao;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private EntidadeParticipante entidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private PlanoPrevidencia planoPrevidencia;

	private List<TipoDevolucao> listaTipoDevolucao;

	private TipoDevolucao tipoDevolucao;

	private List<ContaDevolucao> listaContaDevolucao;

	private List<Participante> listaParticipante;

	private Participante participante;

	private List<SelectItem> listaIndicadorFormaPagamentoContribCarencia;

	private String indicadorFormaPagamentoContribCarencia;

	private Integer numTotalParcelas;

	private Date dataRequerimento;

	private Date dataCota;

	private ValorCotaPlano valorCotaPlano;

	private RegraDevolucao regraDevolucao;

	private RegraCalculoDevolucao regraCalculoDevolucao;

	private double percentualOpcao;

	private double valorEmprestimo;

	private boolean possueEmprestimo;

	private Devolucao devolucao;

	private boolean prcMimMaxIgual;

	//Atrbutos de controle de ambiente
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean possuiAcessoTotal;

	/**
	 * Método encarredado por iniciar a página da solicitação de devolução de forma manual
	 * 
	 * @author  BBPF0415 - Yanisley Mora  Ritchie
	 * @since 16/05/2017
	 * @return {@link String}
	 */
	public String iniciarDevolucaoManual() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("requerimentoDevolucaoManual");
		} else {
			this.possuiAcessoTotal = false;
		}

		inicializarAmbiente();
		return FW_DEVOLUCAO_MANUAL_REQUERIMENTO;

	}

	/**
	 * Método reponsável por iniciar todos os valores das variáveis
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/05/2017
	 */
	public void inicializarAmbiente() {
		this.listaIndicadorFormaPagamentoContribCarencia = IndicadorFormaPagamentoContribCarencia.listaElementosEnum();
		this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBo.listarTodosTipoDevolucao());
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.entidadeParticipanteBO.listarEntidadeParticipante());
		this.setIndicadorFormaPagamentoContribCarencia(null);
		this.setEntidadeParticipante(null);
		this.setTipoDevolucao(null);
		this.setValorCotaPlano(null);
		this.setDataRequerimento(null);
		this.setDataCota(null);
		this.setNumTotalParcelas(1);
		this.setParticipante(new Participante());
		this.setPlanoPrevidencia(null);
		this.setRegraCalculoDevolucao(null);
		this.setRegraDevolucao(null);
		this.setPossueEmprestimo(false);
		this.setPercentualOpcao(0D);
		this.setValorEmprestimo(0D);
		this.setPrcMimMaxIgual(false);
		carregarObjetoDevolucao();
		preencherListaContaDevolucaoPadrao();
	}

	private void carregarObjetoDevolucao() {
		this.setDevolucao(new Devolucao());
		this.getDevolucao().setDataCadastro(new Date());
		this.getDevolucao().setIndicadorDevManual("S");
	}

	/**
	 * Método encarregado de Preencher uma lista inicial de contas de devolução;
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/05/2017
	 */
	private void preencherListaContaDevolucaoPadrao() {
		listaContaDevolucao = new ArrayList<ContaDevolucao>();
		List<TipoContaDevolucao> listaTipoContaDEvolucao = new ArrayList<TipoContaDevolucao>(this.tipoContaDevolucaoBO.listarTodos());
		for (TipoContaDevolucao tipoContaDevolucao : listaTipoContaDEvolucao) {
			if (!tipoContaDevolucao.getNomeTipoConta().equalsIgnoreCase("REMANESCENTE")) {
				for (int i = 0; i < 3; i++) {
					ContaDevolucao contaDevolucao;
					if (i == 0) {
						contaDevolucao = new ContaDevolucao(this.devolucao, tipoContaDevolucao, "1", "N");
					} else if (i == 1) {
						contaDevolucao = new ContaDevolucao(this.devolucao, tipoContaDevolucao, "2", "N");
					} else {
						contaDevolucao = new ContaDevolucao(this.devolucao, tipoContaDevolucao, "1", "S");
					}
					listaContaDevolucao.add(contaDevolucao);
				}
			}
		}

	}

	/**
	 * Método para retornar a descrição do indicador do mantenedor
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param indicadorMantenedor
	 * @since 16/05/2017
	 * @return {@link String}
	 */
	public String buscarDescricaoMantenedor(String codigo) {
		return MantenedorEnum.getMantenedorEnum(codigo).getDescricao();
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo digitado no autocomplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link String} 
	 * @since 16/05/2017
	 * @return
	 */
	public List<Participante> listarParticipantes(String nome) {
		if (this.planoPrevidencia != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else if (this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			return new ArrayList<Participante>();
		}
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/05/2017
	 * @param event
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());
		if (this.getEntidadeParticipante() != null && this.getPlanoPrevidencia() != null && this.getParticipante() != null) {
			if (!UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() != null) {
				UtilSession.adicionarObjetoSessao("participante", getParticipante());
				if (this.getParticipante().getListaParticipantePlano().size() > 1) {
					for (ParticipantePlano pP : this.getParticipante().getListaParticipantePlano()) {
						if (pP.getPlanoPrevidencia().equals(this.getPlanoPrevidencia())) {
							this.getDevolucao().setParticipantePlano(pP);
						}
					}
				} else {
					this.getDevolucao().setParticipantePlano(this.getParticipante().getListaParticipantePlano().get(0));
				}
			} else {
				setParticipante(new Participante());
			}
		}
	}

	/**
	 * Método para pesuisar o Valor Cota Plano quando a data é selecionada na UI do Calendar
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/05/2017
	 * @param {@link SelectEvent}
	 */
	public void dataPosicaoCotaSelecionada(SelectEvent event) {
		if (event.getObject() instanceof Date) {
			pesquisarValorCotaPlano((Date) event.getObject());
		} else {
			System.out.println("Chegou outra Coisa");
		}
	}

	/**
	 * Método para pesuisar o Valor Cota Plano quando a data é digitada
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/05/2017
	 * @param {@link AjaxBehaviorEvent}
	 */
	public void dataPosicaoCotaAltecaoManual(AjaxBehaviorEvent event) {
		Date dataManual = (Date) ((UIOutput) event.getSource()).getValue();

		pesquisarValorCotaPlano(dataManual);
	}

	/**
	 * Método para pesquisar Valor Cota Plano
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 16/05/2017
	 * @param {@link Date}
	 */
	private void pesquisarValorCotaPlano(Date dataPosicaoCota) {
		if (this.getEntidadeParticipante() == null) {
			Mensagens.addMsgErro("Favor, selecionar uma patrocinadora.");
		} else if (this.getPlanoPrevidencia() == null) {
			Mensagens.addMsgErro("Favor, selecionar um plano.");
		} else if (this.getParticipante() == null || this.getParticipante().getCodigo() == null) {
			Mensagens.addMsgErro("Favor, selecionar um participante.");
		} else {

			ParticipantePlano participantePlano = new ParticipantePlano();

			participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(this.getParticipante(), this.getPlanoPrevidencia());

			List<PerfilInvestimento> listaPefilIvestimento = new ArrayList<PerfilInvestimento>(perfilInvestimentoBO.listarPerfilInvestimentoPorParticipantePlano(participantePlano));

			for (PerfilInvestimento perfilInvestimento : listaPefilIvestimento) {

				ValorCotaPlano valorCotaPlano = valorCotaPlanoBO.pesquisarCotaPlanoPorEmpresaPlanoPerfil(
						dataPosicaoCota,
						this.getEntidadeParticipante(),
						this.getPlanoPrevidencia(),
						perfilInvestimento);

				if (valorCotaPlano != null) {
					this.valorCotaPlano = valorCotaPlano;
					this.setDataCota(this.valorCotaPlano.getChavePrimaria().getDataPosicaoCota());
					this.getDevolucao().setDataCota(this.valorCotaPlano.getChavePrimaria().getDataPosicaoCota());
					this.getDevolucao().setValorCota(this.valorCotaPlano.getValorCota().doubleValue());
				} else {
					this.valorCotaPlano = null;
				}
			}

		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/05/2017
	 * @param event
	 */
	public void onCellEditContaDevolucao(CellEditEvent event) {
		DataTable dtContasDevolucao = (DataTable) event.getSource();
		String idUpdate = dtContasDevolucao.getClientId(FacesContext.getCurrentInstance()) + ":" + event.getRowIndex() + ":totalCotas";
		PrimeFaces.current().ajax().update(idUpdate);
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/05/2017
	 */
	public void listarPlanosPorPatrocinadora() {
		if (this.entidadeParticipante != null) {
			try {
				this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.entidadeParticipante));
			} catch (RegistroNaoEncontradoException eN) {
				Mensagens.addMsgInfo("Não foram encontrados planos para esta patrocinadora!");
				eN.printStackTrace();
			} catch (Exception e) {
				Mensagens.addMsgErro(e.getMessage());
				e.printStackTrace();
			}
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 17/05/2017
	 */
	public void listarTiposDevolucao() {
		try {
			if (this.planoPrevidencia != null) {
				this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBo.listarTodosTipoDevolucaoPorPlanoPrevidencia(this.planoPrevidencia));
				this.regraDevolucao = this.regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigencia(this.planoPrevidencia, new Date());
			} else {
				this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(this.tipoDevolucaoBo.listarTodosTipoDevolucao());
			}
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception e) {
			Mensagens.addMsgErro(e.getMessage());
		}
	}

	/**
	 * Método encarregado pesquisar a regra de cálculo devolução quanddo for selecionada um tipo de devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 18/05/2017
	 */
	public void pesquisarRegraDevolucao() {
		try {
			if (this.tipoDevolucao != null) {
				if (this.regraDevolucao != null) {
					pesquisarRegraCalculoDevolucao();
				} else {
					if (this.planoPrevidencia != null) {
						this.regraDevolucao = this.regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigencia(this.planoPrevidencia, new Date());
						pesquisarRegraCalculoDevolucao();
					}
				}

				if (this.tipoDevolucao.getMinimoPercentualDevolucao().equals(this.tipoDevolucao.getMaximoPercentualDevolucao())) {
					this.percentualOpcao = this.tipoDevolucao.getMinimoPercentualDevolucao();
					this.setPrcMimMaxIgual(true);
				}
			}
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception e) {
			Mensagens.addMsgErro(e.getMessage());
		}
	}

	/**
	 * Método encarregado pesquisar a regra de cálculo devolução quando exitir a regra de devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 18/05/2017
	 */
	public void pesquisarRegraCalculoDevolucao() {
		for (RegraCalculoDevolucao rCd : this.regraDevolucao.getListaRegraCalculoDevolucao()) {
			if (rCd.getTipoDevolucao().equals(this.tipoDevolucao)) {
				this.regraCalculoDevolucao = rCd;
				this.getDevolucao().setRegraCalculoDevolucao(rCd);
			}
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/05/2017
	 */
	public void atualizarQuantidadeParcelas() {
		this.getDevolucao().setNumeroTotalParcelas(this.numTotalParcelas);
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 19/05/2017
	 */
	public void atualizarIndicadorPagamento() {
		this.getDevolucao().setIndicadorFormaPagtoContribCarencia(this.getIndicadorFormaPagamentoContribCarencia());
	}

	private boolean possuiBloqueiosParticipante() {
		List<BloqueioParticipante> listaBloqueios = this.bloqueioParticipanteBO.pesquisarBloqueioValidasPorParticipanteETipo(
				participante,
				this.tipoDevolucao.isPortabilidade() ? TipoBloqueioParticipante.PORTABILIDADE : TipoBloqueioParticipante.RESGATE);

		if (UtilJava.isColecaoDiferenteDeVazia(listaBloqueios)) {
			String msg = "";
			for (BloqueioParticipante bloqueioParticipante : listaBloqueios) {
				msg += bloqueioParticipante.getDescricaoMotivoBloqueio();
			}
			Mensagens.addMsgErro("Participante possui bloqueio para Devolução.");
			Mensagens.addMsgErro(msg);
			;
			return true;
		}

		return false;
	}

	/**
	 * Método responsável por cálcular o processo de devolução de forma manual
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @return
	 */
	@SuppressWarnings("unused")
	public String calcularDevolcaoManual() {
		try {

			if (possuiBloqueiosParticipante())
				return FW_DEVOLUCAO_MANUAL_REQUERIMENTO;

			this.getDevolucao().setPercentualDevolucao(this.percentualOpcao);
			this.getDevolucao().setIndicadorFormaPagtoContribCarencia(this.getIndicadorFormaPagamentoContribCarencia());
			this.getDevolucao().setDataCadastro(new Date());
			this.getDevolucao().setDataUltimaSituacao(new Date());
			this.getDevolucao().setDataInclusao(new Date());
			this.getDevolucao().setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			this.getDevolucao().setNumeroTotalParcelas(getNumTotalParcelas());

			if (this.dataCota == null) {
				// pesquiso novamente o ValorCotaPlano para a data atual
				pesquisarValorCotaPlano(new Date());
				this.dataCota = this.getValorCotaPlano().getChavePrimaria().getDataPosicaoCota();
				this.getDevolucao().setDataCota(dataCota);
			}

			String opcaoTributacao = this.getDevolucao().getParticipantePlano().getTipoRegimeTributacao().getCodigo();

			DevolucaoCompletoDTO devolucaoCompletoDTO = this.calculoDevolucao.calculoDevolucaoManual(
					this.getDevolucao(),
					this.getListaContaDevolucao(),
					this.getValorEmprestimo(),
					"N",
					opcaoTributacao);

			return this.devolucaoVisao.mostrarResumoDevolucaoManualCalculada(devolucaoCompletoDTO);
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			Mensagens.addMsgErro(ex.getMessage());
		}

		return "S";
	}

	//Getters and Setters
	public CalculoDevolucaoBO getCalculoDevolucao() {
		return calculoDevolucao;
	}

	public void setCalculoDevolucao(CalculoDevolucaoBO calculoDevolucao) {
		this.calculoDevolucao = calculoDevolucao;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public List<ContaDevolucao> getListaContaDevolucao() {
		return listaContaDevolucao;
	}

	public void setListaContaDevolucao(List<ContaDevolucao> listaContaDevolucao) {
		this.listaContaDevolucao = listaContaDevolucao;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public List<SelectItem> getListaIndicadorFormaPagamentoContribCarencia() {
		return listaIndicadorFormaPagamentoContribCarencia;
	}

	public void setListaIndicadorFormaPagamentoContribCarencia(List<SelectItem> listaIndicadorFormaPagamentoContribCarencia) {
		this.listaIndicadorFormaPagamentoContribCarencia = listaIndicadorFormaPagamentoContribCarencia;
	}

	public String getIndicadorFormaPagamentoContribCarencia() {
		return indicadorFormaPagamentoContribCarencia;
	}

	public void setIndicadorFormaPagamentoContribCarencia(String indicadorFormaPagamentoContribCarencia) {
		this.indicadorFormaPagamentoContribCarencia = indicadorFormaPagamentoContribCarencia;
	}

	public Integer getNumTotalParcelas() {
		return numTotalParcelas;
	}

	public void setNumTotalParcelas(Integer numTotalParcelas) {
		this.numTotalParcelas = numTotalParcelas;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public ValorCotaPlano getValorCotaPlano() {
		return valorCotaPlano;
	}

	public void setValorCotaPlano(ValorCotaPlano valorCotaPlano) {
		this.valorCotaPlano = valorCotaPlano;
	}

	public RegraDevolucao getRegraDevolucao() {
		return regraDevolucao;
	}

	public void setRegraDevolucao(RegraDevolucao regraDevolucao) {
		this.regraDevolucao = regraDevolucao;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public double getPercentualOpcao() {
		return percentualOpcao;
	}

	public void setPercentualOpcao(double percentualOpcao) {
		this.percentualOpcao = percentualOpcao;
	}

	public double getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(double valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public boolean isPossueEmprestimo() {
		return possueEmprestimo;
	}

	public void setPossueEmprestimo(boolean possueEmprestimo) {
		this.possueEmprestimo = possueEmprestimo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public boolean isPrcMimMaxIgual() {
		return prcMimMaxIgual;
	}

	public void setPrcMimMaxIgual(boolean prcMimMaxIgual) {
		this.prcMimMaxIgual = prcMimMaxIgual;
	}

}
