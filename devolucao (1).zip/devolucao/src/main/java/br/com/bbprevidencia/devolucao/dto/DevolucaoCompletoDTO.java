package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.SaldoHistoricoFinanceiroPagoDTO;
import br.com.bbprevidencia.cadastroweb.enumerador.MantenedorEnum;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.enumerador.TipoContaDevolucaoEnum;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   17/01/2017
 * Classe de objeto recebendo vários dados de devolução
 * 
 */
public class DevolucaoCompletoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Devolucao devolucao;
	private List<AnotacaoDevolucao> listaAnotacaoDevolucao;
	private List<HistoricoSituacaoDevolucao> listaHistoricoSituacaoDevolucao;
	private List<ContaDevolucao> listaContaDevolucao;
	private List<ParcelaContaDevolucao> listaParcelaContaDevolucao;

	private List<ParcelaContaDevolucaoPagto> listaParcelaContaDevolucaoPagto; // =  parcelaContaDevolucaoPagtoBO.pesquisarParcelaContaDevolucaoPagtoPorParcelaContaDevolucao(parcelaContaDevolucao);

	private List<ParcelaContaDevolucaoDetalhe> listaParcelaContaDevolucaoDetalhe;
	private List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevolucaoDetalheImposto;
	private SaldoHistoricoFinanceiroPagoDTO saldoHistoricoFinanceiroPagoDTO;
	private boolean simulacao;
	private String msgErro;

	private Double saldoAtualParticipante = 0.0;
	private Double saldoAtualIsento = 0.0;

	public static Logger log = Logger.getLogger(DevolucaoCompletoDTO.class);

	public DevolucaoCompletoDTO(String msgErro) {
		super();
		this.msgErro = msgErro;
	}

	public DevolucaoCompletoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public List<AnotacaoDevolucao> getListaAnotacaoDevolucao() {
		return listaAnotacaoDevolucao;
	}

	public void setListaAnotacaoDevolucao(List<AnotacaoDevolucao> listaAnotacaoDevolucao) {
		this.listaAnotacaoDevolucao = listaAnotacaoDevolucao;
	}

	public List<ParcelaContaDevolucaoPagto> getListaParcelaContaDevolucaoPagto() {
		return listaParcelaContaDevolucaoPagto;
	}

	public void setListaParcelaContaDevolucaoPagto(List<ParcelaContaDevolucaoPagto> listaParcelaContaDevolucaoPagto) {
		this.listaParcelaContaDevolucaoPagto = listaParcelaContaDevolucaoPagto;
	}

	public List<ContaDevolucao> getListaContaDevolucao() {
		return listaContaDevolucao;
	}

	public void setListaContaDevolucao(List<ContaDevolucao> listaContaDevolucao) {
		this.listaContaDevolucao = listaContaDevolucao;
	}

	public List<ParcelaContaDevolucao> getListaParcelaContaDevolucao() {
		return listaParcelaContaDevolucao;
	}

	public void setListaParcelaContaDevolucao(List<ParcelaContaDevolucao> listaParcelaContaDevolucao) {
		this.listaParcelaContaDevolucao = listaParcelaContaDevolucao;
	}

	public List<ParcelaContaDevolucaoDetalhe> getListaParcelaContaDevolucaoDetalhe() {
		return listaParcelaContaDevolucaoDetalhe;
	}

	public void setListaParcelaContaDevolucaoDetalhe(List<ParcelaContaDevolucaoDetalhe> listaParcelaContaDevolucaoDetalhe) {
		this.listaParcelaContaDevolucaoDetalhe = listaParcelaContaDevolucaoDetalhe;
	}

	public List<ParcelaContaDevolucaoDetalheImposto> getListaParcelaContaDevolucaoDetalheImposto() {
		return listaParcelaContaDevolucaoDetalheImposto;
	}

	public void setListaParcelaContaDevolucaoDetalheImposto(List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevolucaoDetalheImposto) {
		this.listaParcelaContaDevolucaoDetalheImposto = listaParcelaContaDevolucaoDetalheImposto;
	}

	public List<HistoricoSituacaoDevolucao> getListaHistoricoSituacaoDevolucao() {
		return listaHistoricoSituacaoDevolucao;
	}

	public void setListaHistoricoSituacaoDevolucao(List<HistoricoSituacaoDevolucao> listaHistoricoSituacaoDevolucao) {
		this.listaHistoricoSituacaoDevolucao = listaHistoricoSituacaoDevolucao;
	}

	public boolean isSimulacao() {
		return simulacao;
	}

	public void setSimulacao(boolean simulacao) {
		this.simulacao = simulacao;
	}

	public SaldoHistoricoFinanceiroPagoDTO getSaldoHistoricoFinanceiroPagoDTO() {
		return saldoHistoricoFinanceiroPagoDTO;
	}

	public void setSaldoHistoricoFinanceiroPagoDTO(SaldoHistoricoFinanceiroPagoDTO saldoHistoricoFinanceiroPagoDTO) {
		this.saldoHistoricoFinanceiroPagoDTO = saldoHistoricoFinanceiroPagoDTO;
	}

	//Quantidade de cotas resgatável
	public Double getQuantidadeCotasTotalResgatavel() throws PrevidenciaException {

		Double valor = 0D;

		for (ParcelaContaDevolucao parcelaContaDevolucao : this.listaParcelaContaDevolucao) {
			valor = valor + parcelaContaDevolucao.getQtdCotaParcela();
		}

		return valor;

	}

	//Valor resgatável
	public Double getValorTotalResgatavel() {

		Double valor = 0D;

		valor = this.getQuantidadeCotasContaResgatavel() * this.getDevolucao().getValorIndiceAjustado();

		return UtilJava.arredondaNumero(valor, 2);

	}

	public Double getQuantidadeCotasContaResgatavel() {

		Double valor = 0D;

		valor = getQuantidadeCotasContaResgatavelParticipante() + getQuantidadeCotasContaResgatavelPatrocinadora();

		return valor;
	}

	public Double getPercenutalResgatel() {

		Double valorPercentual = 0D;
		Double valorResgatavel = 0D;
		Double valorTotal = 0D;

		valorResgatavel = getValorContaResgatavelParticipante() + getValorContaResgatavelPatrocinadora();
		valorTotal = getValorTotalParticipante() + getValorTotalPatrocinadora();

		if (valorTotal > 0) {
			valorPercentual = valorResgatavel / valorTotal * 100;
		}

		return UtilJava.arredondaNumero(valorPercentual, 2);

	}

	//Participante
	public Double getQuantidadeCotasContaResgatavelParticipante() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.RESGATAVEL.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PARTICIPANTE.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;
	}

	public Double getQuantidadeCotasContaRemanescenteParticipante() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.REMANESCENTE.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PARTICIPANTE.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;
	}

	public Double getQuantidadeCotasContaReversaoParticipante() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.REVERSAO.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PARTICIPANTE.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;
	}

	public Double getQuantidadeCotasContaNaoResgatavelParticipante() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.NAO_RESGATAVEL.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PARTICIPANTE.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;

	}

	public Double getQuantidadeCotasResgatavelParticipante() {

		Double valor = 0D;

		valor = getQuantidadeCotasContaResgatavelParticipante() + getQuantidadeCotasContaRemanescenteParticipante();

		return valor;
	}

	public Double getQuantidadeCotasNaoResgatavelParticipante() {

		Double valor = 0D;

		valor = getQuantidadeCotasContaReversaoParticipante() + getQuantidadeCotasContaNaoResgatavelParticipante();

		return valor;
	}

	public Double getQuantidadeCotasTotalParticipante() {

		Double valor = 0D;

		valor = getQuantidadeCotasResgatavelParticipante() + getQuantidadeCotasNaoResgatavelParticipante();

		return valor;
	}

	public Double getValorContaResgatavelParticipante() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaResgatavelParticipante() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorContaRemanescenteParticipante() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaRemanescenteParticipante() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorContaReversaoParticipante() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaReversaoParticipante() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorContaNaoResgatavelParticipante() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaNaoResgatavelParticipante() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorResgatavelParticipante() {

		Double valor = 0D;

		valor = getQuantidadeCotasResgatavelParticipante() * this.devolucao.getValorIndiceAjustado();

		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorNaoResgatavelParticipante() {

		Double valor = 0D;

		valor = getQuantidadeCotasNaoResgatavelParticipante() * this.devolucao.getValorIndiceAjustado();

		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorTotalParticipante() {

		Double valor = 0D;

		valor = getQuantidadeCotasTotalParticipante() * this.devolucao.getValorIndiceAjustado();

		return UtilJava.arredondaNumero(valor, 2);

	}

	public Double getPercentualResgateParticipante() {

		Double valorPercentual = 0D;
		Double valorResgatavel = 0D;
		Double valorTotal = 0D;

		valorResgatavel = getValorContaResgatavelParticipante();
		valorTotal = getValorTotalParticipante();

		if (valorTotal > 0) {
			valorPercentual = valorResgatavel / valorTotal * 100;
		}

		return UtilJava.arredondaNumero(valorPercentual, 2);
	}

	public Double getPercentualRemanescenteParticipante() {
		Double valorPercentual = 0D;
		Double valorRemanescente = 0D;
		Double valorTotal = 0D;

		valorRemanescente = getValorContaRemanescenteParticipante();
		valorTotal = getValorTotalParticipante();

		if (valorTotal > 0) {
			valorPercentual = valorRemanescente / valorTotal * 100;
		}

		return UtilJava.arredondaNumero(valorPercentual, 2);
	}

	//Partrocinadora
	public Double getQuantidadeCotasContaResgatavelPatrocinadora() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.RESGATAVEL.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PATROCINADORA.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;
	}

	public Double getQuantidadeCotasContaRemanescentePatrocinadora() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.REMANESCENTE.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PATROCINADORA.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;
	}

	public Double getQuantidadeCotasContaReversaoPatrocinadora() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.REVERSAO.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PATROCINADORA.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;
	}

	public Double getQuantidadeCotasContaNaoResgatavelPatrocinadora() {

		Double valor = 0D;

		for (ContaDevolucao contaDevolucao : this.listaContaDevolucao) {

			if (contaDevolucao.getTipoContaDevolucao().getCodigo().equals(TipoContaDevolucaoEnum.NAO_RESGATAVEL.getCodigo())) {

				if (contaDevolucao.getIndicadorMantenedor().equals(MantenedorEnum.PATROCINADORA.getCodigo()))

					valor = valor + contaDevolucao.getQtdTotalCotasContribuicao() + contaDevolucao.getQtdTotalCotasCorrecao() + contaDevolucao.getQtdTotalCotasJuros()
							+ contaDevolucao.getQtdTotalCotasMulta();
			}
		}
		return valor;

	}

	public Double getQuantidadeCotasResgatavelPatrocinadora() {

		Double valor = 0D;

		valor = getQuantidadeCotasContaResgatavelPatrocinadora() + getQuantidadeCotasContaRemanescentePatrocinadora();

		return valor;
	}

	public Double getQuantidadeCotasNaoResgatavelPatrocinadora() {

		Double valor = 0D;

		valor = getQuantidadeCotasContaReversaoPatrocinadora() + getQuantidadeCotasContaNaoResgatavelPatrocinadora();

		return valor;
	}

	public Double getQuantidadeCotasTotalPatrocinadora() {

		Double valor = 0D;

		valor = getQuantidadeCotasResgatavelPatrocinadora() + getQuantidadeCotasNaoResgatavelPatrocinadora();

		return valor;
	}

	public Double getValorContaResgatavelPatrocinadora() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaResgatavelPatrocinadora() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);

	}

	public Double getValorContaRemanescentePatrocinadora() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaRemanescentePatrocinadora() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorContaReversaoPatrocinadora() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaReversaoPatrocinadora() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorContaNaoResgatavelPatrocinadora() {

		Double valor = 0D;
		valor = getQuantidadeCotasContaNaoResgatavelPatrocinadora() * this.getDevolucao().getValorIndiceAjustado();
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorResgatavelPatrocinadora() {

		Double valor = 0D;

		valor = getQuantidadeCotasResgatavelPatrocinadora() * this.devolucao.getValorIndiceAjustado();

		return UtilJava.arredondaNumero(valor, 2);

	}

	public Double getValorNaoResgatavelPatrocinadora() {

		Double valor = 0D;

		valor = getQuantidadeCotasNaoResgatavelPatrocinadora() * this.devolucao.getValorIndiceAjustado();

		return UtilJava.arredondaNumero(valor, 2);

	}

	public Double getValorTotalPatrocinadora() {

		Double valor = 0D;

		valor = getQuantidadeCotasTotalPatrocinadora() * this.devolucao.getValorIndiceAjustado();

		return UtilJava.arredondaNumero(valor, 2);

	}

	public Double getPercentualResgatePatrocionadora() {

		Double valorPercentual = 0D;
		Double valorResgatavel = 0D;
		Double valorTotal = 0D;

		valorResgatavel = getValorContaResgatavelPatrocinadora();
		valorTotal = getValorTotalPatrocinadora();

		if (valorTotal > 0) {
			valorPercentual = valorResgatavel / valorTotal * 100;
		}

		return UtilJava.arredondaNumero(valorPercentual, 2);
	}

	public Double getPercentualRemanescentePatrocionadora() {

		Double valorPercentual = 0D;
		Double valorRemanescente = 0D;
		Double valorTotal = 0D;

		valorRemanescente = getValorContaRemanescentePatrocinadora();
		valorTotal = getValorTotalPatrocinadora();

		if (valorTotal > 0) {
			valorPercentual = valorRemanescente / valorTotal * 100;
		}

		return UtilJava.arredondaNumero(valorPercentual, 2);
	}

	public Double getValorImposto() {

		Double valor = 0D;

		for (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto : this.listaParcelaContaDevolucaoDetalheImposto) {

			if (parcelaContaDevolucaoDetalheImposto.getCronogramaDevolucao() == null
					&& parcelaContaDevolucaoDetalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().getTipoContaDevolucao().getCodigo().equals(
							TipoContaDevolucaoEnum.RESGATAVEL.getCodigo())) {
				valor += parcelaContaDevolucaoDetalheImposto.getValorIrrf();
			}
		}

		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getValorImpostoTotal() {

		Double valor = 0D;
		for (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto : this.listaParcelaContaDevolucaoDetalheImposto) {

			if (parcelaContaDevolucaoDetalheImposto.getCronogramaDevolucao() == null
					&& (parcelaContaDevolucaoDetalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().getTipoContaDevolucao().getCodigo().equals(
							TipoContaDevolucaoEnum.RESGATAVEL.getCodigo()) || parcelaContaDevolucaoDetalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().getTipoContaDevolucao()
							.getCodigo().equals(TipoContaDevolucaoEnum.REMANESCENTE.getCodigo()))) {
				valor += parcelaContaDevolucaoDetalheImposto.getValorIrrf();
			}
		}
		return UtilJava.arredondaNumero(valor, 2);
	}

	public Double getPercentualImposto() {

		Double valorPercentual = 0D;
		Double valorImposto = 0D;
		Double valorResgatavel = 0D;

		valorImposto = getValorImposto();
		valorResgatavel = getValorTotalResgatavel();

		if (valorResgatavel > 0) {
			valorPercentual = valorImposto / valorResgatavel * 100;
		}

		return UtilJava.arredondaNumero(valorPercentual, 2);
	}

	public String getMsgErro() {
		return msgErro;
	}

	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}

	public boolean isCalculoComErro() {
		return this.msgErro != null && !this.msgErro.isEmpty();
	}

	@Override
	public String toString() {
		return "DevolucaoCompletoDTO [devolucao=" + devolucao + ", listaAnotacaoDevolucao=" + listaAnotacaoDevolucao + ", listaHistoricoSituacaoDevolucao=" + listaHistoricoSituacaoDevolucao
				+ ", listaContaDevolucao=" + listaContaDevolucao + ", listaParcelaContaDevolucao=" + listaParcelaContaDevolucao + ", listaParcelaContaDevolucaoDetalhe="
				+ listaParcelaContaDevolucaoDetalhe + ", listaParcelaContaDevolucaoDetalheImposto=" + listaParcelaContaDevolucaoDetalheImposto + ", saldoHistoricoFinanceiroPagoDTO="
				+ saldoHistoricoFinanceiroPagoDTO + ", simulacao=" + simulacao + "]";
	}

	public DevolucaoCompletoDTO compararTotalDevolucao(DevolucaoCompletoDTO devolucaoCompletoDTOComparativa) {
		// TODO Auto-generated method stub
		
		List<AnotacaoDevolucao> listaAnotacao = new ArrayList<>();
		AnotacaoDevolucao anotacao1 = new AnotacaoDevolucao();
		AnotacaoDevolucao anotacao2 = new AnotacaoDevolucao();
		AnotacaoDevolucao anotacao3 = new AnotacaoDevolucao();
		boolean atual = true;
		
		if ( this.getValorTotalResgatavel() > devolucaoCompletoDTOComparativa.getValorTotalResgatavel() ){
			atual = true;
			
			anotacao1 = new AnotacaoDevolucao(this.devolucao, new java.util.Date(), "Valor do cálculo nova Regra: " + devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" maior que Regra Anterior: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo(), new java.util.Date(), 
					!this.simulacao ? "admin" : UtilSession.getUsuarioSessao().getDescricaoLogin());

			anotacao2 = new AnotacaoDevolucao(this.devolucao, new java.util.Date(), "Valor Regra: " + this.devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução " + this.getValorTotalResgatavel(), new java.util.Date(), !this.simulacao ? "admin" : UtilSession.getUsuarioSessao().getDescricaoLogin());

			
			anotacao3 = new AnotacaoDevolucao(this.devolucao, new java.util.Date(), "Valor Regra: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução: " + devolucaoCompletoDTOComparativa.getValorTotalResgatavel(), new java.util.Date(), !this.simulacao ? "admin" : UtilSession.getUsuarioSessao().getDescricaoLogin());
			
		}else{
			atual = false;

			anotacao1 = new AnotacaoDevolucao(devolucaoCompletoDTOComparativa.getDevolucao(), new java.util.Date(), "Valor do cálculo Regra Anterior: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" maior que Regra Nova: " + this.devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo(), new java.util.Date(), !this.simulacao ? "admin" : UtilSession.getUsuarioSessao().getDescricaoLogin());

			anotacao2 = new AnotacaoDevolucao(devolucaoCompletoDTOComparativa.getDevolucao(), new java.util.Date(), "Valor Regra: " + this.devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução " + this.getValorTotalResgatavel(), new java.util.Date(), !this.simulacao ? "admin" : UtilSession.getUsuarioSessao().getDescricaoLogin());

			
			anotacao3 = new AnotacaoDevolucao(devolucaoCompletoDTOComparativa.getDevolucao(), new java.util.Date(), "Valor Regra: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução: " + devolucaoCompletoDTOComparativa.getValorTotalResgatavel(), new java.util.Date(), !this.simulacao ? "admin" : UtilSession.getUsuarioSessao().getDescricaoLogin());


		}
		
		listaAnotacao.add(anotacao1);
		listaAnotacao.add(anotacao2);
		listaAnotacao.add(anotacao3);
		
		if (atual){
			this.getListaAnotacaoDevolucao().addAll(listaAnotacao);
			return this;
		}else{
			devolucaoCompletoDTOComparativa.getListaAnotacaoDevolucao().addAll(listaAnotacao);
			return devolucaoCompletoDTOComparativa;
		}
		
	}

	public DevolucaoCompletoDTO compararTotalDevolucaoPortal(DevolucaoCompletoDTO devolucaoCompletoDTOComparativa, String descricaoLogin) {
		// TODO Auto-generated method stub

		List<AnotacaoDevolucao> listaAnotacao = new ArrayList<>();
		AnotacaoDevolucao anotacao1 = new AnotacaoDevolucao();
		AnotacaoDevolucao anotacao2 = new AnotacaoDevolucao();
		AnotacaoDevolucao anotacao3 = new AnotacaoDevolucao();
		boolean atual = true;

		if ( this.getValorTotalResgatavel() > devolucaoCompletoDTOComparativa.getValorTotalResgatavel() ){
			atual = true;

			anotacao1 = new AnotacaoDevolucao(this.devolucao, new java.util.Date(), "Valor do cálculo nova Regra: " + devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" maior que Regra Anterior: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo(), new java.util.Date(),
					"admin" );

			anotacao2 = new AnotacaoDevolucao(this.devolucao, new java.util.Date(), "Valor Regra: " + this.devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução " + this.getValorTotalResgatavel(), new java.util.Date(), "admin");

			anotacao3 = new AnotacaoDevolucao(this.devolucao, new java.util.Date(), "Valor Regra: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução: " + devolucaoCompletoDTOComparativa.getValorTotalResgatavel(), new java.util.Date(),  "admin" );

		}else{
			atual = false;
			anotacao1 = new AnotacaoDevolucao(devolucaoCompletoDTOComparativa.getDevolucao(), new java.util.Date(), "Valor do cálculo Regra Anterior: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" maior que Regra Nova: " + this.devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo(), new java.util.Date(), "admin" );

			anotacao2 = new AnotacaoDevolucao(devolucaoCompletoDTOComparativa.getDevolucao(), new java.util.Date(), "Valor Regra: " + this.devolucao.getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução " + this.getValorTotalResgatavel(), new java.util.Date(), "admin" );

			anotacao3 = new AnotacaoDevolucao(devolucaoCompletoDTOComparativa.getDevolucao(), new java.util.Date(), "Valor Regra: " + devolucaoCompletoDTOComparativa.getDevolucao().getRegraCalculoDevolucao().getRegraDevolucao().getCodigo() +
					" Total Devolução: " + devolucaoCompletoDTOComparativa.getValorTotalResgatavel(), new java.util.Date(),"admin");

		}
		listaAnotacao.add(anotacao1);
		listaAnotacao.add(anotacao2);
		listaAnotacao.add(anotacao3);

		if (atual){
			this.getListaAnotacaoDevolucao().addAll(listaAnotacao);
			return this;
		}else{
			devolucaoCompletoDTOComparativa.getListaAnotacaoDevolucao().addAll(listaAnotacao);
			return devolucaoCompletoDTOComparativa;
		}
	}

	public Double getSaldoAtualParticipante() {
		return saldoAtualParticipante;
	}

	public void setSaldoAtualParticipante(Double saldoAtualParticipante) {
		this.saldoAtualParticipante = saldoAtualParticipante;
	}

	public Double getSaldoAtualIsento() {
		return saldoAtualIsento;
	}

	public void setSaldoAtualIsento(Double saldoAtualIsento) {
		this.saldoAtualIsento = saldoAtualIsento;
	}
}