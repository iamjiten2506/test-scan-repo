package br.com.bbprevidencia.devolucao.controle;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.io.BufferedReader;
import java.io.IOException; //import java.net.http.HttpClient;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.Normalizer;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import br.com.bbprevidencia.devolucao.dao.ParticipantePortalDAO;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;
import org.jfree.util.Log;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import br.bb.previdencia.seguranca.criptografia.Criptografia;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.beneficio.bo.ConcessaoBeneficioBO;
import br.com.bbprevidencia.beneficio.dto.BeneficioVerificadoDTO;
import br.com.bbprevidencia.cadastroweb.bo.BancoBO;
import br.com.bbprevidencia.cadastroweb.bo.HistoricoFinanceiroPagoBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.UsuarioBO;
import br.com.bbprevidencia.cadastroweb.context.AppContext;
import br.com.bbprevidencia.cadastroweb.dao.ParticipanteDAO;
import br.com.bbprevidencia.cadastroweb.dto.BancoDTO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipanteDevolucaoPosicionadaDTO;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.Usuario;
import br.com.bbprevidencia.cadastroweb.exception.EmailException;
import br.com.bbprevidencia.cadastroweb.servico.EmailServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.cotas.bo.ValorCotaPlanoBO;
import br.com.bbprevidencia.cotas.dto.ValorCotaPlano;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.CalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DetalhePortabilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoItemBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MensagemLoteProcessamentoRefCalcDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.PlanoVigenciaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ReferenciaCalculoDevPosicionadoValoresBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraElegibilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RelatorioComprovanteRendimentoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dao.DetalhePortabilidadeDevolucaoDAO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.ComprovanteRendimentosJasperDTO;
import br.com.bbprevidencia.devolucao.dto.DadosPlanoResgatePortabilidadeDTO;
import br.com.bbprevidencia.devolucao.dto.DetalhePortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.devolucao.dto.DevolucaoInstituidoResponse;
import br.com.bbprevidencia.devolucao.dto.DevolucaoIntegracaoDTO;
import br.com.bbprevidencia.devolucao.dto.ElegibilidadeDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.EntidadeDTO;
import br.com.bbprevidencia.devolucao.dto.ExtratoPrevRequestDTO;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.InserirDevolucaoRequestDTO;
import br.com.bbprevidencia.devolucao.dto.InserirDevolucaoResponseDTO;
import br.com.bbprevidencia.devolucao.dto.LoteProcessamentoReferenciaCalcDevolucao;
import br.com.bbprevidencia.devolucao.dto.MensagemLoteProcessamentoRefCalcDevolucao;
import br.com.bbprevidencia.devolucao.dto.PlanoVigenciaDevolucao;
import br.com.bbprevidencia.devolucao.dto.RecebedorConsultaDTO;
import br.com.bbprevidencia.devolucao.dto.ReferenciaCalculoDevPosicionadoValores;
import br.com.bbprevidencia.devolucao.dto.ReferenciaCalculoDevolucaoPosicionado;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoRequestDTO;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraElegibilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioHistoricoPagamentosFichaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioSimulacaoResgateDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioSimulacaoResgatePortabilidadeDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoCalculoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoElegibilidadeDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoInformacaoExtratoDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoTemposCalculadosRegraDTO;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucaoRequestDTO;
import br.com.bbprevidencia.devolucao.dto.SumulaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.TemposCalculadosRegraDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoPlanoDestinoPortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.request.CalcularProcessoDevolucaoRequest;
import br.com.bbprevidencia.devolucao.dto.response.CalcularProcessoDevolucaoResponse;
import br.com.bbprevidencia.devolucao.dto.response.ValorEmprestimoResponse;
import br.com.bbprevidencia.devolucao.enumerador.BloqueioInformeRedimentoEnum;
import br.com.bbprevidencia.devolucao.execucao.ExecutionSummary;
import br.com.bbprevidencia.devolucao.execucao.TransactionParticipanteCalculo;
import br.com.bbprevidencia.devolucao.util.AsyncForm;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.folha.bo.LoteProcessamentoDirfBO;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoaPK;

/**
 * Classe controller que manipula as requisições de cálculo de devolução somente para WebService
 *
 * @author BBPF0333 - Daniel Martins
 * @since  01/08/2017
 *
 */
@Controller
@EnableWebMvc
public class CalculoDevolucaoWs {

	public static Logger log = Logger.getLogger(CalculoDevolucaoWs.class);
	private static final long VALOR_ZERO_LONG = 0L;
	private final int TOTAL_THEARD = 200;

	@Autowired
	private CalculoDevolucaoBO calculoDevolucao;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private ValorCotaPlanoBO valorCotaPlanoBO;

	@Autowired
	private UsuarioBO usuarioBO;

	@Autowired
	private RegraCalculoDevolucaoBO regraCalculoDevolucaoBO;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private RegraElegibilidadeDevolucaoBO regraElegibilidadeDevolucaoBO;

	@Autowired
	private HistoricoFinanceiroPagoBO historicoFinanceiroPagoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private ServletContext context;

	@Autowired
	private ReferenciaCalculoDevPosicionadoValoresBO referenciaCalculoDevPosicionadoValoresBO;

	@Autowired
	private BancoBO bancoBO;

	@Autowired
	private EmailServico emailServico;

	@Autowired
	private MensagemLoteProcessamentoRefCalcDevolucaoBO mensagemLoteProcessamentoRefCalcDevolucaoBO;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	@Autowired
	private ConcessaoBeneficioBO concessaoBeneficioBO;

	@Autowired
	private LoteProcessamentoDirfBO loteProcessamentoFirfBO;
	@Autowired
	private RelatorioComprovanteRendimentoBO relatorioComprovanteRendimentoBO;
	@Autowired
	private DocumentoDevolucaoVisaoItemBO documentoDevolucaoVisaoItemBO;
	@Autowired
	private DetalhePortabilidadeDevolucaoBO detalhePortabilidadeDevolucaoBO;
	private LoginBBPrevWebDTO loginBBPrevWebDTO;
	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;
	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;
	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;
	@Autowired
	DetalhePortabilidadeDevolucaoDAO detalhePortabilidadeDevolucaoDAO;
	@Autowired
	ParticipanteDAO participanteDAO;
	@Autowired
	ResgateValoresEmprestimoVisao resgateValoresEmprestimoVisao;
	@Autowired
	PlanoVigenciaDevolucaoBO planoVigenciaDevolucaoBO;
	@Autowired
	RegraDevolucaoBO regraDevolucaoBO;

	@Autowired
	private ParticipantePortalDAO participantePortalDAO;

	@RequestMapping(method = RequestMethod.POST, value = "/calcularProcessoDevolucao", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SumulaDevolucaoDTO> calcularProcessoDevolucao(@RequestBody CalcularProcessoDevolucaoRequest calcularProcessoDevolucaoRequest) throws Exception {

		System.out.println("[start] CalculoDevolucaoWs - calcularProcessoDevolucao");
		List<DetalhePortabilidadeDevolucao> detalhePortabilidadeDevolucaoPortal = new ArrayList<>();

		CalcularProcessoDevolucaoResponse response = new CalcularProcessoDevolucaoResponse();
		DevolucaoVisao devolucaoVisao = new DevolucaoVisao();
		DevolucaoCompletoDTO devolucaoCalculoCompleto = new DevolucaoCompletoDTO();

		Gson gsonCalcularProcessoDevolucao = new GsonBuilder().create();

		String dataCota = UtilJava.formataDataPorPadrao(calcularProcessoDevolucaoRequest.getDataPosicaoCota(), "dd/MM/yyyy");
		String dataRequerimento = UtilJava.formataDataPorPadrao(calcularProcessoDevolucaoRequest.getDataRequerimento(), "dd/MM/yyyy");

		devolucaoCalculoCompleto = calculoDevolucao.calcularDevolucaoPortal(
				calcularProcessoDevolucaoRequest.getCodigoParticipantePlano(),
				calcularProcessoDevolucaoRequest.getCodigoParticipante(),
				calcularProcessoDevolucaoRequest.getCodigoPlanoPrevidencia(),
				calcularProcessoDevolucaoRequest.getCodigoTipoDevolucao(),
				calcularProcessoDevolucaoRequest.getDataRequerimento(),
				"R",
				"N",
				calcularProcessoDevolucaoRequest.getNumTotalparcelas(),
				calcularProcessoDevolucaoRequest.getDataPosicaoCota(),
				calcularProcessoDevolucaoRequest.getIndicadorFormaPamamentoContribCarencia(),
//				"7lVtRpitgIjhJtodRgA8zg",
				Criptografia.criptografar(String.valueOf(calcularProcessoDevolucaoRequest.getCodResponsavel())),
				calcularProcessoDevolucaoRequest.getPercentualOpcao(),
				calcularProcessoDevolucaoRequest.getValorEmprestimo(),
				calcularProcessoDevolucaoRequest.getInstituido(),
				calcularProcessoDevolucaoRequest.getTipoTributacao());

		devolucaoCalculoCompleto.setSimulacao(false);
		try {
			calculoDevolucao.salvarDevolucaoPortal(devolucaoCalculoCompleto);

			if (devolucaoCalculoCompleto.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().isPortabilidade()) {
				AtuacaoPessoaPK chavePrimariaAP = new AtuacaoPessoaPK();
				chavePrimariaAP.setCodigo(calcularProcessoDevolucaoRequest.isPortabilidadePenseFuturo() ? 1246L : calcularProcessoDevolucaoRequest.getDetalhePortabilidade()
						.getCodigoPessoaEntidadeDestino());
				chavePrimariaAP.setCodigoAreaAtuacao("7");

				AtuacaoPessoa atuacaoPessoa = new AtuacaoPessoa();
				atuacaoPessoa.setChavePrimaria(chavePrimariaAP);

				TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidade = new TipoPlanoDestinoPortabilidadeDevolucao();
				tipoPlanoDestinoPortabilidade.setCodigo(calcularProcessoDevolucaoRequest.isPortabilidadePenseFuturo() ? 1L : calcularProcessoDevolucaoRequest.getDetalhePortabilidade()
						.getTipoPlanoDestinoPortabilidade());

				DetalhePortabilidadeDevolucao detalhePortabilidadeDevolucao = new DetalhePortabilidadeDevolucao();
				detalhePortabilidadeDevolucao.setDevolucao(devolucaoCalculoCompleto.getDevolucao());
				detalhePortabilidadeDevolucao.setAtuacaoPessoa(atuacaoPessoa);
				detalhePortabilidadeDevolucao.setTipoPlanoDestinoPortabilidadeDevolucao(tipoPlanoDestinoPortabilidade);
				detalhePortabilidadeDevolucao.setNomePlanoDestino(calcularProcessoDevolucaoRequest.isPortabilidadePenseFuturo() ? "PLANO PENSE FUTURO" : calcularProcessoDevolucaoRequest
						.getDetalhePortabilidade().getNomePlanoDestino());
				detalhePortabilidadeDevolucao.setCodigoParticEntidadeDestino(calcularProcessoDevolucaoRequest.getDetalhePortabilidade().getCodigoParticipanteEntidadeDestino());
				detalhePortabilidadeDevolucao.setCodigoPlanoEntidadeDestino(calcularProcessoDevolucaoRequest.isPortabilidadePenseFuturo() ? "2019000865" : calcularProcessoDevolucaoRequest
						.getDetalhePortabilidade().getCodigoPlanoEntidadeDestino());
				detalhePortabilidadeDevolucao.setDataAdesaoPlanoDestino(calcularProcessoDevolucaoRequest.getDetalhePortabilidade().getDataAdesaoPlanoDestino());
				detalhePortabilidadeDevolucao.setIndicadorOpcaoImpostoRendaDestino(calcularProcessoDevolucaoRequest.getTipoTributacao());
				detalhePortabilidadeDevolucao.setDataAprovPlanoOrigemOrgaoRegulador(calcularProcessoDevolucaoRequest.getDetalhePortabilidade().getDataAprovPlanoOrigemOrgaoRegulador());
				detalhePortabilidadeDevolucao.setCodigoAprovPlanoOrigemOrgaoRegulador(calcularProcessoDevolucaoRequest.getDetalhePortabilidade().getCodigoAprovPlanoOrigemOrgaoRegulador());

				if (calcularProcessoDevolucaoRequest.isPortabilidadePenseFuturo()) {
					PlanoPrevidencia plano = new PlanoPrevidencia();
					plano.setCodigo(135L);
					detalhePortabilidadeDevolucao.setPlanoPrevidencia(plano);
				}

				this.detalhePortabilidadeDevolucaoBO.salvarDetalhePortabilidadeDevolucaoPortal(detalhePortabilidadeDevolucao);
				detalhePortabilidadeDevolucaoPortal = detalhePortabilidadeDevolucaoBO.pesquisarDetalhePortabilidadeDevolucaoPorDevolucaoPortal(devolucaoCalculoCompleto.getDevolucao());
			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		String urlFichaFinanceiraBase64 = devolucaoVisao.relatorioProcessoFichaFinanceira(calcularProcessoDevolucaoRequest, devolucaoCalculoCompleto);

		response.setFichaFinanceiraBase64(urlFichaFinanceiraBase64);
		String calcularProcessoDevolucaoJson = gsonCalcularProcessoDevolucao.toJson(response, CalcularProcessoDevolucaoResponse.class);

		//*******GERAR SUMULA
		//=========================================================================
		SumulaDevolucaoDTO sumulaDevolucao = new SumulaDevolucaoDTO();
		try {
//			response.setSumulaFinanceiraBase64(devolucaoVisao.mostrarRelatorioSumulaPortal(devolucaoCalculoCompleto, devolucaoCalculoCompleto.getDevolucao(), calcularProcessoDevolucaoRequest));
			sumulaDevolucao = devolucaoVisao.mostrarRelatorioSumulaPortal(
					devolucaoCalculoCompleto,
					devolucaoCalculoCompleto.getDevolucao(),
					calcularProcessoDevolucaoRequest,
					detalhePortabilidadeDevolucaoPortal);

			sumulaDevolucao.setFichaFinanceiraBase64(urlFichaFinanceiraBase64);
		} catch (Exception e) {
			System.out.println("Erro ao montar sumula: " + e.getMessage());
		}

		sumulaDevolucao.setProtocolo(devolucaoCalculoCompleto.getDevolucao().getCodigo());

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);
		responseHeaders.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));

		response.setProtocoloCalculo(devolucaoCalculoCompleto.getDevolucao().getCodigo());
		return new ResponseEntity<SumulaDevolucaoDTO>(sumulaDevolucao, responseHeaders, HttpStatus.OK);
	}

	@RequestMapping(value = "/buscaValorEmprestimo/{codigoParticipante}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ValorEmprestimoResponse> retornaValorEmprestimo(@PathVariable Long codigoParticipante) {
		log.info("[start] CalculoDevolucaoWs - retornaValorEmprestimo");
		ValorEmprestimoResponse valorEmprestimoResponse = new ValorEmprestimoResponse();
		Participante participante = new Participante();
		participante = participanteDAO.consultarPorCodigo(codigoParticipante);

		valorEmprestimoResponse = resgateValoresEmprestimoVisao.buscarValorEmprestimo(participante, new Date());

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);
		responseHeaders.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
		log.info("[finish] CalculoDevolucaoWs - retornaValorEmprestimo");
		return new ResponseEntity<ValorEmprestimoResponse>(valorEmprestimoResponse, responseHeaders, HttpStatus.OK);
	}

	@PostMapping("/calcularDevolucaoInstituidos")
	public ResponseEntity<String> calcularDevolucaoInstituido(HttpServletRequest request) throws IOException {
		DevolucaoCompletoDTO devolucaoCalculoCompleto = new DevolucaoCompletoDTO();

		BufferedReader reader = request.getReader();
		Gson gsonDevolucaoInstituido = new GsonBuilder().create();
		DevolucaoIntegracaoDTO devolucaoPosicionadoDTO = this.extrairDadosDevolucao(reader);

		ParticipantePlano participantePlano = participantePlanoBO.consultarPorCodigoPlanoCodigoParticipante(Long.parseLong(devolucaoPosicionadoDTO.getCodigoPn()), Long
				.parseLong(devolucaoPosicionadoDTO.getCodigoPt()));

		String opcaoTributacao = participantePortalDAO.consultarPorCodigoPlanoCodigoParticipante(Long.parseLong(devolucaoPosicionadoDTO.getCodigoPn()), Long.parseLong(devolucaoPosicionadoDTO
				.getCodigoPt()));

		devolucaoCalculoCompleto = calculoDevolucao.calcularDevolucao(Long.parseLong(devolucaoPosicionadoDTO.getCodigoPt()), Long.parseLong(devolucaoPosicionadoDTO.getCodigoPn()), Long
				.parseLong(devolucaoPosicionadoDTO.getCodigoTDev()), devolucaoPosicionadoDTO.getDataReq(), null, //devolucaoPosicionadoDTO.getCodigoTDev(),
				"S", //devolucaoPosicionadoDTO.getSimulacao(),
				Integer.parseInt(devolucaoPosicionadoDTO.getQtdParcela()),
				devolucaoPosicionadoDTO.getDataCota(),
				devolucaoPosicionadoDTO.getIndFormaPagRem(),
				devolucaoPosicionadoDTO.getCodigoUsuario(),
				devolucaoPosicionadoDTO.getPercentualResgate(),
				0D,
				opcaoTributacao);

		DevolucaoInstituidoResponse devolucaoInstituido = new DevolucaoInstituidoResponse();
		devolucaoInstituido.setValorBrutoDevolucao(devolucaoCalculoCompleto.getValorTotalParticipante());
		devolucaoInstituido.setPercentualImposto(devolucaoCalculoCompleto.getPercentualImposto());
		devolucaoInstituido.setValorImposto(devolucaoCalculoCompleto.getValorImposto());
		devolucaoInstituido.setValorLiquidoDevolucao(devolucaoCalculoCompleto.getValorTotalParticipante() - devolucaoCalculoCompleto.getValorImposto());

		devolucaoInstituido.setValorTotalParticipante(devolucaoCalculoCompleto.getValorTotalParticipante());
		devolucaoInstituido.setValorTotalPatrocinadora(devolucaoCalculoCompleto.getValorTotalPatrocinadora());
		devolucaoInstituido.setValorResgatavelParticipante(devolucaoCalculoCompleto.getValorResgatavelParticipante());
		devolucaoInstituido.setValorResgatavelPatrocinadora(devolucaoCalculoCompleto.getValorResgatavelPatrocinadora());
		devolucaoInstituido.setValorNaoResgatavelParticipante(devolucaoCalculoCompleto.getValorNaoResgatavelParticipante());
		devolucaoInstituido.setValorNaoResgatavelPatrocinadora(devolucaoCalculoCompleto.getValorNaoResgatavelPatrocinadora());
		devolucaoInstituido.setValorContaResgatavelParticipante(devolucaoCalculoCompleto.getValorContaResgatavelParticipante());
		devolucaoInstituido.setValorContaResgatavelPatrocinadora(devolucaoCalculoCompleto.getValorContaResgatavelPatrocinadora());
		devolucaoInstituido.setValorContaNaoResgatavelParticipante(devolucaoCalculoCompleto.getValorContaNaoResgatavelParticipante());
		devolucaoInstituido.setValorContaNaoResgatavelPatrocinadora(devolucaoCalculoCompleto.getValorContaNaoResgatavelPatrocinadora());
		devolucaoInstituido.setValorContaRemanescenteParticipante(devolucaoCalculoCompleto.getValorContaRemanescenteParticipante());
		devolucaoInstituido.setValorContaRemanescentePatrocinadora(devolucaoCalculoCompleto.getValorContaRemanescentePatrocinadora());
		devolucaoInstituido.setValorContaReversaoParticipante(devolucaoCalculoCompleto.getValorContaReversaoParticipante());
		devolucaoInstituido.setValorContaReversaoPatrocinadora(devolucaoCalculoCompleto.getValorContaReversaoPatrocinadora());

		devolucaoInstituido.setQuantidadeCotasResgatavelParticipante(devolucaoCalculoCompleto.getQuantidadeCotasResgatavelParticipante());
		devolucaoInstituido.setQuantidadeCotasResgatavelPatrocinadora(devolucaoCalculoCompleto.getQuantidadeCotasResgatavelPatrocinadora());
		devolucaoInstituido.setQuantidadeCotasNaoResgatavelParticipante(devolucaoCalculoCompleto.getQuantidadeCotasNaoResgatavelParticipante());
		devolucaoInstituido.setQuantidadeCotasNaoResgatavelPatrocinadora(devolucaoCalculoCompleto.getQuantidadeCotasNaoResgatavelPatrocinadora());
		devolucaoInstituido.setQuantidadeCotasContaResgatavelParticipante(devolucaoCalculoCompleto.getQuantidadeCotasContaResgatavelParticipante());
		devolucaoInstituido.setQuantidadeCotasContaResgatavelPatrocinadora(devolucaoCalculoCompleto.getQuantidadeCotasContaResgatavelPatrocinadora());
		devolucaoInstituido.setQuantidadeCotasContaResgatavel(devolucaoCalculoCompleto.getQuantidadeCotasContaResgatavel());
		devolucaoInstituido.setQuantidadeCotasContaNaoResgatavelParticipante(devolucaoCalculoCompleto.getQuantidadeCotasContaNaoResgatavelParticipante());
		devolucaoInstituido.setQuantidadeCotasContaNaoResgatavelPatrocinadora(devolucaoCalculoCompleto.getQuantidadeCotasContaNaoResgatavelPatrocinadora());
		devolucaoInstituido.setQuantidadeCotasContaRemanescenteParticipante(devolucaoCalculoCompleto.getQuantidadeCotasContaRemanescenteParticipante());
		devolucaoInstituido.setQuantidadeCotasContaRemanescentePatrocinadora(devolucaoCalculoCompleto.getQuantidadeCotasContaRemanescentePatrocinadora());
		devolucaoInstituido.setQuantidadeCotasContaReversaoParticipante(devolucaoCalculoCompleto.getQuantidadeCotasContaReversaoParticipante());
		devolucaoInstituido.setQuantidadeCotasContaReversaoPatrocinadora(devolucaoCalculoCompleto.getQuantidadeCotasContaReversaoPatrocinadora());
		devolucaoInstituido.setQuantidadeCotasTotalParticipante(devolucaoCalculoCompleto.getQuantidadeCotasTotalParticipante());
		devolucaoInstituido.setQuantidadeCotasTotalPatrocinadora(devolucaoCalculoCompleto.getQuantidadeCotasTotalPatrocinadora());
		devolucaoInstituido.setQuantidadeCotasTotalResgatavel(devolucaoCalculoCompleto.getQuantidadeCotasTotalResgatavel());

		String devolucaoInstituidoJson = gsonDevolucaoInstituido.toJson(devolucaoInstituido, DevolucaoInstituidoResponse.class);

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);
		responseHeaders.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));

		System.out.println("DevolucaoInstituidoJson: " + devolucaoInstituidoJson);

		return new ResponseEntity<String>(devolucaoInstituidoJson, responseHeaders, HttpStatus.OK);
	}

	//@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@RequestMapping(method = RequestMethod.POST, value = "/calcularDevolucao", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> calcularDevolucao(HttpServletRequest req) throws IOException {

		BufferedReader reader = req.getReader();
		DevolucaoIntegracaoDTO devolucaoPosicionadoDTO = extrairDadosDevolucao(reader);

		return calcularDevolucaoWs(Long.parseLong(devolucaoPosicionadoDTO.getCodigoPt()), Long.parseLong(devolucaoPosicionadoDTO.getCodigoPn()), Long
				.parseLong(devolucaoPosicionadoDTO.getCodigoTDev()), devolucaoPosicionadoDTO.getDataReq(), devolucaoPosicionadoDTO.getIndTDev(), devolucaoPosicionadoDTO.getSimulacao(), Integer
				.parseInt(devolucaoPosicionadoDTO.getQtdParcela()), devolucaoPosicionadoDTO.getDataCota(), devolucaoPosicionadoDTO.getIndFormaPagRem(), devolucaoPosicionadoDTO.getCodigoUsuario());

	}

	private DevolucaoIntegracaoDTO extrairDadosDevolucao(BufferedReader reader) {
		Gson gson = new Gson();

		DevolucaoIntegracaoDTO devolucaoPosicionadoDTO = gson.fromJson(reader, DevolucaoIntegracaoDTO.class);

		devolucaoPosicionadoDTO.setDataCotaD(buscarDataCota(Long.parseLong(devolucaoPosicionadoDTO.getCodigoPt()), Long.parseLong(devolucaoPosicionadoDTO.getCodigoPn())));

		if (devolucaoPosicionadoDTO.isPesquisaCalculoPadrao()) {
			devolucaoPosicionadoDTO.setCodigoTDev(buscaDevolucaoPadrao(Long.parseLong(devolucaoPosicionadoDTO.getCodigoPn()), devolucaoPosicionadoDTO.getIndTDev()).toString());
		}

		return devolucaoPosicionadoDTO;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/calcularDevolucaoWs", produces = APPLICATION_JSON)
	@ResponseBody
	public ResponseEntity<String> calcularDevolucaoWs(@RequestParam(required = false) Long codigoPt, @RequestParam(required = false) Long codigoPn, @RequestParam(required = false) Long codigoTDev,
													  @RequestParam(required = false) String dataReq, @RequestParam(required = false) String indTDev, @RequestParam(required = false) String simulacao,
													  @RequestParam(required = false) Integer qtdParcelas, @RequestParam(required = false) String dataCota, @RequestParam(required = false) String indFormaPagRem,
													  @RequestParam(required = false) String codigoUsuario) throws PrevidenciaException {

		//RetornoCalculoDevolucaoDTO retornoCalculoDevolucaoDTO = new RetornoCalculoDevolucaoDTO();
		List<RetornoCalculoDevolucaoDTO> listaRetornoCalculoDevolucaoDTO  = new ArrayList<RetornoCalculoDevolucaoDTO>();;

		Date dtCota = new Date();
		Date dtRequerimento = new Date();

		boolean podeCalcular = true;

		List<String> listaDescricaoErro = new ArrayList<String>();

		Gson gsonCalculoDevolucao = new GsonBuilder().create();

		ParticipantePlano participantePlano = new ParticipantePlano();

		//Código de Participante
		if (codigoPt == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Código de participante não informado.");
		}

		//Código de plano
		if (codigoPn == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Código de plano não informado.");
		}

		//Código de tipo de devolução
		if (codigoTDev == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Código do tipo de devolução não informado.");
		}

		//Indicativo de simulação
		if (simulacao == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Indicativo de simulação não informado.");
		}

		//Quantidade de parcelas
		if (qtdParcelas == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Quantidade de parcelas não informada.");
		}

		//Data de requerimento
		if (dataReq == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Data de requerimento não informado.");
		} else {
			if (!UtilJava.isDataValida(dataReq)) {
				podeCalcular = false;
				listaDescricaoErro.add("Data da requerimento inválida.");
			} else {
				try {
					dtRequerimento = UtilJava.formataData(dataReq);
				} catch (Exception e) {
					podeCalcular = false;
					listaDescricaoErro.add("Erro de conversão data da requerimento.");
				}

			}
		}

		//Data de Cota
		if (dataCota == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Data da cota não informada.");
		} else {
			if (!UtilJava.isDataValida(dataCota)) {
				podeCalcular = false;
				listaDescricaoErro.add("Data da cota inválida.");
			} else {
				try {
					dtCota = UtilJava.formataData(dataCota);
				} catch (Exception e) {
					podeCalcular = false;
					listaDescricaoErro.add("Erro de conversão data da cota.");
				}

			}
		}

		//Indicativo de pagamento de remanescente
		if (indFormaPagRem == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Indicativo de pagamento de remanescente não informado.");
		} else {
			if (!indFormaPagRem.equals("F") && !indFormaPagRem.equals("V")) {
				podeCalcular = false;
				listaDescricaoErro.add("Tipo de forma de pagamento de remanescente não suportado.");
			}
		}

		//Código de Usuário
		if (codigoUsuario == null) {
			podeCalcular = false;
			listaDescricaoErro.add("Código de usuário não informado.");
		}

		//Verificação os cadastros com os parametros informados.
		if (podeCalcular) {

			//Verificando participante.
			Participante participante = new Participante();
			participante.setCodigo((long) codigoPt);

//			participante = participanteBO.consultarParticipantePorCodigo((long) codigoPt);

			if (!this.participanteBO.existeParticipantePorId(participante.getCodigo())) {

				listaDescricaoErro.add("Participante não encontrado.");
				podeCalcular = false;
			}

			PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();

			planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo((long) codigoPn);

			if (planoPrevidencia == null) {

				listaDescricaoErro.add("Plano não encontrado.");
				podeCalcular = false;
			} else {

				List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

				listaRegraCalculoDevolucao = regraCalculoDevolucaoBO.listarTodosRegraCalculoDevolucaoSitEmProducaoVigenteHojePorPlanoPrevidencia(planoPrevidencia);

				if (listaRegraCalculoDevolucao.size() == 0) {
					listaDescricaoErro.add("O plano não possui regra devolução virgente.");
					podeCalcular = false;
				} else {
					boolean achouRegra = false;
					RegraCalculoDevolucao regraCalculoDevolucao = listaRegraCalculoDevolucao.stream()
							.filter(e -> e.getTipoDevolucao().getCodigo().equals(codigoTDev))
							.findFirst().orElse(null);

					achouRegra = regraCalculoDevolucao != null;

					if (regraCalculoDevolucao != null && !regraCalculoDevolucao.getTipoDevolucao().getIndicadorTipoDevolucao().equals(indTDev)) {
						listaDescricaoErro.add("Tipo de devolução diferente do indicativo.");
						podeCalcular = false;
					}

//					for (RegraCalculoDevolucao regraCalculoDevolucao : listaRegraCalculoDevolucao) {
//						if (regraCalculoDevolucao.getTipoDevolucao().getCodigo().equals(codigoTDev)) {
//							achouRegra = true;
//
//							if (!regraCalculoDevolucao.getTipoDevolucao().getIndicadorTipoDevolucao().equals(indTDev)) {
//								listaDescricaoErro.add("Tipo de devolução diferente do indicativo.");
//								podeCalcular = false;
//							}
//
//							break;
//						}
//					}

					if (!achouRegra) {
						listaDescricaoErro.add("O plano não possui regra deste tipo devolução virgente.");
						podeCalcular = false;
					}

				}

			}

			//Se participante existe e plano tb.
			if (participante != null && planoPrevidencia != null) {

				//ParticipantePlano participantePlano = new ParticipantePlano();

				participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(participante, planoPrevidencia);

				if (participantePlano == null) {

					listaDescricaoErro.add("Participante não participa do plano informado.");
					podeCalcular = false;
				}

				if (participantePlano != null) {

					ValorCotaPlano valorCotaPlano = new ValorCotaPlano();

					valorCotaPlano = valorCotaPlanoBO.pesquisarCotaParticipantePlano(dtCota, participantePlano);

					if (valorCotaPlano == null) {
						listaDescricaoErro.add("Cota não encotrada para parâmetros informados.");
						podeCalcular = false;

					}

					//Verificação de a cota retornou na mesma data
					try {
						if (!UtilJava.getDataPura(valorCotaPlano.getChavePrimaria().getDataPosicaoCota()).equals(UtilJava.getDataPura(dtCota))) {
							listaDescricaoErro.add("Cota não encontrada para data informada.");
							podeCalcular = false;

						}
					} catch (Exception e) {
						listaDescricaoErro.add("Erro ao validar data cota informada.");
						podeCalcular = false;
					}

				}

			}

		}

		//Fazer validação de usuário.
		String codigoLogin = new String();

		try {
			codigoLogin = Criptografia.descriptografar(codigoUsuario);
		} catch (Exception e) {
			listaDescricaoErro.add("Erro ao ler usuário.");
			podeCalcular = false;
		}

		//Verificar login.
		if (podeCalcular) {
			//Verifica parametros de usuário logado
			Usuario usuario = new Usuario();

			usuario = usuarioBO.consultarPorCodigo(Long.parseLong(codigoLogin));

			if (usuario == null) {
				listaDescricaoErro.add("Usuário não encontrado.");
				podeCalcular = false;
			} else {
				try {
					codigoUsuario = Criptografia.criptografar(usuario.getCodigo().toString());
				} catch (Exception e) {
					listaDescricaoErro.add("Erro ao converter usuário.");
					podeCalcular = false;
				}
			}

		}

		//Se houver erro, não calcula.
		if (!podeCalcular) {

			listaRetornoCalculoDevolucaoDTO.add(preencherRetornoCalculoDevolucaoDTOErro(listaDescricaoErro,""));

		}else {
			ApplicationContext ctx = AppContext.getApplicationContext();
			CalculoDevolucaoBO calculoDevolucao = ctx.getBean(CalculoDevolucaoBO.class);

			//Buscar opcao de tributação do participante

			String opcaoTributacao = participantePlano.getTipoRegimeTributacao().getCodigo();

			if (opcaoTributacao.equalsIgnoreCase("P") ||opcaoTributacao.equalsIgnoreCase("R")){

				List<RetornoCalculoDevolucaoDTO> listaRetornoCalculoDevolucaoDTOOpcaoEscolhida = new ArrayList<RetornoCalculoDevolucaoDTO>();

				try {

					RetornoCalculoDevolucaoDTO retornoCalculoDevolucaoDTO = new RetornoCalculoDevolucaoDTO();
					//Tenta calcular.
					DevolucaoCompletoDTO devolucaoCompletoDTO = new DevolucaoCompletoDTO();
					devolucaoCompletoDTO = calculoDevolucao.calcularDevolucao(codigoPt, codigoPn, codigoTDev, dataReq, indTDev, simulacao, qtdParcelas, dataCota, indFormaPagRem, codigoUsuario, 100D, 0D, opcaoTributacao);

					retornoCalculoDevolucaoDTO.setStatus(true);
					retornoCalculoDevolucaoDTO.setListaDescricaoErro(null);

					retornoCalculoDevolucaoDTO.setQuantidadeCotaResgatavelParticipante(devolucaoCompletoDTO.getQuantidadeCotasContaResgatavelParticipante());
					retornoCalculoDevolucaoDTO.setQuantidadeCotaResgatavelPatrocinadora(devolucaoCompletoDTO.getQuantidadeCotasContaResgatavelPatrocinadora());
					retornoCalculoDevolucaoDTO.setValorResgatavelParticipante(devolucaoCompletoDTO.getValorContaResgatavelParticipante());
					retornoCalculoDevolucaoDTO.setValorResgatavelPatrocinadora(devolucaoCompletoDTO.getValorContaResgatavelPatrocinadora());

					retornoCalculoDevolucaoDTO.setQuantidadeCotaTotalParticipante(devolucaoCompletoDTO.getQuantidadeCotasTotalParticipante());
					retornoCalculoDevolucaoDTO.setQuantidadeCotaTotalPatrocinadora(devolucaoCompletoDTO.getQuantidadeCotasTotalPatrocinadora());
					retornoCalculoDevolucaoDTO.setValorTotalParticipante(devolucaoCompletoDTO.getValorTotalParticipante());
					retornoCalculoDevolucaoDTO.setValorTotalPatrocinadora(devolucaoCompletoDTO.getValorTotalPatrocinadora());

					retornoCalculoDevolucaoDTO.setPercentualParticipante(devolucaoCompletoDTO.getPercentualResgateParticipante());
					retornoCalculoDevolucaoDTO.setPercentualPatrocinadora(devolucaoCompletoDTO.getPercentualResgatePatrocionadora());

					retornoCalculoDevolucaoDTO.setPercentualDevolucao(devolucaoCompletoDTO.getPercenutalResgatel());

					retornoCalculoDevolucaoDTO.setValorDevolucao(devolucaoCompletoDTO.getValorTotalResgatavel());
					retornoCalculoDevolucaoDTO.setValorImposto(devolucaoCompletoDTO.getValorImposto());
					retornoCalculoDevolucaoDTO.setPercentualImposto(devolucaoCompletoDTO.getPercentualImposto());

					retornoCalculoDevolucaoDTO.setIndicativoTipoImposto(opcaoTributacao);

					retornoCalculoDevolucaoDTO.setValorRemanescenteParticipante(devolucaoCompletoDTO.getValorContaRemanescenteParticipante());
					retornoCalculoDevolucaoDTO.setValorRemanescentePatrocinadora(devolucaoCompletoDTO.getValorContaRemanescentePatrocinadora());

					retornoCalculoDevolucaoDTO.setPercentualRemanescenteParticipante(devolucaoCompletoDTO.getPercentualRemanescenteParticipante());
					retornoCalculoDevolucaoDTO.setPercentualRemanescentePatrocinadora(devolucaoCompletoDTO.getPercentualRemanescentePatrocionadora());

					listaRetornoCalculoDevolucaoDTOOpcaoEscolhida.add(retornoCalculoDevolucaoDTO);

				} catch (Exception e) {
					listaDescricaoErro.add("Erro ao calcular devolução. Erro: " + e.getMessage());
					listaRetornoCalculoDevolucaoDTOOpcaoEscolhida.add(preencherRetornoCalculoDevolucaoDTOErro(listaDescricaoErro,opcaoTributacao));
				}

				listaRetornoCalculoDevolucaoDTO.addAll(listaRetornoCalculoDevolucaoDTOOpcaoEscolhida);

			} else if (opcaoTributacao.equalsIgnoreCase("N")) {

				List<RetornoCalculoDevolucaoDTO> listaRetornoCalculoDevolucaoDTOSemOpcaoEscolhida = new ArrayList<RetornoCalculoDevolucaoDTO>();

				for (int i = 1; i <= 2; i++) {

					try {

						RetornoCalculoDevolucaoDTO retornoCalculoDevolucaoDTO = new RetornoCalculoDevolucaoDTO();
						//Tenta calcular.
						DevolucaoCompletoDTO devolucaoCompletoDTO = new DevolucaoCompletoDTO();
						devolucaoCompletoDTO = calculoDevolucao.calcularDevolucao(codigoPt, codigoPn, codigoTDev, dataReq, indTDev, simulacao, qtdParcelas, dataCota, indFormaPagRem, codigoUsuario, 100D, 0D, i == 1? "P" : "R");

						retornoCalculoDevolucaoDTO.setStatus(true);
						retornoCalculoDevolucaoDTO.setListaDescricaoErro(null);

						retornoCalculoDevolucaoDTO.setQuantidadeCotaResgatavelParticipante(devolucaoCompletoDTO.getQuantidadeCotasContaResgatavelParticipante());
						retornoCalculoDevolucaoDTO.setQuantidadeCotaResgatavelPatrocinadora(devolucaoCompletoDTO.getQuantidadeCotasContaResgatavelPatrocinadora());
						retornoCalculoDevolucaoDTO.setValorResgatavelParticipante(devolucaoCompletoDTO.getValorContaResgatavelParticipante());
						retornoCalculoDevolucaoDTO.setValorResgatavelPatrocinadora(devolucaoCompletoDTO.getValorContaResgatavelPatrocinadora());

						retornoCalculoDevolucaoDTO.setQuantidadeCotaTotalParticipante(devolucaoCompletoDTO.getQuantidadeCotasTotalParticipante());
						retornoCalculoDevolucaoDTO.setQuantidadeCotaTotalPatrocinadora(devolucaoCompletoDTO.getQuantidadeCotasTotalPatrocinadora());
						retornoCalculoDevolucaoDTO.setValorTotalParticipante(devolucaoCompletoDTO.getValorTotalParticipante());
						retornoCalculoDevolucaoDTO.setValorTotalPatrocinadora(devolucaoCompletoDTO.getValorTotalPatrocinadora());

						retornoCalculoDevolucaoDTO.setPercentualParticipante(devolucaoCompletoDTO.getPercentualResgateParticipante());
						retornoCalculoDevolucaoDTO.setPercentualPatrocinadora(devolucaoCompletoDTO.getPercentualResgatePatrocionadora());

						retornoCalculoDevolucaoDTO.setPercentualDevolucao(devolucaoCompletoDTO.getPercenutalResgatel());

						retornoCalculoDevolucaoDTO.setValorDevolucao(devolucaoCompletoDTO.getValorTotalResgatavel());
						retornoCalculoDevolucaoDTO.setValorImposto(devolucaoCompletoDTO.getValorImposto());
						retornoCalculoDevolucaoDTO.setPercentualImposto(devolucaoCompletoDTO.getPercentualImposto());

						retornoCalculoDevolucaoDTO.setIndicativoTipoImposto(i == 1? "P" : "R");

						retornoCalculoDevolucaoDTO.setValorRemanescenteParticipante(devolucaoCompletoDTO.getValorContaRemanescenteParticipante());
						retornoCalculoDevolucaoDTO.setValorRemanescentePatrocinadora(devolucaoCompletoDTO.getValorContaRemanescentePatrocinadora());

						retornoCalculoDevolucaoDTO.setPercentualRemanescenteParticipante(devolucaoCompletoDTO.getPercentualRemanescenteParticipante());
						retornoCalculoDevolucaoDTO.setPercentualRemanescentePatrocinadora(devolucaoCompletoDTO.getPercentualRemanescentePatrocionadora());

						listaRetornoCalculoDevolucaoDTOSemOpcaoEscolhida.add(retornoCalculoDevolucaoDTO);

					} catch (Exception e) {
						listaDescricaoErro.add("Erro ao calcular devolução sem opção de tributação. Erro: " + e.getMessage());
						listaRetornoCalculoDevolucaoDTOSemOpcaoEscolhida.add(preencherRetornoCalculoDevolucaoDTOErro(listaDescricaoErro,i == 1? "P" : "R"));
					}

				}

				listaRetornoCalculoDevolucaoDTO.addAll(listaRetornoCalculoDevolucaoDTOSemOpcaoEscolhida);

			}

		}

		String objToJSONCalculoDevolucao = gsonCalculoDevolucao.toJson(listaRetornoCalculoDevolucaoDTO);
		//String objToJSONLoteAlcada = gsonLoteAlcada.toJson(this.solicitaLoteProcessamentoAlcada(codigoSistema, codigoAplicacao, codigoUsuario), RetornoSolicitacaoLoteAlcadaDTO.class);
		//String json = "{\"status\":true,\"descricaoErro\":\"Erro de testes\",\"dataCota\":\"09/01/2017\"}";

		// Thiago C. - 09/02/2017 - Injeta o cabeçalho no HTTP para o cliente reconhecer o retorno HTTP.
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);
		responseHeaders.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));

		return new ResponseEntity<String>(objToJSONCalculoDevolucao, responseHeaders, HttpStatus.CREATED);

	}

	public Future<AsyncForm> calculoDevolucaoAssincrono(EntidadeParticipante entidadeParticipante, PlanoPrevidencia planoPrevidencia, List<ParticipanteDevolucaoPosicionadaDTO> listaParticipante,
			ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado, LoginBBPrevWebDTO loginTemporariaDTO) throws PrevidenciaException, Exception {
		StringBuilder log = new StringBuilder();

		HttpSession session = (HttpSession) UtilSession.getExternalContext().getSession(false);
		this.addSessaoLog(session, log);
		Future<AsyncForm> promisse = this.calculoDevolucao
				.calcularDevolucaoAssinc(entidadeParticipante, planoPrevidencia, listaParticipante, referenciaCalculoDevolucaoPosicionado, loginTemporariaDTO);
		this.addSessaoPromisse(session, promisse);

		return promisse;
	}

	/**
	 * Metodo chamado pelo Javascript para verificar conclusao do Async.
	 * Caso ainda nao tenha concluido, retorna o log de execucao.
	 *
	 * @param session HttpSession
	 * @return AsyncForm
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	@ResponseBody
	@RequestMapping(value = "/assinc/verificar", method = RequestMethod.GET)
	public ResponseEntity<AsyncForm> verificarAssinc(HttpSession session) throws InterruptedException, ExecutionException {
		Future<AsyncForm> promisse = this.getSessaoPromisse(session);
		if (promisse == null) {
			return null;
		} else {
			//caso o Async ainda nao tenha concluido, este metodo cria como retorno o parametro passado.
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.APPLICATION_JSON);

			return new ResponseEntity<AsyncForm>(promisse.get(), responseHeaders, HttpStatus.CREATED);
		}
	}

	private void addSessaoLog(HttpSession session, StringBuilder log) {
		session.setAttribute("LOG_IMPORTACAO", log);
	}

	private StringBuilder getSessaoLog(HttpSession session) {
		return (StringBuilder) session.getAttribute("LOG_IMPORTACAO");
	}

	private void addSessaoPromisse(HttpSession session, Future<AsyncForm> promisse) {
		session.setAttribute("FUTURE_IMPORTACAO", promisse);
	}

	@SuppressWarnings("unchecked")
	private Future<AsyncForm> getSessaoPromisse(HttpSession session) {
		return (Future<AsyncForm>) session.getAttribute("FUTURE_IMPORTACAO");
	}

	public LoginBBPrevWebDTO getLoginBBPrevWebDTO() {
		if (this.loginBBPrevWebDTO == null) {
			this.loginBBPrevWebDTO = UtilSession.getLoginSessao();
		}
		return loginBBPrevWebDTO;
	}

	public void setLoginBBPrevWebDTO(LoginBBPrevWebDTO loginBBPrevWebDTO) {
		this.loginBBPrevWebDTO = loginBBPrevWebDTO;
	}

	public RetornoCalculoDevolucaoDTO preencherRetornoCalculoDevolucaoDTOErro(List<String> listaDescriucaoErro, String tipoImposto) {

		RetornoCalculoDevolucaoDTO retornoCalculoDevolucaoDTO = new RetornoCalculoDevolucaoDTO();

		retornoCalculoDevolucaoDTO.setStatus(false);
		retornoCalculoDevolucaoDTO.setListaDescricaoErro(this.tiraAcetuacao(listaDescriucaoErro));

		retornoCalculoDevolucaoDTO.setQuantidadeCotaResgatavelParticipante(0D);
		retornoCalculoDevolucaoDTO.setQuantidadeCotaResgatavelPatrocinadora(0D);
		retornoCalculoDevolucaoDTO.setValorResgatavelParticipante(0D);
		retornoCalculoDevolucaoDTO.setValorResgatavelPatrocinadora(0D);

		retornoCalculoDevolucaoDTO.setQuantidadeCotaTotalParticipante(0D);
		retornoCalculoDevolucaoDTO.setQuantidadeCotaTotalPatrocinadora(0D);
		retornoCalculoDevolucaoDTO.setValorTotalParticipante(0D);
		retornoCalculoDevolucaoDTO.setValorTotalPatrocinadora(0D);

		retornoCalculoDevolucaoDTO.setPercentualParticipante(0D);
		retornoCalculoDevolucaoDTO.setPercentualPatrocinadora(0D);

		retornoCalculoDevolucaoDTO.setPercentualDevolucao(0D);

		retornoCalculoDevolucaoDTO.setValorDevolucao(0D);
		retornoCalculoDevolucaoDTO.setValorImposto(0D);
		retornoCalculoDevolucaoDTO.setPercentualImposto(0D);

		retornoCalculoDevolucaoDTO.setIndicativoTipoImposto(tipoImposto);

		return retornoCalculoDevolucaoDTO;

	}

	private List<String> tiraAcetuacao(List<String> listaDescriucaoErro) {
		List<String> errosTmp = new ArrayList<>();
		for (String erro : listaDescriucaoErro) {
			errosTmp.add(Normalizer.normalize(erro, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", ""));
		}
		return errosTmp;
	}

	public Long buscaDevolucaoPadrao(Long codigoPlanoPrevidencia, String tipoDevolucao) {

		PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();

		planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(codigoPlanoPrevidencia);

		if (planoPrevidencia != null) {

			if (tipoDevolucao.equals("R")) {
				return planoPrevidencia.getTipoResgatePadrao();
			} else {
				return planoPrevidencia.getTipoPortabilidadePadrao();
			}

		}

		return 0L;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/buscaDevolucaoPadraoWs", produces = APPLICATION_JSON)
	@ResponseBody
	public ResponseEntity<String> buscaDevolucaoPadraoWs(@RequestParam(required = false) Long codigoPlanoPrevidencia, @RequestParam(required = false) String tipoDevolucao) throws PrevidenciaException {

		Long codigoTipoDevolucao = buscaDevolucaoPadrao(codigoPlanoPrevidencia, tipoDevolucao);

		Gson gsonCalculoDevolucao = new GsonBuilder().create();

		String objToJSONCalculoDevolucao = gsonCalculoDevolucao.toJson(codigoTipoDevolucao, Long.class);

		//Injeta o cabeçalho no HTTP para o cliente reconhecer o retorno HTTP.
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);

		return new ResponseEntity<String>(objToJSONCalculoDevolucao, responseHeaders, HttpStatus.CREATED);

	}

	public boolean planoPossueResgatePadrao(Long codigoPlanoPrevidencia) {

		PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();

		planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(codigoPlanoPrevidencia);

		if (planoPrevidencia != null) {

			List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

			listaRegraCalculoDevolucao = regraCalculoDevolucaoBO.listarTodosRegraCalculoDevolucaoSitEmProducaoVigenteHojePorPlanoPrevidencia(planoPrevidencia);

			for (RegraCalculoDevolucao regraCalculoDevolucao : listaRegraCalculoDevolucao) {
				if (regraCalculoDevolucao.getTipoDevolucao().getCodigo().equals(planoPrevidencia.getTipoResgatePadrao())) {
					return true;
				}
			}

		}

		return false;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/planoPossueResgatePadraoWs", produces = APPLICATION_JSON)
	@ResponseBody
	public ResponseEntity<String> planoPossueResgatePadraoWs(@RequestParam(required = false) Long codigoPlanoPrevidencia) throws PrevidenciaException {

		boolean planoPossueResgatePadrao = planoPossueResgatePadrao(codigoPlanoPrevidencia);

		Gson gsonRetorno = new GsonBuilder().create();

		String objToJSONRetorno = gsonRetorno.toJson(planoPossueResgatePadrao, Boolean.class);

		//Injeta o cabeçalho no HTTP para o cliente reconhecer o retorno HTTP.
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);

		return new ResponseEntity<String>(objToJSONRetorno, responseHeaders, HttpStatus.CREATED);

	}

	public boolean planoPossuePortabilidadePadrao(Long codigoPlanoPrevidencia) {

		PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();

		planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(codigoPlanoPrevidencia);

		if (planoPrevidencia != null) {

			List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

			listaRegraCalculoDevolucao = regraCalculoDevolucaoBO.listarTodosRegraCalculoDevolucaoSitEmProducaoVigenteHojePorPlanoPrevidencia(planoPrevidencia);

			for (RegraCalculoDevolucao regraCalculoDevolucao : listaRegraCalculoDevolucao) {
				if (regraCalculoDevolucao.getTipoDevolucao().getCodigo().equals(planoPrevidencia.getTipoPortabilidadePadrao())) {
					return true;
				}
			}

		}

		return false;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/planoPossuePortabilidadePadraoWs", produces = APPLICATION_JSON)
	@ResponseBody
	public ResponseEntity<String> planoPossuePortabilidadePadraoWs(@RequestParam(required = false) Long codigoPlanoPrevidencia) throws PrevidenciaException {

		boolean planoPossuePortabilidadePadrao = planoPossuePortabilidadePadrao(codigoPlanoPrevidencia);

		Gson gsonRetorno = new GsonBuilder().create();

		String objToJSONRetorno = gsonRetorno.toJson(planoPossuePortabilidadePadrao, Boolean.class);

		//Injeta o cabeçalho no HTTP para o cliente reconhecer o retorno HTTP.
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);

		return new ResponseEntity<String>(objToJSONRetorno, responseHeaders, HttpStatus.CREATED);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/calcularTemposParticipanteWs", produces = APPLICATION_JSON)
	@ResponseBody
	public ResponseEntity<String> calcularTemposParticipanteWs(@RequestParam(required = false) Long codigoParticipantePlano, @RequestParam(required = false) Long codigoTipoDevolucao,
			@RequestParam(required = false) String dataCalculo) throws PrevidenciaException {

		RetornoTemposCalculadosRegraDTO retornoTemposCalculadosRegraDTO = new RetornoTemposCalculadosRegraDTO();

		boolean podeCalcular = true;

		Date dtCalculo = new Date();
		List<String> listaDescricaoErro = new ArrayList<String>();

		try {
			dtCalculo = UtilJava.formataData(dataCalculo);
		} catch (Exception e) {
			podeCalcular = false;
			listaDescricaoErro.add("Erro ao converter data de calculo.");
		}

		TemposCalculadosRegraDTO temposCalculadosRegraDTO = new TemposCalculadosRegraDTO();

		ParticipantePlano participantePlano = new ParticipantePlano();
		RegraCalculoDevolucao regraCalculoDevolucao = new RegraCalculoDevolucao();

		//Buscar particpante
		try {
			participantePlano = participantePlanoBO.consultarParticipantePlanoPorCodigo(codigoParticipantePlano);
		} catch (PrevidenciaException e) {
			podeCalcular = false;
			listaDescricaoErro.add("Erro ao buscar participante.");
		}

		if (podeCalcular) {

			//Buscar Regra Calculo Devolução
			try {

				List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

				//Pesquisa Participante Plano
				listaRegraCalculoDevolucao = regraCalculoDevolucaoBO.listarTodosRegraCalculoDevolucaoSitEmProducaoVigenteHojePorPlanoPrevidencia(participantePlano.getPlanoPrevidencia());

				if (listaRegraCalculoDevolucao.size() == 0) {
					podeCalcular = false;
					listaDescricaoErro.add("Não existe regra de devolução vigente para plano.");
				} else {
					boolean achouRegra = false;

					for (RegraCalculoDevolucao regraCalculoDevolucaoLista : listaRegraCalculoDevolucao) {

						if (regraCalculoDevolucaoLista.getTipoDevolucao().getCodigo().equals(codigoTipoDevolucao)) {
							regraCalculoDevolucao = regraCalculoDevolucaoLista;
							achouRegra = true;
							break;

						}
					}

					if (!achouRegra) {
						podeCalcular = false;
						listaDescricaoErro.add("Regra de calculo devolução não encontrada.");
					}

				}

			} catch (PrevidenciaException e) {
				podeCalcular = false;
				listaDescricaoErro.add("Erro ao buscar regra de calculo devolução.");
			}
		}

		if (podeCalcular) {

			//Cálculo de tempos.
			temposCalculadosRegraDTO = devolucaoBO.calcularTemposParticipante(participantePlano, regraCalculoDevolucao, dtCalculo);

			retornoTemposCalculadosRegraDTO.setStatus(true);
			retornoTemposCalculadosRegraDTO.setQtdMesesIdade(temposCalculadosRegraDTO.getQtdMesesIdade());
			retornoTemposCalculadosRegraDTO.setQtdMesesPlano(temposCalculadosRegraDTO.getQtdMesesPlano());
			retornoTemposCalculadosRegraDTO.setQtdMesesEmpresa(temposCalculadosRegraDTO.getQtdMesesEmpresa());
			retornoTemposCalculadosRegraDTO.setQtdMesesContribuicao(temposCalculadosRegraDTO.getQtdMesesContribuicao());
			retornoTemposCalculadosRegraDTO.setListaDescricaoErro(null);

		} else {
			retornoTemposCalculadosRegraDTO.setStatus(false);
			retornoTemposCalculadosRegraDTO.setQtdMesesIdade(0);
			retornoTemposCalculadosRegraDTO.setQtdMesesPlano(0);
			retornoTemposCalculadosRegraDTO.setQtdMesesEmpresa(0);
			retornoTemposCalculadosRegraDTO.setQtdMesesContribuicao(0);
			retornoTemposCalculadosRegraDTO.setListaDescricaoErro(listaDescricaoErro);
		}

		Gson gsonRetorno = new GsonBuilder().create();

		String objToJSONRetorno = gsonRetorno.toJson(retornoTemposCalculadosRegraDTO, RetornoTemposCalculadosRegraDTO.class);

		//Injeta o cabeçalho no HTTP para o cliente reconhecer o retorno HTTP.
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);

		return new ResponseEntity<String>(objToJSONRetorno, responseHeaders, HttpStatus.CREATED);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/isElegivelPorDevolucaoWs", produces = APPLICATION_JSON)
	@ResponseBody
	public ResponseEntity<String> isElegivelPorDevolucaoWs(@RequestParam(required = false) Long codigoParticipantePlano, @RequestParam(required = false) Long codigoTipoDevolucao,
			@RequestParam(required = false) String dataCalculo) throws PrevidenciaException {

		boolean podeCalcular = true;

		Date dtCalculo = new Date();
		List<String> listaDescricaoErro = new ArrayList<String>();

		try {
			dtCalculo = UtilJava.formataData(dataCalculo);
		} catch (Exception e) {
			podeCalcular = false;
			listaDescricaoErro.add("Erro ao converter data de calculo.");
		}

		ParticipantePlano participantePlano = new ParticipantePlano();
		TipoDevolucao tipoDevolucao = new TipoDevolucao();
		ElegibilidadeDevolucaoDTO elegibilidadeDevolucaoDTO = new ElegibilidadeDevolucaoDTO();
		RetornoElegibilidadeDevolucaoDTO retornoElegibilidadeDevolucaoDTO = new RetornoElegibilidadeDevolucaoDTO();

		//Buscar particpante
		try {
			participantePlano = participantePlanoBO.consultarParticipantePlanoPorCodigo(codigoParticipantePlano);
		} catch (PrevidenciaException e) {
			podeCalcular = false;
			listaDescricaoErro.add("Erro ao buscar participante.");
		}

		//Buscar de Tipo devolução
		try {
			tipoDevolucao = tipoDevolucaoBO.pesquisarTipoDevolucaoPorCodigo(codigoTipoDevolucao);
		} catch (PrevidenciaException e) {
			podeCalcular = false;
			listaDescricaoErro.add("Erro ao buscar tipo de devolução.");
		}

		if (podeCalcular) {

			//Buscar Regra Calculo Devolução
			try {

				elegibilidadeDevolucaoDTO = regraElegibilidadeDevolucaoBO.isElegivelPorDevolucao(participantePlano, tipoDevolucao, dtCalculo);

				retornoElegibilidadeDevolucaoDTO.setStatus(podeCalcular);

				retornoElegibilidadeDevolucaoDTO.setElegivel(elegibilidadeDevolucaoDTO.isElegivel());
				retornoElegibilidadeDevolucaoDTO.setMotivoDesligamentoNuloOuDiferenteExigido(elegibilidadeDevolucaoDTO.isMotivoDesligamentoNuloOuDiferenteExigido());
				retornoElegibilidadeDevolucaoDTO.setNaoDesligadoDevolucaoExigeDesligamento(elegibilidadeDevolucaoDTO.isNaoDesligadoDevolucaoExigeDesligamento());
				retornoElegibilidadeDevolucaoDTO.setTempoEmpresaFaltante(elegibilidadeDevolucaoDTO.getTempoEmpresaFaltante());
				retornoElegibilidadeDevolucaoDTO.setTempoPlanoFaltante(elegibilidadeDevolucaoDTO.getTempoPlanoFaltante());
				retornoElegibilidadeDevolucaoDTO.setTempoIdadeFaltante(elegibilidadeDevolucaoDTO.getTempoIdadeFaltante());
				retornoElegibilidadeDevolucaoDTO.setTempoFaltante(elegibilidadeDevolucaoDTO.getTempoFaltante());
				retornoElegibilidadeDevolucaoDTO.setDescricao(elegibilidadeDevolucaoDTO.getDescricao());
				retornoElegibilidadeDevolucaoDTO.setListaDescricaoErro(listaDescricaoErro);

			} catch (PrevidenciaException e) {
				podeCalcular = false;
				listaDescricaoErro.add("Erro ao calcular Elegibilidade Devolução.");
			}
		} else {

			retornoElegibilidadeDevolucaoDTO.setStatus(podeCalcular);

			retornoElegibilidadeDevolucaoDTO.setElegivel(false);
			retornoElegibilidadeDevolucaoDTO.setMotivoDesligamentoNuloOuDiferenteExigido(false);
			retornoElegibilidadeDevolucaoDTO.setNaoDesligadoDevolucaoExigeDesligamento(false);
			retornoElegibilidadeDevolucaoDTO.setTempoEmpresaFaltante(VALOR_ZERO_LONG);
			retornoElegibilidadeDevolucaoDTO.setTempoPlanoFaltante(VALOR_ZERO_LONG);
			retornoElegibilidadeDevolucaoDTO.setTempoIdadeFaltante(VALOR_ZERO_LONG);
			retornoElegibilidadeDevolucaoDTO.setTempoFaltante(VALOR_ZERO_LONG);
			retornoElegibilidadeDevolucaoDTO.setListaDescricaoErro(listaDescricaoErro);

		}

		Gson gsonRetorno = new GsonBuilder().create();

		String objToJSONRetorno = gsonRetorno.toJson(retornoElegibilidadeDevolucaoDTO, RetornoElegibilidadeDevolucaoDTO.class);

		//Injeta o cabeçalho no HTTP para o cliente reconhecer o retorno HTTP.
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);

		return new ResponseEntity<String>(objToJSONRetorno, responseHeaders, HttpStatus.CREATED);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/buscaInformacaoExtratoWs", produces = APPLICATION_JSON)
	@ResponseBody
	public ResponseEntity<String> buscaInformacaoExtratoWs(@RequestParam(required = false) Long codigoPlano, @RequestParam(required = false) String indFundador) throws PrevidenciaException {

		boolean podeCalcular = true;
		boolean isFundador = false;
		Long quantidadeMaximaParcelasResgate;
		Long quantidadeMesesCarenciaPortabilidade;

		quantidadeMaximaParcelasResgate = VALOR_ZERO_LONG;
		quantidadeMesesCarenciaPortabilidade = VALOR_ZERO_LONG;

		if (indFundador.equals("S")) {
			isFundador = true;
		}

		List<String> listaDescricaoErro = new ArrayList<String>();

		RetornoInformacaoExtratoDTO retornoInformacaoExtratoDTO = new RetornoInformacaoExtratoDTO();
		PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();

		TipoDevolucao tipoDevolucaoPadraoResgate = new TipoDevolucao();
		TipoDevolucao tipoDevolucaoPadraoPortabilidade = new TipoDevolucao();

		RegraCalculoDevolucao regraCalculoDevolucaoResgate = new RegraCalculoDevolucao();
		RegraCalculoDevolucao regraCalculoDevolucaoPortabilidade = new RegraCalculoDevolucao();

		//Busca planos
		try {
			planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(codigoPlano);
		} catch (PrevidenciaException e) {
			podeCalcular = false;
			listaDescricaoErro.add("Erro ao buscar plano.");
		}

		//Buscando tipo de devoluções.
		if (podeCalcular) {
			try {
				tipoDevolucaoPadraoResgate = tipoDevolucaoBO.pesquisarTipoDevolucaoPorCodigo(planoPrevidencia.getTipoResgatePadrao());
				tipoDevolucaoPadraoPortabilidade = tipoDevolucaoBO.pesquisarTipoDevolucaoPorCodigo(planoPrevidencia.getTipoPortabilidadePadrao());
			} catch (PrevidenciaException e) {
				podeCalcular = false;
				listaDescricaoErro.add("Erro ao tipo de devoluções.");
			}
		}

		if (podeCalcular) {
			//Buscar Regra Calculo Devolução
			try {

				List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

				//Pesquisa Participante Plano
				listaRegraCalculoDevolucao = regraCalculoDevolucaoBO.listarTodosRegraCalculoDevolucaoSitEmProducaoVigenteHojePorPlanoPrevidencia(planoPrevidencia);

				if (listaRegraCalculoDevolucao.size() == 0) {
					podeCalcular = false;
					listaDescricaoErro.add("Não existe regra de devolução vigente para plano.");
				} else {
					boolean achouRegraResgate = false;
					boolean achouRegraPortabilidade = false;

					for (RegraCalculoDevolucao regraCalculoDevolucaoLista : listaRegraCalculoDevolucao) {

						if (regraCalculoDevolucaoLista.getTipoDevolucao().equals(tipoDevolucaoPadraoResgate)) {
							regraCalculoDevolucaoResgate = regraCalculoDevolucaoLista;
							achouRegraResgate = true;

						}

						if (regraCalculoDevolucaoLista.getTipoDevolucao().equals(tipoDevolucaoPadraoPortabilidade)) {
							regraCalculoDevolucaoPortabilidade = regraCalculoDevolucaoLista;
							achouRegraPortabilidade = true;

						}
					}

					if (!achouRegraResgate) {
						quantidadeMaximaParcelasResgate = 1L;
					} else {
						quantidadeMaximaParcelasResgate = regraCalculoDevolucaoResgate.getNumeroMaximoParcelas();
					}

					if (!achouRegraPortabilidade) {
						quantidadeMesesCarenciaPortabilidade = 36L;
					} else {

						quantidadeMesesCarenciaPortabilidade = VALOR_ZERO_LONG;

						for (RegraElegibilidadeDevolucao regraElegibilidadeDevolucao : regraCalculoDevolucaoPortabilidade.getListaRegraElegibilidadeDevolucao()) {

							Long quantidadePlanoRegra = VALOR_ZERO_LONG;

							if (isFundador) {
								quantidadePlanoRegra = regraElegibilidadeDevolucao.getMesesPlanoFundador();
							} else {
								quantidadePlanoRegra = regraElegibilidadeDevolucao.getMesesPlanoFundador();
							}

							if (quantidadeMesesCarenciaPortabilidade < quantidadePlanoRegra) {
								quantidadeMesesCarenciaPortabilidade = quantidadePlanoRegra;
							}
						}
					}

				}

			} catch (PrevidenciaException e) {
				podeCalcular = false;
				listaDescricaoErro.add("Erro ao buscar regra de calculo devolução.");
			}

		}

		if (podeCalcular) {

			retornoInformacaoExtratoDTO.setStatus(true);
			retornoInformacaoExtratoDTO.setQuantidadeMaximaParcelasResgate(quantidadeMaximaParcelasResgate);
			retornoInformacaoExtratoDTO.setQuantidadeMesesCarenciaPortabilidade(quantidadeMesesCarenciaPortabilidade);
			retornoInformacaoExtratoDTO.setListaDescricaoErro(listaDescricaoErro);

		} else {

			retornoInformacaoExtratoDTO.setStatus(false);
			retornoInformacaoExtratoDTO.setQuantidadeMaximaParcelasResgate(quantidadeMaximaParcelasResgate);
			retornoInformacaoExtratoDTO.setQuantidadeMesesCarenciaPortabilidade(quantidadeMesesCarenciaPortabilidade);
			retornoInformacaoExtratoDTO.setListaDescricaoErro(listaDescricaoErro);
		}

		Gson gsonRetorno = new GsonBuilder().create();

		String objToJSONRetorno = gsonRetorno.toJson(retornoInformacaoExtratoDTO, RetornoInformacaoExtratoDTO.class);

		//Injeta o cabeçalho no HTTP para o cliente reconhecer o retorno HTTP.
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);

		return new ResponseEntity<String>(objToJSONRetorno, responseHeaders, HttpStatus.CREATED);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/extrairRelatorioSimulacaoResgateWs")
	@ResponseBody
	public ResponseEntity<byte[]> extrairRelatorioSimulacaoResgateWs(@RequestParam(required = false) Long codigoPt, @RequestParam(required = false) List<Long> codigoPn,
			@RequestParam(required = false) Long codigoTDev, @RequestParam(required = false) String codigoUsuario) throws IOException {

		List<RelatorioSimulacaoResgateDTO> dataSource = new ArrayList<RelatorioSimulacaoResgateDTO>();

		String nomeArquivo = "";

		byte[] arquivo = null;

		for (Long codigoPlano : codigoPn) {

			Date dataCota = buscarDataCota(codigoPt, codigoPlano);

			Participante participante = this.participanteBO.consultarParticipantePorCodigo(codigoPt);

			PlanoPrevidencia planoPrevidencia = this.planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(codigoPlano);

			ParticipantePlano participantePlano = this.participantePlanoBO.consultparPorParticipanteEPlano(participante, planoPrevidencia);

			ResponseEntity<String> jsonCalculoDevolucao = this.calcularDevolucaoWs(codigoPt, codigoPlano, codigoTDev, UtilJava.formataDataPorPadrao(new Date(), "dd/MM/yyyy"), "R", "S", 1, UtilJava
					.formataDataPorPadrao(dataCota, "dd/MM/yyyy"), "F", codigoUsuario);

			Gson gsonRetorno = new GsonBuilder().create();

			Type retornoCalculoDevolucaoDTOListType = new TypeToken<List<RetornoCalculoDevolucaoDTO>>() {
			}.getType();
			RetornoCalculoDevolucaoDTO calculoDevolucaoDTO = new RetornoCalculoDevolucaoDTO();
			//RetornoCalculoDevolucaoDTO calculoDevolucaoDTO = gsonRetorno.fromJson(jsonCalculoDevolucao.getBody(), RetornoCalculoDevolucaoDTO.class);
			List<RetornoCalculoDevolucaoDTO> listaCalculoDevolucaoDTO = gsonRetorno.fromJson(jsonCalculoDevolucao.getBody(), retornoCalculoDevolucaoDTOListType);
			if (UtilJava.isColecaoDiferenteDeVazia(listaCalculoDevolucaoDTO)) {
				/* Codigo provisorio
				 * Quando o participante não for definitivo, mostrar os valores para tributação Regressiva
				 * */
				if (participantePlano.getTipoRegimeTributacao().getCodigo().equalsIgnoreCase("N") ) {
					calculoDevolucaoDTO = listaCalculoDevolucaoDTO.stream()
							.filter(e -> e.getIndicativoTipoImposto().equalsIgnoreCase("R"))
							.findFirst()
							.orElse(null);
				}else {

					calculoDevolucaoDTO = listaCalculoDevolucaoDTO.stream()
							.filter(e -> e.getIndicativoTipoImposto().equalsIgnoreCase(participantePlano.getTipoRegimeTributacao().getCodigo()))
							.findFirst()
							.orElse(null);

				}
			}
			if (calculoDevolucaoDTO != null) {
				RelatorioSimulacaoResgateDTO simulacaoResgateDTO = new RelatorioSimulacaoResgateDTO();

				Date ultimoLancamentoEmFicha = this.historicoFinanceiroPagoBO.pesquisarDataUltimoLancamentoEmFicha(participantePlano);

				simulacaoResgateDTO.setNomePlano(planoPrevidencia.getNomePlano());
				simulacaoResgateDTO.setNomeParticipante(participante.getNomeParticipante());
				simulacaoResgateDTO.setMatriculaParticipante(participante.getNumeroMatriculaPatrocinadora());
				simulacaoResgateDTO.setSituacaoPlano(participantePlano.getSituacaoParticipantePlano().getDescricaoSituacao());
				simulacaoResgateDTO.setIndicadorFundador(participantePlano.getIndicadorFundador().equalsIgnoreCase("S") ? "SIM" : "NÃO");
				simulacaoResgateDTO.setTipoTributacao(participantePlano.getTipoRegimeTributacao().getDescricao());
				simulacaoResgateDTO.setDataAdmissao(participante.getDataAdmissao());
				simulacaoResgateDTO.setDataInscricaoPlano(participantePlano.getDataInscricao());
				simulacaoResgateDTO.setDataDesligamento(participante.getDataDesligamento());
				simulacaoResgateDTO.setDataCancelamentoPlano(participantePlano.getSituacaoParticipantePlano().getCodigoSituacaoParticipantePlano().equalsIgnoreCase("04") ? participantePlano
						.getDataSituacao() : null);
				simulacaoResgateDTO.setDataUltProcessoPlano(ultimoLancamentoEmFicha);
				simulacaoResgateDTO.setDataUltimoLancamento(ultimoLancamentoEmFicha);
				simulacaoResgateDTO.setSaldoResgParticipante(calculoDevolucaoDTO.getValorResgatavelParticipante());
				simulacaoResgateDTO.setPrcResgParticipante(calculoDevolucaoDTO.getPercentualParticipante() != 0D ? calculoDevolucaoDTO.getPercentualParticipante() / 100 : calculoDevolucaoDTO
						.getPercentualParticipante());
				simulacaoResgateDTO.setSaldoResgPatrocinadora(calculoDevolucaoDTO.getValorResgatavelPatrocinadora());
				simulacaoResgateDTO.setPrcResgPatrocinadora(calculoDevolucaoDTO.getPercentualPatrocinadora() != 0D ? calculoDevolucaoDTO.getPercentualPatrocinadora() / 100 : calculoDevolucaoDTO
						.getPercentualPatrocinadora());
				simulacaoResgateDTO.setValorBruto(calculoDevolucaoDTO.getValorDevolucao());
				simulacaoResgateDTO.setValorIR(calculoDevolucaoDTO.getValorImposto());
				simulacaoResgateDTO.setPrcIR(calculoDevolucaoDTO.getPercentualImposto() != 0D ? calculoDevolucaoDTO.getPercentualImposto() / 100 : calculoDevolucaoDTO.getPercentualImposto());

				simulacaoResgateDTO
						.setSaldoRemaParticicipante((calculoDevolucaoDTO.getValorRemanescenteParticipante() == null || calculoDevolucaoDTO.getValorRemanescenteParticipante().isInfinite() || calculoDevolucaoDTO
								.getValorRemanescenteParticipante().isNaN()) ? 0D : calculoDevolucaoDTO.getValorRemanescenteParticipante());

				simulacaoResgateDTO
						.setSaldoRemaPatrocinadora((calculoDevolucaoDTO.getValorRemanescentePatrocinadora() == null || calculoDevolucaoDTO.getValorRemanescentePatrocinadora().isInfinite() || calculoDevolucaoDTO
								.getValorRemanescentePatrocinadora().isNaN()) ? 0D : calculoDevolucaoDTO.getValorRemanescentePatrocinadora());

				simulacaoResgateDTO.setPrcRemaParticipante((calculoDevolucaoDTO.getPercentualRemanescenteParticipante() == null
						|| calculoDevolucaoDTO.getPercentualRemanescenteParticipante().isInfinite() || calculoDevolucaoDTO.getPercentualRemanescenteParticipante().isNaN()) ? 0D : calculoDevolucaoDTO
						.getPercentualRemanescenteParticipante() / 100);

				simulacaoResgateDTO.setPrcRemaPatrocinadora((calculoDevolucaoDTO.getPercentualRemanescentePatrocinadora() == null
						|| calculoDevolucaoDTO.getPercentualRemanescentePatrocinadora().isInfinite() || calculoDevolucaoDTO.getPercentualRemanescentePatrocinadora().isNaN()) ? 0D
						: calculoDevolucaoDTO.getPercentualRemanescentePatrocinadora() / 100);

				dataSource.add(simulacaoResgateDTO);
			}
		}

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
		String logo = context.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
		parametros.put("logo", logo);
		nomeArquivo = relatorioUtil.gerarRelatorio("simulacaoResgate", dataSource, parametros);

		arquivo = Files.readAllBytes(Paths.get(relatorioUtil.reportFile() + nomeArquivo));

		return new ResponseEntity<byte[]>(arquivo, HttpStatus.CREATED);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/extrairRelatorioSimulacaoResgatePortabilidadeWs")
	@ResponseBody
	public ResponseEntity<byte[]> extrairRelatorioSimulacaoResgatePortabilidadeWs(@RequestParam(required = false) Long codigoPt, @RequestParam(required = false) String codigoUsuario)
			throws IOException {

		Participante participante = this.participanteBO.consultarParticipantePorCodigo(codigoPt);
		List<ParticipantePlano> listaParticipantePlano = this.participantePlanoBO.listarParticipantePlanoPorParticipante(participante);

		RelatorioSimulacaoResgatePortabilidadeDTO simulacaoResgatePortabilidadeDTO = new RelatorioSimulacaoResgatePortabilidadeDTO();

		byte[] arquivo = null;

		String nomeArquivo = "";

		if (UtilJava.isColecaoDiferenteDeVazia(listaParticipantePlano)) {
			//Informações pessoiasi
			simulacaoResgatePortabilidadeDTO.setMatriculaParticipante(participante.getNumeroMatriculaPatrocinadora());
			simulacaoResgatePortabilidadeDTO.setNomePatrocinadora(participante.getEntidadeParticipante().getNomeAbreviadoEntidadeParticipante());
			simulacaoResgatePortabilidadeDTO.setNomeParticipante(participante.getNomeParticipante());
			simulacaoResgatePortabilidadeDTO.setDataNascimento(participante.getDataNascimento());
			simulacaoResgatePortabilidadeDTO.setDataObito(participante.getDataObito());
			simulacaoResgatePortabilidadeDTO.setEstadoCivil(participante.getEstadoCivil() != null ? participante.getEstadoCivil().getDescricao() : null);
			simulacaoResgatePortabilidadeDTO.setSexo(participante.getDescricaoSexo());
			simulacaoResgatePortabilidadeDTO.setNacionalidade(participante.getNacionalidade() != null ? participante.getNacionalidade().getDescricao() : null);

			simulacaoResgatePortabilidadeDTO.setNomePai(participante.getNomePai());
			simulacaoResgatePortabilidadeDTO.setIdentidade(participante.getNumeroIdentidade());
			simulacaoResgatePortabilidadeDTO.setDataEmissaoIdentidade(participante.getDataEmissaoIdentidade());
			simulacaoResgatePortabilidadeDTO.setNomeMae(participante.getNomeMae());
			simulacaoResgatePortabilidadeDTO.setCpf(UtilJava.formataCPF(participante.getCpf()));
			simulacaoResgatePortabilidadeDTO.setEmail(participante.getEnderecoEmail() != null ? participante.getEnderecoEmail() : participante.getEnderecoEmailSec() != null ? participante
					.getEnderecoEmailSec() : null);

			//Informações de endereço
			simulacaoResgatePortabilidadeDTO.setEnderecoLogradouro(participante.getEnderecoLogradouro());
			simulacaoResgatePortabilidadeDTO.setEnderecoNumero(participante.getNumeroLogradouro() != null ? participante.getNumeroLogradouro().toString() : null);
			simulacaoResgatePortabilidadeDTO.setEnderecoComplemento(participante.getEnderecoComplementoLogrd());
			simulacaoResgatePortabilidadeDTO.setEnderecoBairro(participante.getEnderecoBairro());
			simulacaoResgatePortabilidadeDTO.setEnderecoCidade(participante.getNomeCidade());
			simulacaoResgatePortabilidadeDTO.setEnderecoCEP(participante.getCepFormatado());
			simulacaoResgatePortabilidadeDTO.setEnderecoUF(participante.getEnderecoUnidadeFederativa() != null ? participante.getEnderecoUnidadeFederativa().getCodigo() : null);

			//Informações bancárias
			if (participante.getAgenciaBancaria() != null) {
				BancoDTO banco = this.bancoBO.pesquisarBanco(participante.getAgenciaBancaria().getChavePrimaria().getCodigoBanco());
				simulacaoResgatePortabilidadeDTO.setBanco(banco.getNomeBanco());
				simulacaoResgatePortabilidadeDTO.setAgencia(participante.getAgenciaBancaria().getNumeroAgencia()
						+ (participante.getAgenciaBancaria().getDigitoAgencia() != null ? "-" + participante.getAgenciaBancaria().getDigitoAgencia() : ""));
			} else {
				simulacaoResgatePortabilidadeDTO.setBanco(null);
				simulacaoResgatePortabilidadeDTO.setAgencia(null);
			}

			simulacaoResgatePortabilidadeDTO.setConta(participante.getNumeroContaCorrenteFormatado());
			simulacaoResgatePortabilidadeDTO.setTipoConta(participante.getIndicadorTipoConta());

			//Informações do empregador
			simulacaoResgatePortabilidadeDTO.setDataAdmissao(participante.getDataAdmissao());
			simulacaoResgatePortabilidadeDTO.setDataDesligamento(participante.getDataDesligamento());
			simulacaoResgatePortabilidadeDTO.setSituacaoEmpresa(participante.getSituacaoParticipante().getDescricaoSituacao());
			simulacaoResgatePortabilidadeDTO.setDataSituacaoEmpresa(participante.getDataSituacaoParticipante());
			simulacaoResgatePortabilidadeDTO.setMotivoDesligamento(participante.getMotivoDesligamento() != null ? participante.getMotivoDesligamento().getDescricaoMotivoDesligamento() : null);

			//Informações dos planos

			List<DadosPlanoResgatePortabilidadeDTO> listaDadosPlanoResgatePortabilidade = new ArrayList<DadosPlanoResgatePortabilidadeDTO>();
			for (ParticipantePlano pp : listaParticipantePlano) {

				DadosPlanoResgatePortabilidadeDTO dadosPlano = new DadosPlanoResgatePortabilidadeDTO();
				dadosPlano.setNomePlano(pp.getPlanoPrevidencia().getNomeAbreviadoPlano());
				dadosPlano.setDataSituacaoPlano(pp.getDataSituacao());
				dadosPlano.setSituacaoPlano(pp.getSituacaoParticipantePlano().getDescricaoSituacao());
				dadosPlano.setDataInscricao(pp.getDataInscricao());
				dadosPlano.setFundadorPlano(pp.getIndicadorFundador().equalsIgnoreCase("S") ? "SIM" : "NÃO");
				dadosPlano.setTipoTributacao(pp.getTipoRegimeTributacao().getDescricao());

				Date dataCota = buscarDataCota(codigoPt, pp.getPlanoPrevidencia().getCodigo());

				//Calculo Resgate caso possua código padrão
				if (pp.getPlanoPrevidencia().getTipoResgatePadrao() != null) {
					Long codigoResgate = pp.getPlanoPrevidencia().getTipoResgatePadrao();

					if (participante != null && participante.getDataObito() != null) {
						codigoResgate = 2L;
					}
					String resumoResgate = this.extrairResumoDevolucao(codigoPt, pp.getPlanoPrevidencia().getCodigo(), codigoResgate, "R", dataCota, codigoUsuario);

					dadosPlano.setResumoResgate(resumoResgate);

				} else {
					dadosPlano.setResumoResgate("Participante não possui direito a Resgate. Favor verificar junto a GESEG.");
				}

				if (pp.getPlanoPrevidencia().getTipoPortabilidadePadrao() != null) {
					String resumoPortabilidade = this.extrairResumoDevolucao(
							codigoPt,
							pp.getPlanoPrevidencia().getCodigo(),
							pp.getPlanoPrevidencia().getTipoPortabilidadePadrao(),
							"P",
							dataCota,
							codigoUsuario);

					dadosPlano.setResumoPortabilidade(resumoPortabilidade);
				} else {
					dadosPlano.setResumoPortabilidade("Participante não possui direito a Portabilidade. Favor verificar junto a GESEG.");
				}

				listaDadosPlanoResgatePortabilidade.add(dadosPlano);

			}

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
			parametros.put("listaDevolucaoPlanos", listaDadosPlanoResgatePortabilidade);

			String logo = context.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
			parametros.put("logo", logo);

			List<RelatorioSimulacaoResgatePortabilidadeDTO> dataSource = new ArrayList<RelatorioSimulacaoResgatePortabilidadeDTO>();
			dataSource.add(simulacaoResgatePortabilidadeDTO);

			nomeArquivo = relatorioUtil.gerarRelatorio("resgatePortabilidade", dataSource, parametros);
		}

		arquivo = Files.readAllBytes(Paths.get(relatorioUtil.reportFile() + nomeArquivo));

		return new ResponseEntity<byte[]>(arquivo, HttpStatus.CREATED);
	}

	private String extrairResumoDevolucao(Long codigoPt, Long codigoPn, Long codTipDev, String tipDev, Date dataCota, String codigoUsuario) {
		ResponseEntity<String> jsonCalculoDevolucao = this.calcularDevolucaoWs(codigoPt, codigoPn, codTipDev, UtilJava.formataDataPorPadrao(new Date(), "dd/MM/yyyy"), tipDev, "S", 1, UtilJava
				.formataDataPorPadrao(dataCota, "dd/MM/yyyy"), "F", codigoUsuario);

		Gson gsonRetorno = new GsonBuilder().create();

		RetornoCalculoDevolucaoDTO calculoDevolucaoDTO = gsonRetorno.fromJson(jsonCalculoDevolucao.getBody(), RetornoCalculoDevolucaoDTO.class);

		String resumoDevolucao = "";

		if (calculoDevolucaoDTO != null) {
			resumoDevolucao = "Reserva Participante a " + (tipDev.equals("R") ? "Resgatar " : "Portar ") + UtilJava.formataNumero(calculoDevolucaoDTO.getPercentualParticipante(), 2) + " %: R$ "
					+ UtilJava.formataNumero(calculoDevolucaoDTO.getValorResgatavelParticipante(), 2) + "\n";

			resumoDevolucao += "Reserva Patrocinadora a " + (tipDev.equals("R") ? "Resgatar " : "Portar ") + UtilJava.formataNumero(calculoDevolucaoDTO.getPercentualPatrocinadora(), 2) + " %: R$ "
					+ UtilJava.formataNumero(calculoDevolucaoDTO.getValorResgatavelPatrocinadora(), 2) + "\n\n";

			resumoDevolucao += "Valor BRUTO " + (tipDev.equals("R") ? "do RESGATE: " : "da PORTABILIDADE: ") + "R$ " + UtilJava.formataNumero(calculoDevolucaoDTO.getValorDevolucao(), 2) + "\n\n";

			resumoDevolucao += "Valor Imposto Sobre " + (tipDev.equals("R") ? "RESGATE: " : "PORTABILIDADE: ") + "R$ " + UtilJava.formataNumero(calculoDevolucaoDTO.getValorImposto(), 2) + "\n";

			resumoDevolucao += "Valor LÍQUIDO " + (tipDev.equals("R") ? "do RESGATE: " : "da PORTABILIDADE: ") + "R$ "
					+ UtilJava.formataNumero(calculoDevolucaoDTO.getValorDevolucao() - calculoDevolucaoDTO.getValorImposto(), 2);

		}

		return resumoDevolucao;
	}

	public Date buscarDataCota(Long codigoPt, Long codigoPn) {
		try {
			Participante participante = new Participante();
			participante = this.participanteBO.consultarParticipantePorCodigo(codigoPt);

			PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();
			planoPrevidencia = this.planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(codigoPn);

			ParticipantePlano participantePlano = new ParticipantePlano();

			participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(participante, planoPrevidencia);

			ValorCotaPlano valorCotaPlano = new ValorCotaPlano();

			valorCotaPlano = valorCotaPlanoBO.pesquisarCotaParticipantePlano(new Date(), participantePlano);

			if (valorCotaPlano == null) {
				return new Date();
			} else {
				return valorCotaPlano.getChavePrimaria().getDataPosicaoCota();
			}

		} catch (Exception e) {
			return new Date();
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional
	@Async
	public Future<List<ReferenciaCalculoDevPosicionadoValores>> calculoDevolucaoAssincronoDados(List<ParticipanteDevolucaoPosicionadaDTO> listaParticipante, final LoteProcessamentoReferenciaCalcDevolucao lote,
																								final ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado, final LoginBBPrevWebDTO loginBBPrevWebDTO) throws PrevidenciaException, Exception {

		int totalResto = listaParticipante.size() % TOTAL_THEARD;

		final ExecutorService pool = Executors.newFixedThreadPool(TOTAL_THEARD);
		try {

			List<Future<ExecutionSummary>> summariesToBeGet = new ArrayList<Future<ExecutionSummary>>();

			int numberOfElementsPerList = ( listaParticipante.size() / TOTAL_THEARD );
			int iniPos = 0;
			for (int i = 0; i < TOTAL_THEARD; i++) {

				int numeroAtualizacao = 0;
				if (totalResto > 0){
					numeroAtualizacao = numberOfElementsPerList + 1;
					totalResto--;
				}else{
					numeroAtualizacao = numberOfElementsPerList;
				}

				final List<ParticipanteDevolucaoPosicionadaDTO> subList = listaParticipante.subList(iniPos,
						iniPos + numeroAtualizacao);

				Future<ExecutionSummary> future = pool.submit(new Callable<ExecutionSummary>() {

					@Override
					public ExecutionSummary call() throws Exception {
						List<TransactionParticipanteCalculo> listaNova = new ArrayList<>();
						Long count = 0L;
						for (ParticipanteDevolucaoPosicionadaDTO participanteDevolucaoPosicionadaDTO : subList) {
							listaNova.add(
									new TransactionParticipanteCalculo(++count, participanteDevolucaoPosicionadaDTO,
											referenciaCalculoDevolucaoPosicionado, loginBBPrevWebDTO, lote));
						}

						ExecutionSummary exec = new ExecutionSummary();
						for (TransactionParticipanteCalculo transactionParticipanteCalculo : listaNova) {
							ReferenciaCalculoDevPosicionadoValores ref = transactionParticipanteCalculo.process();
							exec.addListaReferencia(ref);
						}

						return exec;
					}
				});

				iniPos += numeroAtualizacao;
				summariesToBeGet.add(future);
			}

			List<ReferenciaCalculoDevPosicionadoValores> lista = new ArrayList<ReferenciaCalculoDevPosicionadoValores>();

			for (Future<ExecutionSummary> futureSummary : summariesToBeGet) {
				lista.addAll(futureSummary.get().getLista());

			}

			//Lista objetos sem erro
			List<MensagemLoteProcessamentoRefCalcDevolucao> listaErros = pesquisarErrosCalculo(lista);

			//Lista objetos sem erro
			lista = (List<ReferenciaCalculoDevPosicionadoValores>) CollectionUtils.select(lista, new Predicate() {

				@Override
				public boolean evaluate(Object object) {
					ReferenciaCalculoDevPosicionadoValores ref = (ReferenciaCalculoDevPosicionadoValores) object;
					// TODO Auto-generated method stub
					return (ref != null && ref.getMensagem() == null);
				}
			});

			// manda salvar toda lista em banco de dados
			this.referenciaCalculoDevPosicionadoValoresBO.salvarListaMovimentoCalculoPagamentoDevolucaoBatch(lista);

			if (UtilJava.isColecaoDiferenteDeVazia(listaErros)){
				this.mensagemLoteProcessamentoRefCalcDevolucaoBO.salvarInBatchMensagemLoteProcessamentoRefCalcDevolucao(listaErros);
			}

			enviarEmail(listaParticipante, lista);

			return (Future<List<ReferenciaCalculoDevPosicionadoValores>>) lista;

		} catch (Exception e) {
			log.error(e);
			System.out.println(e.getMessage());
		}finally {
			pool.shutdown();
		}

		return null;
	}

	private void enviarEmail(List<ParticipanteDevolucaoPosicionadaDTO> listaParticipante, List<ReferenciaCalculoDevPosicionadoValores> lista) throws EmailException {

		String textoEmail = "Prezados (a), <br /><br />";
		textoEmail += "Total registros processados posicionados calculados: <strong>" + listaParticipante.size() + "</strong> <br />";
		textoEmail += "Total resgates posicionados calculados com exito: <strong>" + lista.size() + "</strong> <br />";

		if ((listaParticipante.size() - lista.size()) > 0) {
			textoEmail += "Total de Registros com Erro: <strong>" + (listaParticipante.size() - lista.size()) + "</strong> <br />";
		}

		String[] destinatario = { "resgates@bbprevidencia.com.br" };

		String assunto = "Cálculo Resgates Posicionados";

		this.emailServico.enviarEmail(destinatario, assunto, textoEmail);
	}

	@SuppressWarnings("unchecked")
	private List<MensagemLoteProcessamentoRefCalcDevolucao> pesquisarErrosCalculo(List<ReferenciaCalculoDevPosicionadoValores> listaCalculo){

		List<ReferenciaCalculoDevPosicionadoValores> listaFiltrada = (List<ReferenciaCalculoDevPosicionadoValores>) CollectionUtils.select(listaCalculo, new Predicate() {

			@Override
			public boolean evaluate(Object object) {
				ReferenciaCalculoDevPosicionadoValores ref = (ReferenciaCalculoDevPosicionadoValores) object;
				// TODO Auto-generated method stub
				return (ref != null && ref.getMensagem() != null);
			}
		});

		List<MensagemLoteProcessamentoRefCalcDevolucao> listaErros = new ArrayList<>();

		for (ReferenciaCalculoDevPosicionadoValores referenciaCalculoDevPosicionadoValores : listaFiltrada) {
			listaErros.add(referenciaCalculoDevPosicionadoValores.getMensagem());
		}

		return listaErros;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/relatorioHistoricoPagamentosFichaDevolucao", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> relatorioHistoricoPagamentosFichaDevolucao(@RequestBody EntidadeDTO beneficioDTO) throws IOException {
		try {
			List<RelatorioHistoricoPagamentosFichaDevolucaoDTO> listaRetono = this.historicoPagamentoDevolucaoBO.extrairRelatorioHistoricoPagamentosFichaDevolucao(beneficioDTO.getCodigoEntidade());

			String nomeArquivo = "";
			String relatorioBase64 = "";

			if (UtilJava.isColecaoDiferenteDeVazia(listaRetono)) {
				ParticipantePlano participantePlano = this.participantePlanoBO.consultarParticipantePlanoPorCodigo(listaRetono.get(0).getCodigoParticipantePlano());
				Date dataInicio = listaRetono.stream()
						.min(Comparator.comparing(RelatorioHistoricoPagamentosFichaDevolucaoDTO::getDataCota))
						.orElse(null).getDataCota();

				Date dataFim  = listaRetono.stream()
						.max(Comparator.comparing(RelatorioHistoricoPagamentosFichaDevolucaoDTO::getDataCota))
						.orElse(null).getDataCota();

				List<ValorCotaPlano> listaValorCotaPlano = this.valorCotaPlanoBO.listarCotaPlanoPorEmpresaPlanoPerfil(
						participantePlano.getParticipante().getEntidadeParticipante(),
						participantePlano.getPlanoPrevidencia(),
						participantePlano.getListaModalidadePerfil().get(0).getChavePrimaria().getPerfilInvestimento(),
						dataInicio,
						dataFim);


				Double valorAcumulado = 0D;
				for (RelatorioHistoricoPagamentosFichaDevolucaoDTO item : listaRetono) {

					if (participantePlano.getCodigo().compareTo(item.getCodigoParticipantePlano()) != 0) {
						participantePlano = this.participantePlanoBO.consultarParticipantePlanoPorCodigo(item.getCodigoParticipantePlano());
					}

					//ValorCotaPlano valorCotaPlano = this.valorCotaPlanoBO.pesquisarCotaParticipantePlano(item.getDataCota(), participantePlano);

					ValorCotaPlano valorCotaPlano = listaValorCotaPlano.stream()
							.filter(e -> dateToLocalDate(e.getChavePrimaria().getDataPosicaoCota()).isEqual(dateToLocalDate(item.getDataCota())))
							.findFirst().orElse(null);

					if (valorCotaPlano != null) {
						item.setValorCota(valorCotaPlano.getValorCota().doubleValue());
						item.setValorReais(UtilJava.arredondaNumero(item.getQtdCotaUtil() * valorCotaPlano.getValorCota().doubleValue(), 2));
						valorAcumulado += item.getQtdCotaUtil();
						Double total = item.getQtdTotalAmaior() > 0D ? item.getQtdTotalAmaior() : item.getQtdTotal();
						item.setSaldoAtualCotas(total - valorAcumulado);
					}

				}

				Double valorUltimoPgto =  listaRetono.stream()
						.max((r1, r2) ->  r1.getDataCreditoBancario().compareTo(r2.getDataCreditoBancario())) //filtra pela maior data de credito bancario
						.get().getValorReais();

				listaRetono.stream().forEach(r -> r.setValorUltimoPgto(valorUltimoPgto));

				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = context.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

				log.info(logo);

				parametros.put("logo", logo);

				nomeArquivo = relatorioUtil.gerarRelatorio("historicoPagamentosFichaDevolucao", listaRetono, parametros);

				relatorioBase64 = Base64.encodeBase64String(Files.readAllBytes(Paths.get(relatorioUtil.reportFile() + nomeArquivo)));

			}

			return ResponseEntity.status(HttpStatus.OK).body(relatorioBase64);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	@PostMapping(value = "/beneficioVerificado", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> beneficioVerificado(@RequestBody EntidadeDTO participante) {
		BeneficioVerificadoDTO beneficioVerificadoDTO = new BeneficioVerificadoDTO();
		beneficioVerificadoDTO.setBeneficioVerificado("N");

		try {
			List<BeneficioVerificadoDTO> listaBeneficio = new ArrayList<BeneficioVerificadoDTO>();

			listaBeneficio = this.concessaoBeneficioBO.listarBeneficioPorCodigoParticipante(participante.getCodigoEntidade());

			for (BeneficioVerificadoDTO obj : listaBeneficio) {
				if (obj.getBeneficioVerificado().equalsIgnoreCase("S")) {
					beneficioVerificadoDTO = obj;
					break;
				}
				beneficioVerificadoDTO = obj;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}

		Gson gsonRetorno = new GsonBuilder().create();

		String objToJSONRetorno = gsonRetorno.toJson(beneficioVerificadoDTO, BeneficioVerificadoDTO.class);

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_JSON);

		return new ResponseEntity<String>(objToJSONRetorno, responseHeaders, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/relatorioComprovanteRendimentos", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> relatorioComprovanteRendimentos(HttpServletRequest req) {
		try {
			String nomeArquivo = "";
			String relatorioBase64 = "";

			Gson gson = new Gson();
			RecebedorConsultaDTO recebedor = gson.fromJson(req.getReader(), RecebedorConsultaDTO.class);

			if (BloqueioInformeRedimentoEnum.isCpfBloqueado(recebedor.getCpf(), recebedor.getAno())) {
				throw new PrevidenciaException("CPF Bloqueado para emitir informe de rendimentos no ano especifivcado.");
			}

			String lote = this.loteProcessamentoFirfBO.pesquisarUltimoLoteProcessadoDirfPorAno(recebedor.getAno());

			List<ComprovanteRendimentosJasperDTO> listaInforme = this.relatorioComprovanteRendimentoBO.retornaListaComprovanteRendimentos(null, null, null, recebedor.getCpf(), null, lote);

			if (UtilJava.isColecaoDiferenteDeVazia(listaInforme)) {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

				String logo = context.getRealPath("imagens/brasao-brasil-gray.png");
				parametros.put("logo", logo);
				parametros.put("anoCalendario", listaInforme.get(0).getAnoCalendario());
				parametros.put("anoExercicio", Long.parseLong(listaInforme.get(0).getAnoCalendario()) + 1);
				parametros.put("dataAtual", UtilJava.formataDataPorPadrao(new Date(), "dd/MM/yyyy"));

				nomeArquivo = relatorioUtil.gerarRelatorio("comprovanteRendimentos", listaInforme, parametros);

				relatorioBase64 = Base64.encodeBase64String(Files.readAllBytes(Paths.get(relatorioUtil.reportFile() + nomeArquivo)));
			}

			return ResponseEntity.status(HttpStatus.OK).body(relatorioBase64);

		} catch (PrevidenciaException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	public static LocalDate dateToLocalDate(Date date) {
		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
	}

	@PostMapping(value = "/extrato-previdenciario", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> extratoPrevidenciarioPdf(@RequestBody ExtratoPrevRequestDTO request) {
		try {
			ProcessoExtratoPrevidenciarioVisao processoExtratoController = AppContext.getApplicationContext().getBean(ProcessoExtratoPrevidenciarioVisao.class);

			String reportName = processoExtratoController.exportarRelatorioExtratoToApi(request);

			String relatorioBase64 = Base64.encodeBase64String(Files.readAllBytes(Paths.get(relatorioUtil.reportFile() + reportName)));

			return ResponseEntity.status(HttpStatus.OK).body(relatorioBase64);

		} catch (Exception e) {
			log.error(e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao gerar Extrato Previdenciário");

		}
	}

	@PostMapping(value = "/regra-calculo-devolucao", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<RegraCalculoDevolucaoDTO>> retornarRegraRegraCalculoDevolucao(@RequestBody RegraCalculoRequestDTO requestRegraCalculo){
		try {
			List<RegraCalculoDevolucao> listaRegraVigente = this.regraCalculoDevolucaoBO.listarRegraCalculoDevolucaoVigentePorPlanoETipo(requestRegraCalculo);

			List<RegraCalculoDevolucaoDTO> responseRegraCalculoDevolucao = new ArrayList<>();

			responseRegraCalculoDevolucao = listaRegraVigente.stream()
					.map(e -> {
						ModelMapper modelMapper = new ModelMapper();
						modelMapper.getConfiguration().setAmbiguityIgnored(true);

						RegraCalculoDevolucaoDTO retorno = modelMapper.map(e, RegraCalculoDevolucaoDTO.class);

						return retorno;
					})
					.collect(Collectors.toList());


			return ResponseEntity.status(HttpStatus.OK).body(responseRegraCalculoDevolucao);

		} catch (Exception e) {
			log.error(e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());

		}
	}

	@PostMapping(value = "/criar-processo-devolucao", produces = MediaType.APPLICATION_JSON_VALUE)
	@Transactional(rollbackFor = { PrevidenciaException.class, Exception.class })
	public ResponseEntity<InserirDevolucaoResponseDTO> criarProcessoDevolucao(@RequestBody InserirDevolucaoRequestDTO request){
		InserirDevolucaoResponseDTO response = new InserirDevolucaoResponseDTO();
		try {
			Date dtCota = new Date();

			if (!request.getFormaPagamentoRemanescente().equals("F") && !request.getFormaPagamentoRemanescente().equals("V")) {
				throw new PrevidenciaException("Tipo de forma de pagamento de remanescente não suportado.");
			}

			Participante participante = new Participante();
			//Verificando participante.
			if (!this.participanteBO.existeParticipantePorId(request.getCodigoParticipante())) {
				throw new PrevidenciaException("Participante não encontrado.");
			}

			participante.setCodigo(request.getCodigoParticipante());

			PlanoPrevidencia planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(request.getCodigoPlano());

			if (planoPrevidencia == null) {
				throw new PrevidenciaException("Plano não encontrado.");
			} else {
				List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();

				listaRegraCalculoDevolucao = regraCalculoDevolucaoBO.listarTodosRegraCalculoDevolucaoSitEmProducaoVigenteHojePorPlanoPrevidencia(planoPrevidencia);

				if (listaRegraCalculoDevolucao.size() == 0) {
					throw new PrevidenciaException("O plano não possui regra devolução vigente.");
				} else {
					boolean achouRegra = false;
					RegraCalculoDevolucao regraCalculoDevolucao = listaRegraCalculoDevolucao.stream()
							.filter(e -> e.getTipoDevolucao().getCodigo().equals(request.getCodigoTipoDevolucao()))
							.findFirst().orElse(null);

					achouRegra = regraCalculoDevolucao != null;

					if (regraCalculoDevolucao != null && !regraCalculoDevolucao.getTipoDevolucao().getIndicadorTipoDevolucao().equals(request.getIndicadorTipoDevolucao())) {
						throw new PrevidenciaException("Tipo de devolução diferente do indicativo.");
					}

					if (!achouRegra) {
						throw new PrevidenciaException("O plano não possui regra deste tipo devolução vigente.");
					}

				}
			}

			//Se participante existe e plano tb.
			ParticipantePlano participantePlano = new ParticipantePlano();
			participantePlano = participantePlanoBO.consultparPorParticipanteEPlano(participante, planoPrevidencia);

			if (participantePlano == null) {
				throw new PrevidenciaException("Participante não participa do plano informado.");
			}

			String opcaoTributacao = participantePlano.getTipoRegimeTributacao().getCodigo();

			if (opcaoTributacao == null) {
				throw new PrevidenciaException("Opção de tributação não encontrada.");
			}

			ValorCotaPlano valorCotaPlano = valorCotaPlanoBO.pesquisarCotaParticipantePlano(dtCota, participantePlano);

			if (valorCotaPlano == null) {
				throw new PrevidenciaException("Cota não encontrada para parâmetros informados.");
			}

			//Verificação de a cota retornou na mesma data
			if (!UtilJava.getDataPura(valorCotaPlano.getChavePrimaria().getDataPosicaoCota()).equals(UtilJava.getDataPura(dtCota))) {
				throw new PrevidenciaException("Cota não encontrada para data informada.");
			}

			ApplicationContext ctx = AppContext.getApplicationContext();
			CalculoDevolucaoBO calculoDevolucao = ctx.getBean(CalculoDevolucaoBO.class);

			//Tenta calcular.
			DevolucaoCompletoDTO devolucaoCompletoDTO = new DevolucaoCompletoDTO();
			devolucaoCompletoDTO = calculoDevolucao.calcularDevolucao(
					request.getCodigoParticipante(),
					request.getCodigoPlano(),
					request.getCodigoTipoDevolucao(),
					request.getDataRequerimento(),
					request.getIndicadorTipoDevolucao(),
					"S",
					request.getQuantidadeParcelas(),
					request.getDataCota(),
					request.getFormaPagamentoRemanescente(),
					"7lVtRpitgIjhJtodRgA8zg",
					100D,
					0D,
					opcaoTributacao);

			if (request.getIndicadorTipoDevolucao().equals("R")) {
				devolucaoCompletoDTO.getDevolucao().setIndicadorDevolucaoInterna(1);
			} else if (request.getIndicadorTipoDevolucao().equals("P")) {
				devolucaoCompletoDTO.getDevolucao().setIndicadorDevolucaoInterna(request.isPortabilidadePenseFuturo() ? 4 : 2);
			}

			//Processar inserção do processo de devolução
			this.calculoDevolucao.salvarDevolucao(devolucaoCompletoDTO);

			//Criar documentos de devolução
			this.documentoDevolucaoVisaoItemBO.gerarDocumentosDevolucao(devolucaoCompletoDTO.getDevolucao());

			//Se for portabilidade, fazer apontamento da portabilidade
			if (devolucaoCompletoDTO.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().isPortabilidade()) {
				AtuacaoPessoaPK chavePrimariaAP = new AtuacaoPessoaPK();
				chavePrimariaAP.setCodigo(request.isPortabilidadePenseFuturo() ? 1246L : request.getDetalhePortabilidade().getCodigoPessoaEntidadeDestino());
				chavePrimariaAP.setCodigoAreaAtuacao("7");

				AtuacaoPessoa atuacaoPessoa = new AtuacaoPessoa();
				atuacaoPessoa.setChavePrimaria(chavePrimariaAP);

				TipoPlanoDestinoPortabilidadeDevolucao tipoPlanoDestinoPortabilidade = new TipoPlanoDestinoPortabilidadeDevolucao();
				tipoPlanoDestinoPortabilidade.setCodigo(request.isPortabilidadePenseFuturo() ? 1L : request.getDetalhePortabilidade().getTipoPlanoDestinoPortabilidade());

				DetalhePortabilidadeDevolucao detalhePortabilidadeDevolucao = new DetalhePortabilidadeDevolucao();
				detalhePortabilidadeDevolucao.setDevolucao(devolucaoCompletoDTO.getDevolucao());
				detalhePortabilidadeDevolucao.setAtuacaoPessoa(atuacaoPessoa);
				detalhePortabilidadeDevolucao.setTipoPlanoDestinoPortabilidadeDevolucao(tipoPlanoDestinoPortabilidade);
				detalhePortabilidadeDevolucao.setNomePlanoDestino(request.isPortabilidadePenseFuturo() ? "PLANO PENSE FUTURO" : request.getDetalhePortabilidade().getNomePlanoDestino());
				detalhePortabilidadeDevolucao.setCodigoParticEntidadeDestino(request.getDetalhePortabilidade().getCodigoParticipanteEntidadeDestino());
				detalhePortabilidadeDevolucao.setCodigoPlanoEntidadeDestino(request.isPortabilidadePenseFuturo() ? "2019000865" : request.getDetalhePortabilidade().getCodigoPlanoEntidadeDestino());
				detalhePortabilidadeDevolucao.setDataAdesaoPlanoDestino(request.getDetalhePortabilidade().getDataAdesaoPlanoDestino());
				detalhePortabilidadeDevolucao.setIndicadorOpcaoImpostoRendaDestino(request.getDetalhePortabilidade().getIndicadorOpcaoImpostoRendaDestino());

				if (request.isPortabilidadePenseFuturo()) {
					PlanoPrevidencia plano = new PlanoPrevidencia();
					plano.setCodigo(135L);
					detalhePortabilidadeDevolucao.setPlanoPrevidencia(plano);
				}

				this.detalhePortabilidadeDevolucaoBO.salvarDetalhePortabilidadeDevolucao(detalhePortabilidadeDevolucao);

			}

			response.setCodigoProcessoDevolucao(devolucaoCompletoDTO.getDevolucao().getCodigo());


		} catch (PrevidenciaException pe) {
			log.error(pe);
			response.setMensagemErro(pe.getMessage());
		} catch (Exception e) {
			log.error(e);
			response.setMensagemErro("Erro ao gerar o processo de devolução");
		}

		return ResponseEntity.ok(response);
	}

	@PutMapping(value = "/alterar-situacao-devolucao", produces = MediaType.APPLICATION_JSON_VALUE)
	@Transactional(rollbackFor = { PrevidenciaException.class, Exception.class })
	public ResponseEntity<Object> alterarSituacaoDevolucao(@RequestBody SituacaoDevolucaoRequestDTO dto) {
		try {
			SituacaoDevolucao situacao = this.situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(dto.getSituacaoDevolucao());

			if (situacao == null) {
				throw new PrevidenciaException("Situação não encontrada para o código informado.");
			}

			Devolucao devolucao = this.devolucaoBO.pesquisarDevolucaoPorCodigo(dto.getCodigoDevolucao());

			if (devolucao == null)
				throw new PrevidenciaException("Devolução não encontrada para o código informado.");

			//Montando e atualizando a devolução
			devolucao.setSituacaoDevolucao(situacao);
			devolucao.setDataAlteracao(new Date());
			devolucao.setNomeUsuarioAlteracao(dto.getUsuarioAlteracao());

			this.devolucaoBO.atualizarSituacaoDevolucao(devolucao);

			//Montando e salvando o histórico da devolução
			HistoricoSituacaoDevolucao historico = new HistoricoSituacaoDevolucao();
			historico.setDevolucao(devolucao);
			historico.setSituacaoDevolucao(devolucao.getSituacaoDevolucao());
			historico.setDataCota(devolucao.getDataCota());
			historico.setDataHistorico(new Date());
			historico.setValorCota(devolucao.getValorCota());
			historico.setValorIndiceAjustado(devolucao.getValorIndiceAjustado());
			historico.setNomeUsuarioInclusao(dto.getUsuarioAlteracao());
			historico.setDataInclusao(devolucao.getDataInclusao());

			this.historicoSituacaoDevolucaoBO.salvarHistoricoSituacaoDevolucao(historico);

			//Montando e salvando a anotação da devolução
			AnotacaoDevolucao anotacao = new AnotacaoDevolucao();
			anotacao.setDevolucao(devolucao);
			anotacao.setDescricaoAnotacao("Alterado situação para: " + situacao.getNome());
			anotacao.setDataAnotacao(new Date());
			anotacao.setNomeUsuarioInclusao(dto.getUsuarioAlteracao());
			anotacao.setDataInclusao(new Date());

			this.anotacaoDevolucaoBO.salvarAnotacaoDevolucao(anotacao);

			return ResponseEntity.status(HttpStatus.OK).body("Situação da devolução atualizada com sucesso!");
		} catch (PrevidenciaException e) {
			Log.error(">>>ERRO ao tentar atualizar o status da devolução: " + e);
			throw new RuntimeException("ERRO ao tentar atualizar o status da devolução: " + e);
		}

	}

	@GetMapping(value = "/data-pagamento-devolucao/{numSeqDevolucao}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> buscarDataPagamentoDevolucao(@PathVariable Long numSeqDevolucao) {
		try {
			return ResponseEntity.status(HttpStatus.OK).body(devolucaoBO.dataPagamentoDevolucao(numSeqDevolucao));
		} catch (PrevidenciaException e) {
			Log.error(">>>ERRO ao tentar buscar data de pagamento da devolução: " + e);
			throw new RuntimeException("ERRO ao tentar buscar data de pagamento da devolução: " + e);
		}

	}
}
