package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.cadastroweb.servico.EmailServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoDetalheImpostoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.CloudDocsDTO;
import br.com.bbprevidencia.devolucao.dto.ConferenciaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   24/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("processoConferenciaVisao")
public class ProcessoConferenciaVisao {

	private static String FW_PROCESSO_CONFERENCIA = "/paginas/processoConferencia.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final Logger log = Logger.getLogger(ProcessoConferenciaVisao.class);

	@Autowired
	private DevolucaoBO devolucaoBO;
	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;
	@Autowired
	private ParametroGeralBO parametroGeralBO;
	@Autowired
	private AmbienteServico ambienteServico;
	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;
	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;
	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;
	@Autowired
	private ParcelaContaDevolucaoDetalheImpostoBO detalheImpostoBO;
	@Autowired
	private EmailServico emailServico;

	private List<Devolucao> listaDevolucao;
	private List<Devolucao> listaDevolucaoSelecionadas;

	private List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTO = new ArrayList<ConferenciaDevolucaoDTO>();
	private List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTOSelecionados = new ArrayList<ConferenciaDevolucaoDTO>();
	private ConferenciaDevolucaoDTO linhaConferenciaDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean listarStatus;
	private SituacaoDevolucao situacaoDevolucao;

	//Url para redirecionamento do Cloud Docs
	//	private final String urlCloudDocs = "http://www.google.com.br";
	private CloudDocsDTO cloudDocsDTO = new CloudDocsDTO();
	private final String urlCloudDocs = cloudDocsDTO.getUrlRedirect();

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since   22/02/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoConferencia");
		} else {
			this.possuiAcessoTotal = false;
		}
		listarDevolucao();
		return FW_PROCESSO_CONFERENCIA;
	}

	/**
	 * Método encarredado por listar as devolução que estão na situação ATUALIZADO.
	 *  
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since   24/01/2017
	 * @return {@link String}
	 */
	public void listarDevolucao() {
		this.listaConferenciaDevolucaoDTO = new ArrayList<ConferenciaDevolucaoDTO>();

		List<ConferenciaDevolucaoDTO> listaConferencia = new ArrayList<ConferenciaDevolucaoDTO>();

		this.situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.ATUALIZADO.getCodigo());

		listaConferencia = this.devolucaoBO.listarDevolucaoPorSituacaoCodigoSituacao(situacaoDevolucao);
		if (UtilJava.isColecaoDiferenteDeVazia(listaConferencia)) {

			for (ConferenciaDevolucaoDTO conferencia : this.devolucaoBO.listarDevolucaoPorSituacaoCodigoSituacao(situacaoDevolucao)) {
				if (conferencia.getDevolucao().getNomeUsuarioInclusao().equals(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin())) {
					conferencia.setUsuarioRequerimento(false);
				} else {
					conferencia.setUsuarioRequerimento(true);
				}

				this.listaConferenciaDevolucaoDTO.add(conferencia);
			}
		}
		/*this.listaConferenciaDevolucaoDTO = this.devolucaoBO.listarDevolucaoPorSituacaoCodigoSituacao(situacaoDevolucao);*/
		/*this.listaDevolucao = devolucaoBO.listarDevolucaoPorSituacao(situacaoDevolucao);
		this.listaDevolucao = contaDevolucaoBO.carregarSaldoResgatavelEmListaDevolucao(this.listaDevolucao);
		 */

		this.listaConferenciaDevolucaoDTO = devolucaoBO.carregarListaRecebedoresConferencia(this.listaConferenciaDevolucaoDTO);
	}

	/**
	 * Método encarredado por atualizar a devolução, colocando em situação de CONFERIDO. 
	 *  
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since   22/02/2017
	 * @return 
	 */
	public String enviarParaConferencia() {
		try {

			if (listaConferenciaDevolucaoDTOSelecionados == null || listaConferenciaDevolucaoDTOSelecionados.size() == 0) {

				Mensagens.addMsgErro("Favor selecionar pelo menos uma devolução.");

				return FW_PROCESSO_CONFERENCIA;
			}

			//List<ConferenciaDevolucaoDTO> listaResgateMaior100000 = new ArrayList<ConferenciaDevolucaoDTO>();

			for (ConferenciaDevolucaoDTO conferenciaDevolucaoDTO : listaConferenciaDevolucaoDTOSelecionados) {

				/* Demanda 37947  - Yanisley Mora Ritchie - Enviar email resgates acima de R$ 100.000,00 
				 * Cancelado - Aguardando definição 
				if ((conferenciaDevolucaoDTO.getTotalCotas() * conferenciaDevolucaoDTO.getValorAjustado()) > 100000D
						&& conferenciaDevolucaoDTO.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorTipoDevolucao().equalsIgnoreCase("R")) {
					listaResgateMaior100000.add(conferenciaDevolucaoDTO);
				}
				 */

				Devolucao devolucaoAtualizavel = new Devolucao();
				devolucaoAtualizavel = devolucaoBO.pesquisarDevolucaoPorCodigo(conferenciaDevolucaoDTO.getDevolucao().getCodigo());

				//Busca situação para atualização de devolução enviada para deferimento.
				SituacaoDevolucao situacaoDevolucao = new SituacaoDevolucao();

				situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.CONFERIDO.getCodigo()); //CONFERENCIA

				devolucaoAtualizavel.setSituacaoDevolucao(situacaoDevolucao);
				devolucaoAtualizavel.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getIdentificacaoUsuario());
				devolucaoBO.salvarDevolucao(devolucaoAtualizavel);

				//Historico de situação.
				HistoricoSituacaoDevolucao historicoSituacaoDevolucao = new HistoricoSituacaoDevolucao();
				historicoSituacaoDevolucao = historicoSituacaoDevolucaoBO.gerarHistoricoSituacaoDevolucao(devolucaoAtualizavel);
				historicoSituacaoDevolucao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getIdentificacaoUsuario());
				historicoSituacaoDevolucaoBO.salvarHistoricoSituacaoDevolucao(historicoSituacaoDevolucao);

				//Anotação devolução
				AnotacaoDevolucao anotacaoDevolucao = new AnotacaoDevolucao();
				anotacaoDevolucao = anotacaoDevolucaoBO.gerarAnotacaoDevolucao(
						devolucaoAtualizavel,
						"Alterado situação para: " + SituacaoDevolucaoEnum.CONCEDIDO.getDescricao(),
						new Date(),
						loginTemporariaDTO);
				anotacaoDevolucaoBO.salvarAnotacaoDevolucao(anotacaoDevolucao);

			}

			/* Demanda 37947  - Yanisley Mora Ritchie - Enviar email resgates acima de R$ 100.000,00 
			 * Cancelado - Aguardando definição 
			if (UtilJava.isColecaoDiferenteDeVazia(listaResgateMaior100000)) {
				this.enviarEmailNotificacaoInvestimento(listaResgateMaior100000);
			}
			 */

			Mensagens.addMsgInfo("Devolução enviada para Envio para Deferimento.");

			listarDevolucao();

			return FW_PROCESSO_CONFERENCIA;

		} catch (Exception e) {
			log.error("Erro ao enviar para... Erro: " + e.getMessage());
			throw new PrevidenciaException("Nao foi possível realizar está operaçao", e.getMessage());
		}
	}

	/**
	 * Envia e-mail de notificação dos resgates acima de R$ 100.000,00
	 * Cancelado - Aguardando definição 
	 * @param listaResgateMaior100000
	 */
	private void enviarEmailNotificacaoInvestimento(List<ConferenciaDevolucaoDTO> listaResgateMaior100000) {
		try {
			String textoEmail = "<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>" + "<body style='background-color: #f4f4f4; font-family: arial; padding: 10px;'>"
					+ "<p>Prezado (a),</p>";
			textoEmail += "<p>Segue abaixo a lista de participantes com Resgates acima de R$ 100.000,00.</p>";

			textoEmail += "<table style='display: table; width: 100%; font-family: arial; border-collapse: collapse;'>" + "<tr style='padding: 5px; background-color: #BFC9CA;'>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>PATROCINADORA</th>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>PARTICIPANTE</th>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>MATRÍCULA</th>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>CPF</th>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>PARTE PLANO</th>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>VALOR BRUTO</th>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>VALOR IR</th>"
					+ "<th style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6; background-color: #BFC9CA;'>VALOR LÍQUIDO</th><tr>";

			for (ConferenciaDevolucaoDTO item : listaResgateMaior100000) {
				textoEmail += "<tr style='padding: 5px; text-align: left;'>";
				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>"
						+ item.getParticipantePlano().getParticipante().getEntidadeParticipante().getNomeAbreviadoEntidadeParticipante() + "</td>";
				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>" + item.getNomeParticipante() + "</td>";
				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>" + item.getMatricula() + "</td>";
				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>"
						+ UtilJava.formataCPF(item.getParticipantePlano().getParticipante().getCpf()) + "</td>";
				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>" + item.getParticipantePlano().getPlanoPrevidencia().getDescricaoPlano()
						+ "</td>";

				Double totalDevolucao = item.getTotalCotas() * item.getValorAjustado();
				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>R$ " + UtilJava.arredondaNumero(totalDevolucao, 2) + "</td>";

				Double totalImpostos = this.detalheImpostoBO.calcularImpostoDevolucao(item.getDevolucao());
				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>R$ " + UtilJava.arredondaNumero(totalImpostos, 2) + "</td>";

				textoEmail += "<td style='text-align: left; border-bottom: 2px solid #95A5A6; border-top: 1px solid #95A5A6;'>R$ " + UtilJava.arredondaNumero(totalDevolucao - totalImpostos, 2)
						+ "</td></tr>";
			}

			textoEmail = textoEmail + "</table>";

			String[] destinatarios = { "geinv@bbprevidencia.com.br", "resgates@bbprevidencia.com.br" };

			//String[] destinatarios = { "yanisley@bbprevidencia.com.br", "thallita@bbprevidencia.com.br" };

			String assunto = "Processo de resgate para a folha de pagamento";

			this.emailServico.enviarEmail(destinatarios, assunto, textoEmail);

		} catch (Exception e) {
			log.error(e);
		}

	}

	public DevolucaoBO getDevolucaoBO() {
		return devolucaoBO;
	}

	public void setDevolucaoBO(DevolucaoBO devolucaoBO) {
		this.devolucaoBO = devolucaoBO;
	}

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public SituacaoDevolucao getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public SituacaoDevolucaoBO getSituacaoDevolucaoBO() {
		return situacaoDevolucaoBO;
	}

	public void setSituacaoDevolucaoBO(SituacaoDevolucaoBO situacaoDevolucaoBO) {
		this.situacaoDevolucaoBO = situacaoDevolucaoBO;
	}

	public List<Devolucao> getListaDevolucaoSelecionadas() {
		return listaDevolucaoSelecionadas;
	}

	public void setListaDevolucaoSelecionadas(List<Devolucao> listaDevolucaoSelecionadas) {
		this.listaDevolucaoSelecionadas = listaDevolucaoSelecionadas;
	}

	public ParametroGeralBO getParametroGeralBO() {
		return parametroGeralBO;
	}

	public void setParametroGeralBO(ParametroGeralBO parametroGeralBO) {
		this.parametroGeralBO = parametroGeralBO;
	}

	public AmbienteServico getAmbienteServico() {
		return ambienteServico;
	}

	public void setAmbienteServico(AmbienteServico ambienteServico) {
		this.ambienteServico = ambienteServico;
	}

	public ContaDevolucaoBO getContaDevolucaoBO() {
		return contaDevolucaoBO;
	}

	public void setContaDevolucaoBO(ContaDevolucaoBO contaDevolucaoBO) {
		this.contaDevolucaoBO = contaDevolucaoBO;
	}

	public HistoricoSituacaoDevolucaoBO getHistoricoSituacaoDevolucaoBO() {
		return historicoSituacaoDevolucaoBO;
	}

	public void setHistoricoSituacaoDevolucaoBO(HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO) {
		this.historicoSituacaoDevolucaoBO = historicoSituacaoDevolucaoBO;
	}

	public AnotacaoDevolucaoBO getAnotacaoDevolucaoBO() {
		return anotacaoDevolucaoBO;
	}

	public void setAnotacaoDevolucaoBO(AnotacaoDevolucaoBO anotacaoDevolucaoBO) {
		this.anotacaoDevolucaoBO = anotacaoDevolucaoBO;
	}

	public List<ConferenciaDevolucaoDTO> getListaConferenciaDevolucaoDTO() {
		if (this.listaConferenciaDevolucaoDTO == null) {
			return new ArrayList<ConferenciaDevolucaoDTO>();
		}
		return listaConferenciaDevolucaoDTO;
	}

	public void setListaConferenciaDevolucaoDTO(List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTO) {
		this.listaConferenciaDevolucaoDTO = listaConferenciaDevolucaoDTO;
	}

	public List<ConferenciaDevolucaoDTO> getListaConferenciaDevolucaoDTOSelecionados() {
		return listaConferenciaDevolucaoDTOSelecionados;
	}

	public void setListaConferenciaDevolucaoDTOSelecionados(List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTOSelecionados) {
		this.listaConferenciaDevolucaoDTOSelecionados = listaConferenciaDevolucaoDTOSelecionados;
	}

	public ConferenciaDevolucaoDTO getLinhaConferenciaDevolucao() {
		return linhaConferenciaDevolucao;
	}

	public void setLinhaConferenciaDevolucao(ConferenciaDevolucaoDTO linhaConferenciaDevolucao) {
		this.linhaConferenciaDevolucao = linhaConferenciaDevolucao;
	}

	public String getUrlCloudDocs() {
		return urlCloudDocs;
	}

}
