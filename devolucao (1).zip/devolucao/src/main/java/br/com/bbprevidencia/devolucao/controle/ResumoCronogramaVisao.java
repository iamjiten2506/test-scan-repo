package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.ResumoCronogramaDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 250/01/2018
 *
 */
@Scope("session")
@Component("resumoCronogramaVisao")
public class ResumoCronogramaVisao {

	private static final Logger log = Logger.getLogger(ResumoCronogramaVisao.class);

	private static String FW_RESUMO_CRONOGRAMA = "/paginas/resumoCronograma.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	private List<ResumoCronogramaDTO> listaResumoCronograma;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private CronogramaDevolucao cronogramaDevolucao;

	private Date dataInicio;

	private Date dataFim;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	/**
	 * Inicia a tela
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 25/01/2018
	 * @return
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		this.listaCronogramaDevolucao = this.cronogramaDevolucaoBO.listarCronogramaDescendente();
		limparPesquisa();

		return FW_RESUMO_CRONOGRAMA;
	}

	/**
	 * Limpa as informações de pesquisa que estiver na tela
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 25/01/2018
	 */
	public void limparPesquisa() {
		this.cronogramaDevolucao = null;
		this.dataInicio = null;
		this.dataFim = null;
		this.listaResumoCronograma = new ArrayList<ResumoCronogramaDTO>();
	}

	/**
	 * Pesquisa as informações baseadas nos parâmetros de pesquisa
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 25/01/2018
	 */
	public void pesquisar() {
		try {
			if (this.cronogramaDevolucao != null && this.dataInicio != null) {
				Mensagens.addMsgWarn("O filtro de pesquisa deve ser por Cronograma ou por intervalo de data!");
			}

			if (this.dataInicio != null) {
				if (this.dataFim != null) {
					if (this.dataFim.before(this.dataInicio)) {
						Mensagens.addMsgWarn("A data final deve ser menor que a data inicial");
					}
				}
			}

			this.listaResumoCronograma = new ArrayList<ResumoCronogramaDTO>(this.cronogramaDevolucaoBO.listarResumoCronograma(
					this.cronogramaDevolucao == null ? null : this.cronogramaDevolucao,
					this.dataInicio,
					this.dataFim));

			if (UtilJava.isColecaoVazia(this.listaResumoCronograma)) {
				Mensagens.addMsgWarn("Não foram pagamentos para o cronograma selecionado!");
			}

		} catch (Exception e) {
			Mensagens.addMsgErro(e.getMessage());
		}
	}

	public void limparDatas() {
		this.dataInicio = null;
		this.dataFim = null;
	}

	/************  GETTER AND SETTER ********************/

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public List<ResumoCronogramaDTO> getListaResumoCronograma() {
		return listaResumoCronograma;
	}

	public void setListaResumoCronograma(List<ResumoCronogramaDTO> listaResumoCronograma) {
		this.listaResumoCronograma = listaResumoCronograma;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

}
