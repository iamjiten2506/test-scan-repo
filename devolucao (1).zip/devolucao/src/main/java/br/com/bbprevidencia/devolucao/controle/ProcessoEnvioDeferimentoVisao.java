package br.com.bbprevidencia.devolucao.controle;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.bb.previdencia.seguranca.criptografia.Criptografia;
import br.com.bbprevidencia.alcada.dto.RetornoFecharLoteAlcadaDTO;
import br.com.bbprevidencia.alcada.dto.RetornoInsercaoMovAlcadaDTO;
import br.com.bbprevidencia.alcada.dto.RetornoMsgLoteAlcadaDTO;
import br.com.bbprevidencia.alcada.dto.RetornoSolicitacaoLoteAlcadaDTO;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO.PARAMETROS;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.ParametroGeral;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoDetalheImpostoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.CloudDocsDTO;
import br.com.bbprevidencia.devolucao.dto.ConferenciaDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.DescontoDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.UtilJson;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   27/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("processoEnvioDeferimentoVisao")
public class ProcessoEnvioDeferimentoVisao {

	private static String FW_PROCESSO_ENVIO_DEFERIMENTO = "/paginas/processoEnvioDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static Logger log = Logger.getLogger(ProcessoEnvioDeferimentoVisao.class);

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private ContaDevolucaoBO contaDevolucaoBO;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private AmbienteServico ambienteServico;

	@Autowired
	private ParametroGeralBO parametroGeralBO;

	@Autowired
	private ParcelaContaDevolucaoDetalheImpostoBO devolucaoDetalheImpostoBO;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<TipoDevolucao> listaTipoDevolucao;

	private List<Devolucao> listaDevolucao;

	private List<Devolucao> listaDevolucaoSelecionadas;

	private Devolucao devolucaoSelecianada;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private CronogramaDevolucao cronogramaDevolucao;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private TipoDevolucao tipoDevolucao;

	private String numeroMatriculaPatrocinadora;

	private List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTO = new ArrayList<ConferenciaDevolucaoDTO>();
	private List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTOSelecionados = new ArrayList<ConferenciaDevolucaoDTO>();

	//Url para redirecionamento do Cloud Docs
	//	private final String urlCloudDocs = "http://www.google.com.br";
	private CloudDocsDTO cloudDocsDTO = new CloudDocsDTO();
	private final String urlCloudDocs = cloudDocsDTO.getUrlRedirect();

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0333 - Daniel Martins
	 * @since   24/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoEnvioDeferimento");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.listarDevolucao();

		//Fazer cargas de listas de Combo.
		this.listaCronogramaDevolucao = new ArrayList<CronogramaDevolucao>(cronogramaDevolucaoBO.listarCronogramaDevolucaoPermitemProcessamento());
		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(entidadeParticipanteBO.listarEntidadeParticipante());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanos());
		this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBO.listarTodosTipoDevolucao());

		return FW_PROCESSO_ENVIO_DEFERIMENTO;
	}

	//Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   26/01/2017
	 */
	public void limpaSelecao() {
		this.setCronogramaDevolucao(null);
		this.setEntidadeParticipante(null);
		this.setPlanoPrevidencia(null);
		this.setTipoDevolucao(null);
		this.setNumeroMatriculaPatrocinadora(null);
	}

	public void listarDevolucao() {

		SituacaoDevolucao situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.CONFERIDO.getCodigo());

		/*this.listaDevolucao = devolucaoBO.listarDevolucaoPorSituacao(situacaoDevolucao);

		this.listaDevolucao = contaDevolucaoBO.carregarSaldoResgatavelEmListaDevolucao(this.listaDevolucao);
		 */

		this.listaConferenciaDevolucaoDTO = this.devolucaoBO.listarDevolucaoPorSituacaoCodigoSituacao(situacaoDevolucao);

		for (ConferenciaDevolucaoDTO conferenciaDevolucaoDTO : this.listaConferenciaDevolucaoDTO) {
			conferenciaDevolucaoDTO.getDevolucao().setValorTotalImposto(this.devolucaoDetalheImpostoBO.calcularImpostoDevolucao(conferenciaDevolucaoDTO.getDevolucao()));
		}

	}

	public RetornoFecharLoteAlcadaDTO fecharLote(Long numeroLoteAlcada) {

		RetornoFecharLoteAlcadaDTO retornoFecharLoteAlcadaDTO = new RetornoFecharLoteAlcadaDTO();

		try {

			Criptografia criptografia = new Criptografia();

			String codigoLoteCrip = new String();

			codigoLoteCrip = Long.toString(numeroLoteAlcada);

			codigoLoteCrip = criptografia.criptografar(codigoLoteCrip);

			URL urlFecharLote = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/fecharLoteProcessamentoAlcadaWs?" + "codigolLote=" + codigoLoteCrip);

			//Inserção de Log
			log.error(this.ambienteServico.getUrlAlcada() + "dispatcher/fecharLoteProcessamentoAlcadaWs?" + "codigolLote=" + codigoLoteCrip);

			HttpURLConnection connectionFecharLote = (HttpURLConnection) urlFecharLote.openConnection();
			connectionFecharLote.setConnectTimeout(15000);
			connectionFecharLote.connect();

			String responseJsonFecharLote = UtilJson.inputStreamToString(connectionFecharLote.getInputStream());

			retornoFecharLoteAlcadaDTO = (RetornoFecharLoteAlcadaDTO) UtilJson.fromJson(responseJsonFecharLote, RetornoFecharLoteAlcadaDTO.class);

			return retornoFecharLoteAlcadaDTO;

		} catch (Exception e) {
			log.error("Erro ao fechar lote de deferimento. Erro: " + e.getMessage());
			Mensagens.addMsgErro("Erro ao fechar lote de deferimento. Erro: " + e.getMessage());
			return retornoFecharLoteAlcadaDTO;

		}

	}

	public String enviarParaDeferimento() {

		long numeroLoteAlcada = 0;

		try {

			if (listaConferenciaDevolucaoDTOSelecionados == null || listaConferenciaDevolucaoDTOSelecionados.size() == 0) {
				Mensagens.addMsgErro("Favor selecionar pelo menos uma devolução.");
				return FW_PROCESSO_ENVIO_DEFERIMENTO;
			}

			String usuarioCrip = new String();

			Criptografia criptografia = new Criptografia();

			usuarioCrip = criptografia.criptografar(this.loginTemporariaDTO.getIdentificacaoUsuario());

			String codigoSistema = new String();

			ParametroGeral parametroCodigoSistema = parametroGeralBO.consultarParametro(PARAMETROS.CODIGO_SISTEMA_DEVOLUCAO);

			codigoSistema = parametroCodigoSistema.getDescricaoPatrametro();

			//Solicitar Lote.
			URL url = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/solicitaLoteProcessamentoAlcadaWs?codigoSistema=" + codigoSistema + "&codigoAplicacao=0&codigoUsuario=" + usuarioCrip);

			System.out.println(this.ambienteServico.getUrlAlcada() + "dispatcher/solicitaLoteProcessamentoAlcadaWs?codigoSistema=" + codigoSistema + "&codigoAplicacao=0&codigoUsuario=" + usuarioCrip);
			log.error(this.ambienteServico.getUrlAlcada() + "dispatcher/solicitaLoteProcessamentoAlcadaWs?codigoSistema=" + codigoSistema + "&codigoAplicacao=0&codigoUsuario=" + usuarioCrip);

			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setConnectTimeout(15000);
			connection.connect();

			String responseJson = UtilJson.inputStreamToString(connection.getInputStream());

			RetornoSolicitacaoLoteAlcadaDTO retornoSolicitacaoLoteAlcadaDTO = new RetornoSolicitacaoLoteAlcadaDTO();

			retornoSolicitacaoLoteAlcadaDTO = (RetornoSolicitacaoLoteAlcadaDTO) UtilJson.fromJson(responseJson, RetornoSolicitacaoLoteAlcadaDTO.class);

			connection.disconnect();

			numeroLoteAlcada = retornoSolicitacaoLoteAlcadaDTO.getNumeroLote();

			if (retornoSolicitacaoLoteAlcadaDTO.isStatus()) {

				for (ConferenciaDevolucaoDTO conferenciaDevolucaoDTO : listaConferenciaDevolucaoDTOSelecionados) {

					System.out.println(retornoSolicitacaoLoteAlcadaDTO.getNumeroLote());

					contaDevolucaoBO.carregarSaldoResgatavelPorDevolucao(conferenciaDevolucaoDTO.getDevolucao());

					Long numeroTipoFuncionalidadeAlcada = 1L; //TIPO_FUNCIONALIDADE_ALCADA
					Long numeroUnidadeOrganizacional = 40L; //GERÊNCIA DE SEGURIDADE
					String codigoControle01 = conferenciaDevolucaoDTO.getDevolucao().getCodigo().toString();
					String codigoControle02 = null;
					String codigoControle03 = null;
					String codigoChaveOrigem = codigoControle01;

					//Alteração Código de Chave de Origem conforme solicitação do GESEG

					if (conferenciaDevolucaoDTO.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorTipoDevolucao().equalsIgnoreCase("R")) {
						codigoChaveOrigem = "RESG - ";
					}
					;

					if (conferenciaDevolucaoDTO.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorTipoDevolucao().equalsIgnoreCase("P")) {
						codigoChaveOrigem = "PORT - ";
					}
					;

					codigoChaveOrigem = codigoChaveOrigem + conferenciaDevolucaoDTO.getDevolucao().getParticipantePlano().getPlanoPrevidencia().getNomeAbreviadoPlano() + " - MAT:"
							+ conferenciaDevolucaoDTO.getDevolucao().getParticipantePlano().getParticipante().getNumeroMatriculaPatrocinadora();

					if (conferenciaDevolucaoDTO.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorFormaDevolucao().equalsIgnoreCase("P")) {

						if (conferenciaDevolucaoDTO.getDevolucao().getPercentualDevolucao() > 100) {
							codigoChaveOrigem = codigoChaveOrigem + " - TIPO:PARCIAL";
						} else {
							codigoChaveOrigem = codigoChaveOrigem + " - TIPO:TOTAL";
						}

					}

					if (conferenciaDevolucaoDTO.getDevolucao().getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorFormaDevolucao().equalsIgnoreCase("T")) {
						codigoChaveOrigem = codigoChaveOrigem + " - TIPO:TOTAL";
					}

					double valorAlcada = UtilJava.arredondaNumero(conferenciaDevolucaoDTO.getDevolucao().getSaldoResgatavel() * conferenciaDevolucaoDTO.getDevolucao().getValorIndiceAjustado(), 2);

					URL urlMov = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/insereMovimentosAlcadasWs?" + "numeroLoteAlcada=" + numeroLoteAlcada + "&"
							+ "numeroTipoFuncionalidadeAlcada=" + numeroTipoFuncionalidadeAlcada + "&" + "numeroUnidadeOrganizacional=" + numeroUnidadeOrganizacional + "&" + "codigoControle01="
							+ codigoControle01 + "&" + "codigoControle02=" + codigoControle02 + "&" + "codigoControle03=" + codigoControle03 + "&" + "codigoChaveOrigem="
							+ URLEncoder.encode(codigoChaveOrigem, StandardCharsets.UTF_8.toString()) + "&" + "valorAlcada=" + valorAlcada);

					//Inserção de Log 
					log.info(this.ambienteServico.getUrlAlcada() + "dispatcher/insereMovimentosAlcadasWs?" + "numeroLoteAlcada=" + numeroLoteAlcada + "&" + "numeroTipoFuncionalidadeAlcada="
							+ numeroTipoFuncionalidadeAlcada + "&" + "numeroUnidadeOrganizacional=" + numeroUnidadeOrganizacional + "&" + "codigoControle01=" + codigoControle01 + "&"
							+ "codigoControle02=" + codigoControle02 + "&" + "codigoControle03=" + codigoControle03 + "&" + "codigoChaveOrigem="
							+ URLEncoder.encode(codigoChaveOrigem, StandardCharsets.UTF_8.toString()) + "&" + "valorAlcada=" + valorAlcada);

					HttpURLConnection connectionMov = (HttpURLConnection) urlMov.openConnection();
					connectionMov.setConnectTimeout(15000);
					connectionMov.connect();

					String responseJsonMov = UtilJson.inputStreamToString(connectionMov.getInputStream());

					RetornoInsercaoMovAlcadaDTO retornoInsercaoMovAlcadaDTO = new RetornoInsercaoMovAlcadaDTO();

					retornoInsercaoMovAlcadaDTO = (RetornoInsercaoMovAlcadaDTO) UtilJson.fromJson(responseJsonMov, RetornoInsercaoMovAlcadaDTO.class);

					if (retornoInsercaoMovAlcadaDTO.isStatus()) {

						Devolucao devolucaoAtualizavel = new Devolucao();

						devolucaoAtualizavel = devolucaoBO.pesquisarDevolucaoPorCodigo(conferenciaDevolucaoDTO.getDevolucao().getCodigo());

						//Busca situação para atualização de devolução enviada para deferimento.
						SituacaoDevolucao situacaoDevolucao = new SituacaoDevolucao();

						situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.EM_DEFERIMENTO.getCodigo());

						devolucaoAtualizavel.setMovimentoAlcada(retornoInsercaoMovAlcadaDTO.getCodigoAlcada());
						devolucaoAtualizavel.setSituacaoDevolucao(situacaoDevolucao);
						devolucaoAtualizavel.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getIdentificacaoUsuario());
						devolucaoBO.salvarDevolucao(devolucaoAtualizavel);

						//Historico de situação.
						HistoricoSituacaoDevolucao historicoSituacaoDevolucao = new HistoricoSituacaoDevolucao();
						historicoSituacaoDevolucao = historicoSituacaoDevolucaoBO.gerarHistoricoSituacaoDevolucao(devolucaoAtualizavel);
						historicoSituacaoDevolucao.setNomeUsuarioInclusao(this.loginTemporariaDTO.getIdentificacaoUsuario());
						historicoSituacaoDevolucaoBO.salvarHistoricoSituacaoDevolucao(historicoSituacaoDevolucao);

						//Anotação devolução
						AnotacaoDevolucao anotacaoDevolucao = new AnotacaoDevolucao();
						anotacaoDevolucao = anotacaoDevolucaoBO.gerarAnotacaoDevolucao(devolucaoAtualizavel, "Enviado para deferimento", new Date(), loginTemporariaDTO);
						anotacaoDevolucaoBO.salvarAnotacaoDevolucao(anotacaoDevolucao);

					} else {
						Mensagens.addMsgErro("Devolução não enviada para deferimento. Verificar mensagens do lote: " + numeroLoteAlcada);

						//Solicitar Lote.
						URL urlMsgLote = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/listarMsgLoteProcessamentoAlcadaWs?numeroLote=" + numeroLoteAlcada);

						//Inserção de Log
						log.error(this.ambienteServico.getUrlAlcada() + "dispatcher/listarMsgLoteProcessamentoAlcadaWs?numeroLote=" + numeroLoteAlcada);

						HttpURLConnection connectionMsgLote = (HttpURLConnection) urlMsgLote.openConnection();
						connectionMsgLote.setConnectTimeout(15000);
						connectionMsgLote.connect();

						String responseJsonMsgLote = UtilJson.inputStreamToString(connectionMsgLote.getInputStream());

						RetornoMsgLoteAlcadaDTO retornoMsgLoteAlcadaDTO = new RetornoMsgLoteAlcadaDTO();

						retornoMsgLoteAlcadaDTO = (RetornoMsgLoteAlcadaDTO) UtilJson.fromJson(responseJsonMsgLote, RetornoMsgLoteAlcadaDTO.class);

						connectionMsgLote.disconnect();

						if (retornoMsgLoteAlcadaDTO.isStatus()) {
							for (String msgLote : retornoMsgLoteAlcadaDTO.getListadescricaoMsg()) {
								Mensagens.addMsgErro(msgLote);
							}
						} else {
							Mensagens.addMsgErro("Erro ao buscar mensagem de lote. Erro: " + retornoMsgLoteAlcadaDTO.getDescricaoErro());
						}

						break;

					}

					connection.disconnect();

				}

				RetornoFecharLoteAlcadaDTO retornoFecharLoteAlcadaDTO = new RetornoFecharLoteAlcadaDTO();

				retornoFecharLoteAlcadaDTO = fecharLote(numeroLoteAlcada);

				if (!retornoFecharLoteAlcadaDTO.isStatus()) {
					System.out.println(retornoFecharLoteAlcadaDTO.getDescricaoErro());
					Mensagens.addMsgErro(retornoFecharLoteAlcadaDTO.getDescricaoErro());
				} else {
					numeroLoteAlcada = 0;
				}

			} else {

				System.out.println(retornoSolicitacaoLoteAlcadaDTO.getDescricaoErro());

				Mensagens.addMsgErro(retornoSolicitacaoLoteAlcadaDTO.getDescricaoErro());

				log.error("Erro ao gerar lote. Erro: " + retornoSolicitacaoLoteAlcadaDTO.getDescricaoErro());

				return FW_PROCESSO_ENVIO_DEFERIMENTO;
			}

			listarDevolucao();

			return FW_PROCESSO_ENVIO_DEFERIMENTO;

		} catch (Exception e) {

			if (numeroLoteAlcada != 0) {
				RetornoFecharLoteAlcadaDTO retornoFecharLoteAlcadaDTO = new RetornoFecharLoteAlcadaDTO();

				retornoFecharLoteAlcadaDTO = fecharLote(numeroLoteAlcada);

				if (!retornoFecharLoteAlcadaDTO.isStatus()) {
					System.out.println(retornoFecharLoteAlcadaDTO.getDescricaoErro());
					Mensagens.addMsgErro(retornoFecharLoteAlcadaDTO.getDescricaoErro());
				}
			}

			log.error("Erro ao enviar para deferimento. Erro: " + e.getMessage());
			Mensagens.addMsgErro("Erro ao enviar para deferimento. Erro: " + e.getMessage());
			return FW_PROCESSO_ENVIO_DEFERIMENTO;
			//throw new PrevidenciaException("Nao foi possível realizar está operaçao", e.getMessage());
		}
	}

	/**
	 * Método para calcular o valor líquido da devolução
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 02/11/2017
	 * @param {@link Devolucao}
	 * @return
	 */
	public double calcularValorLiquidoDevolucao(ConferenciaDevolucaoDTO conferenciaDevolucao) {
		double valorDesconto = 0D;
		double valorResgatavel = 0D;
		double valorImpostos = 0D;

		valorResgatavel = UtilJava.arredondaNumero(conferenciaDevolucao.getTotalCotas() * conferenciaDevolucao.getValorAjustado(), 2);
		valorImpostos = UtilJava.arredondaNumero(conferenciaDevolucao.getDevolucao().getValorTotalImposto(), 2);

		if (UtilJava.isColecaoDiferenteDeVazia(conferenciaDevolucao.getDevolucao().getListaDescontoDevolucao())) {
			for (DescontoDevolucao dD : conferenciaDevolucao.getDevolucao().getListaDescontoDevolucao()) {
				valorDesconto += dD.getValorDesconto();
			}
		}

		return valorResgatavel - (valorDesconto + valorImpostos);
	}

	/**
	 * Método para calcular os descontos da devolução
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 02/06/2017
	 * @param {@link Devolucao}
	 * @return
	 */
	public double calcularDescontoDevolucao(Devolucao devolucao) {
		double descontoDevolucao = 0D;

		if (UtilJava.isColecaoDiferenteDeVazia(devolucao.getListaDescontoDevolucao())) {
			for (DescontoDevolucao dD : devolucao.getListaDescontoDevolucao()) {
				descontoDevolucao += dD.getValorDesconto();
			}
		}

		return descontoDevolucao;
	}

	public static String getFW_PROCESSO_ENVIO_DEFERIMENTO() {
		return FW_PROCESSO_ENVIO_DEFERIMENTO;
	}

	public static void setFW_PROCESSO_ENVIO_DEFERIMENTO(String fW_PROCESSO_ENVIO_DEFERIMENTO) {
		FW_PROCESSO_ENVIO_DEFERIMENTO = fW_PROCESSO_ENVIO_DEFERIMENTO;
	}

	public CronogramaDevolucaoBO getCronogramaDevolucaoBO() {
		return cronogramaDevolucaoBO;
	}

	public void setCronogramaDevolucaoBO(CronogramaDevolucaoBO cronogramaDevolucaoBO) {
		this.cronogramaDevolucaoBO = cronogramaDevolucaoBO;
	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public TipoDevolucaoBO getTipoDevolucaoBO() {
		return tipoDevolucaoBO;
	}

	public void setTipoDevolucaoBO(TipoDevolucaoBO tipoDevolucaoBO) {
		this.tipoDevolucaoBO = tipoDevolucaoBO;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public String getNumeroMatriculaPatrocinadora() {
		return numeroMatriculaPatrocinadora;
	}

	public void setNumeroMatriculaPatrocinadora(String numeroMatriculaPatrocinadora) {
		this.numeroMatriculaPatrocinadora = numeroMatriculaPatrocinadora;
	}

	public AmbienteServico getAmbienteServico() {
		return ambienteServico;
	}

	public void setAmbienteServico(AmbienteServico ambienteServico) {
		this.ambienteServico = ambienteServico;
	}

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	public Devolucao getDevolucaoSelecianada() {
		return devolucaoSelecianada;
	}

	public void setDevolucaoSelecianada(Devolucao devolucaoSelecianada) {
		this.devolucaoSelecianada = devolucaoSelecianada;
	}

	public List<Devolucao> getListaDevolucaoSelecionadas() {
		return listaDevolucaoSelecionadas;
	}

	public void setListaDevolucaoSelecionadas(List<Devolucao> listaDevolucaoSelecionadas) {
		this.listaDevolucaoSelecionadas = listaDevolucaoSelecionadas;
	}

	public List<ConferenciaDevolucaoDTO> getListaConferenciaDevolucaoDTO() {
		return listaConferenciaDevolucaoDTO;
	}

	public void setListaConferenciaDevolucaoDTO(List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTO) {
		this.listaConferenciaDevolucaoDTO = listaConferenciaDevolucaoDTO;
	}

	public List<ConferenciaDevolucaoDTO> getListaConferenciaDevolucaoDTOSelecionados() {
		return listaConferenciaDevolucaoDTOSelecionados;
	}

	public void setListaConferenciaDevolucaoDTOSelecionados(List<ConferenciaDevolucaoDTO> listaConferenciaDevolucaoDTOSelecionados) {
		this.listaConferenciaDevolucaoDTOSelecionados = listaConferenciaDevolucaoDTOSelecionados;
	}

	public String getUrlCloudDocs() {
		return urlCloudDocs;
	}

}
