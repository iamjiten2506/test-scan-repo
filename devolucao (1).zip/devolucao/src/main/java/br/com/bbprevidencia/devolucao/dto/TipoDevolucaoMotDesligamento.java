package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.MotivoDesligamento;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   01/12/2016
 * Classe de persistência para tabela DEV_TIP_MOT_DES.
 */
@Entity
@Table(name = "MOT_DES_TIP_DEV", schema = "OWN_DCR")
@NamedQuery(name = "TipoDevolucaoMotDesligamento.findAll", query = "SELECT q FROM TipoDevolucaoMotDesligamento q")
public class TipoDevolucaoMotDesligamento implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MOT_DES_TIP_DEV_GER", sequenceName = "S_QUALIDADE_RECEBEDOR_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MOT_DES_TIP_DEV_GER")
	@Column(name = "NUM_MOT_DES_TIP_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_DEV")
	private TipoDevolucao tipoDevolucao;

	@ManyToOne
	@JoinColumn(name = "COD_MOTIVO_DESLIG")
	private MotivoDesligamento motivoDesligamento;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public MotivoDesligamento getMotivoDesligamento() {
		return motivoDesligamento;
	}

	public void setMotivoDesligamento(MotivoDesligamento motivoDesligamento) {
		this.motivoDesligamento = motivoDesligamento;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

}