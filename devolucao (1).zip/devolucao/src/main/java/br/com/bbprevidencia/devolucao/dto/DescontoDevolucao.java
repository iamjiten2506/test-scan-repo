package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   09/01/2017
 * Classe de persistência para tabela DESCONTO_DEVOLUCAO.
 */
@Entity
@Table(name = "DESCONTO_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "DescontoDevolucao.findAll", query = "SELECT q FROM DescontoDevolucao q")
public class DescontoDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DESCONTO_DEVOLUCAO_GER", sequenceName = "S_DD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DESCONTO_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_DES_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RUB_DEV")
	private RubricaDevolucao rubricaDevolucao;

	@Column(name = "QTD_DES")
	private Long qtdParcelasDesconto;

	@Column(name = "QTD_TOT_DES")
	private Long qtdTotalParcelasDesconto;

	@Column(name = "VAL_DES")
	private Double valorDesconto;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	public Long getQtdParcelasDesconto() {
		return qtdParcelasDesconto;
	}

	public void setQtdParcelasDesconto(Long qtdParcelasDesconto) {
		this.qtdParcelasDesconto = qtdParcelasDesconto;
	}

	public Long getQtdTotalParcelasDesconto() {
		return qtdTotalParcelasDesconto;
	}

	public void setQtdTotalParcelasDesconto(Long qtdTotalParcelasDesconto) {
		this.qtdTotalParcelasDesconto = qtdTotalParcelasDesconto;
	}

	public Double getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(Double valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

}