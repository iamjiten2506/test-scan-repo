package br.com.bbprevidencia.devolucao.listener;

import java.util.Date;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.devolucao.bo.CalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.LoteProcessamentoReferenciaCalcDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MensagemLoteProcessamentoRefCalcDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.ReferenciaCalculoDevPosicionadoValoresBO;
import br.com.bbprevidencia.devolucao.bo.ReferenciaCalculoDevolucaoPosicionadoBO;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.devolucao.dto.DevolucaoPosicionadoDTO;
import br.com.bbprevidencia.devolucao.dto.LoteProcessamentoReferenciaCalcDevolucao;
import br.com.bbprevidencia.devolucao.dto.MensagemLoteProcessamentoRefCalcDevolucao;
import br.com.bbprevidencia.devolucao.dto.ReferenciaCalculoDevPosicionadoValores;
import br.com.bbprevidencia.devolucao.dto.ReferenciaCalculoDevolucaoPosicionado;

@Component
public class Consumer {

	@Autowired
	private CalculoDevolucaoBO CalculoDevolucaoBO;

	@Autowired
	private ReferenciaCalculoDevolucaoPosicionadoBO referenciaCalculoDevolucaoPosicionadoBO;

	@Autowired
	private ReferenciaCalculoDevPosicionadoValoresBO referenciaCalculoDevPosicionadoValoresBO;

	@Autowired
	private MensagemLoteProcessamentoRefCalcDevolucaoBO mensagemLoteProcessamentoRefCalcDevolucaoBO;

	@Autowired
	private LoteProcessamentoReferenciaCalcDevolucaoBO loteProcessamentoReferenciaCalcDevolucaoBO;

	/**
	 * The function that consumes messages from the broker(RabbitMQ)
	 * 
	 * @param data
	 * @throws Exception 
	 * @throws ClassNotFoundException 
	 */
	@RabbitListener(queues = "jsa.queue")
	public void calcularMessage(DevolucaoPosicionadoDTO devolucaoDTO) throws Exception {

		DevolucaoCompletoDTO dev = this.CalculoDevolucaoBO.calcularDevolucaoParcial(
				Long.parseLong(devolucaoDTO.getCodigoPt()),
				Long.parseLong(devolucaoDTO.getCodigoPn()),
				Long.parseLong(devolucaoDTO.getCodigoTDev()),
				devolucaoDTO.getDataReq(),
				devolucaoDTO.getIndTDev(),
				devolucaoDTO.getSimulacao(),
				Integer.parseInt(devolucaoDTO.getQtdParcela()),
				devolucaoDTO.getDataCota(),
				devolucaoDTO.getIndFormaPagRem(),
				devolucaoDTO.getCodigoUsuario(),
				100D,
				0D,
				null,
				true);

		if (dev.isCalculoComErro()) {
			geradoComErro(devolucaoDTO, dev.getMsgErro());

			//verificaFila();

			//Joga excessão para cima, para não tentar fazer um segundo cálculo
			throw new AmqpRejectAndDontRequeueException(dev.getMsgErro());
		} else {

			Double qtdParticipante = dev.getQuantidadeCotasContaResgatavelParticipante();
			Double qtdPatronal = dev.getQuantidadeCotasContaResgatavelPatrocinadora();
			Double qtdRemanescente = dev.getQuantidadeCotasContaRemanescenteParticipante() + dev.getQuantidadeCotasContaRemanescentePatrocinadora();
			Double qtdReversao = dev.getQuantidadeCotasContaReversaoParticipante() + dev.getQuantidadeCotasContaReversaoPatrocinadora();

			Double valorParticipante = qtdParticipante * dev.getDevolucao().getValorIndiceAjustado();
			Double valorPatronal = qtdPatronal * dev.getDevolucao().getValorIndiceAjustado();
			Double valorRemanescente = qtdRemanescente * dev.getDevolucao().getValorIndiceAjustado();
			Double valorReversao = qtdReversao * dev.getDevolucao().getValorIndiceAjustado();

			ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado = this.referenciaCalculoDevolucaoPosicionadoBO
					.perquisarReferenciaCalculoDevolucaoPosicionadoPorCodigo(devolucaoDTO.getCodigoReferenciaCalculo());

			ReferenciaCalculoDevPosicionadoValores valores = new ReferenciaCalculoDevPosicionadoValores(referenciaCalculoDevolucaoPosicionado, dev.getDevolucao().getParticipantePlano(), dev
					.getDevolucao().getDataCota(), dev.getDevolucao().getValorIndiceAjustado(), qtdParticipante, qtdPatronal, qtdReversao, qtdRemanescente, valorParticipante, valorPatronal,
					valorReversao, valorRemanescente, new Date(), dev.getDevolucao().getNomeUsuarioInclusao());

			this.referenciaCalculoDevPosicionadoValoresBO.salvarReferenciaCalculoDevPosicionadoValores(valores);

			System.out.println(" [x] Consumed  '" + dev + "'");

			//verificaFila();
		}

	}

	private void geradoComErro(DevolucaoPosicionadoDTO devolucaoDTO, String erro) {
		LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao = this.loteProcessamentoReferenciaCalcDevolucaoBO.pesquisarLoteProcessamentoDevolucaoPorCodigo(devolucaoDTO
				.getCodigoLoteReferencia());

		MensagemLoteProcessamentoRefCalcDevolucao msg = new MensagemLoteProcessamentoRefCalcDevolucao(loteProcessamentoReferenciaCalcDevolucao, new Date(), devolucaoDTO.getCodigoParticipantePlano(),
				erro, "E", new Date());

		//Tive que utilizar a função no banco de dados, não sei o motivo não de fazer o commit pelo Hibernate
		this.mensagemLoteProcessamentoRefCalcDevolucaoBO.salvar(msg);

	}

}
