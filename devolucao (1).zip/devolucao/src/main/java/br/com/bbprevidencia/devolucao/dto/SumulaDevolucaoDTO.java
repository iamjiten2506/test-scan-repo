package br.com.bbprevidencia.devolucao.dto;

import java.util.ArrayList;
import java.util.List;

public class SumulaDevolucaoDTO {

	private String tituloRelatorio;

	/* Dados Participante */
	private String nomePlano;

	private String nomeParticipante;

	private String matriculaParticipante;

	private String situacaoPlano;

	private String fundadorPlano;

	private String participanteFalecido;

	private String tipoTributacao;

	private String possuiEmprestimo;

	private String modalidadeDevolucao;

	private String dataAdmissao;

	private String dataInscricaoPlano;

	private String dataDesligamento;

	private String dataCancelamentoPlano;

	private String dataUltimoProcessoPlano;

	private String dataUltimoLancamentoPartic;

	private Integer idadeAnos;

	private Integer idadeMeses;

	private Integer idadeDias;

	private Integer planoAnos;

	private Integer planoMeses;

	private Integer planoDias;

	private Integer empresaAnos;

	private Integer empresaMeses;

	private Integer empresaDias;

	/* Valores */
	private String dataCota;

	private Double valorCota;

	private Double percentualEmpresa;

	private Double totalCotasEmpresa;

	private Double totalValorEmpresa;

	private Double totalCotasResgatavelEmpresa;

	private Double totalValorResgatavelEmpresa;

	private Double valorInstituidor;

	private Double percentualParticipante;

	private Double totalCotasParticipante;

	private Double totalValorParticipante;

	private Double totalCotasResgatavelParticipante;

	private Double totalValorResgatavelParticipante;

	private Double valorIR;

	private Double valorEmprestimo;

	/*Dados Bancários*/
	private String banco;

	private String agencia;

	private String conta;

	private String tipoConta;

	private Double valorBruto;

	private String tipoDevolucao;

	private String indicadorPagamento;

	private int qtdParcelas;

	private String nomePlanoPortabilidade;

	private String tituloRecebedorPortabilidade;

	private List<RecebedoresResgateSumulaDTO> recebedoresResgateSumula;

	private String fichaFinanceiraBase64;
	private Long protocolo;
	private List<String> tratamentoMensagens = new ArrayList<>();

	public String getFichaFinanceiraBase64() {
		return fichaFinanceiraBase64;
	}

	public void setFichaFinanceiraBase64(String fichaFinanceiraBase64) {
		this.fichaFinanceiraBase64 = fichaFinanceiraBase64;
	}

	public Long getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(Long protocolo) {
		this.protocolo = protocolo;
	}

	public List<String> getTratamentoMensagens() {
		return tratamentoMensagens;
	}

	public void setTratamentoMensagens(List<String> tratamentoMensagens) {
		this.tratamentoMensagens = tratamentoMensagens;
	}

	private Double valorSaldoIsento;

	public List<RecebedoresResgateSumulaDTO> getRecebedoresResgateSumula() {
		return recebedoresResgateSumula;
	}



	public void setRecebedoresResgateSumula(List<RecebedoresResgateSumulaDTO> recebedoresResgateSumula) {
		this.recebedoresResgateSumula = recebedoresResgateSumula;
	}

	public String getNomePlanoPortabilidade() {
		return nomePlanoPortabilidade;
	}

	public void setNomePlanoPortabilidade(String nomePlanoPortabilidade) {
		this.nomePlanoPortabilidade = nomePlanoPortabilidade;
	}

	public String getNomePlano() {
		return nomePlano;
	}

	public void setNomePlano(String nomePlano) {
		this.nomePlano = nomePlano;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getSituacaoPlano() {
		return situacaoPlano;
	}

	public void setSituacaoPlano(String situacaoPlano) {
		this.situacaoPlano = situacaoPlano;
	}

	public String getFundadorPlano() {
		return fundadorPlano;
	}

	public void setFundadorPlano(String fundadorPlano) {
		this.fundadorPlano = fundadorPlano;
	}

	public String getParticipanteFalecido() {
		return participanteFalecido;
	}

	public void setParticipanteFalecido(String participanteFalecido) {
		this.participanteFalecido = participanteFalecido;
	}

	public String getTipoTributacao() {
		return tipoTributacao;
	}

	public void setTipoTributacao(String tipoTributacao) {
		this.tipoTributacao = tipoTributacao;
	}

	public String getPossuiEmprestimo() {
		return possuiEmprestimo;
	}

	public void setPossuiEmprestimo(String possuiEmprestimo) {
		this.possuiEmprestimo = possuiEmprestimo;
	}

	public String getModalidadeDevolucao() {
		return modalidadeDevolucao;
	}

	public void setModalidadeDevolucao(String modalidadeDevolucao) {
		this.modalidadeDevolucao = modalidadeDevolucao;
	}

	public String getDataAdmissao() {
		return dataAdmissao;
	}

	public void setDataAdmissao(String dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public String getDataInscricaoPlano() {
		return dataInscricaoPlano;
	}

	public void setDataInscricaoPlano(String dataInscricaoPlano) {
		this.dataInscricaoPlano = dataInscricaoPlano;
	}

	public String getDataDesligamento() {
		return dataDesligamento;
	}

	public void setDataDesligamento(String dataDesligamento) {
		this.dataDesligamento = dataDesligamento;
	}

	public String getDataCancelamentoPlano() {
		return dataCancelamentoPlano;
	}

	public void setDataCancelamentoPlano(String dataCancelamentoPlano) {
		this.dataCancelamentoPlano = dataCancelamentoPlano;
	}

	public String getDataUltimoProcessoPlano() {
		return dataUltimoProcessoPlano;
	}

	public void setDataUltimoProcessoPlano(String dataUltimoProcessoPlano) {
		this.dataUltimoProcessoPlano = dataUltimoProcessoPlano;
	}

	public String getDataUltimoLancamentoPartic() {
		return dataUltimoLancamentoPartic;
	}

	public void setDataUltimoLancamentoPartic(String dataUltimoLancamentoPartic) {
		this.dataUltimoLancamentoPartic = dataUltimoLancamentoPartic;
	}

	public Integer getIdadeAnos() {
		return idadeAnos;
	}

	public void setIdadeAnos(Integer idadeAnos) {
		this.idadeAnos = idadeAnos;
	}

	public Integer getIdadeMeses() {
		return idadeMeses;
	}

	public void setIdadeMeses(Integer idadeMeses) {
		this.idadeMeses = idadeMeses;
	}

	public Integer getIdadeDias() {
		return idadeDias;
	}

	public void setIdadeDias(Integer idadeDias) {
		this.idadeDias = idadeDias;
	}

	public Integer getPlanoAnos() {
		return planoAnos;
	}

	public void setPlanoAnos(Integer planoAnos) {
		this.planoAnos = planoAnos;
	}

	public Integer getPlanoMeses() {
		return planoMeses;
	}

	public void setPlanoMeses(Integer planoMeses) {
		this.planoMeses = planoMeses;
	}

	public Integer getPlanoDias() {
		return planoDias;
	}

	public void setPlanoDias(Integer planoDias) {
		this.planoDias = planoDias;
	}

	public Integer getEmpresaAnos() {
		return empresaAnos;
	}

	public void setEmpresaAnos(Integer empresaAnos) {
		this.empresaAnos = empresaAnos;
	}

	public Integer getEmpresaMeses() {
		return empresaMeses;
	}

	public void setEmpresaMeses(Integer empresaMeses) {
		this.empresaMeses = empresaMeses;
	}

	public Integer getEmpresaDias() {
		return empresaDias;
	}

	public void setEmpresaDias(Integer empresaDias) {
		this.empresaDias = empresaDias;
	}

	public String getDataCota() {
		return dataCota;
	}

	public void setDataCota(String dataCota) {
		this.dataCota = dataCota;
	}

	public Double getValorCota() {
		return valorCota;
	}

	public void setValorCota(Double valorCota) {
		this.valorCota = valorCota;
	}

	public Double getPercentualEmpresa() {
		return percentualEmpresa;
	}

	public void setPercentualEmpresa(Double percentualEmpresa) {
		this.percentualEmpresa = percentualEmpresa;
	}

	public Double getTotalCotasEmpresa() {
		return totalCotasEmpresa;
	}

	public void setTotalCotasEmpresa(Double totalCotasEmpresa) {
		this.totalCotasEmpresa = totalCotasEmpresa;
	}

	public Double getTotalValorEmpresa() {
		return totalValorEmpresa;
	}

	public void setTotalValorEmpresa(Double totalValorEmpresa) {
		this.totalValorEmpresa = totalValorEmpresa;
	}

	public Double getTotalCotasResgatavelEmpresa() {
		return totalCotasResgatavelEmpresa;
	}

	public void setTotalCotasResgatavelEmpresa(Double totalCotasResgatavelEmpresa) {
		this.totalCotasResgatavelEmpresa = totalCotasResgatavelEmpresa;
	}

	public Double getTotalValorResgatavelEmpresa() {
		return totalValorResgatavelEmpresa;
	}

	public void setTotalValorResgatavelEmpresa(Double totalValorResgatavelEmpresa) {
		this.totalValorResgatavelEmpresa = totalValorResgatavelEmpresa;
	}

	public Double getValorInstituidor() {
		return valorInstituidor;
	}

	public void setValorInstituidor(Double valorInstituidor) {
		this.valorInstituidor = valorInstituidor;
	}

	public Double getPercentualParticipante() {
		return percentualParticipante;
	}

	public void setPercentualParticipante(Double percentualParticipante) {
		this.percentualParticipante = percentualParticipante;
	}

	public Double getTotalCotasParticipante() {
		return totalCotasParticipante;
	}

	public void setTotalCotasParticipante(Double totalCotasParticipante) {
		this.totalCotasParticipante = totalCotasParticipante;
	}

	public Double getTotalValorParticipante() {
		return totalValorParticipante;
	}

	public void setTotalValorParticipante(Double totalValorParticipante) {
		this.totalValorParticipante = totalValorParticipante;
	}

	public Double getTotalCotasResgatavelParticipante() {
		return totalCotasResgatavelParticipante;
	}

	public void setTotalCotasResgatavelParticipante(Double totalCotasResgatavelParticipante) {
		this.totalCotasResgatavelParticipante = totalCotasResgatavelParticipante;
	}

	public Double getTotalValorResgatavelParticipante() {
		return totalValorResgatavelParticipante;
	}

	public void setTotalValorResgatavelParticipante(Double totalValorResgatavelParticipante) {
		this.totalValorResgatavelParticipante = totalValorResgatavelParticipante;
	}

	public Double getValorIR() {
		return valorIR;
	}

	public void setValorIR(Double valorIR) {
		this.valorIR = valorIR;
	}

	public Double getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(Double valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getTituloRelatorio() {
		return tituloRelatorio;
	}

	public void setTituloRelatorio(String tituloRelatorio) {
		this.tituloRelatorio = tituloRelatorio;
	}

	public Double getValorBruto() {
		return valorBruto;
	}

	public void setValorBruto(Double valorBruto) {
		this.valorBruto = valorBruto;
	}

	public String getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(String tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public String getIndicadorPagamento() {
		return indicadorPagamento;
	}

	public void setIndicadorPagamento(String indicadorPagamento) {
		this.indicadorPagamento = indicadorPagamento;
	}

	public int getQtdParcelas() {
		return qtdParcelas;
	}

	public void setQtdParcelas(int qtdParcelas) {
		this.qtdParcelas = qtdParcelas;
	}

	public String getTituloRecebedorPortabilidade() {
		return tituloRecebedorPortabilidade;
	}

	public void setTituloRecebedorPortabilidade(String tituloRecebedorPortabilidade) {
		this.tituloRecebedorPortabilidade = tituloRecebedorPortabilidade;
	}

	public Double getValorSaldoIsento() {
		return valorSaldoIsento;
	}

	public void setValorSaldoIsento(Double valorSaldoIsento) {
		this.valorSaldoIsento = valorSaldoIsento;
	}

}
