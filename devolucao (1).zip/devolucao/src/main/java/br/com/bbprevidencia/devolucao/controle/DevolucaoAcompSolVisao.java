package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.AcompSolPortParticipanteBO;
import br.com.bbprevidencia.devolucao.dto.AcompSolPortParticipante;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio para
 * o Cálculo / Visualização das Devoluções
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 26/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("devolucaoAcompSolVisao")
public class DevolucaoAcompSolVisao {

	private static final String FW_PESQUISA_DEVOLUCAO = "/paginas/pesquisaAcompanhamentoSolicitacao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_CALCULO_DEVOLUCAO = "/paginas/calculoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final String FW_ENVIO_DEFERIMENTO = "/paginas/processoEnvioDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_CANCELAMENTO_DEVOLUCAO = "/paginas/processoCancelamento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_VERIFICACAO_DEFERIMENTO = "/paginas/processoVerificacaoDeferimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_CONFERENCIA = "/paginas/processoConferencia.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_PROCESSO_RECEBIMENTO = "/paginas/processoAtualizacaoRecebimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static final String FW_DEVOLUCAO_MANUAL_REQUERIMENTO = "/paginas/devolucaoManualRequerimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(DevolucaoAcompSolVisao.class);

	@Autowired
	private AcompSolPortParticipanteBO acompSolPortParticipanteBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private ParticipanteBO participanteBO;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<Participante> listaParticipante;

	private EntidadeParticipante entidadeParticipante;

	private PlanoPrevidencia planoPrevidencia;

	private Participante participante;

	private Date dataRequerimento;

	private String status;

	private List<AcompSolPortParticipante> listaAcompSolicitacoes;

	// Variaveis de controle de ambiente
	private LoginBBPrevWebDTO loginTemporariaDTO;
	private boolean possuiAcessoTotal;
	private String urlRetorno;
	private String variavelRetorno;
	private Date dataRequerimentoAte;
	private Date dataRequerimentoDesde;

	/**
	 * Método encarredado por iniciar a página de pesquisa das solicitações
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 31/07/2019
	 * @return {@link String}
	 */
	public String iniciarTela() {

		validarAcessoFuncionalidade();

		limparFormularioPesquisa();

		this.listaEntidadeParticipante = listarEntidadeParticipante();

		this.listaPlanoPrevidencia = listarPlanoPrevidencia();

		return FW_PESQUISA_DEVOLUCAO;
	}

	/**
	 * Valida o tipo de acesso à página
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 22/05/2017
	 */
	public void validarAcessoFuncionalidade() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("pesquisaDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo
	 * inicial de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * 
	 */
	public void limparFormularioPesquisa() {
		this.setStatus(null);
		this.setDataRequerimentoAte(null);
		this.setDataRequerimentoDesde(null);

		this.listaAcompSolicitacoes = null;

	}

	/**
	 * Cria uma lista de itens da entidade participante.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return
	 */
	public List<EntidadeParticipante> listarEntidadeParticipante() {
		List<EntidadeParticipante> listaPatrocinadora = new ArrayList<EntidadeParticipante>();

		listaPatrocinadora = entidadeParticipanteBO.listarEntidadeParticipante();

		return listaPatrocinadora;
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/06/2017
	 * @return
	 */
	private List<PlanoPrevidencia> listarPlanoPrevidencia() {
		try {
			if (this.entidadeParticipante == null || this.entidadeParticipante.getChavePrimaria() == null) {
				return this.planoPrevidenciaBO.listarPlanoPrevidencia();
			} else {
				return this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante());
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new PrevidenciaException(e.getMessage());
		}
	}

	/**
	 * Método responsável por retornar a lista de Planos associados à
	 * patrocionadora selecionada.
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @param {@link
	 * 			AjaxBehaviorEvent}
	 * @return {@link String}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {

		// Limapdo os valores antigos à pesquisa
		setPlanoPrevidencia(null);
		setParticipante(new Participante());
		setListaParticipante(null);

		try {
			this.listaPlanoPrevidencia = listarPlanoPrevidencia();

		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}

		return FW_PESQUISA_DEVOLUCAO;
	}

	/**
	 * Método responsável por setar o Plano escolhido no select do plano
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link
	 * 			SelectEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		setParticipante(new Participante());
		setListaParticipante(null);

		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Método responsável por setar a Situação no Select de Situação
	 * 
	 * @author BBPF0468 - Carlos Wallace 
	 * @since 07/08/2019
	 * @param {@link
	 * 			SelectEvent}
	 */
	public void handleSelecionarSituacao(AjaxBehaviorEvent event) {

		setStatus((String) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getStatus())) {
			UtilSession.adicionarObjetoSessao("status", getStatus());

		} else {
			setStatus(null);
		}

	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o
	 * texo digitado no autocomplete
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link
	 * 			String} nome
	 * @return
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.planoPrevidencia != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else if (this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			return new ArrayList<Participante>();
		}

	}

	/**
	 * Retorna o estado inicial da página
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 26/01/2017
	 * @return
	 */
	public String limparPesquisa() {
		PrimeFaces.current().resetInputs("formDevolucao");
		return iniciarTela();
	}

	/**
	 * Método encarregado de retorna msn de acordo com a tela de retorno.
	 * 
	 * @author BBPF0170 - Magson DiAS
	 * @since 17/05/2017
	 * @param {@link
	 * 			String}
	 */

	public void paginaRetornoMessage(String msn) {
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, new FacesMessage("Consultar", "Tela de consulta: " + msn));
		PrimeFaces.current().ajax().update(":pgPesquisa");
	}

	/**
	 * Método encarregado de pesquisar as Solicitações
	 * pesquisa
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 31/07/2019
	 */
	public void pesquisarSolicitacoes() {
		try {

			this.listaAcompSolicitacoes = this.acompSolPortParticipanteBO.listarSolicitacoes(this.getParticipante(), this.getStatus(), this.getDataRequerimentoDesde(), this.getDataRequerimentoAte());

		} catch (Exception e) {
			log.error(e.getMessage());
			Mensagens.addMsgErro(e.getMessage());
			throw new PrevidenciaException(e.getMessage());

		}
	}

	public String atualizarSolicitacao(AcompSolPortParticipante acompSolPortParticipante) {
		try {

			acompSolPortParticipante.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			acompSolPortParticipante.setDataAlteracao(new Date());
			this.acompSolPortParticipanteBO.salvarAcompanhamentoSolicitacao(acompSolPortParticipante);

			Mensagens.addMsgInfo("Solicitação Atualizada com Sucesso!");

			this.iniciarTela();

		} catch (Exception e) {
			log.error(e.getMessage());
			Mensagens.addMsgErro(e.getMessage());
			throw new PrevidenciaException(e.getMessage());

		}

		return FW_PESQUISA_DEVOLUCAO;

	}

	// Getters And Setters

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public String getUrlRetorno() {
		return urlRetorno;
	}

	public void setUrlRetorno(String urlRetorno) {
		this.urlRetorno = urlRetorno;
	}

	public String getVariavelRetorno() {
		return variavelRetorno;
	}

	public void setVariavelRetorno(String variavelRetorno) {
		this.variavelRetorno = variavelRetorno;
	}

	public Date getDataRequerimentoAte() {
		return dataRequerimentoAte;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setDataRequerimentoAte(Date dataRequerimentoAte) {
		this.dataRequerimentoAte = dataRequerimentoAte;
	}

	public Date getDataRequerimentoDesde() {
		return dataRequerimentoDesde;
	}

	public void setDataRequerimentoDesde(Date dataRequerimentoDesde) {
		this.dataRequerimentoDesde = dataRequerimentoDesde;
	}

	public List<AcompSolPortParticipante> getListaAcompSolicitacoes() {
		return listaAcompSolicitacoes;
	}

	public void setListaAcompSolicitacoes(List<AcompSolPortParticipante> listaAcompSolicitacoes) {
		this.listaAcompSolicitacoes = listaAcompSolicitacoes;
	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

}
