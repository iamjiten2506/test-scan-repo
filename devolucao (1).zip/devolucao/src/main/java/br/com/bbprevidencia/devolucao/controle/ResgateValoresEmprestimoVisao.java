package br.com.bbprevidencia.devolucao.controle;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.dto.ParticipanteEmprestimoDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoLoginDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoSaldoDevedorEmprestimoDTO;
import br.com.bbprevidencia.devolucao.dto.UsuarioLoginDTO;
import br.com.bbprevidencia.devolucao.dto.response.ValorEmprestimoResponse;
import br.com.bbprevidencia.devolucao.interceptor.HeaderRequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class ResgateValoresEmprestimoVisao {

	@Value("${url.ambiente}")
	private String urlAmbiente;

	@Value("${url.emprestimo_service}")
	private String urlEmprestimo;

	@Value("${url.login-service}")
	private String urlLogin;

	public ValorEmprestimoResponse buscarValorEmprestimo(Participante participante, Date data) {
		ValorEmprestimoResponse valorEmprestimoResponse = new ValorEmprestimoResponse();
		try {
			String token = this.autenticarViaToken();

			if (token != null) {
				ParticipanteEmprestimoDTO participanteEmprestimoDTO = new ParticipanteEmprestimoDTO().builder().codigoParticipante(participante.getCodigo()).dataCalculo(
						UtilJava.formataDataPorPadrao(data, "dd/MM/yyyy")).build();

				System.setProperty("jsse.enableSNIExtension", "false");
				RestTemplate restTemplate = new RestTemplate();
				List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
				interceptors.add(new HeaderRequestInterceptor("AuthToken", token));
				restTemplate.setInterceptors(interceptors);

				String url = urlEmprestimo + "emprestimo/consultarSaldoDevedorEmprestimo/";

				RetornoSaldoDevedorEmprestimoDTO saldoDevedor = restTemplate.postForObject(url, participanteEmprestimoDTO, RetornoSaldoDevedorEmprestimoDTO.class);
				valorEmprestimoResponse.setValorEmprestimo(saldoDevedor.getSaldoDevedor());

			}
		} catch (Exception e) {
			System.out.println("Erro ao recuperar Saldo Devedor:" + e);
			return null;
		}
		return valorEmprestimoResponse;
	}

	private String autenticarViaToken() {
		try {
			UsuarioLoginDTO usuarioLoginDTO = UsuarioLoginDTO.builder().login("BBPENGRENAGEM").senha("12345678").build();

			System.setProperty("jsse.enableSNIExtension", "false");
			RestTemplate restTemplate = new RestTemplate();
			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();

			restTemplate.setInterceptors(interceptors);
			String url = urlLogin + "login-service/login/autenticarApi/";

			RetornoLoginDTO retorno = restTemplate.postForObject(url, usuarioLoginDTO, RetornoLoginDTO.class);

			if (retorno.isUsuarioAutenticado()) {
				return retorno.getToken();
			} else
				return null;

		} catch (Exception e) {
			System.out.println("Erro ao pegar  valores de emprestimos");
			throw new PrevidenciaException("Erro ao efetuar login.");
		}
	}
}
