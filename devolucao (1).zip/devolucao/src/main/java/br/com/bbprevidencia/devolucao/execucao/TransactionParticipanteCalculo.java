package br.com.bbprevidencia.devolucao.execucao;

import java.util.Date;

import br.com.bbprevidencia.cadastroweb.context.AppContext;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.ParticipanteDevolucaoPosicionadaDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.ReferenciaCalculoDevPosicionadoValoresBO;
import br.com.bbprevidencia.devolucao.dto.LoteProcessamentoReferenciaCalcDevolucao;
import br.com.bbprevidencia.devolucao.dto.MensagemLoteProcessamentoRefCalcDevolucao;
import br.com.bbprevidencia.devolucao.dto.ReferenciaCalculoDevPosicionadoValores;
import br.com.bbprevidencia.devolucao.dto.ReferenciaCalculoDevolucaoPosicionado;

public final class TransactionParticipanteCalculo {
	private final Long id;

	private ParticipanteDevolucaoPosicionadaDTO participanteDevolucaoPosicionadaDTO;
	private ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado;
	private LoginBBPrevWebDTO loginBBPrevWebDTO;
	private LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao;

	public TransactionParticipanteCalculo(Long id) {
		this.id = id;
	}

	public TransactionParticipanteCalculo(Long id, ParticipanteDevolucaoPosicionadaDTO participanteDevolucaoPosicionadaDTO,
			ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado, LoginBBPrevWebDTO loginBBPrevWebDTO,
			LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao) {
		super();
		this.id = id;
		this.participanteDevolucaoPosicionadaDTO = participanteDevolucaoPosicionadaDTO;
		this.referenciaCalculoDevolucaoPosicionado = referenciaCalculoDevolucaoPosicionado;
		this.loginBBPrevWebDTO = loginBBPrevWebDTO;
		this.loteProcessamentoReferenciaCalcDevolucao = loteProcessamentoReferenciaCalcDevolucao;
	}

	/**
	 * Returns a boolean indicating if the transaction was processed
	 * successfully
	 * 
	 * @return
	 * @throws Exception 
	 * @throws PrevidenciaException 
	 */
	public ReferenciaCalculoDevPosicionadoValores process() {
		// waits 5 milliseconds(simulates a slow task, such as accessing a remote system)
		ReferenciaCalculoDevPosicionadoValoresBO calculoDevolucaoBO = AppContext.getApplicationContext().getBean(ReferenciaCalculoDevPosicionadoValoresBO.class);
		try {
			return calculoDevolucaoBO.calcularDevolucaoAssinc(participanteDevolucaoPosicionadaDTO, loteProcessamentoReferenciaCalcDevolucao, referenciaCalculoDevolucaoPosicionado, loginBBPrevWebDTO);
		} catch (Exception e) {
			//Insere o erro na tabela
			MensagemLoteProcessamentoRefCalcDevolucao msg = new MensagemLoteProcessamentoRefCalcDevolucao(loteProcessamentoReferenciaCalcDevolucao, new Date(), participanteDevolucaoPosicionadaDTO
					.getChavePrimaria().getCodigoParticipantePlano(), e.getMessage(), "E", new Date(), loginBBPrevWebDTO.getUsuarioSessao().getDescricaoLogin());

			return new ReferenciaCalculoDevPosicionadoValores(msg);
		}
	}

	public Long getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + "]";
	}

	public ParticipanteDevolucaoPosicionadaDTO getParticipanteDevolucaoPosicionadaDTO() {
		return participanteDevolucaoPosicionadaDTO;
	}

	public void setParticipanteDevolucaoPosicionadaDTO(ParticipanteDevolucaoPosicionadaDTO participanteDevolucaoPosicionadaDTO) {
		this.participanteDevolucaoPosicionadaDTO = participanteDevolucaoPosicionadaDTO;
	}

	public ReferenciaCalculoDevolucaoPosicionado getReferenciaCalculoDevolucaoPosicionado() {
		return referenciaCalculoDevolucaoPosicionado;
	}

	public void setReferenciaCalculoDevolucaoPosicionado(ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado) {
		this.referenciaCalculoDevolucaoPosicionado = referenciaCalculoDevolucaoPosicionado;
	}

	public LoginBBPrevWebDTO getLoginBBPrevWebDTO() {
		return loginBBPrevWebDTO;
	}

	public void setLoginBBPrevWebDTO(LoginBBPrevWebDTO loginBBPrevWebDTO) {
		this.loginBBPrevWebDTO = loginBBPrevWebDTO;
	}

	public LoteProcessamentoReferenciaCalcDevolucao getLoteProcessamentoReferenciaCalcDevolucao() {
		return loteProcessamentoReferenciaCalcDevolucao;
	}

	public void setLoteProcessamentoReferenciaCalcDevolucao(LoteProcessamentoReferenciaCalcDevolucao loteProcessamentoReferenciaCalcDevolucao) {
		this.loteProcessamentoReferenciaCalcDevolucao = loteProcessamentoReferenciaCalcDevolucao;
	}

}