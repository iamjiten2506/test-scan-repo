package br.com.bbprevidencia.devolucao.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RelatorioSimulacaoResgatePortabilidadeDTO {

	private String nomePai;
	private String nomeParticipante;
	private String matriculaParticipante;
	private String nomeMae;
	private String nomePatrocinadora;
	private Date dataNascimento;
	private Date dataObito;
	private String identidade;
	private String cpf;
	private String sexo;
	private String estadoCivil;
	private Date dataEmissaoIdentidade;
	private String email;
	private String enderecoLogradouro;
	private String enderecoBairro;
	private String enderecoNumero;
	private String enderecoCidade;
	private String enderecoComplemento;
	private String enderecoCEP;
	private String enderecoUF;
	private String banco;
	private String agencia;
	private String conta;
	private String tipoConta;
	private String tipoCobranca;
	private String tipoCobrancaEsporadica;
	private String nacionalidade;
	private Date dataAdmissao;
	private Date dataInscricaoPlano;
	private Date dataDesligamento;
	private String situacaoEmpresa;
	private String motivoDesligamento;
	private Date dataSituacaoEmpresa;

	private List<DadosPlanoResgatePortabilidadeDTO> listaDadosPlanoResgatePortabilidade = new ArrayList<DadosPlanoResgatePortabilidadeDTO>();

	public String getNomePai() {
		return nomePai;
	}

	public void setNomePai(String nomePai) {
		this.nomePai = nomePai;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getNomeMae() {
		return nomeMae;
	}

	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}

	public String getNomePatrocinadora() {
		return nomePatrocinadora;
	}

	public void setNomePatrocinadora(String nomePatrocinadora) {
		this.nomePatrocinadora = nomePatrocinadora;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public Date getDataObito() {
		return dataObito;
	}

	public void setDataObito(Date dataObito) {
		this.dataObito = dataObito;
	}

	public String getIdentidade() {
		return identidade;
	}

	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public Date getDataEmissaoIdentidade() {
		return dataEmissaoIdentidade;
	}

	public void setDataEmissaoIdentidade(Date dataEmissaoIdentidade) {
		this.dataEmissaoIdentidade = dataEmissaoIdentidade;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEnderecoLogradouro() {
		return enderecoLogradouro;
	}

	public void setEnderecoLogradouro(String enderecoLogradouro) {
		this.enderecoLogradouro = enderecoLogradouro;
	}

	public String getEnderecoBairro() {
		return enderecoBairro;
	}

	public void setEnderecoBairro(String enderecoBairro) {
		this.enderecoBairro = enderecoBairro;
	}

	public String getEnderecoNumero() {
		return enderecoNumero;
	}

	public void setEnderecoNumero(String enderecoNumero) {
		this.enderecoNumero = enderecoNumero;
	}

	public String getEnderecoCidade() {
		return enderecoCidade;
	}

	public void setEnderecoCidade(String enderecoCidade) {
		this.enderecoCidade = enderecoCidade;
	}

	public String getEnderecoComplemento() {
		return enderecoComplemento;
	}

	public void setEnderecoComplemento(String enderecoComplemento) {
		this.enderecoComplemento = enderecoComplemento;
	}

	public String getEnderecoCEP() {
		return enderecoCEP;
	}

	public void setEnderecoCEP(String enderecoCEP) {
		this.enderecoCEP = enderecoCEP;
	}

	public String getEnderecoUF() {
		return enderecoUF;
	}

	public void setEnderecoUF(String enderecoUF) {
		this.enderecoUF = enderecoUF;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getTipoCobranca() {
		return tipoCobranca;
	}

	public void setTipoCobranca(String tipoCobranca) {
		this.tipoCobranca = tipoCobranca;
	}

	public String getTipoCobrancaEsporadica() {
		return tipoCobrancaEsporadica;
	}

	public void setTipoCobrancaEsporadica(String tipoCobrancaEsporadica) {
		this.tipoCobrancaEsporadica = tipoCobrancaEsporadica;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	public Date getDataAdmissao() {
		return dataAdmissao;
	}

	public void setDataAdmissao(Date dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public Date getDataInscricaoPlano() {
		return dataInscricaoPlano;
	}

	public void setDataInscricaoPlano(Date dataInscricaoPlano) {
		this.dataInscricaoPlano = dataInscricaoPlano;
	}

	public Date getDataDesligamento() {
		return dataDesligamento;
	}

	public void setDataDesligamento(Date dataDesligamento) {
		this.dataDesligamento = dataDesligamento;
	}

	public String getSituacaoEmpresa() {
		return situacaoEmpresa;
	}

	public void setSituacaoEmpresa(String situacaoEmpresa) {
		this.situacaoEmpresa = situacaoEmpresa;
	}

	public String getMotivoDesligamento() {
		return motivoDesligamento;
	}

	public void setMotivoDesligamento(String motivoDesligamento) {
		this.motivoDesligamento = motivoDesligamento;
	}

	public Date getDataSituacaoEmpresa() {
		return dataSituacaoEmpresa;
	}

	public void setDataSituacaoEmpresa(Date dataSituacaoEmpresa) {
		this.dataSituacaoEmpresa = dataSituacaoEmpresa;
	}

	public List<DadosPlanoResgatePortabilidadeDTO> getListaDadosPlanoResgatePortabilidade() {
		return listaDadosPlanoResgatePortabilidade;
	}

	public void setListaDadosPlanoResgatePortabilidade(List<DadosPlanoResgatePortabilidadeDTO> listaDadosPlanoResgatePortabilidade) {
		this.listaDadosPlanoResgatePortabilidade = listaDadosPlanoResgatePortabilidade;
	}

}
