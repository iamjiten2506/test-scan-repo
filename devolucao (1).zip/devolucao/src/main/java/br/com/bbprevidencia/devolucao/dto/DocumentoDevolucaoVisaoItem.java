package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * Classe de persistência para tabela DOC_DEV_VIS_ITE
 *  
 * @author  BBPF0333 - Daniel Martins
 * @since   14/03/2017
 *
 *
 */
@Entity
@Table(name = "DOC_DEV_VIS_ITE", schema = "OWN_DCR")
@NamedQuery(name = "DocumentoDevolucaoVisaoItem.findAll", query = "SELECT q FROM DocumentoDevolucaoVisaoItem q")
public class DocumentoDevolucaoVisaoItem implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DOC_DEV_VIS_ITE_GER", sequenceName = "S_DDVI_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOC_DEV_VIS_ITE_GER")
	@Column(name = "NUM_SEQ_DOC_DEV_VIS_ITE")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_DOC_DEV_VIS")
	private DocumentoDevolucaoVisao documentoDevolucaoVisao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DOC_DEV")
	private DocumentoDevolucao documentoDevolucao;

	@Column(name = "IND_OBR")
	private String indicativoObrigatorio;

	@Column(name = "IND_MAR")
	private String indicativoMarcado;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_MAR")
	private Date dataMarcacao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public DocumentoDevolucaoVisao getDocumentoDevolucaoVisao() {
		return documentoDevolucaoVisao;
	}

	public void setDocumentoDevolucaoVisao(DocumentoDevolucaoVisao documentoDevolucaoVisao) {
		this.documentoDevolucaoVisao = documentoDevolucaoVisao;
	}

	public String getIndicativoObrigatorio() {
		return indicativoObrigatorio;
	}

	public void setIndicativoObrigatorio(String indicativoObrigatorio) {
		this.indicativoObrigatorio = indicativoObrigatorio;
	}

	public String getIndicativoMarcado() {
		return indicativoMarcado;
	}

	public void setIndicativoMarcado(String indicativoMarcado) {
		this.indicativoMarcado = indicativoMarcado;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentoDevolucaoVisaoItem other = (DocumentoDevolucaoVisaoItem) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	public DocumentoDevolucao getDocumentoDevolucao() {
		return documentoDevolucao;
	}

	public void setDocumentoDevolucao(DocumentoDevolucao documentoDevolucao) {
		this.documentoDevolucao = documentoDevolucao;
	}

	public Date getDataMarcacao() {
		return dataMarcacao;
	}

	public void setDataMarcacao(Date dataMarcacao) {
		this.dataMarcacao = dataMarcacao;
	}

}