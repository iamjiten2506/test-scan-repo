package br.com.bbprevidencia.devolucao.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.dto.ParametroIntegracaoOptOutDevolucao;
import br.com.bbprevidencia.infra.repository.JpaDao;

/**
 // * Classe de acesso aos dados de parâmetros de integração cont�bil financeira devolução.
 *
 * @author  BBPF0333 - Daniel Martins
 * @since   24/01/2017
 * 
 * Copyright notice (c) 2017 BBPrevid�ncia S/A
 */
@Repository
@Qualifier("parametroIntegracaoOptOutDevolucaoDao")
@Scope(proxyMode = ScopedProxyMode.NO, value = "prototype")
public class ParametroIntegracaoOptOutDevolucaoDAO extends JpaDao<ParametroIntegracaoOptOutDevolucao> implements Serializable {

	private static final long serialVersionUID = 8145007218992259308L;

	private static Logger log = Logger.getLogger(ParametroIntegracaoOptOutDevolucaoDAO.class);

	/**
	 * Salva ou altera o parâmetros de integração optout devolução correspondente. Salva se o mesmo j� contenha
	 * id na sessao do provedor de persist�ncia, ou insere se nao h� id
	 * correspondente.
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since   07/08/2020
	 * @param   {@link ParametroIntegracaoOptOutDevolucao}
	 * @throws   PrevidenciaException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void salvarParametroIntegracaoOptOutDevolucao(ParametroIntegracaoOptOutDevolucao parametroIntegracaoOptOutDevolucao) throws PrevidenciaException {
		if (parametroIntegracaoOptOutDevolucao == null) {
			throw new PrevidenciaException("A parâmetros de integração cont�bil financeira devolução deve estar inicializada para inser��o ou altera��o.");
		} else {
			try {
				if (parametroIntegracaoOptOutDevolucao.getCodigo() != null) {
					update(parametroIntegracaoOptOutDevolucao);
				} else {
					save(parametroIntegracaoOptOutDevolucao);
				}
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}

		}
	}

	/**
	 * apaga a parâmetros de integração opt out devolução
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since   07/08/2020
	 * @param   {@link ParametroIntegracaoOptOutDevolucao}
	 * @throws  PrevidenciaException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void apagarParametroIntegracaoOptOutDevolucao(ParametroIntegracaoOptOutDevolucao parametroIntegracaoOptOutDevolucao) throws PrevidenciaException {
		if (parametroIntegracaoOptOutDevolucao == null) {
			throw new PrevidenciaException("A parâmetros de integração cont�bil financeira devolução deve estar inicializada para inser��o ou altera��o.");
		} else {
			try {
				delete(parametroIntegracaoOptOutDevolucao.getCodigo());
				getEntityManager().flush();
			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException(ex);
			}
		}
	}

	/**
	 * Método responsável por pesquisar a parâmetros de integração opt out devolução por c�digo
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since   07/08/2020
	 * @param   Long
	 * @return {@link ParametroIntegracaoOptOutDevolucao}
	 * @throws PrevidenciaException
	 */
	public ParametroIntegracaoOptOutDevolucao pesquisarParametroIntegracaoOptOutDevolucaoPorCodigo(Long codigo) throws PrevidenciaException {
		try {
			return (ParametroIntegracaoOptOutDevolucao) getEntityManager().find(ParametroIntegracaoOptOutDevolucao.class, codigo);
		} catch (NoResultException e) {
			log.error(e);
			throw new PrevidenciaException("Não foi encontrada a parâmetros de integração financeira devolução solicitada.");
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar esta operação", ex);
		}
	}

	/**
	 * Método responsável por listar todas as parâmetros de integração opt out devolução
	 * 
	 * @author  BBPF0468 - Carlos Wallace
	 * @since   07/08/2020
	 * @return  {@link List<ParametroIntegracaoOptOutDevolucao>}
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings("unchecked")
	public List<ParametroIntegracaoOptOutDevolucao> listarTodasParametroIntegracaoOptOutDevolucao() throws PrevidenciaException {
		try {
			return getEntityManager().createNamedQuery("ParametroIntegracaoOptOutDevolucao.findAll").getResultList();
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar esta operação", ex);
		}

	}

	/**
	 * Método responsável por lista parâmetro de integração COptOut, conforme critérios de pesquisa.
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 07/08/2020
	 * @return {@link List<ParametroIntegracaoOptOutDevolucao>}
	 * @throws PrevidenciaException
	 */
	@SuppressWarnings("unchecked")
	public List<ParametroIntegracaoOptOutDevolucao> filtrarListaParametroIntegracaoOptOutDevolucao(PlanoPrevidencia planoPrevidencia, Date dataInicioVigencia, Date dataTerminoVigencia) {

		try {
			StringBuilder strquery = new StringBuilder();

			strquery.append("from ParametroIntegracaoOptOutDevolucao where planoPrevidencia.codigo = :planoPrevidenciaCodigo");

			if (dataInicioVigencia != null) {
				strquery.append(" and dataInicioVigencia >= " + dataInicioVigencia);
			}

			if (dataTerminoVigencia != null) {
				strquery.append(" and dataTerminoVigencia <= " + dataTerminoVigencia);
			}

			Query query = getEntityManager().createQuery(strquery.toString());

			query.setParameter("planoPrevidenciaCodigo", planoPrevidencia.getCodigo());

			return query.getResultList();
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar esta operação.", ex);
		}

	}

	public ParametroIntegracaoOptOutDevolucao pesquisarParametroIntegracaoOptOutDevolucaoVigente() throws PrevidenciaException {
		try {
			Query query = getEntityManager().createQuery(
					"SELECT P FROM ParametroIntegracaoOptOutDevolucao P WHERE P.dataInicioVigencia <= :dataAtual AND (P.dataTerminoVigencia >= :dataAtual OR P.dataTerminoVigencia = null)");
			query.setParameter("dataAtual", new Date(), TemporalType.DATE);

			return (ParametroIntegracaoOptOutDevolucao) query.getSingleResult();

		} catch (NoResultException e) {
			log.error(e);
			throw new PrevidenciaException("Não foi encontrado  parâmetro de integração optout solicitado.");
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar esta operação", ex);
		}

	}

}
