package br.com.bbprevidencia.devolucao.controle;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.faces.component.UIOutput;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import br.bb.previdencia.seguranca.criptografia.Criptografia;
import br.com.bbprevidencia.alcada.dto.RetornoFecharLoteAlcadaDTO;
import br.com.bbprevidencia.alcada.dto.RetornoInsercaoMovAlcadaDTO;
import br.com.bbprevidencia.alcada.dto.RetornoMsgLoteAlcadaDTO;
import br.com.bbprevidencia.alcada.dto.RetornoSolicitacaoLoteAlcadaDTO;
import br.com.bbprevidencia.arrecadacao.bo.ProcessamentoControleArrecadacaoBO;
import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.AHistoricoFinanceiroPagoBO;
import br.com.bbprevidencia.cadastroweb.bo.AgenciaBancariaBO;
import br.com.bbprevidencia.cadastroweb.bo.BancoBO;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.HistoricoFinanceiroPagoBO;
import br.com.bbprevidencia.cadastroweb.bo.ParametroGeralBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PerfilInvestimentoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.bo.SituacaoParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.SituacaoParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.ValorPendenteFundoPrevidencialBO;
import br.com.bbprevidencia.cadastroweb.dto.AHistoricoFinanceiroPago;
import br.com.bbprevidencia.cadastroweb.dto.BancoDTO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.HistoricoFinanceiroPago;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.ParametroGeral;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.dto.ValorPendenteFundoPrevidencial;
import br.com.bbprevidencia.cadastroweb.servico.AmbienteServico;
import br.com.bbprevidencia.cadastroweb.servico.EmailServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.contabilidade.bo.OperacaoInternaBO;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.devolucao.bo.CalculoOptOutBO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoSolicitacaoOptOutBO;
import br.com.bbprevidencia.devolucao.bo.LancamentoIntegracaoOptOutBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoAlcadaBO;
import br.com.bbprevidencia.devolucao.bo.OptOutBO;
import br.com.bbprevidencia.devolucao.bo.ParametroDocumentoOptOutBO;
import br.com.bbprevidencia.devolucao.bo.SolicitacaoOptOutBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AprovacaoAlcadaDTO;
import br.com.bbprevidencia.devolucao.dto.CalculoOptOut;
import br.com.bbprevidencia.devolucao.dto.CalculoSolicitacaoSumulaDTO;
import br.com.bbprevidencia.devolucao.dto.CheckListSolicitacaoSumulaDTO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.DocumentoSolicitacaoOptOut;
import br.com.bbprevidencia.devolucao.dto.LancamentoIntegracaoOptOut;
import br.com.bbprevidencia.devolucao.dto.RetornoCalculoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.RetornoSolicitacaoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.SolicitacaoOptOut;
import br.com.bbprevidencia.devolucao.dto.TermoAnulacaoOptOutDTO;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoSolicitacaoOptOutEnum;
import br.com.bbprevidencia.devolucao.util.DataUtil;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.folha.bo.QualidadeRecebedorBO;
import br.com.bbprevidencia.folha.bo.RecebedorBO;
import br.com.bbprevidencia.folha.bo.SituacaoRecebedorBO;
import br.com.bbprevidencia.pessoa.bo.AtuacaoPessoaBO;
import br.com.bbprevidencia.pessoa.bo.PessoaEntidadeBO;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;
import br.com.bbprevidencia.pessoa.dto.PessoaEntidade;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author BBPF0468 - Carlos Wallace
 * @since 27/07/2020
 *
 *        Copyright notice (c) 2020 BBPrevidência S/A
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
@Scope("session")
@Component("solicitacaoOptOutVisao")
public class SolicitacaoOptOutVisao {

	private static String FW_SOLICITACAO_OPTOUT = "/paginas/solicitacaoOptOut.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static String FW_DETALHE_CALCULO_OPTOUT = "/paginas/detalheCalculoOptOut.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static String FW_INTEGRACAO_OPTOUT = "/paginas/integracaoFechamentoOptOut.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(SolicitacaoOptOutVisao.class);

	@Autowired
	private SolicitacaoOptOutBO solicitacaoOptOutBO;

	@Autowired
	private ParametroGeralBO parametroGeralBO;

	private List<SolicitacaoOptOut> listaSolicitacao;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private SituacaoParticipantePlanoBO situacaoParticipantePlanoBO;

	@Autowired
	private SituacaoParticipanteBO situacaoParticipanteBO;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private MovimentoAlcadaBO movimentoAlcadaBO;

	@Autowired
	private AHistoricoFinanceiroPagoBO aHistoricoFinanceiroPagoBO;

	@Autowired
	private OptOutBO optOutBO;

	@Autowired
	private ServletContext context;

	@Autowired
	private ProcessamentoControleArrecadacaoBO processamentoControleArrecadacaoBO;

	@Autowired
	private HistoricoFinanceiroPagoBO historicoFinanceiroPagoBO;

	@Autowired
	private BancoBO bancoBO;

	@Autowired
	private ParametroDocumentoOptOutBO parametroDocumentoOptOutBO;

	private SolicitacaoOptOut solicitacao;

	private SolicitacaoOptOut solicitacaoDetalhe;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<Participante> listaParticipante;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private Participante participante;

	private CronogramaDevolucao cronogramaDevolucao;

	private EntidadeParticipante entidadeParticipante;

	private String numeroMatriculaPatrocinadora;

	private boolean patrocinadoraEditavel;

	private String status;

	private Long codigoSituacao;

	private Date dataSolicitacao;

	private Date dataCancelamento;

	private List<CalculoOptOut> listaCalculos;

	private List<CalculoOptOut> listaCalculoOptOut;

	private List<SolicitacaoOptOut> listaSolicitacaoSelecionada;

	private List<AprovacaoAlcadaDTO> listaDeferimentoSolicitacao;

	private SolicitacaoOptOut solicitacaoBuscaDeferimento;

	@Autowired
	private EmailServico emailServico;

	@Autowired
	private CalculoOptOutBO calculoOptOutBO;

	private List<LancamentoIntegracaoOptOut> listaLancamentosIntegracaoOptOut;

	private List<OperacaoInterna> listaOperacoesInternasOptOut;

	@Autowired
	private OperacaoInternaBO operacaoInternaBO;

	@Autowired
	private RecebedorBO recebedorBO;

	@Autowired
	private PerfilInvestimentoBO perfilInvestimentoBO;

	@Autowired
	private AtuacaoPessoaBO atuacaoPessoaBO;

	@Autowired
	private PessoaEntidadeBO pessoaEntidadeBO;

	@Autowired
	private QualidadeRecebedorBO qualidadeRecebedorBO;

	@Autowired
	private SituacaoRecebedorBO situacaoRecebedorBO;

	@Autowired
	private AgenciaBancariaBO agenciaBancariaBO;

	@Autowired
	private LancamentoIntegracaoOptOutBO lancamentoIntegracaoOptOutBO;

	private List<HistoricoFinanceiroPago> listaHistoricoFinanceiroPagoOptOut;

	private HashMap<String, HistoricoFinanceiroPago> hashMapHistFinPagTipoContrib;

	@Autowired
	private AmbienteServico ambienteServico;

	@Autowired
	private ValorPendenteFundoPrevidencialBO valorPendenteFundoPrevidencialBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private DocumentoSolicitacaoOptOutBO documentoSolicitacaoOptOutBO;

	private Double totalDetalheOptOutPartic;

	private Double totalDetalheOptOutPatroc;

	private Double totalDetalheOptOutTaxaPartic;

	private Double totalDetalheOptOutTaxaPatroc;

	private Double totalDetalheOptOutParticIndice;

	private Double totalDetalheOptOutPatrocIndice;

	private Double totalDetalheOptOutParticCota;

	private Double totalDetalheOptOutPatrocCota;

	private Date dataCotaCalculoSolicitacao;

	private Double valorCotaCalculoSolicitacao;

	private Double valorPendenteSolicitacao;

	private boolean existeSobranteFaltante;

	private List<DocumentoSolicitacaoOptOut> listaCheckListSolicitacao;

	private String textoDialogRetroativo;

	/**
	 * Método encarredado por iniciar a página
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 27/07/2020
	 * @return {@link String}
	 */
	public String iniciarTela(String tipo) {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		// Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		} else {
			this.possuiAcessoTotal = false;
		}

		limparFormularioPesquisa();
		if (UtilJava.isColecaoVazia(this.listaEntidadeParticipante)) {
			//pesquisa o plano BBPrev Brasil
			PlanoPrevidencia planoBBPrevBrasil = this.planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(141L);

			//pesquisa o plano PE-Prevcom
			PlanoPrevidencia planoPePrevcom = this.planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(146L);
			
			if (planoBBPrevBrasil != null || planoPePrevcom != null) {
				this.listaEntidadeParticipante = new ArrayList<>(this.entidadeParticipanteBO.listarEntidadeParticipanteOptOut());
			} else {
				this.listaEntidadeParticipante = new ArrayList<>(this.entidadeParticipanteBO.listarEntidadeParticipante());
			}
			
		}

		//this.listaTipoDevolucao = listarTipoDevolucao();

		//Verifica e atualiza as Solicitações que já foram deferidas
		//this.atualizarSolicitacoesDeferidas();

		return tipo.equalsIgnoreCase("SOLICITACAO") ? FW_SOLICITACAO_OPTOUT : FW_INTEGRACAO_OPTOUT;
	}

	public void atualizarSolicitacoesDeferidas() {

		try {

			List<SolicitacaoOptOut> listaSolicitacoesDeferidas = this.solicitacaoOptOutBO.listarSolicitacoesDeferidas();
			if (!listaSolicitacoesDeferidas.isEmpty()) {
				//Atualiza as situações das solicitações
				this.solicitacaoOptOutBO.salvarListaSolicitacoes(listaSolicitacoesDeferidas);
			}

		} catch (Exception e) {

			log.error(e.getMessage());

		}

	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo inicial
	 * de pesquisa
	 * 
	 * @author BBPF0170 - Magson Dias
	 * @since 26/01/2017
	 */
	public void limparFormularioPesquisa() {
		this.patrocinadoraEditavel = true;
		this.listarStatus = true;

		this.entidadeParticipante = null;
		this.listaEntidadeParticipante = null;
		this.participante = null;
		this.setParticipante(new Participante());
		this.listaParticipante = null;

		this.listaSolicitacao = null;
		this.listaSolicitacaoSelecionada = null;

		this.dataSolicitacao = null;
		this.dataCancelamento = null;

	}

	/**
	 * Retorna o estado inicial da página
	 * 
	 * @author BBPF0170 - Magson
	 * @since 17/02/2017
	 * @return {@link String}
	 */
	public String limparPesquisa(String tipo) {
		PrimeFaces.current().resetInputs("formProcessoDevCanc");
		limparFormularioPesquisa();
		return iniciarTela(tipo);
	}

	/**
	 * Método responsável por listar todos os tipos de devoluções
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2017
	 * @return
	 */
	public List<SelectItem> listarTipoDevolucao() {
		List<SelectItem> itens = new ArrayList<SelectItem>();

		List<TipoDevolucao> listaTipoDevolucaoTemp = tipoDevolucaoBO.listarTodosTipoDevolucao();
		if (!UtilJava.isColecaoVazia(listaTipoDevolucaoTemp)) {
			for (TipoDevolucao tipoDev : listaTipoDevolucaoTemp) {
				itens.add(new SelectItem(tipoDev.getCodigo(), tipoDev.getNome()));
			}
		}

		return itens;
	}

	/**
	 * Método responsável por setar a Situação no Select de Situação
	 * 
	 * @author BBPF0468 - Carlos Wallace 
	 * @since 07/08/2019
	 * @param {@link
	 * 			SelectEvent}
	 */
	public void handleSelecionarSituacao(AjaxBehaviorEvent event) {

		setStatus((String) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getStatus())) {
			UtilSession.adicionarObjetoSessao("status", getStatus());
			setCodigoSituacao(Long.parseLong(getStatus()));

		} else {
			setStatus(null);
			setCodigoSituacao(null);
		}

	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo
	 * digitado no autocomplete
	 * 
	 * @author BBPF0170 - MAGSON
	 * @param {@link String nome }
	 * @return {@link List<Participante>}
	 */
	public List<Participante> listarParticipantesPorNomeEEntidade(String nome) {
		return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link event}
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());

		if (!UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("participante", getParticipante());
		} else {
			setParticipante(new Participante());
		}
	}

	/**
	 * Método para retornar as solicitações de optout
	 * 
	 * @author BBPF0468 - Carlos Wallace
	 * @since 27/07/2020
	 * @param {@link event}
	 * @return {@link String}
	 */
	public void pesquisarSolicitacoes() {
		this.listaSolicitacao = new ArrayList<>();
		
		if (this.getParticipante() == null || this.getParticipante().getCodigo() == null) {

			this.setParticipante(null);

		}

		this.listaSolicitacao = this.solicitacaoOptOutBO.listarSolicitacoesFiltro(this.entidadeParticipante, 
				this.participante, 
				this.codigoSituacao, 
				this.dataSolicitacao, 
				this.dataCancelamento);
		
	}

	public void pesquisarSolicitacoesIntegracaoFechamento() {
		this.listaSolicitacao = new ArrayList<>();
		
		if (this.getParticipante() == null || this.getParticipante().getCodigo() == null) {

			this.setParticipante(null);

		}
		
		if (this.codigoSituacao == null) {
			this.listaSolicitacao = this.solicitacaoOptOutBO.listarSolicitacoesIntegracaoFechamento(this.entidadeParticipante, 
					this.participante, 
					this.codigoSituacao, 
					this.dataSolicitacao, 
					this.dataCancelamento);
		} else {
			this.listaSolicitacao = this.solicitacaoOptOutBO.listarSolicitacoesFiltro(this.entidadeParticipante, 
					this.participante, 
					this.codigoSituacao, 
					this.dataSolicitacao, 
					this.dataCancelamento);
		}

		
		
	}

	public void cancelarSolicitacao(SolicitacaoOptOut solicitacao) {
		try {

			log.info("Cancelando Solicitação do Participante: " + solicitacao.getParticipante().getNomeParticipante());
			
			solicitacao.setSituacao(SituacaoSolicitacaoOptOutEnum.CANCELADO.getCodigo());
			solicitacao.setDataCancelamentoSolicitacao(new Date());
			solicitacao.setNomeUsuarioCancelamentoSolicitacao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			
			//Atualiza A Solicitação
			Boolean solicitacaoAlterada = this.solicitacaoOptOutBO.salvarSolicitacao(solicitacao);
			
			
			if (solicitacaoAlterada) {
				//voltar a situação do participante para Ativo.
				solicitacaoAlterada = this.optOutBO.atualizarSituacaoParticipante(participante, "01");
				
				if(solicitacaoAlterada) {
					Mensagens.addMsgInfo("Solicitação Cancelada com Sucesso!");
					this.listaSolicitacao = new ArrayList<>();
				} else {
					Mensagens.addMsgErro("Erro ao atualizar a situação do participante.");
				}
				
			} else {
				Mensagens.addMsgErro("Erro ao cancelar a solicitação");
			}

		} catch (Exception e) {

			log.error(e.getMessage());
			Mensagens.addMsgErro(e.getMessage());		

		}

	}

	public void processarSolicitacao(SolicitacaoOptOut solicitacao) {
		try {
			if (this.existeContribuicaoSemIndividualizar(solicitacao)) {
				throw new PrevidenciaException("O Participante possui lançamentos aguardando cotas, favor verificar.");
			}

			if (!this.existeDocumentosOptOutCkeckListPatrocinadora(solicitacao)) {
				throw new PrevidenciaException("Não existem documentos cadastrados para Check List de Opt Out.");
			}

			if (this.calcularSolicitacaoOptOut(solicitacao)) {
				Mensagens.addMsgInfo("Solicitacao N° " + solicitacao.getCodigo() + " calculada com sucesso!");
			} else {
				throw new PrevidenciaException("Erro ao calcular a Solicitacao N° " + solicitacao.getCodigo() + ".");
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			Mensagens.addMsgErro(e.getMessage());
		} finally {
			this.pesquisarSolicitacoes();
		}

	}

	private boolean existeDocumentosOptOutCkeckListPatrocinadora(SolicitacaoOptOut solicitacao) {
		return this.parametroDocumentoOptOutBO.existeDocumentosOptOutCkeckListPatrocinadora(solicitacao.getParticipante().getEntidadeParticipante());
	}

	private Boolean existeContribuicaoSemIndividualizar(SolicitacaoOptOut solicitacao) {
		//Verificar se há contruibuições em individualizar
		List<AHistoricoFinanceiroPago> listaSemIndividualizar = this.aHistoricoFinanceiroPagoBO.listarAguardandoCotaPorCodigoParticipante(solicitacao.getParticipante().getCodigo());

		return UtilJava.isColecaoDiferenteDeVazia(listaSemIndividualizar);
	}

	private boolean calcularSolicitacaoOptOut(SolicitacaoOptOut solicitacao) {
		Boolean solicitacaoProcessada = false;
		log.info("Processando Solicitação do Participante: " + solicitacao.getParticipante().getNomeParticipante());

		//Calcula a Solicitação
		RetornoCalculoOptOutDTO retornoCalculoOptOut = this.calculoOptOutBO.calcularSolicitacao(solicitacao);

		if (UtilJava.isColecaoDiferenteDeVazia(retornoCalculoOptOut.getListaCalculoOptoOut())) {
			Long codigoSituacaoAnterior = solicitacao.getSituacao();
			solicitacao.getListaCalculoSolicitacao().clear();
			solicitacao.setListaCalculoSolicitacao(retornoCalculoOptOut.getListaCalculoOptoOut());
			solicitacao.setDataCalculo(new Date());
			solicitacao.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			solicitacao.setSituacao(SituacaoSolicitacaoOptOutEnum.CALCULADO.getCodigo());
			solicitacaoProcessada = this.solicitacaoOptOutBO.salvarSolicitacao(solicitacao);

			//Gera a lista de Documentos de Opt Out
			if (solicitacaoProcessada && codigoSituacaoAnterior == SituacaoSolicitacaoOptOutEnum.REQUERIDO.getCodigo()) {
				solicitacaoProcessada = this.documentoSolicitacaoOptOutBO.salvarCheckListDocumentosSolicitacao(solicitacao, this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			}
		}

		return solicitacaoProcessada;
	}

	public void modalSolicitacao(SolicitacaoOptOut solicitacaoOptOut) {

		this.setSolicitacao(solicitacaoOptOut);
		PrimeFaces.current().executeScript("PF('validarSolicitacao').show()");

	}

	public void deferirSolicitacao(SolicitacaoOptOut solicitacaoOptOut) {

		try {

			log.info("Deferindo Solicitação " + solicitacaoOptOut.getParticipante().getNomeParticipante());
			solicitacaoOptOut.setSituacao(SituacaoSolicitacaoOptOutEnum.CONCEDIDO.getCodigo());

			this.validarSolicitacao(solicitacaoOptOut);

		} catch (Exception e) {

			log.error(e.getMessage());

			Mensagens.addMsgErro(e.getMessage());

		}

	}

	public void indeferirSolicitacao(SolicitacaoOptOut solicitacaoOptOut) {

		try {

			log.info("Indeferindo Solicitação " + solicitacaoOptOut.getParticipante().getNomeParticipante());
			solicitacaoOptOut.setSituacao(SituacaoSolicitacaoOptOutEnum.INDEFERIDO.getCodigo());
			this.validarSolicitacao(solicitacaoOptOut);

		} catch (Exception e) {

			log.error(e.getMessage());

			Mensagens.addMsgErro(e.getMessage());

		}

	}

	public void validarSolicitacao(SolicitacaoOptOut solicitacaoOptOut) {

		try {

			log.info("Validando Solicitação " + solicitacaoOptOut.getParticipante().getNomeParticipante());

			//Atualizar Situação da Solicitação

			Mensagens.addMsgInfo("Solicitação validada com sucesso");
			PrimeFaces.current().executeScript("PF('validarSolicitacao').hide()");

		} catch (Exception e) {

			log.error(e.getMessage());

			Mensagens.addMsgErro(e.getMessage());

		}

	}

	private Boolean salvarListaCalculosOptOut(List<CalculoOptOut> listaCalculoSolicitacao) {
		try {
			return this.calculoOptOutBO.salvarListaCalculo(listaCalculoSolicitacao);
		} catch (Exception e) {
			log.error(e.getMessage());
			return false;
		}
	}

	private Boolean salvarListaValoresPendentesFundoPrevidencial(List<ValorPendenteFundoPrevidencial> listaValorPendenteFundoPrevidencial) {
		Boolean listaSalva = false;

		try {

			this.valorPendenteFundoPrevidencialBO.salvarEmLote(listaValorPendenteFundoPrevidencial);

			listaSalva = true;

		} catch (Exception e) {

			log.error(e.getMessage());

		}

		return listaSalva;

	}

	public void enviarParaDeferimento(SolicitacaoOptOut solicitacaoOptOut) {
		long numeroLoteAlcada = 0;
		try {
			String usuarioCrip = new String();
			usuarioCrip = Criptografia.criptografar(this.loginTemporariaDTO.getIdentificacaoUsuario());

			String codigoSistema = new String();

			ParametroGeral parametroCodigoSistema = this.parametroGeralBO.consultarParametro(ParametroGeralBO.PARAMETROS.CODIGO_SISTEMA_DEVOLUCAO);

			codigoSistema = parametroCodigoSistema.getDescricaoPatrametro();

			//Solicitar Lote.
			URL url = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/solicitaLoteProcessamentoAlcadaWs?codigoSistema=" + codigoSistema + "&codigoAplicacao=0&codigoUsuario=" + usuarioCrip);

			log.info(url);

			RestTemplate restTemplate = new RestTemplate();
			
			RetornoSolicitacaoLoteAlcadaDTO retornoSolicitacaoLoteAlcadaDTO = new RetornoSolicitacaoLoteAlcadaDTO();

			retornoSolicitacaoLoteAlcadaDTO = restTemplate.getForObject(url.toString(), RetornoSolicitacaoLoteAlcadaDTO.class);

			numeroLoteAlcada = retornoSolicitacaoLoteAlcadaDTO.getNumeroLote();

			if (retornoSolicitacaoLoteAlcadaDTO.isStatus()) {
					long numeroTipoFuncionalidadeAlcada = 9l; //TIPO_FUNCIONALIDADE_ALCADA
					long numeroUnidadeOrganizacional = 40l; //GERÊNCIA DE SEGURIDADE
					String codigoControle01 = solicitacaoOptOut.getCodigo().toString();
					String codigoControle02 = null;
					String codigoControle03 = null;
					String codigoChaveOrigem = codigoControle01;

					codigoChaveOrigem = codigoChaveOrigem +"-"+ solicitacaoOptOut.getParticipante().getEntidadeParticipante().getNomeAbreviadoEntidadeParticipante().replaceAll("\\s","")
							+ "-MAT:"+ solicitacaoOptOut.getParticipante().getNumeroMatriculaPatrocinadora();

					List<CalculoOptOut> listaCalculoSolicitacao = this.calculoOptOutBO.listarCalculoSolicitacao(solicitacaoOptOut);
					Double valorAlcada = listaCalculoSolicitacao.stream()
							.mapToDouble(a -> Stream.of(
									a.getValorPatron() + a.getValorPartic(), 
//									a.getValorParticipanteAtualizacaoCota() + a.getValorPatrocinadoraAtualizacaoCota(),
									a.getValorParticipanteAtualizacaoIndice() + a.getValorPatrocinadoraAtualizacaoIndice()).max(Double::compareTo).get())
							.sum();
					
				    valorAlcada = UtilJava.arredondaNumero(valorAlcada, 2);

					URL urlMov = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/insereMovimentosAlcadasWs?" + "numeroLoteAlcada=" + numeroLoteAlcada + "&"
							+ "numeroTipoFuncionalidadeAlcada=" + numeroTipoFuncionalidadeAlcada + "&" + "numeroUnidadeOrganizacional=" + numeroUnidadeOrganizacional + "&" + "codigoControle01="
							+ codigoControle01 + "&" + "codigoControle02=" + codigoControle02 + "&" + "codigoControle03=" + codigoControle03 + "&" + "codigoChaveOrigem=" + codigoChaveOrigem + "&"
							+ "valorAlcada=" + valorAlcada);

					//Inserção de Log
					log.info(urlMov);

					RetornoInsercaoMovAlcadaDTO retornoInsercaoMovAlcadaDTO = new RetornoInsercaoMovAlcadaDTO();

					retornoInsercaoMovAlcadaDTO = restTemplate.getForObject(urlMov.toString(), RetornoInsercaoMovAlcadaDTO.class);

					if (retornoInsercaoMovAlcadaDTO.isStatus()) {

						solicitacaoOptOut.setMovimentoAlcada(retornoInsercaoMovAlcadaDTO.getCodigoAlcada());
						solicitacaoOptOut.setNumeroLoteAlcada(numeroLoteAlcada);
						solicitacaoOptOut.setSituacao(SituacaoSolicitacaoOptOutEnum.EM_DEFERIMENTO.getCodigo());
						solicitacaoOptOut.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getIdentificacaoUsuario());
						this.solicitacaoOptOutBO.salvarSolicitacao(solicitacaoOptOut);
						
						Mensagens.addMsgInfo("Solicitação N° " + solicitacaoOptOut.getCodigo() + " enviada para deferimento!!");
						
						//Envia e-mail avisando que a Solicitação foi enviada para deferimento.
						String mensagem = "<p>Prezado, " + solicitacaoOptOut.getParticipante().getNomeParticipante() + "</p>" +
								"<p>O processo de solicitação de anulação de inscrição foi enviada para deferimento.<p>";
						
						boolean envioEmail = this.optOutBO.enviarEmailNotificacoesOptOut(solicitacaoOptOut, 
								"bbprevidencia@bbprevidencia.com.br", 
								solicitacaoOptOut.getParticipante().getEnderecoEmail(), 
								"Solicicatação de anulação de inscrição enviado para deferimento.", 
								mensagem, 
								null);

					} else {
						Mensagens.addMsgErro("Solicitação não enviada para deferimento. Verificar mensagens do lote: " + numeroLoteAlcada);

						//Solicitar Lote.
						URL urlMsgLote = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/listarMsgLoteProcessamentoAlcadaWs?numeroLote=" + numeroLoteAlcada);

						//Inserção de Log
						log.error(this.ambienteServico.getUrlAlcada() + "dispatcher/listarMsgLoteProcessamentoAlcadaWs?numeroLote=" + numeroLoteAlcada);

						RetornoMsgLoteAlcadaDTO retornoMsgLoteAlcadaDTO = new RetornoMsgLoteAlcadaDTO();

						retornoMsgLoteAlcadaDTO = restTemplate.getForObject(urlMsgLote.toString(), RetornoMsgLoteAlcadaDTO.class);

						if (retornoMsgLoteAlcadaDTO.isStatus()) {
							for (String msgLote : retornoMsgLoteAlcadaDTO.getListadescricaoMsg()) {
								Mensagens.addMsgErro(msgLote);
							}
						} else {
							Mensagens.addMsgErro("Erro ao buscar mensagem de lote. Erro: " + retornoMsgLoteAlcadaDTO.getDescricaoErro());
						}

					}

				RetornoFecharLoteAlcadaDTO retornoFecharLoteAlcadaDTO = new RetornoFecharLoteAlcadaDTO();

				retornoFecharLoteAlcadaDTO = fecharLote(numeroLoteAlcada);

				if (!retornoFecharLoteAlcadaDTO.isStatus()) {
					Mensagens.addMsgErro(retornoFecharLoteAlcadaDTO.getDescricaoErro());
				} else {
					numeroLoteAlcada = 0;
				}

			} else {
				log.error("Erro ao gerar lote. Erro: " + retornoSolicitacaoLoteAlcadaDTO.getDescricaoErro());

				Mensagens.addMsgErro(retornoSolicitacaoLoteAlcadaDTO.getDescricaoErro());
			}

		} catch (Exception e) {
			if (numeroLoteAlcada != 0) {
				RetornoFecharLoteAlcadaDTO retornoFecharLoteAlcadaDTO = new RetornoFecharLoteAlcadaDTO();

				retornoFecharLoteAlcadaDTO = fecharLote(numeroLoteAlcada);

				if (!retornoFecharLoteAlcadaDTO.isStatus()) {
					Mensagens.addMsgErro(retornoFecharLoteAlcadaDTO.getDescricaoErro());
				}
			}

			log.error("Erro ao enviar para deferimento. Erro: " + e.getMessage());
			Mensagens.addMsgErro("Erro ao enviar para deferimento. Erro: " + e.getMessage());
		}


	}

	public RetornoFecharLoteAlcadaDTO fecharLote(Long numeroLoteAlcada) {

		RetornoFecharLoteAlcadaDTO retornoFecharLoteAlcadaDTO = new RetornoFecharLoteAlcadaDTO();

		try {

			String codigoLoteCrip = Criptografia.criptografar(Long.toString(numeroLoteAlcada));

			URL urlFecharLote = new URL(this.ambienteServico.getUrlAlcada() + "dispatcher/fecharLoteProcessamentoAlcadaWs?" + "codigolLote=" + codigoLoteCrip);

			//Inserção de Log
			log.info(urlFecharLote);

			RestTemplate restTemplate = new RestTemplate();

			retornoFecharLoteAlcadaDTO = restTemplate.getForObject(urlFecharLote.toString(), RetornoFecharLoteAlcadaDTO.class);

			return retornoFecharLoteAlcadaDTO;

		} catch (Exception e) {
			log.error("Erro ao fechar lote de deferimento. Erro: " + e.getMessage());
			Mensagens.addMsgErro("Erro ao fechar lote de deferimento. Erro: " + e.getMessage());
			return retornoFecharLoteAlcadaDTO;

		}

	}

	/**
	 * Detalha o cálculo realizado na solicitação de OptOut
	 * @param solicitacao
	 * @return
	 */
	public String detalharCalculoOptOut(SolicitacaoOptOut solicitacao) {
		try {
			this.solicitacaoDetalhe = solicitacao;
			this.listaCalculoOptOut = new ArrayList<CalculoOptOut>(this.calculoOptOutBO.listarCalculoSolicitacao(solicitacao));
		} catch (Exception e) {
			Mensagens.addMsgErro("Ocorreu um erro ao pesquisar o detalhe da Solicitação!!");
			return "";
		}

		return FW_DETALHE_CALCULO_OPTOUT;
	}

	public void calcularDetalheTotalOptOut(Object o) {
		this.totalDetalheOptOutPartic = 0D;
		this.totalDetalheOptOutPatroc = 0D;
		this.totalDetalheOptOutTaxaPartic = 0D;
		this.totalDetalheOptOutTaxaPatroc = 0D;
		this.totalDetalheOptOutParticIndice = 0D;
		this.totalDetalheOptOutPatrocIndice = 0D;
		this.totalDetalheOptOutParticCota = 0D;
		this.totalDetalheOptOutPatrocCota = 0D;
		
		
		this.totalDetalheOptOutPartic = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorPartic()).sum();
		
		this.totalDetalheOptOutPatroc = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorPatron()).sum();
		
		this.totalDetalheOptOutTaxaPartic = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorTaxaPartic()).sum();
		
		this.totalDetalheOptOutTaxaPatroc = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorTaxaPatron()).sum();
		
		this.totalDetalheOptOutParticIndice = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorParticipanteAtualizacaoIndice()).sum();
		
		this.totalDetalheOptOutPatrocIndice = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorPatrocinadoraAtualizacaoIndice()).sum();
		
		this.totalDetalheOptOutParticCota = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorParticipanteAtualizacaoCota()).sum();
		
		this.totalDetalheOptOutPatrocCota = this.listaCalculoOptOut.stream()
				.mapToDouble(a -> a.getValorPatrocinadoraAtualizacaoCota()).sum();
	}

	/**
	 * Realiza o cálculo da integração Financeira e Contábil do processo de Opt Out
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @param solicitacao
	 */
	public void calcularIntegracaoSolicitacao(SolicitacaoOptOut solicitacao) {
		try {
			if (this.existeContribuicaoSemIndividualizar(solicitacao)) {
				throw new PrevidenciaException("O Participante possui lançamentos aguardando cotas, favor verificar.");
			}

			this.lancamentoIntegracaoOptOutBO.calcularLancamentosIntegracaoSolicitacao(solicitacao, this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

			Mensagens.addMsgInfo("Lancamentos de Integração Gerados com Sucesso!!");
		} catch (PrevidenciaException e) {
			log.error(e);
			Mensagens.addMsgErro(e.getCause().getMessage());
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro(e.getMessage());
		} finally {
			this.pesquisarSolicitacoesIntegracaoFechamento();
		}
	}

	/**
	 * Realiza a conclusão do processo de Opt Out
	 * @param solicitacao
	 */
	public void concluirSolicitacao(SolicitacaoOptOut solicitacao) {
		try {
			Boolean solicitacaoConcluida = this.solicitacaoOptOutBO.salvarConclusaoSolicitacaoOptOut(solicitacao, this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

			if (solicitacaoConcluida) {
				Mensagens.addMsgInfo("Solicitação concluida com sucesso!");
			} else {
				Mensagens.addMsgErro("Erro ao concluir a solicitação.");
			}

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao fechar a solicitação: " + e.getMessage());
		}
	}

	public void integrarSolicitacao(SolicitacaoOptOut solicitacao) {
		try {
			Boolean processar = this.lancamentoIntegracaoOptOutBO.integrarSolicitacaoOptOut(solicitacao);

			if (!processar) {
				Mensagens.addMsgErro("Não foi possível integrar a Solicitação.");
			} else {
				//Atualiza a Solicits com a Data que foi  calculada
				solicitacao.setDataAlteracao(new Date());
				solicitacao.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				solicitacao.setSituacao(SituacaoSolicitacaoOptOutEnum.INTEGRADO.getCodigo());
				Boolean solicitacaoProcessada = this.solicitacaoOptOutBO.salvarSolicitacao(solicitacao);

				if (solicitacaoProcessada) {
					Mensagens.addMsgInfo("Solicitação N° " + solicitacao.getCodigo() + " integrada com sucesso!!");
				} else {
					Mensagens.addMsgErro("Erro ao integrar a solicitação N° " + solicitacao.getCodigo() + ".");
				}

			}
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao integrar Solicitação:" + e.getMessage());
		} finally {
			this.pesquisarSolicitacoesIntegracaoFechamento();
		}
	}

	public void enviarSolicitacoesParaDeferimentoEmLote() {
		if (UtilJava.isColecaoVazia(this.listaSolicitacaoSelecionada)) {
			Mensagens.addMsgWarn("Não foram encontradas solicitações para enviar para deferimento!");
		} else {
			List<SolicitacaoOptOut> listaSolicitacoesCalculadas = this.listaSolicitacaoSelecionada.stream()
					.filter(e -> e.getSituacao() == SituacaoSolicitacaoOptOutEnum.CALCULADO.getCodigo())
					.collect(Collectors.toList());
			
			if (UtilJava.isColecaoDiferenteDeVazia(listaSolicitacoesCalculadas)) {
				listaSolicitacoesCalculadas.forEach(a -> {
					this.enviarParaDeferimento(a);
				});
			} else {
				Mensagens.addMsgWarn("Não foram encontradas solicitações calculadas para enviar para deferimento!");
			}
			
			//carrega a lista de solicitações atualizadas
			this.pesquisarSolicitacoes();
			this.listaSolicitacaoSelecionada = null;
		}
	}

	public void calcularSolicitacoesEmLote() {
		if (UtilJava.isColecaoVazia(this.listaSolicitacaoSelecionada)) {
			Mensagens.addMsgWarn("Não foram encontradas solicitações para calcular!");
		} else {
			List<SolicitacaoOptOut> listaSolicitacoesRequeridasCalculadas = this.listaSolicitacaoSelecionada.stream()
					.filter(e -> e.getSituacao() == SituacaoSolicitacaoOptOutEnum.CALCULADO.getCodigo() || e.getSituacao() == SituacaoSolicitacaoOptOutEnum.REQUERIDO.getCodigo())
					.collect(Collectors.toList());
			
			if (UtilJava.isColecaoDiferenteDeVazia(listaSolicitacoesRequeridasCalculadas)) {
				listaSolicitacoesRequeridasCalculadas.forEach(a -> {
					if (!this.existeContribuicaoSemIndividualizar(a)) {
						if (this.calcularSolicitacaoOptOut(a)) {
							Mensagens.addMsgInfo("Solicitacao N° "  + a.getCodigo() + " calculada com sucesso!");
						} else {
							Mensagens.addMsgErro("Erro ao calcular a solicitacao N° "  + a.getCodigo() + ".");
						}
					} else {
						Mensagens.addMsgWarn("Solicitação N° " + a.getCodigo() + " possui lançamentos aguardando cotas, favor verificar.");
					}
				});
			} else {
				Mensagens.addMsgWarn("Não foram encontradas solicitações Requeridas ou Calculadas!");
			}
			
			//carrega a lista de solicitações atualizadas
			this.pesquisarSolicitacoes();
			this.listaSolicitacaoSelecionada = null;
		}
	}

	public void gerarSolicitacao(String tipoSolicitacao) {
		try {
			RetornoSolicitacaoOptOutDTO retornoSolicitacao = new RetornoSolicitacaoOptOutDTO();

			if (tipoSolicitacao.equalsIgnoreCase("N")) {
				retornoSolicitacao = this.optOutBO.processarSolicitacaoOptOut(participante.getCodigo(), null);
			} else {
				if (this.dataSolicitacao == null || this.dataSolicitacao.after(new Date())) {
					throw new PrevidenciaException("Data de solicitação não informada ou posterior à data atual.");
				}
				retornoSolicitacao = this.optOutBO.processarSolicitacaoOptOut(participante.getCodigo(), this.dataSolicitacao);
			}

			if (retornoSolicitacao.getSolicitacaoRealizada() && !retornoSolicitacao.getEtapaImcompleta()) {
				Mensagens.addMsgInfo("Solicitação processada com sucesso!");
			} else if (!retornoSolicitacao.getSolicitacaoRealizada()) {
				Mensagens.addMsgErro("Erro ao gerar solicitação");
			} else if (retornoSolicitacao.getSolicitacaoRealizada() && retornoSolicitacao.getEtapaImcompleta()) {
				Mensagens.addMsgInfo("Solicitação processada com sucesso!");
				Mensagens.addMsgWarn(retornoSolicitacao.getMsgStatus());
			}

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao gerar solicitação: " + e.getMessage());
		}
	}

	public void setSolicitacaoBuscaDeferimento(SolicitacaoOptOut solicitacaoBuscaDeferimento) {
		if (solicitacaoBuscaDeferimento != null) {
			this.listaDeferimentoSolicitacao = new ArrayList<AprovacaoAlcadaDTO>(this.movimentoAlcadaBO.listarAprovacaoDeferimentoSolicitacao(solicitacaoBuscaDeferimento.getMovimentoAlcada()));
		}

		this.solicitacaoBuscaDeferimento = solicitacaoBuscaDeferimento;
	}

	public void gerarSumulaSolicitacaoOptOut(SolicitacaoOptOut solicitacao) {
		try {
			TermoAnulacaoOptOutDTO termoAnulacaoOptOut = new TermoAnulacaoOptOutDTO();
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = context.getRealPath("/imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
			String logoBbpb = context.getRealPath("/imagens/LogotiposExterno/BBPrevBrasil-01.png");
			
			//Imagens
			parametros.put("logo", logo);
			parametros.put("logoBbpb",  logoBbpb);
			
			
			
			String tituloSumula = "PROCESSO DE OPT OUT " + String.valueOf(solicitacao.getCodigo());
			System.out.println(tituloSumula);
			
			parametros.put("tituloSumula", tituloSumula);
			
			String nomePatrocinadora = solicitacao.getParticipante().getEntidadeParticipante().getNomeAbreviadoEntidadeParticipante();
			String cnpb = solicitacao.getParticipante().getListaParticipantePlano().get(0).getPlanoPrevidencia().getPlanoGuardaChuva().getCnpb();
			String nomeParticipante = solicitacao.getParticipante().getNomeParticipante();
			String cpf = UtilJava.formatarCPF(solicitacao.getParticipante().getCpf());
			String email = solicitacao.getParticipante().getEnderecoEmail() != null ? solicitacao.getParticipante().getEnderecoEmail() : solicitacao.getParticipante().getEnderecoEmailSec() != null ? solicitacao.getParticipante().getEnderecoEmailSec()
					: "";
			String matricula = solicitacao.getParticipante().getNumeroMatriculaPatrocinadora();
			
			parametros.put("nomePatrocinadora", nomePatrocinadora);
			parametros.put("cnpb", cnpb);
			parametros.put("nomeParticipante", nomeParticipante);
			parametros.put("cpf", cpf);
			parametros.put("email", email);
			parametros.put("matricula", matricula);
			
			termoAnulacaoOptOut = TermoAnulacaoOptOutDTO.builder()
				.nomePatrocinadora(nomePatrocinadora)
				.cnpb(cnpb)
				.nomeParticipante(nomeParticipante)
				.cpf(cpf)
				.email(email)
				.matricula(matricula).build();
			
			//Informações  participante
			parametros.put("nomePlano", solicitacao.getParticipante().getListaParticipantePlano().get(0).getPlanoPrevidencia().getPlanoGuardaChuva().getNomePlanoGuardaChuva());
			parametros.put("situacaoPlano", solicitacao.getParticipante().getListaParticipantePlano().get(0).getSituacaoParticipantePlano().getDescricaoSituacao());
			parametros.put("tipoTributacao", solicitacao.getParticipante().getListaParticipantePlano().get(0).getTipoRegimeTributacao().getDescricao());
			parametros.put("dataAdmissao", solicitacao.getParticipante().getDataAdmissao());
			parametros.put("dataInscricao", solicitacao.getParticipante().getListaParticipantePlano().get(0).getDataInscricao());
			parametros.put("dataAnulacao", solicitacao.getDataSolicitacao());
			parametros.put("tempoDiasPlano", DataUtil.daysBetWeenDates(solicitacao.getParticipante().getListaParticipantePlano().get(0).getDataInscricao(), solicitacao.getDataSolicitacao()));
			
			Date dataUltimoProcessamento = this.processamentoControleArrecadacaoBO.pesquisarUltimaArrecadacaoPorPlanoPrevidencia(solicitacao.getParticipante().getListaParticipantePlano().get(0).getPlanoPrevidencia());
			parametros.put("dataUltimoProcessamento", dataUltimoProcessamento);
					
			Date dataUltimoLancamentoFicha = this.historicoFinanceiroPagoBO.pesquisarDataUltimoLancamentoEmFicha(solicitacao.getParticipante().getListaParticipantePlano().get(0));
			parametros.put("dataUltimoLancamentoFicha", dataUltimoLancamentoFicha);
			
			//Informaões Entidade Recebedora
			PessoaEntidade pessoa = this.pessoaEntidadeBO.pesquisarPessoaPorCodigoCIC(StringUtils.leftPad(solicitacao.getParticipante().getEntidadeParticipante().getNumeroCgc().toString(), 14, "0"));
			parametros.put("nomeEntidadeRecebedora", pessoa.getNome());
			parametros.put("cnpjEntidadeRecebedora", UtilJava.formataCNPJ(pessoa.getCodigoCIC()));
			
			AtuacaoPessoa atuacaoPessoa = this.atuacaoPessoaBO.pesquisarAtuacaoPessoaPorPessoaOptOut(pessoa);
			
			if (atuacaoPessoa.getAgenciaBancaria() != null && atuacaoPessoa.getAgenciaBancaria().getChavePrimaria() != null) {
				BancoDTO banco = this.bancoBO.pesquisarBanco(atuacaoPessoa.getAgenciaBancaria().getChavePrimaria().getCodigoBanco());
				parametros.put("bancoEntidade", String.format("%03d", banco.getCodigoBanco()) + " - " + banco.getNomeBanco());
				
				parametros.put("agenciaEntidade", atuacaoPessoa.getAgenciaBancaria().getNumeroAgencia() + 
						(atuacaoPessoa.getAgenciaBancaria().getDigitoAgencia() != null ? " - " + atuacaoPessoa.getAgenciaBancaria().getDigitoAgencia() : ""));
			} else {
				parametros.put("bancoEntidade", null);
				parametros.put("agenciaEntidade", null);
			}
			
			if (atuacaoPessoa.getContaCorrente() != null) {
				parametros.put("contaBancariaEntidade",  atuacaoPessoa.getContaCorrente() + 
						(atuacaoPessoa.getDigitoContaCorrente() != null ? " - " + atuacaoPessoa.getDigitoContaCorrente() : ""));
			} else {
				parametros.put("contaBancariaEntidade", null);
			}
			
			parametros.put("tipoContaDeposito", atuacaoPessoa.getIndicadorTipoConta() != null ? 
					(atuacaoPessoa.getIndicadorTipoConta() == "CP" ? "CONTA POUPANÇA" : "CONTA CORRENTE") : "CONTA CORRENTE");
			
				
			parametros.put("dataCota", solicitacao.getDataCotaCalculo());
			parametros.put("valorCota", solicitacao.getValorCotaCalculo());
			parametros.put("valorFaltanteSobrante", solicitacao.getSobranteFaltanteOptOut());
			parametros.put("valorDevolucao", solicitacao.getValorDevolucao());
			
			
			List<CalculoSolicitacaoSumulaDTO> listaCalculoSolicitacaoSumulaDto = solicitacao.getListaCalculoSolicitacao().stream().
					map(a -> {
					CalculoSolicitacaoSumulaDTO calculo = CalculoSolicitacaoSumulaDTO.builder()
							.dataDeposito(a.getDataDeposito())
							.valorIndiceFator(a.getValorIndiceFator())
							.valorFichaParticipante(a.getValorPartic())
							.valorFichaPatrocinadora(a.getValorPatron())
							.valorIndiceParticipante(a.getValorParticipanteAtualizacaoIndice())
							.valorIndicePatrocinadora(a.getValorPatrocinadoraAtualizacaoIndice())
							.valorCotaParticipante(a.getValorParticipanteAtualizacaoCota())
							.valorCotaPatrocinadora(a.getValorPatrocinadoraAtualizacaoCota())
							.build();
					
					return calculo;
			}).collect(Collectors.toList());
			
			parametros.put("listaCalculoSolicitacaoSumulaDto", listaCalculoSolicitacaoSumulaDto);
			
			//montar cheklist de documentos
			List<DocumentoSolicitacaoOptOut> listaDcoumentoSolitacao = this.documentoSolicitacaoOptOutBO.listarDocumentosPorSolicitacao(solicitacao);
			
			List<CheckListSolicitacaoSumulaDTO> listaDocumentoSumula = listaDcoumentoSolitacao.stream()
					.map(e ->  CheckListSolicitacaoSumulaDTO.builder()
								.nomeDocumento(e.getDocumentoDevolucao().getNome())
								.verficado(e.getMarcado() ? "Sim" : "Não").build()
					).collect(Collectors.toList());
			
			List<TermoAnulacaoOptOutDTO> listaTermo = new ArrayList<TermoAnulacaoOptOutDTO>();
			listaTermo.add(termoAnulacaoOptOut);
			
			parametros.put("listaDocumentoSumula", listaDocumentoSumula);
			parametros.put("listaTermo", listaTermo);
			
			parametros.forEach((key, value)  -> {
				System.out.println(key + " = " + value);
			});
			
			String nomeRelatorio = relatorioUtil.gerarRelatorio("sumulaSolicitacaoOptOut", new ArrayList<>(), parametros);
			
			relatorioUtil.abrirPoupUp(nomeRelatorio);
		} catch(Exception e) {
			e.printStackTrace();
			log.error(e);
			Mensagens.addMsgErro("Erro ao gerar súmula da solicitação.");
		}
	}

	public void limparObjetosTemporarios() {
		this.listaCheckListSolicitacao = null;
	}

	public void mostrarCheckListDocumentos(SolicitacaoOptOut solicitacao) {
		this.listaCheckListSolicitacao = this.documentoSolicitacaoOptOutBO.listarDocumentosPorSolicitacao(solicitacao);
		PrimeFaces.current().executeScript("PF('documentosOptOutDialog').show();");
	}

	public void preencherDataMarcacao(DocumentoSolicitacaoOptOut documento) {
		documento.setDataMarcado(documento.getMarcado() ? new Date() : null);
		documento.setDataAlteracao(documento.getMarcado() ? new Date() : null);
		documento.setNomeUsuarioAlteracao(documento.getMarcado() ? this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin() : null);
	}

	@Transactional(rollbackFor = {Exception.class, PrevidenciaException.class})
	public void salvarListaDocumentoSolicitacao() {
		try {
			this.documentoSolicitacaoOptOutBO.salvarListaDocumentoSolicitacaoOptOut(listaCheckListSolicitacao);
			boolean verificacaoIncompleta = this.listaCheckListSolicitacao.stream()
					.filter(e -> (e.getObrigatorio() && !e.getMarcado()))
					.collect(Collectors.toList()).size() > 0;
			
			if(!verificacaoIncompleta) {
				SolicitacaoOptOut solicitacaoVerificada = this.solicitacaoOptOutBO.pesquisarSolicicatacaoPorCodigo(listaCheckListSolicitacao.get(0).getSolicitacaoOptOut().getCodigo());
				solicitacaoVerificada.setNomeUsuarioAlteracao(this.loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				solicitacaoVerificada.setDataAlteracao(new Date());
				solicitacaoVerificada.setSituacao(SituacaoSolicitacaoOptOutEnum.CONFERIDO.getCodigo());
				this.solicitacaoOptOutBO.salvarSolicitacao(solicitacaoVerificada);
			}
			
			this.limparObjetosTemporarios();
			this.pesquisarSolicitacoes();
			
			Mensagens.addMsgInfo("Solicitação Conferida com Sucesso!!");
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro ao salvar documentos da Solicitação.");
		}
		
	}

	public void solicitarOptOut() {
		try {
			RetornoOptOutDTO retorno = this.optOutBO.validarParticipanteAptoOptOut(participante.getCodigo());

			if (retorno.getParticipanteAptoOptOut()) {
				PrimeFaces.current().executeScript("PF('anulacaoPadraoDialog').show()");
			} else {
				boolean feminina = this.participante.getIndicadorSexo() != null && this.participante.getIndicadorSexo().equalsIgnoreCase("F");
				this.textoDialogRetroativo = (feminina ? "A " : "O ") + "participante " + this.participante.getNomeParticipante() + " não está " + (feminina ? "apta " : "apto ");
				PrimeFaces.current().executeScript("PF('anulacaoRetroativaDialog').show()");
			}
		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Erro na solicitação: " + e.getMessage());
		}
	}

	public Date getDataAtual() {
		return new Date();
	}
}
