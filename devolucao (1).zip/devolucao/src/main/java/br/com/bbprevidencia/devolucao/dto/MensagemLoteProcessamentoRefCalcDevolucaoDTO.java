package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * Classe de persistência para tabela MSG_LOT_PRO_DEV.
 */
@JsonIdentityInfo(generator = ObjectIdGenerators.UUIDGenerator.class, property = "@id", scope = MensagemLoteProcessamentoRefCalcDevolucaoDTO.class)
public class MensagemLoteProcessamentoRefCalcDevolucaoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codigoLoteProcessamentoReferenciaCalcDevolucao;
	private String dataMensagem;
	private String codigoParticipantePlano;
	private String descricaoMensagem;
	private String indicadorTipoMensagem;
	private String nomeUsuarioInclusao;

	public MensagemLoteProcessamentoRefCalcDevolucaoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MensagemLoteProcessamentoRefCalcDevolucaoDTO(String codigoLoteProcessamentoReferenciaCalcDevolucao, String dataMensagem, String codigoParticipantePlano, String descricaoMensagem,
			String indicadorTipoMensagem, String nomeUsuarioInclusao) {
		super();
		this.codigoLoteProcessamentoReferenciaCalcDevolucao = codigoLoteProcessamentoReferenciaCalcDevolucao;
		this.dataMensagem = dataMensagem;
		this.codigoParticipantePlano = codigoParticipantePlano;
		this.descricaoMensagem = descricaoMensagem;
		this.indicadorTipoMensagem = indicadorTipoMensagem;
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getCodigoLoteProcessamentoReferenciaCalcDevolucao() {
		return codigoLoteProcessamentoReferenciaCalcDevolucao;
	}

	public void setCodigoLoteProcessamentoReferenciaCalcDevolucao(String codigoLoteProcessamentoReferenciaCalcDevolucao) {
		this.codigoLoteProcessamentoReferenciaCalcDevolucao = codigoLoteProcessamentoReferenciaCalcDevolucao;
	}

	public String getDataMensagem() {
		return dataMensagem;
	}

	public void setDataMensagem(String dataMensagem) {
		this.dataMensagem = dataMensagem;
	}

	public String getCodigoParticipantePlano() {
		return codigoParticipantePlano;
	}

	public void setCodigoParticipantePlano(String codigoParticipantePlano) {
		this.codigoParticipantePlano = codigoParticipantePlano;
	}

	public String getDescricaoMensagem() {
		return descricaoMensagem;
	}

	public void setDescricaoMensagem(String descricaoMensagem) {
		this.descricaoMensagem = descricaoMensagem;
	}

	public String getIndicadorTipoMensagem() {
		return indicadorTipoMensagem;
	}

	public void setIndicadorTipoMensagem(String indicadorTipoMensagem) {
		this.indicadorTipoMensagem = indicadorTipoMensagem;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String toString() {
		JSONObject jsonInfo = new JSONObject();

		try {
			jsonInfo.put("codigoLoteProcessamentoReferenciaCalcDevolucao", this.codigoLoteProcessamentoReferenciaCalcDevolucao);
			jsonInfo.put("dataMensagem", this.dataMensagem);
			jsonInfo.put("codigoParticipantePlano", this.codigoParticipantePlano);
			jsonInfo.put("descricaoMensagem", this.descricaoMensagem);
			jsonInfo.put("indicadorTipoMensagem", this.indicadorTipoMensagem);
			jsonInfo.put("nomeUsuarioInclusao", this.nomeUsuarioInclusao);

		} catch (JSONException e1) {
		}
		return jsonInfo.toString();
	}
}
