package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.DependenteParticipante;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.folha.dto.Recebedor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   23/01/2017
 * Classe de persistência para tabela GRUPO_RECEBIMENTO_DEVOLUCAO.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "GRUPO_RECEBIMENTO_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "GrupoRecebimentoDevolucao.findAll", query = "SELECT q FROM GrupoRecebimentoDevolucao q")
public class GrupoRecebimentoDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "GRUPO_RECEBIMENTO_DEVOLUCAO_GER", sequenceName = "S_GRD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GRUPO_RECEBIMENTO_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_GRU_REC_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_RECEBEDOR")
	private Recebedor recebedor;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PARTIC")
	private Participante participante;

	@Column(name = "NUM_SEQ_DEP")
	private Long codigoDependente;

	@Transient
	private DependenteParticipante dependenteParticipante;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INI")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FIM")
	private Date dataFim;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

}