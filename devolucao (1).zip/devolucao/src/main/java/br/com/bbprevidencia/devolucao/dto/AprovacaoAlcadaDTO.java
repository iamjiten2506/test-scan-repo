package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
@Entity
public class AprovacaoAlcadaDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "NUM_SEQ_NIVEL_ALC")
	private Long codigo;

	@Column(name = "NOM_NIVEL_ALC")
	private String nomeNivelAlcada;

	@Column(name = "DEFERIDO")
	private String deferido;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATA_ACAO")
	private Date dataAcao;
}
