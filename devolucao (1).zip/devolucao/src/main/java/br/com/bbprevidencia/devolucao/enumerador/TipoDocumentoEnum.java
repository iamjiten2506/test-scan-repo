package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoDocumentoEnum {

	DEVOLUCAO("1", "Tipo de documento - Devolução"),
	RECEBEDOR("2", "Tipo de documento - Recebedor"),
	PESSOA_ATUACAO("3", "Tipo de documento - Atuação Pessoa");

	private String codigo;
	private String descricao;

	private TipoDocumentoEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public static TipoDocumentoEnum geTipoDocumentoEnum(String codigo) {
		if (codigo != null) {
			for (TipoDocumentoEnum tipoDocumentoEnum : values()) {
				if (tipoDocumentoEnum.getCodigo().equals(codigo)) {
					return tipoDocumentoEnum;
				}
			}
		}
		return null;

	}

}
