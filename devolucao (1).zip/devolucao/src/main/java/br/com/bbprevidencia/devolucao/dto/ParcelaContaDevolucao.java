package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.com.bbprevidencia.beneficio.dto.FichaDevolucao;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   29/12/2016
 * Classe de persistência para tabela PARCELA_CONTA_DEV.
 */
@Entity
@Table(name = "PARCELA_CONTA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "ParcelaContaDevolucao.findAll", query = "SELECT q FROM ParcelaContaDevolucao q")
public class ParcelaContaDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PARCELA_CONTA_DEV_GER", sequenceName = "S_PCD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PARCELA_CONTA_DEV_GER")
	@Column(name = "NUM_SEQ_PAR_CON_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_DEV")
	private Devolucao devolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_TIP_CON_DEV")
	private TipoContaDevolucao tipoContaDevolucao;

	@Column(name = "DAT_PAR_CON_DEV")
	private Date dataMinimaParcela;

	@Column(name = "QTD_COT")
	private Double qtdCotaParcela;

	@Column(name = "IND_PAR_PGT")
	private String indicadorParcelaPaga;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	//Colocado para facilitar tratamento de Detalhe Parcela para Saldo remanescente
	@Transient
	private FichaDevolucao fichaDevolucao;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "parcelaContaDevolucao", targetEntity = ParcelaContaDevolucaoDetalhe.class, fetch = FetchType.LAZY, orphanRemoval = true)
	private List<ParcelaContaDevolucaoDetalhe> listaParcelaContaDevolucaoDetalhe = new ArrayList<ParcelaContaDevolucaoDetalhe>();
	
	@Transient
	private List<ParcelaContaDevolucaoDetalheImpostoDTO> listaParcelaContaDevolucaoDetalheImpostoDTO = new ArrayList<>();

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public TipoContaDevolucao getTipoContaDevolucao() {
		return tipoContaDevolucao;
	}

	public void setTipoContaDevolucao(TipoContaDevolucao tipoContaDevolucao) {
		this.tipoContaDevolucao = tipoContaDevolucao;
	}

	public Date getDataMinimaParcela() {
		return dataMinimaParcela;
	}

	public void setDataMinimaParcela(Date dataMinimaParcela) {
		this.dataMinimaParcela = dataMinimaParcela;
	}

	public Double getQtdCotaParcela() {
		return qtdCotaParcela;
	}

	public void setQtdCotaParcela(Double qtdCotaParcela) {
		this.qtdCotaParcela = qtdCotaParcela;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getIndicadorParcelaPaga() {
		return indicadorParcelaPaga;
	}

	public void setIndicadorParcelaPaga(String indicadorParcelaPaga) {
		this.indicadorParcelaPaga = indicadorParcelaPaga;
	}

	public FichaDevolucao getFichaDevolucao() {
		return fichaDevolucao;
	}

	public void setFichaDevolucao(FichaDevolucao fichaDevolucao) {
		this.fichaDevolucao = fichaDevolucao;
	}

	public List<ParcelaContaDevolucaoDetalhe> getListaParcelaContaDevolucaoDetalhe() {
		return listaParcelaContaDevolucaoDetalhe;
	}

	public void setListaParcelaContaDevolucaoDetalhe(List<ParcelaContaDevolucaoDetalhe> listaParcelaContaDevolucaoDetalhe) {
		this.listaParcelaContaDevolucaoDetalhe = listaParcelaContaDevolucaoDetalhe;
	}

	public List<ParcelaContaDevolucaoDetalheImpostoDTO> getListaParcelaContaDevolucaoDetalheImpostoDTO() {
		return listaParcelaContaDevolucaoDetalheImpostoDTO;
	}

	public void setListaParcelaContaDevolucaoDetalheImpostoDTO(
			List<ParcelaContaDevolucaoDetalheImpostoDTO> listaParcelaContaDevolucaoDetalheImpostoDTO) {
		this.listaParcelaContaDevolucaoDetalheImpostoDTO = listaParcelaContaDevolucaoDetalheImpostoDTO;
	}

	@Override
	public String toString() {
		return "ParcelaContaDevolucao [codigo=" + codigo + ", devolucao=" + devolucao + ", tipoContaDevolucao="
				+ tipoContaDevolucao + ", dataMinimaParcela=" + dataMinimaParcela + ", qtdCotaParcela=" + qtdCotaParcela
				+ ", indicadorParcelaPaga=" + indicadorParcelaPaga + ", dataAlteracao=" + dataAlteracao
				+ ", dataInclusao=" + dataInclusao + ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao
				+ ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + ", fichaDevolucao=" + fichaDevolucao
				+ ", listaParcelaContaDevolucaoDetalhe=" + listaParcelaContaDevolucaoDetalhe
				+ ", listaParcelaContaDevolucaoDetalheImpostoDTO=" + listaParcelaContaDevolucaoDetalheImpostoDTO + "]";
	}
	
}