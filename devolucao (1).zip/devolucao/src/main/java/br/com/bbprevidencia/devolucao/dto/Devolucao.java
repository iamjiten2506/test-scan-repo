package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.com.bbprevidencia.beneficio.dto.FichaDevolucao;
import br.com.bbprevidencia.beneficio.dto.IdentificadorDevolucao;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.enumerador.MantenedorEnum;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.devolucao.enumerador.TipoDevolucaoInternaEnum;
import br.com.bbprevidencia.utils.UtilJava;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 28/11/2016 Classe de persistência para tabela DEVOLUCAO.
 */
@Entity
@Table(name = "DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "Devolucao.findAll", query = "SELECT q FROM Devolucao q")
public class Devolucao implements Serializable, BaseEntity, Comparable<Devolucao> {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DEVOLUCAO_GER", sequenceName = "S_DEV_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PARTIC_PLANO")
	private ParticipantePlano participantePlano;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CAL_DEV")
	private RegraCalculoDevolucao regraCalculoDevolucao;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_SIT_DEV")
	private SituacaoDevolucao situacaoDevolucao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_CAD")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ULT_SIT_DEV")
	private Date dataUltimaSituacao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_REQ")
	private Date dataRequerimento;

	@Column(name = "IND_OPCAO_IR_CALC")
	private String indOpcaoIrCalc;

	@Column(name = "NUM_TOT_PAR")
	private int numeroTotalParcelas;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ULT_PGT")
	private Date dataUltimoPagamento;

	@Column(name = "PER_DEV")
	private Double percentualDevolucao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_COT")
	private Date dataCota;

	@Column(name = "VAL_COT")
	private double valorCota;

	@Column(name = "VAL_IND_AJU")
	private double valorIndiceAjustado;

	@Column(name = "NUM_SEQ_MOV_ALC")
	private Long movimentoAlcada;

	@Column(name = "IND_MAN")
	private String indicadorDevManual;

	@Column(name = "IND_PGT_CON_CAR")
	private String indicadorFormaPagtoContribCarencia;

	@Column(name = "NUM_DEP_IMP_ULT_CAL")
	private int numeroDependetesIrrf;

	@Column(name = "NUM_MES_IDA_ULT_CAL")
	private int mesesIdadeCalculo;

	@Column(name = "NUM_MES_EMP_ULT_CAL")
	private int mesesEmpresaCalculo;

	@Column(name = "NUM_MES_PLA_ULT_CAL")
	private int mesesPlanoCalculo;

	@Column(name = "NUM_SEQ_HIS_FIN_PAG_ULT")
	private Long numeroUltimoHistoricoFinanceiroPagoUltilizado;

	@Column(name = "NUM_QTD_CON_ULT_CAL")
	private int qtdContribCalculo;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@Column(name = "IND_TP_DEV_INTERNA")
	private int indicadorDevolucaoInterna = 0;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "devolucao", targetEntity = DescontoDevolucao.class, fetch = FetchType.EAGER, orphanRemoval = true)
	private List<DescontoDevolucao> listaDescontoDevolucao;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "devolucao", fetch = FetchType.LAZY)
	private List<ParcelaContaDevolucao> listaParcelaContaDevolucao = new ArrayList<ParcelaContaDevolucao>();

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy = "devolucao", fetch = FetchType.LAZY)
	private List<SaldoParticipanteIsento> listaSaldoParticipanteIsento = new ArrayList<SaldoParticipanteIsento>();

	/*@Column(name = "NUM_SEQ_PEDIDO")
	private Long codigoPedido;
	 */
	@Transient
	private List<FichaDevolucao> listaFichaDevolucao;

	@Transient
	private IdentificadorDevolucao identificadorDevolucao;

	@Transient
	private String descricao;

	@Transient
	private String descricaoDeferimento;

	@Transient
	private String motivoIndeferimento;

	@Transient
	private Double valorCotaPagamentoMes;

	@Transient
	private Double saldoResgatavel;

	@Transient
	private Date dataCotaPagamentoMes;

	@Transient
	private Double valorTotalImposto;

	@Transient
	private List<RecebedorDTO> listaRecebedorDTO;

	@Transient
	private boolean possuiEmprestimoPortabilidade;

	@Transient
	private Date dataReferenciaMinima;

	@Transient
	private Date dataReferenciaMaxima;

	@Transient
	private String dataFormadataInclusao;

	@Transient
	private boolean isDevolucaoPaga;

	@Transient
	private boolean isResgate;

	@Transient
	private boolean isPortabilidade;

	@Transient
	private boolean isPosicionado = false;

	@Transient
	private boolean remanescenteFinal;

	@Transient
	private boolean planoSarahPrev;

	@Transient
	private Double qtdBruto;

	@Transient
	private Double qtdImposto;

	public String getIndOpcaoIrCalc() {
		return indOpcaoIrCalc;
	}

	public void setIndOpcaoIrCalc(String indOpcaoIrCalc) {
		this.indOpcaoIrCalc = indOpcaoIrCalc;
	}

	public Double getQtdBruto() {
		return qtdBruto;
	}

	public void setQtdBruto(Double qtdBruto) {
		this.qtdBruto = qtdBruto;
	}

	public Double getQtdImposto() {
		return qtdImposto;
	}

	public void setQtdImposto(Double qtdImposto) {
		this.qtdImposto = qtdImposto;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public ParticipantePlano getParticipantePlano() {
		return participantePlano;
	}

	public void setParticipantePlano(ParticipantePlano participantePlano) {
		this.participantePlano = participantePlano;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public SituacaoDevolucao getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(SituacaoDevolucao situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public Date getDataUltimaSituacao() {
		return dataUltimaSituacao;
	}

	public void setDataUltimaSituacao(Date dataUltimaSituacao) {
		this.dataUltimaSituacao = dataUltimaSituacao;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public int getNumeroTotalParcelas() {
		return numeroTotalParcelas;
	}

	public void setNumeroTotalParcelas(int numeroTotalParcelas) {
		this.numeroTotalParcelas = numeroTotalParcelas;
	}

	public Date getDataUltimoPagamento() {
		return dataUltimoPagamento;
	}

	public void setDataUltimoPagamento(Date dataUltimoPagamento) {
		this.dataUltimoPagamento = dataUltimoPagamento;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public double getValorCota() {
		return valorCota;
	}

	public void setValorCota(double valorCota) {
		this.valorCota = valorCota;
	}

	public double getValorIndiceAjustado() {
		return valorIndiceAjustado;
	}

	public void setValorIndiceAjustado(double valorIndiceAjustado) {
		this.valorIndiceAjustado = valorIndiceAjustado;
	}

	public Long getMovimentoAlcada() {
		return movimentoAlcada;
	}

	public void setMovimentoAlcada(Long movimentoAlcada) {
		this.movimentoAlcada = movimentoAlcada;
	}

	public String getIndicadorDevManual() {
		return indicadorDevManual;
	}

	public void setIndicadorDevManual(String indicadorDevManual) {
		this.indicadorDevManual = indicadorDevManual;
	}

	public String getIndicadorFormaPagtoContribCarencia() {
		return indicadorFormaPagtoContribCarencia;
	}

	public void setIndicadorFormaPagtoContribCarencia(String indicadorFormaPagtoContribCarencia) {
		this.indicadorFormaPagtoContribCarencia = indicadorFormaPagtoContribCarencia;
	}

	public int getNumeroDependetesIrrf() {
		return numeroDependetesIrrf;
	}

	public void setNumeroDependetesIrrf(int numeroDependetesIrrf) {
		this.numeroDependetesIrrf = numeroDependetesIrrf;
	}

	public int getMesesEmpresaCalculo() {
		return mesesEmpresaCalculo;
	}

	public void setMesesEmpresaCalculo(int mesesEmpresaCalculo) {
		this.mesesEmpresaCalculo = mesesEmpresaCalculo;
	}

	public int getMesesPlanoCalculo() {
		return mesesPlanoCalculo;
	}

	public void setMesesPlanoCalculo(int mesesPlanoCalculo) {
		this.mesesPlanoCalculo = mesesPlanoCalculo;
	}

	public int getQtdContribCalculo() {
		return qtdContribCalculo;
	}

	public void setQtdContribCalculo(int qtdContribCalculo) {
		this.qtdContribCalculo = qtdContribCalculo;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public List<FichaDevolucao> getListaFichaDevolucao() {
		return listaFichaDevolucao;
	}

	public void setListaFichaDevolucao(List<FichaDevolucao> listaFichaDevolucao) {
		this.listaFichaDevolucao = listaFichaDevolucao;
	}

	public IdentificadorDevolucao getIdentificadorDevolucao() {
		return identificadorDevolucao;
	}

	public void setIdentificadorDevolucao(IdentificadorDevolucao identificadorDevolucao) {
		this.identificadorDevolucao = identificadorDevolucao;
	}

	public List<DescontoDevolucao> getListaDescontoDevolucao() {
		return listaDescontoDevolucao;
	}

	public void setListaDescontoDevolucao(List<DescontoDevolucao> listaDescontoDevolucao) {
		this.listaDescontoDevolucao = listaDescontoDevolucao;
	}

	/*
	 public Long getCodigoPedido() {
	 return codigoPedido;
	 }

	 public void setCodigoPedido(Long codigoPedido) {
	 this.codigoPedido = codigoPedido;
	 }
	 */
	@Override
	public int compareTo(Devolucao o) {
		if (o.getCodigo() != this.codigo) {
			return 1;
		} else if (o.getCodigo() == this.codigo) {
			return 0;
		} else {
			return -1;
		}

	}

	public Double getPercentualDevolucao() {
		return percentualDevolucao;
	}

	public void setPercentualDevolucao(Double percentualDevolucao) {
		this.percentualDevolucao = percentualDevolucao;
	}

	public String getDescricao() {

		descricao = " Mat.: " + this.getParticipantePlano().getParticipante().getNumeroMatriculaPatrocinadora() + "Cod.: - " + this.codigo.toString();

		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Double getValorCotaPagamentoMes() {
		return valorCotaPagamentoMes;
	}

	public void setValorCotaPagamentoMes(Double valorCotaPagamentoMes) {
		this.valorCotaPagamentoMes = valorCotaPagamentoMes;
	}

	public Date getDataCotaPagamentoMes() {
		return dataCotaPagamentoMes;
	}

	public void setDataCotaPagamentoMes(Date dataCotaPagamentoMes) {
		this.dataCotaPagamentoMes = dataCotaPagamentoMes;
	}

	public Double getSaldoResgatavel() {
		return saldoResgatavel;
	}

	public void setSaldoResgatavel(Double saldoResgatavel) {
		this.saldoResgatavel = saldoResgatavel;
	}

	public String getDescricaoDeferimento() {
		return descricaoDeferimento;
	}

	public void setDescricaoDeferimento(String descricaoDeferimento) {
		this.descricaoDeferimento = descricaoDeferimento;
	}

	public String getMotivoIndeferimento() {
		return motivoIndeferimento;
	}

	public void setMotivoIndeferimento(String motivoIndeferimento) {
		this.motivoIndeferimento = motivoIndeferimento;
	}

	public int getMesesIdadeCalculo() {
		return mesesIdadeCalculo;
	}

	public void setMesesIdadeCalculo(int mesesIdadeCalculo) {
		this.mesesIdadeCalculo = mesesIdadeCalculo;
	}

	public Double getValorTotalImposto() {
		return valorTotalImposto;
	}

	public void setValorTotalImposto(Double valorTotalImposto) {
		this.valorTotalImposto = valorTotalImposto;
	}

	public List<RecebedorDTO> getListaRecebedorDTO() {
		if (this.listaRecebedorDTO == null) {
			this.listaRecebedorDTO = new ArrayList<RecebedorDTO>();
		}
		return listaRecebedorDTO;
	}

	public void setListaRecebedorDTO(List<RecebedorDTO> listaRecebedorDTO) {
		this.listaRecebedorDTO = listaRecebedorDTO;
	}

	public Long getNumeroUltimoHistoricoFinanceiroPagoUltilizado() {
		return numeroUltimoHistoricoFinanceiroPagoUltilizado;
	}

	public void setNumeroUltimoHistoricoFinanceiroPagoUltilizado(Long numeroUltimoHistoricoFinanceiroPagoUltilizado) {
		this.numeroUltimoHistoricoFinanceiroPagoUltilizado = numeroUltimoHistoricoFinanceiroPagoUltilizado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Devolucao other = (Devolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	public boolean isPossuiEmprestimoPortabilidade() {

		if (UtilJava.isColecaoDiferenteDeVazia(this.listaDescontoDevolucao)) {

			for (DescontoDevolucao descontoDevolucao : this.listaDescontoDevolucao) {

				if (descontoDevolucao.getRubricaDevolucao().getTipoRubrica().getCodigo() == 3) {
					return true;
				}
			}

			return false;
		} else {
			return false;
		}

	}

	public void setPossuiEmprestimoPortabilidade(boolean possuiEmprestimoPortabilidade) {
		this.possuiEmprestimoPortabilidade = possuiEmprestimoPortabilidade;
	}

	public Date getDataReferenciaMinima() {
		return dataReferenciaMinima;
	}

	public void setDataReferenciaMinima(Date dataReferenciaMinima) {
		this.dataReferenciaMinima = dataReferenciaMinima;
	}

	public Date getDataReferenciaMaxima() {
		return dataReferenciaMaxima;
	}

	public void setDataReferenciaMaxima(Date dataReferenciaMaxima) {
		this.dataReferenciaMaxima = dataReferenciaMaxima;
	}

	public String getDataFormadataInclusao() {
		return br.com.bbprevidencia.bbpcomum.util.UtilJava.formataDataPorPadrao(this.dataInclusao, "dd/MM/YYYY");
	}

	public void setDataFormadataInclusao(String dataFormadataInclusao) {
		this.dataFormadataInclusao = dataFormadataInclusao;
	}

	public boolean isDevolucaoPaga() {
		return this.situacaoDevolucao.getCodigo().equals(SituacaoDevolucaoEnum.PAGO.getCodigo());
	}

	public boolean isResgate() {
		return regraCalculoDevolucao.getTipoDevolucao().getIndicadorTipoDevolucao().equals("R");
	}

	public boolean isPortabilidade() {
		return regraCalculoDevolucao.getTipoDevolucao().getIndicadorTipoDevolucao().equals("P");
	}

	public boolean isPosicionado() {
		return isPosicionado;
	}

	public void setPosicionado(boolean isPosicionado) {
		this.isPosicionado = isPosicionado;
	}

	public boolean isRemanescenteFinal() {
		return this.indicadorFormaPagtoContribCarencia.equals("F");
	}

	public Double getTotalValorFichaDevPorMantenedor(MantenedorEnum mantenedorEnum) {

		Double valor = 0D;
		for (FichaDevolucao ficha : this.listaFichaDevolucao) {

			if (mantenedorEnum.equals(MantenedorEnum.PARTICIPANTE)) {
				valor += ficha.getTotalFichaParticipante();
			}

			if (mantenedorEnum.equals(MantenedorEnum.PATROCINADORA)) {
				valor += ficha.getTotalFichaParticipante();
			}
		}
		return valor;
	}

	public boolean isParcelamento() {
		// TODO Auto-generated method stub
		return this.situacaoDevolucao.getCodigo().equals(SituacaoDevolucaoEnum.EM_PARCELAMENTO.getCodigo());
	}

	public int getIndicadorDevolucaoInterna() {
		return indicadorDevolucaoInterna;
	}

	public void setIndicadorDevolucaoInterna(int indicadorDevolucaoInterna) {
		this.indicadorDevolucaoInterna = indicadorDevolucaoInterna;
	}

	public TipoDevolucaoInternaEnum tipoDevolucaoInterna() {
		return TipoDevolucaoInternaEnum.getTipoDevolucaoInternaEnum(this.indicadorDevolucaoInterna);
	}

	public boolean isPortabilidadeInterna() {
		return TipoDevolucaoInternaEnum.getTipoDevolucaoInternaEnum(this.indicadorDevolucaoInterna).equals(TipoDevolucaoInternaEnum.PORT_INTERNA_MATRICULA)
				|| TipoDevolucaoInternaEnum.getTipoDevolucaoInternaEnum(this.indicadorDevolucaoInterna).equals(TipoDevolucaoInternaEnum.PORT_INTERNA_PLANOS);
	}

	public boolean isPortabilidadeInternaMatricula() {
		return TipoDevolucaoInternaEnum.getTipoDevolucaoInternaEnum(this.indicadorDevolucaoInterna).equals(TipoDevolucaoInternaEnum.PORT_INTERNA_MATRICULA);
	}

	public boolean isPortabilidadeInternaPlanos() {
		return TipoDevolucaoInternaEnum.getTipoDevolucaoInternaEnum(this.indicadorDevolucaoInterna).equals(TipoDevolucaoInternaEnum.PORT_INTERNA_PLANOS);
	}

	public String getCpfParticipanteDevolucao() {
		// TODO Auto-generated method stub
		return this.participantePlano != null ? this.participantePlano.getParticipante().getCpf() : "";
	}

	public boolean isPlanoSarahPrev() {
		if (this.participantePlano != null && this.participantePlano.getPlanoPrevidencia() != null
				&& (this.participantePlano.getPlanoPrevidencia().getCodigo().equals(112L) || this.participantePlano.getPlanoPrevidencia().getCodigo().equals(111L)))
			return true;

		return false;
	}

	public void setPlanoSarahPrev(boolean planoSarahPrev) {
		this.planoSarahPrev = planoSarahPrev;
	}

	public List<ParcelaContaDevolucao> getListaParcelaContaDevolucao() {
		return listaParcelaContaDevolucao;
	}

	public void setListaParcelaContaDevolucao(List<ParcelaContaDevolucao> listaParcelaContaDevolucao) {
		this.listaParcelaContaDevolucao = listaParcelaContaDevolucao;
	}

	public List<SaldoParticipanteIsento> getListaSaldoParticipanteIsento() {
		return listaSaldoParticipanteIsento;
	}

	public void setListaSaldoParticipanteIsento(List<SaldoParticipanteIsento> listaSaldoParticipanteIsento) {
		this.listaSaldoParticipanteIsento = listaSaldoParticipanteIsento;
	}
}
