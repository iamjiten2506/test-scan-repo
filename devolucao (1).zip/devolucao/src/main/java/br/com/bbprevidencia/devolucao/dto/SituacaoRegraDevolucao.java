package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0351 - Marco Figueiredo
 * @since   05/12/2016
 * Classe de persistência para tabela SITUACAO_REGRA.
 */
@Entity
@Table(name = "SITUACAO_REGRA_DEVOLUCAO", schema = "OWN_DCR")
@NamedQuery(name = "SituacaoRegraDevolucao.findAll", query = "SELECT q FROM SituacaoRegraDevolucao q")
public class SituacaoRegraDevolucao implements Serializable, BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SITUACAO_REGRA_DEVOLUCAO_GER", sequenceName = "S_SRD_01")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SITUACAO_REGRA_DEVOLUCAO_GER")
	@Column(name = "NUM_SEQ_SIT_REGRA_DEV")
	private Long codigo;

	@Column(name = "NOM_SIT_REGRA_DEV")
	private String nome;

	@Column(name = "DSC_SIT_REGRA_DEV")
	private String descricao;

	@Column(name = "IND_PER_CAL")
	private String indicativoPermiteCalculo;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public String getIndicativoPermiteCalculo() {
		return indicativoPermiteCalculo;
	}

	public void setIndicativoPermiteCalculo(String indicativoPermiteCalculo) {
		this.indicativoPermiteCalculo = indicativoPermiteCalculo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((dataAlteracao == null) ? 0 : dataAlteracao.hashCode());
		result = prime * result + ((dataInclusao == null) ? 0 : dataInclusao.hashCode());
		result = prime * result + ((descricao == null) ? 0 : descricao.hashCode());
		result = prime * result + ((indicativoPermiteCalculo == null) ? 0 : indicativoPermiteCalculo.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((nomeUsuarioAlteracao == null) ? 0 : nomeUsuarioAlteracao.hashCode());
		result = prime * result + ((nomeUsuarioInclusao == null) ? 0 : nomeUsuarioInclusao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SituacaoRegraDevolucao other = (SituacaoRegraDevolucao) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (dataAlteracao == null) {
			if (other.dataAlteracao != null)
				return false;
		} else if (!dataAlteracao.equals(other.dataAlteracao))
			return false;
		if (dataInclusao == null) {
			if (other.dataInclusao != null)
				return false;
		} else if (!dataInclusao.equals(other.dataInclusao))
			return false;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (indicativoPermiteCalculo == null) {
			if (other.indicativoPermiteCalculo != null)
				return false;
		} else if (!indicativoPermiteCalculo.equals(other.indicativoPermiteCalculo))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (nomeUsuarioAlteracao == null) {
			if (other.nomeUsuarioAlteracao != null)
				return false;
		} else if (!nomeUsuarioAlteracao.equals(other.nomeUsuarioAlteracao))
			return false;
		if (nomeUsuarioInclusao == null) {
			if (other.nomeUsuarioInclusao != null)
				return false;
		} else if (!nomeUsuarioInclusao.equals(other.nomeUsuarioInclusao))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SituacaoRegraDevolucao [codigo=" + codigo + ", nome=" + nome + ", descricao=" + descricao + ", indicativoPermiteCalculo=" + indicativoPermiteCalculo + ", dataAlteracao="
				+ dataAlteracao + ", dataInclusao=" + dataInclusao + ", nomeUsuarioAlteracao=" + nomeUsuarioAlteracao + ", nomeUsuarioInclusao=" + nomeUsuarioInclusao + "]";
	}

}