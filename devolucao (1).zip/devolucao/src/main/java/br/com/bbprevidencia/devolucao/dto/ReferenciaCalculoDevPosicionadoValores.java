package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;

/**
 * @author BBPF0351 - Marco Figueiredo
 * @since 28/11/2016 Classe de persistência para tabela DEVOLUCAO.
 */
@Entity
@Table(name = "REF_CALC_DR_VAL", schema = "OWN_DR")
//Owner antigo do devolucao
@NamedQuery(name = "ReferenciaCalculoDevPosicionadoValores.findAll", query = "SELECT q FROM ReferenciaCalculoDevPosicionadoValores q")
public class ReferenciaCalculoDevPosicionadoValores implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REF_CALC_DR_VAL_GER", sequenceName = "S_REF_CALC_DR_VAL_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REF_CALC_DR_VAL_GER")
	@Column(name = "NUM_SEQ_REF_CALC_DR_VALOR")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REF_CALC_DR")
	private ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PARTIC_PLANO")
	private ParticipantePlano participantePlano;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_COTA")
	private Date dataCota;

	@Column(name = "VAL_COTA")
	private Double valorCota;

	@Column(name = "QTD_COTA_PARTIC")
	private Double qtdCotaParticipante;

	@Column(name = "QTD_COTA_PATRON")
	private Double qtdCotaPartronal;

	@Column(name = "QTD_COTA_REVERSAO")
	private Double qtdCotaReversao;

	@Column(name = "QTD_COTA_REMANESCENTE")
	private Double qtdCotaRemanescente;

	@Column(name = "VAL_PARTIC")
	private Double valorParticipante;

	@Column(name = "VAL_PATRON")
	private Double valorPatronal;

	@Column(name = "VAL_REVERSAO")
	private Double valorReversao;

	@Column(name = "VAL_REMANESCENTE")
	private Double valorRemanescente;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTER")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCL")
	private Date dataInclusao;

	@Column(name = "NOM_USU_ALTER")
	private String nomeUsuarioAlteracao;

	@Column(name = "NOM_USU_INCL")
	private String nomeUsuarioInclusao;

	@Transient
	private MensagemLoteProcessamentoRefCalcDevolucao mensagem;

	public ReferenciaCalculoDevPosicionadoValores(MensagemLoteProcessamentoRefCalcDevolucao mensagem) {
		super();
		this.mensagem = mensagem;
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public ReferenciaCalculoDevolucaoPosicionado getReferenciaCalculoDevolucaoPosicionado() {
		return referenciaCalculoDevolucaoPosicionado;
	}

	public void setReferenciaCalculoDevolucaoPosicionado(ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado) {
		this.referenciaCalculoDevolucaoPosicionado = referenciaCalculoDevolucaoPosicionado;
	}

	public ParticipantePlano getParticipantePlano() {
		return participantePlano;
	}

	public void setParticipantePlano(ParticipantePlano participantePlano) {
		this.participantePlano = participantePlano;
	}

	public Double getValorCota() {
		return valorCota;
	}

	public void setValorCota(Double valorCota) {
		this.valorCota = valorCota;
	}

	public Double getQtdCotaParticipante() {
		return qtdCotaParticipante;
	}

	public void setQtdCotaParticipante(Double qtdCotaParticipante) {
		this.qtdCotaParticipante = qtdCotaParticipante;
	}

	public Double getQtdCotaPartronal() {
		return qtdCotaPartronal;
	}

	public void setQtdCotaPartronal(Double qtdCotaPartronal) {
		this.qtdCotaPartronal = qtdCotaPartronal;
	}

	public Double getQtdCotaReversao() {
		return qtdCotaReversao;
	}

	public void setQtdCotaReversao(Double qtdCotaReversao) {
		this.qtdCotaReversao = qtdCotaReversao;
	}

	public Double getQtdCotaRemanescente() {
		return qtdCotaRemanescente;
	}

	public void setQtdCotaRemanescente(Double qtdCotaRemanescente) {
		this.qtdCotaRemanescente = qtdCotaRemanescente;
	}

	public Double getValorParticipante() {
		return valorParticipante;
	}

	public void setValorParticipante(Double valorParticipante) {
		this.valorParticipante = valorParticipante;
	}

	public Double getValorPatronal() {
		return valorPatronal;
	}

	public void setValorPatronal(Double valorPatronal) {
		this.valorPatronal = valorPatronal;
	}

	public Double getValorReversao() {
		return valorReversao;
	}

	public void setValorReversao(Double valorReversao) {
		this.valorReversao = valorReversao;
	}

	public Double getValorRemanescente() {
		return valorRemanescente;
	}

	public void setValorRemanescente(Double valorRemanescente) {
		this.valorRemanescente = valorRemanescente;
	}

	public MensagemLoteProcessamentoRefCalcDevolucao getMensagem() {
		return mensagem;
	}

	public void setMensagem(MensagemLoteProcessamentoRefCalcDevolucao mensagem) {
		this.mensagem = mensagem;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReferenciaCalculoDevPosicionadoValores other = (ReferenciaCalculoDevPosicionadoValores) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	public String getDataFormadataInclusao() {
		return br.com.bbprevidencia.bbpcomum.util.UtilJava.formataDataPorPadrao(this.dataInclusao, "dd/MM/YYYY");
	}

	public ReferenciaCalculoDevPosicionadoValores() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReferenciaCalculoDevPosicionadoValores(ReferenciaCalculoDevolucaoPosicionado referenciaCalculoDevolucaoPosicionado, ParticipantePlano participantePlano, Date dataCota, Double valorCota,
			Double qtdCotaParticipante, Double qtdCotaPartronal, Double qtdCotaReversao, Double qtdCotaRemanescente, Double valorParticipante, Double valorPatronal, Double valorReversao,
			Double valorRemanescente, Date dataInclusao, String nomeUsuarioAlteracao) {
		super();
		this.referenciaCalculoDevolucaoPosicionado = referenciaCalculoDevolucaoPosicionado;
		this.participantePlano = participantePlano;
		this.dataCota = dataCota;
		this.valorCota = valorCota;
		this.qtdCotaParticipante = qtdCotaParticipante;
		this.qtdCotaPartronal = qtdCotaPartronal;
		this.qtdCotaReversao = qtdCotaReversao;
		this.qtdCotaRemanescente = qtdCotaRemanescente;
		this.valorParticipante = valorParticipante;
		this.valorPatronal = valorPatronal;
		this.valorReversao = valorReversao;
		this.valorRemanescente = valorRemanescente;
		this.dataInclusao = dataInclusao;
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

}
