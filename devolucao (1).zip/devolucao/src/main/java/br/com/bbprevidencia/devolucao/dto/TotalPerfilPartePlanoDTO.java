package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

public class TotalPerfilPartePlanoDTO {

	private String perfilInvestimento;

	private String planoPrevidencia;

	private String tipoFolhaDevolucao;

	private Date dataCota;

	private Date dataPgto;

	private Double valorTotal;

	public String getPerfilInvestimento() {
		return perfilInvestimento;
	}

	public void setPerfilInvestimento(String perfilInvestimento) {
		this.perfilInvestimento = perfilInvestimento;
	}

	public String getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(String planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public String getTipoFolhaDevolucao() {
		return tipoFolhaDevolucao;
	}

	public void setTipoFolhaDevolucao(String tipoFolhaDevolucao) {
		this.tipoFolhaDevolucao = tipoFolhaDevolucao;
	}

	public Date getDataCota() {
		return dataCota;
	}

	public void setDataCota(Date dataCota) {
		this.dataCota = dataCota;
	}

	public Double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public Date getDataPgto() {
		return dataPgto;
	}

	public void setDataPgto(Date dataPgto) {
		this.dataPgto = dataPgto;
	}

}
