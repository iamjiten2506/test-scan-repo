package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoTempoPlanoBO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoTempoPlano;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio
 * para manter as Regras de Cálculo de Tempo de Plano
 * 
 * @author  BBPF0415 - Yanisley Mora  Ritchie
 * @since 25/01/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */
@Scope("session")
@Component("regraCalculoTempoPlanoVisao")
public class RegraCalculoTempoPlanoVisao {

	private static final String FW_REGRA_CALC_TEMPO_PLANO = "/paginas/regraCalculoTempoPlano.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private RegraCalculoTempoPlanoBO regraCalculoTempoPlanoBO;

	private List<RegraCalculoTempoPlano> listaRegraCalculoTempoPlano;

	private RegraCalculoTempoPlano regraCalculoTempoPlano;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	/**
	 * Método encarregado por iniciar a página das Regras de Cálculo Tempo Plano
	 * @author  BBPF0415 - Yanisley Mora  Ritchie
	 * @since 26/01/2017
	 * @return {@link String}
	 */
	public String inciciarRegraCalculoTempoPlano() {

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("regraCalculoTempoPlano");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.listarStatus = true;

		this.regraCalculoTempoPlano = null;

		this.listaRegraCalculoTempoPlano = new ArrayList<RegraCalculoTempoPlano>(regraCalculoTempoPlanoBO.listarRegraCalculoTempoPlano());

		return FW_REGRA_CALC_TEMPO_PLANO;
	}

	public List<RegraCalculoTempoPlano> getListaRegraCalculoTempoPlano() {
		return listaRegraCalculoTempoPlano;
	}

	public void setListaRegraCalculoTempoPlano(List<RegraCalculoTempoPlano> listaRegraCalculoTempoPlano) {
		this.listaRegraCalculoTempoPlano = listaRegraCalculoTempoPlano;
	}

	public RegraCalculoTempoPlano getRegraCalculoTempoPlano() {
		return regraCalculoTempoPlano;
	}

	public void setRegraCalculoTempoPlano(RegraCalculoTempoPlano regraCalculoTempoPlano) {
		this.regraCalculoTempoPlano = regraCalculoTempoPlano;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

}
