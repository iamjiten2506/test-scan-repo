package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteEnderecoBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoGuardaChuvaBO;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipanteEndereco;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PlanoGuardaChuva;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.cadastroweb.servico.EmailServico;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.AnotacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DetalhePortabilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoItemBO;
import br.com.bbprevidencia.devolucao.bo.GrupoRecebimentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoSituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoPlanoDestinoPortabilidadeDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.AnotacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.DetalhePortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DocumentoDevolucaoVisaoItem;
import br.com.bbprevidencia.devolucao.dto.GrupoRecebimentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.HistoricoSituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RelatorioConclusaoPortabilidadeDTO;
import br.com.bbprevidencia.devolucao.dto.SituacaoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoPlanoDestinoPortabilidadeDevolucao;
import br.com.bbprevidencia.devolucao.enumerador.SituacaoDevolucaoEnum;
import br.com.bbprevidencia.devolucao.enumerador.TipoDevolucaoInternaEnum;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;
import br.com.bbprevidencia.pessoa.bo.AreaAtuacaoBO;
import br.com.bbprevidencia.pessoa.bo.AtuacaoPessoaBO;
import br.com.bbprevidencia.pessoa.bo.PessoaEntidadeBO;
import br.com.bbprevidencia.pessoa.dto.AreaAtuacao;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoa;
import br.com.bbprevidencia.pessoa.dto.AtuacaoPessoaPK;
import br.com.bbprevidencia.pessoa.dto.PessoaEntidade;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   24/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("processoAtualizacaoRecebimentoVisao")
public class ProcessoAtualizacaoRecebimentoVisao {

	private static String FW_PROCESSO_ATUALIZACAO_RECEBIMENTO = "/paginas/processoAtualizacaoRecebimento.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static String FW_PROCESSO_ATUALIZACAO_ATUACAO_PESSOA = "/paginas/processoAtualizacaoAtuacaoPessoa.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	private static final Logger log = Logger.getLogger(ProcessoAtualizacaoRecebimentoVisao.class);

	//private Long codigoEntidadeParticipante;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private ParticipanteBO participanteBO;
	
	@Autowired
	private EntidadeParticipanteEnderecoBO entidadeParticipanteEnderecoBO;

	private EntidadeParticipante entidadeParticipante;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBo;

	@Autowired
	private AtuacaoPessoaBO atuacaoPessoaBO;

	@Autowired
	private TipoPlanoDestinoPortabilidadeDevolucaoBO tipoPlanoDestinoPortabilidadeDevolucaoBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private GrupoRecebimentoDevolucaoBO grupoRecebimentoDevolucaoBO;

	@Autowired
	private DocumentoDevolucaoVisaoItemBO documentoDevolucaoVisaoItemBO;

	@Autowired
	private AnotacaoDevolucaoBO anotacaoDevolucaoBO;

	@Autowired
	private HistoricoSituacaoDevolucaoBO historicoSituacaoDevolucaoBO;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	@Autowired
	private EmailServico emailServico;

	@Autowired
	RelatorioUtil relatorioUtil;

	private HistoricoSituacaoDevolucao historicoSituacaoDevolucao;

	private AnotacaoDevolucao anotacaoDevolucao;

	private PlanoPrevidencia planoPrevidencia;

	private List<GrupoRecebimentoDevolucao> listaGrupoRecebimentoDevolucao;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<Participante> listaParticipante;

	private Participante participante;

	private boolean listarStatus;

	private List<Devolucao> listaDevolucao;

	private List<TipoDevolucao> listaTipoDevolucao;

	private List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem;

	private TipoDevolucao tipoDevolucao;
	
	private boolean bbprevidencia = false;

	//private Long codigoTipoDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private Devolucao devolucao;
	private boolean possuiDocumentoAtuacaoPessoaPendente;
	private boolean chamaPendenciasAberturaTela;
	private boolean possuiDocumentoAtuacaoPessoa;
	private String descricaoPendencias;

	private List<TipoPlanoDestinoPortabilidadeDevolucao> listarTipoPlanoDestinoPortabilidadeDevolucao;

	private GrupoRecebimentoDevolucao grupoRecebimentoDevolucao;

	private String mensagem;
	
	private boolean portabilidadeInterna = false;

	/******************************************************************************/

	/**                     Atuação Pessoa - Portabilidade                       **/

	@Autowired
	private DetalhePortabilidadeDevolucaoBO detalhePortabilidadeDevolucaoBO;

	private List<DetalhePortabilidadeDevolucao> detalhePortabilidadeDevolucaoList;
	private DetalhePortabilidadeDevolucao detalhePortabilidadeDevolucao = new DetalhePortabilidadeDevolucao();

	@Autowired
	private PessoaEntidadeBO pessoaEntidadeBO;

	private PessoaEntidade pessoaEntidade;

	private List<PessoaEntidade> listarPessoaEntidade;

	private AtuacaoPessoa atuacaoPessoa;

	@Autowired
	private AreaAtuacaoBO areaAtuacaoBO;

	private AreaAtuacao areaAtuacaoPessoa;

	private List<AtuacaoPessoa> listaAtuacoes;

	private List<AreaAtuacao> listaAreaAtuacoes;

	private String codigoAreaAtuacao;

	@Autowired
	private PlanoGuardaChuvaBO planoGuardaChuvaBO;
	
	private List<PlanoGuardaChuva> listaPlanos = new ArrayList<>();
	
	public void definirAreaAtuacaoPessoa() {

		this.listaAreaAtuacoes = this.listarAreasAtuacao();

	}

	/******************************************************************************/

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since   16/02/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();
		this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoAtualizacaoRecebimento");
		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoAtualizacaoRecebimento");
		} else {
			this.possuiAcessoTotal = false;
		}
		pessoaEntidade = new PessoaEntidade();
		this.anotacaoDevolucao = new AnotacaoDevolucao();
		this.listarStatus = true;
		limparFormularioPesquisa();
		this.listaEntidadeParticipante = listarEntidadeParticipante();
		this.listaTipoDevolucao = listarTipoDevolucao();

		return FW_PROCESSO_ATUALIZACAO_RECEBIMENTO;
	}

	/**
	 * Método responsável por listar todos os tipos de devoluções
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @return {@link List<SelectItem>}
	 */
	public List<TipoDevolucao> listarTipoDevolucao() {
		return tipoDevolucaoBo.listarTodosTipoDevolucao();
	}

	/**
	 * Cria uma lista de itens da entidade participante.
	 *  
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @return {@link  List<SelectItem> }
	 */
	public List<EntidadeParticipante> listarEntidadeParticipante() {
		return entidadeParticipanteBO.listarEntidadeParticipante();
	}

	/**
	 * Método responsável por retornar a lista de Planos associados à patrocionadora selecionada.
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @param {@link AjaxBehaviorEvent}
	 * @return	{@link String}
	 */
	public String listarPlanoParticipantePorPatrocinadora(AjaxBehaviorEvent event) {
		setPlanoPrevidencia(null);
		setListaPlanoPrevidencia(null);
		setListaParticipante(null);
		this.participante = new Participante();

		try {
			this.listaPlanoPrevidencia = listarPlanoPrevidencia();
		} catch (Exception ex) {
			log.error(ex);
			throw new PrevidenciaException("Não foi possível realizar a operação", ex);
		}

		return FW_PROCESSO_ATUALIZACAO_RECEBIMENTO;
	}

	/**
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/06/2017
	 * @return
	 */
	private List<PlanoPrevidencia> listarPlanoPrevidencia() {
		try {
			if (this.entidadeParticipante == null || this.entidadeParticipante.getChavePrimaria() == null) {
				return this.planoPrevidenciaBO.listarPlanoPrevidencia();
			} else {
				return this.planoPrevidenciaBO.listarPlanoPrevidenciaPorEntidadeParticipante(this.getEntidadeParticipante());
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new PrevidenciaException(e.getMessage());
		}
	}

	/**
	 * @author BBPF0468 - Carlos Wallace
	 * @since 24/12/2018
	 * @return
	 */
	private List<AreaAtuacao> listarAreasAtuacao() {
		List<AtuacaoPessoa> listaAtuacoes = new ArrayList<>();
		List<AreaAtuacao> listaAreaAtuacoes = new ArrayList<>();
		try {
			
			if(this.pessoaEntidade != null) {
				
				listaAtuacoes = this.atuacaoPessoaBO.pesquisarListaAtuacaoPessoaPorPessoa(this.pessoaEntidade);
				
				for(AtuacaoPessoa atPessoa : listaAtuacoes) {
					listaAreaAtuacoes.add(this.areaAtuacaoBO.pesquisarAreaAtuacaoCodigoAreaAtuacao(atPessoa.getChavePrimaria().getCodigoAreaAtuacao()));
				}
			}
			
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			throw new PrevidenciaException(e.getMessage());
		}
		
		
		return listaAreaAtuacoes;
				
	}

	/**
	 * Método encarregado de limpar as infomações da tela e coloca-a em modo inicial de pesquisa
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since  16/02/2017
	 */
	public void limparFormularioPesquisa() {
		this.listarStatus = true;
		this.planoPrevidencia = null;
		this.listaPlanoPrevidencia = null;
		//this.codigoEntidadeParticipante = null;
		this.entidadeParticipante = null;
		this.setParticipante(new Participante());
		this.listaParticipante = null;
		this.listaDevolucao = null;
		this.setTipoDevolucao(null);

	}

	/**
	 * Método responsável por setar o Plano escolhido no select do plano
	 * 
	 * @author  BBPF0152 - BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @param {@link SelectEvent}
	 */
	public void handleSelecionarTipo(AjaxBehaviorEvent event) {
		//setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());
		setTipoDevolucao((TipoDevolucao) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getTipoDevolucao().getNome()) && getTipoDevolucao().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("tipoDevolucao", getTipoDevolucao());

		} else {
			setTipoDevolucao(null);
		}

	}
	
	public void handlePlano(SelectEvent event) {
		
		if (event.getObject() != null) {
			this.bbprevidencia = this.pessoaEntidadeBO.pesquisarFundacaoBBPrevidencia(this.pessoaEntidade.getCodigoCIC());
			
			if (bbprevidencia)
				carregarPlano((String) event.getObject());
			
			this.portabilidadeInterna = true;
		}
	}
	
	public void carregarPlano(String descricao) {

		if (!UtilJava.isStringVazia(descricao)) {

			this.listaPlanos = this.planoGuardaChuvaBO.pesquisarPlanoGuardaChuvaPorNome(descricao);

			for (PlanoGuardaChuva planoGuardaChuva : listaPlanos) {
				detalhePortabilidadeDevolucao.setCodigoPlanoEntidadeDestino(planoGuardaChuva.getCnpb());
				detalhePortabilidadeDevolucao.setPlanoGuardaChuva(planoGuardaChuva);
				break;
			}
			
			this.listaPlanoPrevidencia = this.planoPrevidenciaBO.listarPlanos();
			this.listaPlanoPrevidencia = this.listaPlanoPrevidencia.stream().filter(p -> p.getPlanoGuardaChuva() != null && p.getPlanoGuardaChuva().getCodigo().equals(detalhePortabilidadeDevolucao.getPlanoGuardaChuva().getCodigo())).collect(Collectors.toList());

		}
	}
	
	/**
	 * Método responsável por buscar o plano por descrição
	 * (autocomplete)
	 * 
	 * @author bbpf0351 - Marco Figueiredo
	 * @since 07/03/2019
	 * @param descricao
	 */
	public List<String> listarPlanoPorDescricao(String descricao) {

		List<String> results = new ArrayList<String>();

		try {

			this.bbprevidencia = this.pessoaEntidadeBO.pesquisarFundacaoBBPrevidencia(this.pessoaEntidade.getCodigoCIC());
			
			if (bbprevidencia) {
				List<PlanoGuardaChuva> listaPlanos = this.planoGuardaChuvaBO
						.pesquisarPlanoGuardaChuvaPorNome(descricao.toUpperCase());

				if (UtilJava.isColecaoVazia(listaPlanos)) {

					String alertNovaUnidade = "Não foi possível encontrar plano com o nome ";
					FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_WARN, alertNovaUnidade, null);
					FacesContext.getCurrentInstance().addMessage(null, msg);

				} else {
					for (PlanoGuardaChuva planoGuardaChuva : listaPlanos) {
						results.add(planoGuardaChuva.getNomePlanoGuardaChuva());
					}

					Collections.sort(results);

					return results;
				}
			}

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Não foi possível realizar está operação.");
		}

		return results;
	}
	
	public void handleMatricula(SelectEvent event) {
		
		if (event.getObject() != null) {
			this.bbprevidencia = this.pessoaEntidadeBO.pesquisarFundacaoBBPrevidencia(this.pessoaEntidade.getCodigoCIC());
			
			if (bbprevidencia)
				carregarMatriculas((String) event.getObject());
		}
	}
	
	public void carregarMatriculas(String descricao) {

		if (!UtilJava.isStringVazia(descricao)) {

			ParticipantePlano participantePlano =  this.participantePlanoBO.pesquisarParticipantePlanoPorMatriculaECnpb(descricao, detalhePortabilidadeDevolucao.getCnpb());
			detalhePortabilidadeDevolucao.setCodigoParticEntidadeDestino(participantePlano.getParticipante().getNumeroMatriculaPatrocinadora());
			detalhePortabilidadeDevolucao.setIndicadorOpcaoImpostoRendaDestino(participantePlano.getTipoRegimeTributacao().getCodigo());
		}
	}
	
	/**
	 * Método responsável por buscar o matricula por descrição
	 * (autocomplete)
	 * 
	 * @author bbpf0351 - Marco Figueiredo
	 * @since 07/03/2019
	 * @param descricao
	 */
	public List<String> listarMatriculas(String descricao) {

		List<String> results = new ArrayList<String>();

		try {

			this.bbprevidencia = this.pessoaEntidadeBO.pesquisarFundacaoBBPrevidencia(this.pessoaEntidade.getCodigoCIC());
			
			if (bbprevidencia) {
				List<Participante> listaParticipante = this.participanteBO.listarParticipantesPorCPF(devolucao.getCpfParticipanteDevolucao());

				if (UtilJava.isColecaoVazia(listaParticipante)) {

					String alertNovaUnidade = "Não foi possível encontrar participante.";
					FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_WARN, alertNovaUnidade, null);
					FacesContext.getCurrentInstance().addMessage(null, msg);

				} else {
					for (Participante participante : listaParticipante) {
						if (participante.getNumeroMatriculaPatrocinadora().contains(descricao))
							results.add(participante.getNumeroMatriculaPatrocinadora());
					}

					Collections.sort(results);
					
					if (UtilJava.isColecaoVazia(results)){
						String alertNovaUnidade = "Não foi possível encontrado cadastro de participante para a matrícula preenchida.";
						FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_WARN, alertNovaUnidade, null);
						FacesContext.getCurrentInstance().addMessage(null, msg);
					}
					return results;
				}
			}

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro("Não foi possível realizar está operação.");
		}

		return results;
	}

	/**
	 * Método para redicionar a página de pesquisa para página de Manter de Atuação Pessoa - Portabilidade
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 21/02/2017
	 * @param {@link Devolucao} 
	 * @return {@link String}
	 * 
	 */
	public String mostrarCadastroPortabilidade(Devolucao devolucao) {
		this.setDevolucao(devolucao);
		this.setTipoDevolucao(null);
		this.setParticipante(null);
		this.setPlanoPrevidencia(null);
		this.setDetalhePortabilidadeDevolucao(null);

		this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoAtualizacaoRecebimento");
		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("processoAtualizacaoRecebimento");
		} else {
			this.possuiAcessoTotal = false;
		}
		
		this.portabilidadeInterna = devolucao.isPortabilidadeInterna();

		if (this.participante == null) {
			this.setParticipante(devolucao.getParticipantePlano().getParticipante());
		}
		this.entidadeParticipante = entidadeParticipanteBO.consultarPorChavePrimaria(this.entidadeParticipante.getChavePrimaria());
		this.planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(devolucao.getParticipantePlano().getPlanoPrevidencia().getCodigo());
		this.tipoDevolucao = tipoDevolucaoBo.pesquisarTipoDevolucaoPorCodigo(devolucao.getSituacaoDevolucao().getCodigo());
		this.detalhePortabilidadeDevolucaoList = detalhePortabilidadeDevolucaoBO.pesquisarDetalhePortabilidadeDevolucaoPorDevolucao(devolucao);
		this.listarTipoPlanoDestinoPortabilidadeDevolucao = tipoPlanoDestinoPortabilidadeDevolucaoBO.listarTodos();

		if (UtilJava.isColecaoDiferenteDeVazia(this.detalhePortabilidadeDevolucaoList)) {

			this.detalhePortabilidadeDevolucao = detalhePortabilidadeDevolucaoList.get(0);
			this.pessoaEntidade = pessoaEntidadeBO.pesquisarPessoaEntidadePorCodigo(this.detalhePortabilidadeDevolucao.getAtuacaoPessoa().getChavePrimaria().getCodigo());
			verificarDocumentosDevolucao(detalhePortabilidadeDevolucao.getDevolucao(), detalhePortabilidadeDevolucao.getAtuacaoPessoa());
			this.definirAreaAtuacaoPessoa();

		} else {
			detalhePortabilidadeDevolucao = new DetalhePortabilidadeDevolucao();
		}
		this.listarPessoaEntidade = pessoaEntidadeBO.listarTodosPessoaEntidadeAreaAtuacao();

		return FW_PROCESSO_ATUALIZACAO_ATUACAO_PESSOA;
	}

	/**
	 * Método para salvar Atuação Pessoa - Portabilidade
	 * 
	 * @author  BBPF0170 - MAGSON DIAS
	 * @since 31/03/2017
	 * @return {@link String}
	 * 
	 */
	public String salvarDetalhePortabilidadeDevolucao() {
		AtuacaoPessoaPK atuacaoPessoaPK = new AtuacaoPessoaPK();
		// valida dados obrigatórios
		if (this.detalhePortabilidadeDevolucao.getCodigo() == null) {
			this.detalhePortabilidadeDevolucao.setDevolucao(this.devolucao);
		}
		
		if (validaCampos()) {
			return "";
		}
		try {
			if (this.detalhePortabilidadeDevolucao.getCodigo() == null) {
				this.detalhePortabilidadeDevolucao.setDataInclusao(new Date());
				this.detalhePortabilidadeDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Registro salvo com sucesso!";
			} else {
				this.detalhePortabilidadeDevolucao.setDataAlteracao(new Date());
				this.detalhePortabilidadeDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
				mensagem = "Registro atualizado com sucesso!";
			}
			// CARREGAR ATUAÇÃO PESSOA
			atuacaoPessoaPK.setCodigo(this.pessoaEntidade.getCodigo());
			//Pesquisa apenas para a Área de atuação 7 -- RECEBEDOR DE RESGATE/PORTAB. Chamado 38299 
			//			atuacaoPessoaPK.setCodigoAreaAtuacao("7");
			//adiciona a área de atuação da pessoa
			atuacaoPessoaPK.setCodigoAreaAtuacao(this.codigoAreaAtuacao);

			this.atuacaoPessoa = this.atuacaoPessoaBO.consultarPorChavePrimaria(atuacaoPessoaPK);
			this.detalhePortabilidadeDevolucao.setAtuacaoPessoa(atuacaoPessoa);
			//setar os valores. de atuação e devolução
			if (this.detalhePortabilidadeDevolucao.getCodigo() == null) {
				this.detalhePortabilidadeDevolucao.setDevolucao(this.devolucao);
			}
			if (this.detalhePortabilidadeDevolucao.getCodigo() != null) {
				DetalhePortabilidadeDevolucao detalhePortabilidadeDevolucao = new DetalhePortabilidadeDevolucao();
				detalhePortabilidadeDevolucao = detalhePortabilidadeDevolucaoBO.pesquisarDetalhePortabilidadeDevolucaoPorCodigo(this.detalhePortabilidadeDevolucao.getCodigo());
				detalhePortabilidadeDevolucao = this.detalhePortabilidadeDevolucao;
			}
			this.detalhePortabilidadeDevolucaoBO.salvarDetalhePortabilidadeDevolucao(detalhePortabilidadeDevolucao);
			Mensagens.addMsgInfo(mensagem);

			// veririfica se tem documento para recebedor. 
			if (documentoDevolucaoVisaoItemBO.verificarDocumentosPorDevolucaoAtuacaoPessoa(
					this.detalhePortabilidadeDevolucao.getDevolucao(),
					this.detalhePortabilidadeDevolucao.getAtuacaoPessoa(),
					loginTemporariaDTO)) {
				Mensagens.addMsgInfo("Favor verificar documento do recebedor!");
				verificarDocumentosDevolucao(this.detalhePortabilidadeDevolucao.getDevolucao(), this.detalhePortabilidadeDevolucao.getAtuacaoPessoa());
				//PrimeFaces.current().executeScript("PF('documentosDevolucaoAtuacaoPessoaDialog').show();");
			}

			return FW_PROCESSO_ATUALIZACAO_ATUACAO_PESSOA;
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar");
			return "";
		}
	}

	/**
	 * Método responsável por validar os campos da tela entidade destino portabilidade. 
	 * @author  BBPF00170 - Magson Dias
	 * @since 30/03/2017
	 * @return {@linkplain boolean}
	 */
	private boolean validaCampos() {
		boolean res = false;
		//if (this.detalhePortabilidadeDevolucao.getDevolucao() == null) {
		//	addMsgErro("Selecione uma devolução.");
		//	res = true;
		//}
		if (pessoaEntidade == null) {
			addMsgErro("Seleção de uma pessoa é obrigatório!");
			res = true;
		}

		if (this.codigoAreaAtuacao == null) {
			addMsgErro("Selecione uma Área de Atuação.");
			res = true;
		}

		if (UtilJava.isStringVazia(this.detalhePortabilidadeDevolucao.getNomePlanoDestino())) {
			addMsgErro("O campo nome do plano destino é de preenchimento obrigatório.");
			res = true;
		}

		if (UtilJava.isStringVazia(this.detalhePortabilidadeDevolucao.getCodigoParticEntidadeDestino())) {
			addMsgErro("O campo do código do participante é de preenchimento obrigatório.");
			res = true;
		}
		if (this.detalhePortabilidadeDevolucao.getDataAdesaoPlanoDestino() == null) {
			addMsgErro("Campo data de adesão ao plano é de preenchimento obrigatório.");
			res = true;
		}
		if (UtilJava.isStringVazia(this.detalhePortabilidadeDevolucao.getIndicadorOpcaoImpostoRendaDestino())) {
			addMsgErro("Selcione um indicador de opção de imposto.");
			res = true;
		}
		if (this.detalhePortabilidadeDevolucao.getTipoPlanoDestinoPortabilidadeDevolucao() == null) {
			addMsgErro("Selcione um tipo de plano destino de portabilidade..");
			res = true;
		}
		
		if (this.detalhePortabilidadeDevolucao.getDevolucao().isPortabilidadeInterna() && this.detalhePortabilidadeDevolucao.getPlanoPrevidencia() == null){
			addMsgErro("Para portabilidade internas é necessário preencher campo de Parte Plano..");
			res = true;
		}
		
		return res;
	}

	/**
	 * Adiciona a mensage de erro no faces.
	 * @author  BBPF00170 - MAGSON 
	 * @param 	{{@link String}
	 */
	private void addMsgErro(String mensagem) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "", mensagem);
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(null, message);
	}

	/**
	 * Método para retornar os participantes por plano que incluam o no nome o texo digitado no autocomplete
	 * 
	 * @author  BBPF0152 - Thiago de Castro Xavier
	 * @since 16/02/2017
	 * @param  {@link String}
	 * @return {@link List<Participante>}
	 */
	public List<Participante> listarParticipantesPorNomeEPlano(String nome) {
		if (this.planoPrevidencia != null) {
			return this.participanteBO.listarParticipantesPorNomePlanoENomeParticipante(nome, this.getPlanoPrevidencia());
		} else if (this.entidadeParticipante != null) {
			return this.participanteBO.listarParticipantesPorEntidaParticipanteENomeParticipante(nome, this.entidadeParticipante);
		} else {
			return new ArrayList<Participante>();
		}
	}

	/**
	 * Método para retornar o processo de devolução
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 20/02/2017
	 * @return {@link String}
	 */
	public void pesquisarDevolucaoParticipante() {
		try {
			if (this.getEntidadeParticipante() == null && this.getPlanoPrevidencia() == null && this.getParticipante() == null && this.tipoDevolucao == null) {
				this.setListaDevolucao(new ArrayList<Devolucao>());
				Mensagens.addMsgWarn("Selecione pelo menos um parâmetro antes de pesquisar!");
			} else {
				SituacaoDevolucao situacaoDevolucao = this.situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(1L);

				this.listaDevolucao = new ArrayList<Devolucao>(devolucaoBO.listarDevolucaoParametrizada(
						this.entidadeParticipante,
						this.planoPrevidencia,
						this.participante,
						this.tipoDevolucao,
						situacaoDevolucao,
						null,
						null));
				if (UtilJava.isColecaoVazia(this.listaDevolucao)) {
					Mensagens.addMsgInfo("Não foram encontradas devoluções!");
				}

			}
		} catch (Exception e) {
			log.error(e.getMessage());
			Mensagens.addMsgErro(e.getMessage());
			throw new PrevidenciaException(e.getMessage());

		}

	}

	/**
	 * Método responsável por setar o participante escolhido no autoComplete
	 * 
	 * @author  BBPF0170 - Magson Dias 
	 * @since 08/03/2017
	 * @param {@link SelectEvent}
	 */
	public void handleSelecionarParticipante(SelectEvent event) {
		setParticipante((Participante) event.getObject());
		if (!UtilJava.isStringVazia(getParticipante().getNomeParticipante()) && getParticipante().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("participante", getParticipante());
		} else {
			setParticipante(new Participante());
		}
	}

	/**
	 * Retorna o estado inicial da página
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/02/2017
	 * @return {@link String}
	 */
	public String limparPesquisa() {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove(participante);
		PrimeFaces.current().resetInputs("formProcessoAtualizacaoRecebimento");
		this.participante = new Participante();
		return iniciarTela();
	}

	/**
	 * Método responsável por setar o Plano escolhido no select do plano
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 27/01/2016
	 * @param {@link SelectEvent}
	 */
	public void handleSelecionarPlano(AjaxBehaviorEvent event) {
		this.setParticipante(new Participante());
		this.setListaParticipante(null);
		this.setTipoDevolucao(null);
		setPlanoPrevidencia((PlanoPrevidencia) ((UIOutput) event.getSource()).getValue());

		if (!UtilJava.isStringVazia(getPlanoPrevidencia().getNomePlano()) && getPlanoPrevidencia().getCodigo() != null) {
			UtilSession.adicionarObjetoSessao("plano", getPlanoPrevidencia());

			this.listaTipoDevolucao = new ArrayList<TipoDevolucao>(tipoDevolucaoBO.listarTodosTipoDevolucaoPorPlanoPrevidencia(this.getPlanoPrevidencia()));

		} else {
			setPlanoPrevidencia(null);
		}

	}

	/**
	 * Método responsável por salva os documentos referentes a atuação pessoa.
	 * 
	 * @author BBPF0170 - Magson Dias
	 * @since 16/03/2017
	 *
	 */
	public void salvarListaDocumentoDevolucaoVisaoItem() {
		for (DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItem : this.listaDocumentoDevolucaoVisaoItem) {
			DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItemPesq = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorCodigo(documentoDevolucaoVisaoItem.getCodigo());
			if (!documentoDevolucaoVisaoItemPesq.getIndicativoMarcado().equals(documentoDevolucaoVisaoItem.getIndicativoMarcado())) {
				//Marcando a data de marcação do documento.
				if (documentoDevolucaoVisaoItem.getIndicativoMarcado().equals("S")) {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(new Date());
				} else {
					documentoDevolucaoVisaoItemPesq.setDataMarcacao(null);
				}
				documentoDevolucaoVisaoItemPesq.setIndicativoMarcado(documentoDevolucaoVisaoItem.getIndicativoMarcado());
				documentoDevolucaoVisaoItemPesq.setNomeUsuarioAlteracao(loginTemporariaDTO.getIdentificacaoUsuario());
				documentoDevolucaoVisaoItemBO.salvarDocumentoDevolucaoVisaoItem(documentoDevolucaoVisaoItemPesq);
			}
		}
		verificarDocumentosDevolucao(this.detalhePortabilidadeDevolucao.getDevolucao(), this.detalhePortabilidadeDevolucao.getAtuacaoPessoa());
		PrimeFaces.current().executeScript("PF('documentosDevolucaoAtuacaoPessoaDialog').hide();");
		//PrimeFaces.current().ajax().update(":painelMantemProcessoAtualizacao");
	}

	/**
	 * Método responsável por verificar os documentos referentes a atuação pessoa.
	 * 
	 * @author BBPF0170 - Magson Dias
	 * @since 16/03/2017
	 * @param {@link  Devolucao}
	 * @param {@link  AtuacaoPessoa}
	 */
	public void verificarDocumentosDevolucao(Devolucao devolucao, AtuacaoPessoa atuacaoPessoa) {
		String descricaoPendenciasLocal = new String();
		descricaoPendenciasLocal = "Não existe(m) documento(s)";
		if (devolucao == null) {
			this.setPossuiDocumentoAtuacaoPessoa(false);
			this.setPossuiDocumentoAtuacaoPessoaPendente(false);
			this.setChamaPendenciasAberturaTela(false);
		} else {
			this.listaDocumentoDevolucaoVisaoItem = documentoDevolucaoVisaoItemBO.pesquisarDocumentoDevolucaoVisaoItemPorDevolucaoAtuacaoPessoa(devolucao, atuacaoPessoa);
			this.setPossuiDocumentoAtuacaoPessoaPendente(false);
			this.setChamaPendenciasAberturaTela(false);
			if (this.listaDocumentoDevolucaoVisaoItem.size() > 0) {
				descricaoPendenciasLocal = "Não existe(m) documento(s) pendente(s)";
				this.setPossuiDocumentoAtuacaoPessoa(true);
				if (documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemPendentePorAtuacaoPessoa(devolucao, atuacaoPessoa)) {
					this.setPossuiDocumentoAtuacaoPessoaPendente(true);
					descricaoPendenciasLocal = "Existe(m) documento(s) Pendende(s)";
				}
			} else {
				descricaoPendenciasLocal = "Não existe(m) documento(s)";
				this.setPossuiDocumentoAtuacaoPessoa(false);
			}
		}
		this.setDescricaoPendencias(descricaoPendenciasLocal);
	}

	/**
	 *  Método responsável por fechar o modal de documentos. 
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 */
	public void close() {
		PrimeFaces.current().executeScript("PF('documentosDevolucaoAtuacaoPessoaDialog').hide();");
	}

	/**
	 *  Método responsável por verificar se a devolução pode alterar sua situação.
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 18/04/2017
	 * @return {@link boolean}
	 * @param {@link Devolucao}
	 */
	public boolean atualizarDevolucao(Devolucao devolucao) {
		boolean acaoAtualizarDevolucao = false;
		List<GrupoRecebimentoDevolucao> listGrupo =  new ArrayList<>();
		List<DetalhePortabilidadeDevolucao> listDetalhePortabilidade =  new ArrayList<>();
		
		listGrupo = this.grupoRecebimentoDevolucaoBO.pesquisarGrupoRecebimentoDevolucaoPorDevolucao(devolucao);
		listDetalhePortabilidade = this.detalhePortabilidadeDevolucaoBO.pesquisarDetalhePortabilidadeDevolucaoPorDevolucao(devolucao);
		
			if (devolucao.getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorTipoDevolucao().equals("R")){
				if (listGrupo.size() > 0 ){
					if (this.documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemMarcadoPorDevolucao(devolucao)) {
						acaoAtualizarDevolucao = true;
					}
				} else {
					acaoAtualizarDevolucao = false;
				}
			}
			if (devolucao.getRegraCalculoDevolucao().getTipoDevolucao().getIndicadorTipoDevolucao().equals("P")){
				if (listDetalhePortabilidade.size() > 0 ){
					if (this.documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemMarcadoPorDevolucao(devolucao)) {
						acaoAtualizarDevolucao = true;
					}
				} else {
					acaoAtualizarDevolucao = false;
				}
			}
					
		return acaoAtualizarDevolucao;
	}

	/**
	 *  Método por retorna a devolução selecionada para cadastrar uma anotação.
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 17/03/2017
	 * @param {@link Devolucao}
	 */

	public void acaoAtualizarDevolucao(Devolucao devolucao) {

		this.setDevolucao(devolucaoBO.pesquisarDevolucaoPorCodigo(devolucao.getCodigo()));
		incluirAnotacaoDevolucao(devolucao);

	}

	/**
	 * Método responsável de incluir novas Anotações quando for alteração a situação da devolução.
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 18/04/2017
	 * @param Devolucao
	 */
	public void incluirAnotacaoDevolucao(Devolucao devolucao) {
		if (this.anotacaoDevolucao.getDataAnotacao() == null) {
			this.anotacaoDevolucao.setDataAnotacao(new Date());
		}
		//Inserção de descrição de anotação.
		this.anotacaoDevolucao.setDescricaoAnotacao("Alterado situação para: " + SituacaoDevolucaoEnum.ATUALIZADO.getDescricao());
		this.anotacaoDevolucao = anotacaoDevolucaoBO.gerarAnotacaoDevolucao(devolucao, this.anotacaoDevolucao.getDescricaoAnotacao(), this.anotacaoDevolucao.getDataAnotacao(), loginTemporariaDTO);
		/*
		 * Metodo para atualizar na base alterando a situação para cancelado.
		 */
		processoAtualizaDevolucao(devolucao);
		/*
		 *Faz anotação referente a alteração da situaçaõ de uma devolução. 
		 */
		anotacaoDevolucaoBO.salvarAnotacaoDevolucao(this.anotacaoDevolucao);

		if (!UtilJava.isColecaoVazia(this.listaPlanoPrevidencia)) {
			if (!UtilJava.isColecaoVazia(this.devolucaoBO.consultarDevolucaoRequeridaPorPlanoPrevidencia(this.listaPlanoPrevidencia))) {
				this.listaDevolucao = new ArrayList<Devolucao>(this.devolucaoBO.consultarDevolucaoRequeridaPorPlanoPrevidencia(this.listaPlanoPrevidencia));
			} else {
				this.listaDevolucao = new ArrayList<Devolucao>();
			}
		}

		Mensagens.addMsgInfo("Devolução enviada para conferência.");

		this.anotacaoDevolucao = new AnotacaoDevolucao();
		this.devolucao = new Devolucao();
	}

	/**
	 * Método responsável para fazer a alteração da situação da devolução, passando para situação de ATUALIZADO. 
	 * 
	 * @author BBPF0170 - MAGSON DIAS
	 * @since 21/02/2017
	 * @param {@link Devolucao}
	 */
	public void processoAtualizaDevolucao(Devolucao devolucao) {
		SituacaoDevolucao situacao = new SituacaoDevolucao();
		situacao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(SituacaoDevolucaoEnum.ATUALIZADO.getCodigo());

		Devolucao devolucaoNovo = this.devolucaoBO.pesquisarDevolucaoPorCodigo(devolucao.getCodigo());

		if (devolucaoNovo.getCodigo() != null) {
			devolucaoNovo.setSituacaoDevolucao(situacao);
			devolucaoNovo.setDataAlteracao(new Date());
			devolucaoNovo.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());

			if (devolucaoNovo.isPortabilidade()) {
				DetalhePortabilidadeDevolucao detalhe = this.detalhePortabilidadeDevolucaoBO.pesquisarDetalhePortabilidadeDevolucaoPorDevolucao(devolucaoNovo).get(0);
				detalhe.setQtd(this.detalhePortabilidadeDevolucaoBO.pesquisarDetalhePortabilidadePorDevolucao(devolucaoNovo));
				devolucaoNovo.setIndicadorDevolucaoInterna(detalhe.getTipoDevolucaoInternaPorPlano().getCodigo());
			} else {
				devolucaoNovo.setIndicadorDevolucaoInterna(TipoDevolucaoInternaEnum.RESGATE.getCodigo());
			}

			/*
			 * Atualiza a entidade devolucao com a nova situação (ATUALIZADO.)
			 */
			devolucaoBO.salvarDevolucao(devolucaoNovo);

			/*
			 * Inclui historico de alteração da situação, passa o Objeto devolucao antigo, e salvando histórico. 
			 */
			incluiiHistoricoSituacaoDevoluca(devolucaoNovo);
		}

	}

	/**
	 * Método responsável por incluir um novo histórico da situação devolução.
	 * 
	 * @author BBPF0170 - MAGSON
	 * @since 21/02/2017
	 * @param {@link Devolucao}
	 */
	public void incluiiHistoricoSituacaoDevoluca(Devolucao devolucao) {
		this.historicoSituacaoDevolucao = historicoSituacaoDevolucaoBO.gerarHistoricoSituacaoDevolucao(devolucao);
		historicoSituacaoDevolucaoBO.salvarHistoricoSituacaoDevolucao(historicoSituacaoDevolucao);

	}

	/**
	 * Envia o termo da portabilidade para o participante
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 06/04/2018
	 * @param devolucao
	 */
	public void enviarEmailTermoPortabilidade(Devolucao devolucao) {
		try {
			if (UtilJava.isStringVazia(devolucao.getParticipantePlano().getParticipante().getEnderecoEmail())) {
				throw new PrevidenciaException("Participante sem e-mail cadastrado!");
			}
			

			List<Devolucao> listaDevolucao = new ArrayList<Devolucao>();
			listaDevolucao.add(devolucao);
			List<RelatorioConclusaoPortabilidadeDTO> relatorioConclusaoPortabilidade = new ArrayList<RelatorioConclusaoPortabilidadeDTO>();
			relatorioConclusaoPortabilidade = this.devolucaoBO.montarRelatorioDePortabilidade(listaDevolucao, "TP");

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

			String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");

			parametros.put("logo", logo);

			String arquivoTermo = relatorioUtil.gerarRelatorio("termoPortabilidade", relatorioConclusaoPortabilidade, parametros);

			String caminhoArquivo = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/relatorios/") + "/" + arquivoTermo;

			String textoEmail = "Prezado (a) Participante, <br /><br />";
			textoEmail += "Em atenção à sua solicitação de portabilidade, encaminhamos anexo o termo de portabilidade. Segue abaixo os procedimentos a serem realizados: <br />";
			textoEmail += "<ul><li>Assinar, datar e reconhecer firma em três vias originais do Termo de Portabilidade, anexo;</li></ul>";

			//Antigo
//			textoEmail += "Encaminhar as três vias a BB Previdência para o seguinte endereço:<br /><br />";
//			textoEmail += "BB Previdência - Fundo de Pensão Banco do Brasil<br />";
//			textoEmail += "A/C: GESEG – Gerência de Seguridade<br />";
//			textoEmail += "SAUN Quadra 05, Bloco B, Edifício Banco do Brasil (Torre Central), 2º andar<br />";
//			textoEmail += "CEP: 70.040-912 - Brasília (DF)<br />";
//			textoEmail += "<p>Após recebimento de Termo de Transferência, esta BB Previdência encaminhará as três vias do referido termo à entidade receptora dos recursos, e quando da ";
//			textoEmail += "devolução dos formulários pela entidade receptora a esta entidade, será efetivada a transferência dos recursos bem como, remetidas vias do termo para V.S.ª e ";
//			textoEmail += "para entidade receptora dos recursos. </p>";
//			textoEmail += "<p>Esclarecemos que os recursos destinados a transferência serão atualizados de acordo com a rentabilidade líquida do fundo até a data de efetiva transferência e que ";
//			textoEmail += "os valores estão sujeitos a alterações decorrentes de variações positivas ou negativas.</p><br /><br /><br />";
			
			//Novo
			//Entidade Participante
			
//			EntidadeParticipante entidPartic = devolucao.getParticipantePlano().getParticipante().getEntidadeParticipante();
			EntidadeParticipante entidPartic = this.entidadeParticipanteBO.consultarPorNomeAbreviado(relatorioConclusaoPortabilidade.get(0).getNomeCurtoEntidadeDestino());
			//Endereço da Entidade Participante
			EntidadeParticipanteEndereco entidParticEnd = this.entidadeParticipanteEnderecoBO.pesquisarEntidadeParticipanteEnderecoPorEntidadeParticipante(entidPartic);
			String complementoLogradouro = (entidParticEnd.getComplementoLogradouro() != null)?entidParticEnd.getComplementoLogradouro():"";
			textoEmail += "Encaminhar as três vias  para o seguinte endereço:<br /><br />";
			textoEmail += entidPartic.getNomeEntidadeParticipante()+"<br />";			
			textoEmail += entidParticEnd.getNomeLogradouro()+","+complementoLogradouro+"<br />";
			textoEmail += "CEP: "+UtilJava.formatarCep(entidParticEnd.getCep()+""+entidParticEnd.getCepComplemento())+ "- "+entidParticEnd.getBairro()+" ("+entidParticEnd.getUf()+")<br />";			
			textoEmail += "<p>Quando da devolução dos formulários pela entidade receptora a esta entidade, será efetivada a transferência dos recursos bem como, remetidas vias do termo para V.S.ª e ";
			textoEmail += "para entidade receptora dos recursos. </p>";
			textoEmail += "<p>Esclarecemos que os recursos destinados a transferência serão atualizados de acordo com a rentabilidade líquida do fundo até a data de efetiva transferência e que ";
			textoEmail += "os valores estão sujeitos a alterações decorrentes de variações positivas ou negativas.</p><br /><br /><br />";
			textoEmail += "Atenciosamente,<br />";
			textoEmail += "BB Previdência";
			

			String[] destinatario = { devolucao.getParticipantePlano().getParticipante().getEnderecoEmail() };

			//String[] destinatario = { "thallita@bbprevidencia.com.br" };	
			

			String[] cc = { "portabilidade@bbprevidencia.com.br"};

			String assunto = "Termo de Portabilidade - " + devolucao.getParticipantePlano().getParticipante().getNomeParticipante() + " - "
					+ devolucao.getParticipantePlano().getParticipante().getEntidadeParticipante().getNomeAbreviadoEntidadeParticipante();

			this.emailServico.enviarEmail(destinatario, cc, "portabilidade@bbprevidencia.com.br", assunto, textoEmail, caminhoArquivo);

			AnotacaoDevolucao anotacaoDevolucao = this.anotacaoDevolucaoBO.gerarAnotacaoDevolucao(
					devolucao,
					"Termo de portabilidade enviado via e-mail pela rotina.",
					new Date(),
					this.loginTemporariaDTO);

			this.anotacaoDevolucaoBO.salvarAnotacaoDevolucao(anotacaoDevolucao);

			Mensagens.addMsgInfo("E-mail enviado para o participante!");

		} catch (Exception e) {
			log.error(e);
			Mensagens.addMsgErro(e.getMessage());
		}

	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public EntidadeParticipanteBO getEntidadeParticipanteBO() {
		return entidadeParticipanteBO;
	}

	public void setEntidadeParticipanteBO(EntidadeParticipanteBO entidadeParticipanteBO) {
		this.entidadeParticipanteBO = entidadeParticipanteBO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public List<Participante> getListaParticipante() {
		return listaParticipante;
	}

	public void setListaParticipante(List<Participante> listaParticipante) {
		this.listaParticipante = listaParticipante;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public EntidadeParticipante getEntidadeParticipante() {
		return entidadeParticipante;
	}

	public void setEntidadeParticipante(EntidadeParticipante entidadeParticipante) {
		this.entidadeParticipante = entidadeParticipante;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public List<Devolucao> getListaDevolucao() {
		return listaDevolucao;
	}

	public void setListaDevolucao(List<Devolucao> listaDevolucao) {
		this.listaDevolucao = listaDevolucao;
	}

	public DevolucaoBO getDevolucaoBO() {
		return devolucaoBO;
	}

	public void setDevolucaoBO(DevolucaoBO devolucaoBO) {
		this.devolucaoBO = devolucaoBO;
	}

	public ParticipanteBO getParticipanteBO() {
		return participanteBO;
	}

	public void setParticipanteBO(ParticipanteBO participanteBO) {
		this.participanteBO = participanteBO;
	}

	public TipoDevolucaoBO getTipoDevolucaoBo() {
		return tipoDevolucaoBo;
	}

	public void setTipoDevolucaoBo(TipoDevolucaoBO tipoDevolucaoBo) {
		this.tipoDevolucaoBo = tipoDevolucaoBo;
	}

	public List<TipoDevolucao> getListaTipoDevolucao() {
		return listaTipoDevolucao;
	}

	public void setListaTipoDevolucao(List<TipoDevolucao> listaTipoDevolucao) {
		this.listaTipoDevolucao = listaTipoDevolucao;
	}

	public TipoDevolucao getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(TipoDevolucao tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public Devolucao getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(Devolucao devolucao) {
		this.devolucao = devolucao;
	}

	public DetalhePortabilidadeDevolucaoBO getDetalhePortabilidadeDevolucaoBO() {
		return detalhePortabilidadeDevolucaoBO;
	}

	public void setDetalhePortabilidadeDevolucaoBO(DetalhePortabilidadeDevolucaoBO detalhePortabilidadeDevolucaoBO) {
		this.detalhePortabilidadeDevolucaoBO = detalhePortabilidadeDevolucaoBO;
	}

	public List<DetalhePortabilidadeDevolucao> getDetalhePortabilidadeDevolucaoList() {
		return detalhePortabilidadeDevolucaoList;
	}

	public void setDetalhePortabilidadeDevolucaoList(List<DetalhePortabilidadeDevolucao> detalhePortabilidadeDevolucaoList) {
		this.detalhePortabilidadeDevolucaoList = detalhePortabilidadeDevolucaoList;
	}

	public DetalhePortabilidadeDevolucao getDetalhePortabilidadeDevolucao() {
		return detalhePortabilidadeDevolucao;
	}

	public void setDetalhePortabilidadeDevolucao(DetalhePortabilidadeDevolucao detalhePortabilidadeDevolucao) {
		this.detalhePortabilidadeDevolucao = detalhePortabilidadeDevolucao;
	}

	public PessoaEntidadeBO getPessoaEntidadeBO() {
		return pessoaEntidadeBO;
	}

	public void setPessoaEntidadeBO(PessoaEntidadeBO pessoaEntidadeBO) {
		this.pessoaEntidadeBO = pessoaEntidadeBO;
	}

	public PessoaEntidade getPessoaEntidade() {
		return pessoaEntidade;
	}

	public void setPessoaEntidade(PessoaEntidade pessoaEntidade) {
		this.pessoaEntidade = pessoaEntidade;
	}

	public List<PessoaEntidade> getListarPessoaEntidade() {
		return listarPessoaEntidade;
	}

	public void setListarPessoaEntidade(List<PessoaEntidade> listarPessoaEntidade) {
		this.listarPessoaEntidade = listarPessoaEntidade;
	}

	public AtuacaoPessoaBO getAtuacaoPessoaBO() {
		return atuacaoPessoaBO;
	}

	public void setAtuacaoPessoaBO(AtuacaoPessoaBO atuacaoPessoaBO) {
		this.atuacaoPessoaBO = atuacaoPessoaBO;
	}

	public TipoPlanoDestinoPortabilidadeDevolucaoBO getTipoPlanoDestinoPortabilidadeDevolucaoBO() {
		return tipoPlanoDestinoPortabilidadeDevolucaoBO;
	}

	public void setTipoPlanoDestinoPortabilidadeDevolucaoBO(TipoPlanoDestinoPortabilidadeDevolucaoBO tipoPlanoDestinoPortabilidadeDevolucaoBO) {
		this.tipoPlanoDestinoPortabilidadeDevolucaoBO = tipoPlanoDestinoPortabilidadeDevolucaoBO;
	}

	public List<TipoPlanoDestinoPortabilidadeDevolucao> getListarTipoPlanoDestinoPortabilidadeDevolucao() {
		return listarTipoPlanoDestinoPortabilidadeDevolucao;
	}

	public void setListarTipoPlanoDestinoPortabilidadeDevolucao(List<TipoPlanoDestinoPortabilidadeDevolucao> listarTipoPlanoDestinoPortabilidadeDevolucao) {
		this.listarTipoPlanoDestinoPortabilidadeDevolucao = listarTipoPlanoDestinoPortabilidadeDevolucao;
	}

	public ParticipantePlanoBO getParticipantePlanoBO() {
		return participantePlanoBO;
	}

	public void setParticipantePlanoBO(ParticipantePlanoBO participantePlanoBO) {
		this.participantePlanoBO = participantePlanoBO;
	}

	public AtuacaoPessoa getAtuacaoPessoa() {
		return atuacaoPessoa;
	}

	public void setAtuacaoPessoa(AtuacaoPessoa atuacaoPessoa) {
		this.atuacaoPessoa = atuacaoPessoa;
	}

	public TipoDevolucaoBO getTipoDevolucaoBO() {
		return tipoDevolucaoBO;
	}

	public void setTipoDevolucaoBO(TipoDevolucaoBO tipoDevolucaoBO) {
		this.tipoDevolucaoBO = tipoDevolucaoBO;
	}

	public GrupoRecebimentoDevolucaoBO getGrupoRecebimentoDevolucaoBO() {
		return grupoRecebimentoDevolucaoBO;
	}

	public void setGrupoRecebimentoDevolucaoBO(GrupoRecebimentoDevolucaoBO grupoRecebimentoDevolucaoBO) {
		this.grupoRecebimentoDevolucaoBO = grupoRecebimentoDevolucaoBO;
	}

	public GrupoRecebimentoDevolucao getGrupoRecebimentoDevolucao() {
		return grupoRecebimentoDevolucao;
	}

	public void setGrupoRecebimentoDevolucao(GrupoRecebimentoDevolucao grupoRecebimentoDevolucao) {
		this.grupoRecebimentoDevolucao = grupoRecebimentoDevolucao;
	}

	public List<GrupoRecebimentoDevolucao> getListaGrupoRecebimentoDevolucao() {
		return listaGrupoRecebimentoDevolucao;
	}

	public void setListaGrupoRecebimentoDevolucao(List<GrupoRecebimentoDevolucao> listaGrupoRecebimentoDevolucao) {
		this.listaGrupoRecebimentoDevolucao = listaGrupoRecebimentoDevolucao;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public List<DocumentoDevolucaoVisaoItem> getListaDocumentoDevolucaoVisaoItem() {
		return listaDocumentoDevolucaoVisaoItem;
	}

	public void setListaDocumentoDevolucaoVisaoItem(List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem) {
		this.listaDocumentoDevolucaoVisaoItem = listaDocumentoDevolucaoVisaoItem;
	}

	public boolean isPossuiDocumentoAtuacaoPessoaPendente() {
		return possuiDocumentoAtuacaoPessoaPendente;
	}

	public void setPossuiDocumentoAtuacaoPessoaPendente(boolean possuiDocumentoAtuacaoPessoaPendente) {
		this.possuiDocumentoAtuacaoPessoaPendente = possuiDocumentoAtuacaoPessoaPendente;
	}

	public boolean isChamaPendenciasAberturaTela() {
		return chamaPendenciasAberturaTela;
	}

	public void setChamaPendenciasAberturaTela(boolean chamaPendenciasAberturaTela) {
		this.chamaPendenciasAberturaTela = chamaPendenciasAberturaTela;
	}

	public boolean isPossuiDocumentoAtuacaoPessoa() {
		return possuiDocumentoAtuacaoPessoa;
	}

	public void setPossuiDocumentoAtuacaoPessoa(boolean possuiDocumentoAtuacaoPessoa) {
		this.possuiDocumentoAtuacaoPessoa = possuiDocumentoAtuacaoPessoa;
	}

	public String getDescricaoPendencias() {
		return descricaoPendencias;
	}

	public void setDescricaoPendencias(String descricaoPendencias) {
		this.descricaoPendencias = descricaoPendencias;
	}

	public HistoricoSituacaoDevolucao getHistoricoSituacaoDevolucao() {
		return historicoSituacaoDevolucao;
	}

	public void setHistoricoSituacaoDevolucao(HistoricoSituacaoDevolucao historicoSituacaoDevolucao) {
		this.historicoSituacaoDevolucao = historicoSituacaoDevolucao;
	}

	public AnotacaoDevolucao getAnotacaoDevolucao() {
		if (this.anotacaoDevolucao == null) {
			this.anotacaoDevolucao = new AnotacaoDevolucao();
		}
		return anotacaoDevolucao;
	}

	public void setAnotacaoDevolucao(AnotacaoDevolucao anotacaoDevolucao) {
		this.anotacaoDevolucao = anotacaoDevolucao;
	}

	public AreaAtuacao getAreaAtuacaoPessoa() {
		return areaAtuacaoPessoa;
	}

	public void setAreaAtuacaoPessoa(AreaAtuacao areaAtuacaoPessoa) {
		this.areaAtuacaoPessoa = areaAtuacaoPessoa;
	}

	public List<AtuacaoPessoa> getListaAtuacoes() {
		return listaAtuacoes;
	}

	public void setListaAtuacoes(List<AtuacaoPessoa> listaAtuacoes) {
		this.listaAtuacoes = listaAtuacoes;
	}

	public List<AreaAtuacao> getListaAreaAtuacoes() {
		return listaAreaAtuacoes;
	}

	public void setListaAreaAtuacoes(List<AreaAtuacao> listaAreaAtuacoes) {
		this.listaAreaAtuacoes = listaAreaAtuacoes;
	}

	public String getCodigoAreaAtuacao() {
		return codigoAreaAtuacao;
	}

	public void setCodigoAreaAtuacao(String codigoAreaAtuacao) {
		this.codigoAreaAtuacao = codigoAreaAtuacao;
	}

	public List<PlanoGuardaChuva> getListaPlanos() {
		return listaPlanos;
	}

	public void setListaPlanos(List<PlanoGuardaChuva> listaPlanos) {
		this.listaPlanos = listaPlanos;
	}

	public boolean isBbprevidencia() {
		return bbprevidencia;
	}

	public void setBbprevidencia(boolean bbprevidencia) {
		this.bbprevidencia = bbprevidencia;
	}

	public boolean isPortabilidadeInterna() {
		return portabilidadeInterna;
	}

	public void setPortabilidadeInterna(boolean portabilidadeInterna) {
		this.portabilidadeInterna = portabilidadeInterna;
	}
	
}
