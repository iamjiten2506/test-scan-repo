package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.List;

import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.LoteProcessamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MensagemLoteProcessamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.LoteProcessamentoDevolucao;
import br.com.bbprevidencia.devolucao.dto.MensagemLoteProcessamentoDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;

/**
 * Classe de comunicação entre a interface de usuário e a classe de negócio.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   26/01/2017
 *
 * Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("folhaIntegracaoVerificacaoVisao")
public class FolhaIntegracaoVerificacaoVisao {

	private static final Logger log = Logger.getLogger(FolhaIntegracaoVerificacaoVisao.class);

	private static String FW_FOLHA_INTEGRACAO_VERIFICACAO = "/paginas/folhaIntegracaoVerificacao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private LoteProcessamentoDevolucaoBO loteProcessamentoDevolucaoBO;

	@Autowired
	private MensagemLoteProcessamentoDevolucaoBO mensagemLoteProcessamentoDevolucaoBO;

	private List<CronogramaDevolucao> listaCronogramaDevolucao;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private CronogramaDevolucao cronogramaDevolucao;

	private LoteProcessamentoDevolucao loteProcessamentoDevolucao;

	private List<LoteProcessamentoDevolucao> listaLoteProcessamentoDevolucao;

	private List<MensagemLoteProcessamentoDevolucao> listaMensagemLoteProcessamentoDevolucao;

	private boolean mostrarDataTable;

	/**
	 * Método encarredado por iniciar a página
	 *  
	 * @author  BBPF0333 - Daniel Martins
	 * @since   27/01/2017
	 * @return {@link String}
	 */
	public String iniciarTela() {
		Boolean temMensagem;

		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("folhaIntegracaoVerificacao");
		} else {
			this.possuiAcessoTotal = false;
		}

		this.setMostrarDataTable(false);

		//Fazer cargas de listas de Combo.
		List<CronogramaDevolucao> listaCronogramaDevolucaoBase = new ArrayList<CronogramaDevolucao>();
		List<CronogramaDevolucao> listaCronogramaDevolucaoFinal = new ArrayList<CronogramaDevolucao>();

		listaCronogramaDevolucaoBase = cronogramaDevolucaoBO.listarTodosCronogramaDevolucao();

		for (CronogramaDevolucao cronogramaDevolucaoFor : listaCronogramaDevolucaoBase) {

			temMensagem = false;

			List<LoteProcessamentoDevolucao> listaBase = new ArrayList<LoteProcessamentoDevolucao>();

			listaBase = this.loteProcessamentoDevolucaoBO.listarLoteProcessamentoDevolucaoTipoIntegracaoPorCronogramaDevolucao(cronogramaDevolucaoFor);

			for (LoteProcessamentoDevolucao loteProcessamentoDevolucao : listaBase) {

				if (mensagemLoteProcessamentoDevolucaoBO.existeMensagemLoteProcessamentoDevolucaoPorLote(loteProcessamentoDevolucao)) {
					temMensagem = true;
				}
			}

			if (temMensagem == true) {
				listaCronogramaDevolucaoFinal.add(cronogramaDevolucaoFor);
			}
		}

		this.listaCronogramaDevolucao = listaCronogramaDevolucaoFinal;

		return FW_FOLHA_INTEGRACAO_VERIFICACAO;
	}

	//Métodos de funcionamento da página
	/**
	 * Método limpa seleção da tela
	 * 
	 * @author  BBPF0333 - Daniel Martins
	 * @since   27/01/2017
	 */
	public void limpaSelecao() {
		this.setCronogramaDevolucao(null);
		this.setLoteProcessamentoDevolucao(null);
		this.setMostrarDataTable(false);
		this.setListaMensagemLoteProcessamentoDevolucao(null);
	}

	public String listarLoteProcessamentoDevolucao(AjaxBehaviorEvent event) {

		this.setMostrarDataTable(false);
		this.setListaMensagemLoteProcessamentoDevolucao(null);

		if (this.getCronogramaDevolucao() == null) {
			this.setListaLoteProcessamentoDevolucao(new ArrayList<LoteProcessamentoDevolucao>());
		} else {
			try {

				List<LoteProcessamentoDevolucao> listaBase = new ArrayList<LoteProcessamentoDevolucao>();
				List<LoteProcessamentoDevolucao> listaFinal = new ArrayList<LoteProcessamentoDevolucao>();

				listaBase = this.loteProcessamentoDevolucaoBO.listarLoteProcessamentoDevolucaoTipoIntegracaoPorCronogramaDevolucao(this.cronogramaDevolucao);

				for (LoteProcessamentoDevolucao loteProcessamentoDevolucao : listaBase) {
					if (mensagemLoteProcessamentoDevolucaoBO.existeMensagemLoteProcessamentoDevolucaoPorLote(loteProcessamentoDevolucao)) {
						listaFinal.add(loteProcessamentoDevolucao);
					}
				}

				this.listaLoteProcessamentoDevolucao = listaFinal;

			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}

		return FW_FOLHA_INTEGRACAO_VERIFICACAO;
	}

	public String listarMensagemLoteProcessamentoDevolucao(AjaxBehaviorEvent event) {

		this.setMostrarDataTable(false);
		this.setListaMensagemLoteProcessamentoDevolucao(null);

		if (this.getLoteProcessamentoDevolucao() == null) {
			this.setListaMensagemLoteProcessamentoDevolucao(new ArrayList<MensagemLoteProcessamentoDevolucao>());
		} else {
			try {
				this.listaMensagemLoteProcessamentoDevolucao = new ArrayList<MensagemLoteProcessamentoDevolucao>(this.mensagemLoteProcessamentoDevolucaoBO
						.listarMensagemLoteProcessamentoDevolucaoPorFiltros(this.loteProcessamentoDevolucao, null, null, null, null, null));

				if (UtilJava.isColecaoVazia(this.listaMensagemLoteProcessamentoDevolucao)) {
					this.setMostrarDataTable(false);
				} else {
					this.setMostrarDataTable(true);
				}

			} catch (Exception ex) {
				log.error(ex);
				throw new PrevidenciaException("Não foi possível realizar a operação", ex);
			}
		}

		return FW_FOLHA_INTEGRACAO_VERIFICACAO;
	}

	public static String getFW_FOLHA_INTEGRACAO_VERIFICACAO() {
		return FW_FOLHA_INTEGRACAO_VERIFICACAO;
	}

	public static void setFW_FOLHA_INTEGRACAO_VERIFICACAO(String fW_FOLHA_INTEGRACAO_VERIFICACAO) {
		FW_FOLHA_INTEGRACAO_VERIFICACAO = fW_FOLHA_INTEGRACAO_VERIFICACAO;
	}

	public CronogramaDevolucaoBO getCronogramaDevolucaoBO() {
		return cronogramaDevolucaoBO;
	}

	public void setCronogramaDevolucaoBO(CronogramaDevolucaoBO cronogramaDevolucaoBO) {
		this.cronogramaDevolucaoBO = cronogramaDevolucaoBO;
	}

	public List<CronogramaDevolucao> getListaCronogramaDevolucao() {
		return listaCronogramaDevolucao;
	}

	public void setListaCronogramaDevolucao(List<CronogramaDevolucao> listaCronogramaDevolucao) {
		this.listaCronogramaDevolucao = listaCronogramaDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public CronogramaDevolucao getCronogramaDevolucao() {
		return cronogramaDevolucao;
	}

	public void setCronogramaDevolucao(CronogramaDevolucao cronogramaDevolucao) {
		this.cronogramaDevolucao = cronogramaDevolucao;
	}

	public LoteProcessamentoDevolucaoBO getLoteProcessamentoDevolucaoBO() {
		return loteProcessamentoDevolucaoBO;
	}

	public void setLoteProcessamentoDevolucaoBO(LoteProcessamentoDevolucaoBO loteProcessamentoDevolucaoBO) {
		this.loteProcessamentoDevolucaoBO = loteProcessamentoDevolucaoBO;
	}

	public MensagemLoteProcessamentoDevolucaoBO getMensagemLoteProcessamentoDevolucaoBO() {
		return mensagemLoteProcessamentoDevolucaoBO;
	}

	public void setMensagemLoteProcessamentoDevolucaoBO(MensagemLoteProcessamentoDevolucaoBO mensagemLoteProcessamentoDevolucaoBO) {
		this.mensagemLoteProcessamentoDevolucaoBO = mensagemLoteProcessamentoDevolucaoBO;
	}

	public LoteProcessamentoDevolucao getLoteProcessamentoDevolucao() {
		return loteProcessamentoDevolucao;
	}

	public void setLoteProcessamentoDevolucao(LoteProcessamentoDevolucao loteProcessamentoDevolucao) {
		this.loteProcessamentoDevolucao = loteProcessamentoDevolucao;
	}

	public List<MensagemLoteProcessamentoDevolucao> getListaMensagemLoteProcessamentoDevolucao() {
		return listaMensagemLoteProcessamentoDevolucao;
	}

	public void setListaMensagemLoteProcessamentoDevolucao(List<MensagemLoteProcessamentoDevolucao> listaMensagemLoteProcessamentoDevolucao) {
		this.listaMensagemLoteProcessamentoDevolucao = listaMensagemLoteProcessamentoDevolucao;
	}

	public List<LoteProcessamentoDevolucao> getListaLoteProcessamentoDevolucao() {
		return listaLoteProcessamentoDevolucao;
	}

	public void setListaLoteProcessamentoDevolucao(List<LoteProcessamentoDevolucao> listaLoteProcessamentoDevolucao) {
		this.listaLoteProcessamentoDevolucao = listaLoteProcessamentoDevolucao;
	}

	public boolean isMostrarDataTable() {
		return mostrarDataTable;
	}

	public void setMostrarDataTable(boolean mostrarDataTable) {
		this.mostrarDataTable = mostrarDataTable;
	}

}
