package br.com.bbprevidencia.devolucao.dto;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

@Entity
public class RelatorioPortabilidadeFinalizadoDTO implements BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "NUM_SEQ_DEV")
	private Long codigo;

	@Column(name = "NOM_PARTIC")
	private String nomeParticipante;

	@Column(name = "NUM_CPF")
	private BigDecimal numeroCpf;

	@Column(name = "NUM_COMPL_CPF")
	private BigDecimal numeroComplementoCpf;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INSCR")
	private Date dataInscricao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_PGT")
	private Date dataPagamento;

	@Column(name = "RESERVA_PARTICIPANTE")
	private Double reservaParticipante;

	@Column(name = "RESERVA_PATROCINADORA")
	private Double reservaPatrocinadora;

	@Column(name = "VAL_IND_AJU")
	private Double valorCota;

	@Transient
	private String cpf;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public BigDecimal getNumeroCpf() {
		return numeroCpf;
	}

	public void setNumeroCpf(BigDecimal numeroCpf) {
		this.numeroCpf = numeroCpf;
	}

	public BigDecimal getNumeroComplementoCpf() {
		return numeroComplementoCpf;
	}

	public void setNumeroComplementoCpf(BigDecimal numeroComplementoCpf) {
		this.numeroComplementoCpf = numeroComplementoCpf;
	}

	public Date getDataInscricao() {
		return dataInscricao;
	}

	public void setDataInscricao(Date dataInscricao) {
		this.dataInscricao = dataInscricao;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Double getReservaParticipante() {
		return reservaParticipante;
	}

	public void setReservaParticipante(Double reservaParticipante) {
		this.reservaParticipante = reservaParticipante;
	}

	public Double getReservaPatrocinadora() {
		return reservaPatrocinadora;
	}

	public void setReservaPatrocinadora(Double reservaPatrocinadora) {
		this.reservaPatrocinadora = reservaPatrocinadora;
	}

	public String getCpf() {
		if (getNumeroComplementoCpf() != null && getNumeroCpf() != null) {
			this.cpf = "";

			this.cpf = UtilJava.formataCPF(String.format("%09d", this.getNumeroCpf().longValue()) + String.format("%02d", this.getNumeroComplementoCpf().longValue()));
		}

		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Double getValorCota() {
		return valorCota;
	}

	public void setValorCota(Double valorCota) {
		this.valorCota = valorCota;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RelatorioPortabilidadeFinalizadoDTO other = (RelatorioPortabilidadeFinalizadoDTO) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}
