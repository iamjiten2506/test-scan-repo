package br.com.bbprevidencia.devolucao.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegraElegibilidadeDevolucaoDTO {

	private Long mesesIdade;

	private Long mesesIdadeFundador;

	private Long mesesEmpresa;

	private Long mesesEmpresaFundador;

	private Long mesesPlano;

	private Long mesesPlanoFundador;

	private Long quantidadeContribuicao;

	private Long quantidadeContribuicaoFundador;

}
