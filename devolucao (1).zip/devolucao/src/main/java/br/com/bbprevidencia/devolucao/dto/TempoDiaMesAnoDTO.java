package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.Period;

public class TempoDiaMesAnoDTO {

	private int tempoAnos;

	private int tempoMeses;

	private int tempoDias;

	public TempoDiaMesAnoDTO() {
		super();
	}

	public TempoDiaMesAnoDTO(int anos, int meses, int dias) {
		this.tempoAnos = anos;
		this.tempoMeses = meses;
		this.tempoDias = dias;
	}

	public static TempoDiaMesAnoDTO calcularTempos(Date dataInicio, Date dataFim) {
		TempoDiaMesAnoDTO tempoRetorno = new TempoDiaMesAnoDTO();

		try {
			DateTime dt1 = new DateTime(dataInicio);
			DateTime dt2 = new DateTime(dataFim);
			Period periodo = new Period(dt1, dt2);

			tempoRetorno.setTempoAnos(periodo.getYears());
			tempoRetorno.setTempoMeses(periodo.getMonths());
			tempoRetorno.setTempoDias(periodo.getDays());

			return tempoRetorno;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempoRetorno;
	}

	public int getTempoAnos() {
		return tempoAnos;
	}

	public void setTempoAnos(int tempoAnos) {
		this.tempoAnos = tempoAnos;
	}

	public int getTempoMeses() {
		return tempoMeses;
	}

	public void setTempoMeses(int tempoMeses) {
		this.tempoMeses = tempoMeses;
	}

	public int getTempoDias() {
		return tempoDias;
	}

	public void setTempoDias(int tempoDias) {
		this.tempoDias = tempoDias;
	}

}
