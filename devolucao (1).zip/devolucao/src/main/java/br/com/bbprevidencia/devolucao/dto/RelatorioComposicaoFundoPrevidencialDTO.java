package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode
@ToString
@Entity
public class RelatorioComposicaoFundoPrevidencialDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CODIGO")
	private Long codigo;

	@Column(name = "MATRICULA")
	private String matricula;

	@Column(name = "PLANO")
	private String nomePlano;

	@Column(name = "PARTE_PLANO")
	private String nomePartePlano;

	@Column(name = "DATA")
	@Temporal(TemporalType.DATE)
	private Date dataMovimento;

	@Column(name = "VALOR")
	private Double valorIntegrado;
}
