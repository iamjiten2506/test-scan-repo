package br.com.bbprevidencia.devolucao.dto;

import br.com.bbprevidencia.folha.dto.CaracteristicaDirf;
import br.com.bbprevidencia.utils.UtilJava;

public class RelatorioAnaliticoIRDTO {

	private String patrocinadora;

	private String matriculaParticipante;

	private String nomeParticipante;

	private String cpfParticipante;

	private Double valorIrrf;

	private String indicadorRetencao;

	private String tipoRetencao;

	private String dataRetencao;

	private Long codigoPlano;

	private String codigoCaracteristicaDIRF;

	private String codigoRetencao;

	private String modalidePlano;

	private String codigoNaturezaRendimento;

	public String getMatriculaParticipante() {
		return matriculaParticipante;
	}

	public void setMatriculaParticipante(String matriculaParticipante) {
		this.matriculaParticipante = matriculaParticipante;
	}

	public String getNomeParticipante() {
		return nomeParticipante;
	}

	public void setNomeParticipante(String nomeParticipante) {
		this.nomeParticipante = nomeParticipante;
	}

	public String getCpfParticipante() {
		return cpfParticipante;
	}

	public void setCpfParticipante(String cpfParticipante) {
		this.cpfParticipante = cpfParticipante;
	}

	public Double getValorIrrf() {
		return valorIrrf;
	}

	public void setValorIrrf(Double valorIrrf) {
		this.valorIrrf = valorIrrf;
	}

	public String getTipoRetencao() {
		return tipoRetencao;
	}

	public void setTipoRetencao(String tipoRetencao) {
		this.tipoRetencao = tipoRetencao;
	}

	public String getDataRetencao() {
		return dataRetencao;
	}

	public void setDataRetencao(String dataRetencao) {
		this.dataRetencao = dataRetencao;
	}

	public String getPatrocinadora() {
		return patrocinadora;
	}

	public void setPatrocinadora(String patrocinadora) {
		this.patrocinadora = patrocinadora;
	}

	public String getIndicadorRetencao() {
		return indicadorRetencao;
	}

	public void setIndicadorRetencao(String indicadorRetencao) {
		this.indicadorRetencao = indicadorRetencao;
	}

	public Long getCodigoPlano() {
		return codigoPlano;
	}

	public void setCodigoPlano(Long codigoPlano) {
		this.codigoPlano = codigoPlano;
	}

	public String getCodigoRetencao() {
		return codigoRetencao;
	}

	public void setCodigoRetencao(String codigoRetencao) {
		this.codigoRetencao = codigoRetencao;
	}

	public String getModalidePlano() {
		return modalidePlano;
	}

	public void setModalidePlano(String modalidePlano) {
		this.modalidePlano = modalidePlano;
	}

	public String getCodigoCaracteristicaDIRF() {
		return codigoCaracteristicaDIRF;
	}

	public void setCodigoCaracteristicaDIRF(String codigoCaracteristicaDIRF) {
		this.codigoCaracteristicaDIRF = codigoCaracteristicaDIRF;
	}

	public String getCodigoNaturezaRendimento() {
		return codigoNaturezaRendimento;
	}

	public void setCodigoNaturezaRendimento(String codigoNaturezaRendimento) {
		this.codigoNaturezaRendimento = codigoNaturezaRendimento;
	}

	public void preencheTipoRetencao(CaracteristicaDirf caracteristicaDirf) {

		String codigoRetencaoBD = caracteristicaDirf.getTipoRetencaoDIRFBD() == null ? "" : caracteristicaDirf.getTipoRetencaoDIRFBD().getCodigoRetencaoDirf();
		String descricaoRetencaoBD = caracteristicaDirf.getTipoRetencaoDIRFBD() == null ? "" : caracteristicaDirf.getTipoRetencaoDIRFBD().getNomeTipoRetencao();

		String codigoRetencaoProgressivo = caracteristicaDirf.getTipoRetencaoDirfPro() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfPro().getCodigoRetencaoDirf();
		String descricaoRetencaoProgressivo = caracteristicaDirf.getTipoRetencaoDirfPro() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfPro().getNomeTipoRetencao();

		String codigoRetencaoRegressivo = caracteristicaDirf.getTipoRetencaoDirfReg() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfReg().getCodigoRetencaoDirf();
		String descricaoRetencaoRegressivo = caracteristicaDirf.getTipoRetencaoDirfReg() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfReg().getNomeTipoRetencao();

		String codigoRetencaoExterior = caracteristicaDirf.getTipoRetencaoDirfExt() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfExt().getCodigoRetencaoDirf();
		String descricaoRetencaoExterior = caracteristicaDirf.getTipoRetencaoDirfExt() == null ? "" : caracteristicaDirf.getTipoRetencaoDirfExt().getNomeTipoRetencao();

		if (this.modalidePlano.equals("BD")) {
			this.codigoRetencao = codigoRetencaoBD;
			this.tipoRetencao = descricaoRetencaoBD;
			return;
		}

		if (this.indicadorRetencao.equals("P")) {
			this.codigoRetencao = codigoRetencaoProgressivo;
			this.tipoRetencao = descricaoRetencaoProgressivo;
			return;
		}

		if (this.indicadorRetencao.equals("R")) {
			this.codigoRetencao = codigoRetencaoRegressivo;
			this.tipoRetencao = descricaoRetencaoRegressivo;
			return;
		}

		if (this.indicadorRetencao.equals("E")) {
			this.codigoRetencao = codigoRetencaoExterior;
			this.tipoRetencao = descricaoRetencaoExterior;
			return;
		}

	}

	public void preencheNaturezaRendimento(CaracteristicaDirf caracteristicaDirf) {

		String codigoNaturezaRendimentoBD = "";
		String codigoNaturezaRendimentoProgressivo = "";
		String codigoNaturezaRendimentoRegressivo = "";
		String codigoNaturezaRendimentoExterior = "";

		if (caracteristicaDirf.getTipoRetencaoDIRFBD() != null && caracteristicaDirf.getTipoRetencaoDIRFBD().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoBD = caracteristicaDirf.getTipoRetencaoDIRFBD().getNaturezaRendimento().getCodigoReceita();
		}

		if (caracteristicaDirf.getTipoRetencaoDirfPro() != null && caracteristicaDirf.getTipoRetencaoDirfPro().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoProgressivo = caracteristicaDirf.getTipoRetencaoDirfPro().getNaturezaRendimento().getCodigoReceita();
		}

		if (caracteristicaDirf.getTipoRetencaoDirfReg() != null && caracteristicaDirf.getTipoRetencaoDirfReg().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoRegressivo = caracteristicaDirf.getTipoRetencaoDirfReg().getNaturezaRendimento().getCodigoReceita();
		}

		if (caracteristicaDirf.getTipoRetencaoDirfExt() != null && caracteristicaDirf.getTipoRetencaoDirfExt().getNaturezaRendimento() != null) {
			codigoNaturezaRendimentoExterior = caracteristicaDirf.getTipoRetencaoDirfExt().getNaturezaRendimento().getCodigoReceita();
		}

		if (this.modalidePlano.equals("BD")) {
			this.codigoNaturezaRendimento = codigoNaturezaRendimentoBD;
			return;
		}

		if (this.indicadorRetencao.equals("P")) {
			this.codigoNaturezaRendimento = codigoNaturezaRendimentoProgressivo;
			return;
		}

		if (this.indicadorRetencao.equals("R")) {
			this.codigoNaturezaRendimento = codigoNaturezaRendimentoRegressivo;
			return;
		}

		if (this.indicadorRetencao.equals("E")) {
			this.codigoNaturezaRendimento = codigoNaturezaRendimentoExterior;
			return;
		}

	}

}
