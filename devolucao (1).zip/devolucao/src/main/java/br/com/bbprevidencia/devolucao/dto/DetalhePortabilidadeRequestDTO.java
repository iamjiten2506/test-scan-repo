package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetalhePortabilidadeRequestDTO {

	private Long tipoPlanoDestinoPortabilidade;

	private String nomePlanoDestino;

	private String codigoParticipanteEntidadeDestino;

	private String codigoPlanoEntidadeDestino;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dataAdesaoPlanoDestino;

	private String indicadorOpcaoImpostoRendaDestino;

	private String codigoAprovPlanoOrigemOrgaoRegulador;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dataAprovPlanoOrigemOrgaoRegulador;

	private Long codigoPessoaEntidadeDestino;
}
