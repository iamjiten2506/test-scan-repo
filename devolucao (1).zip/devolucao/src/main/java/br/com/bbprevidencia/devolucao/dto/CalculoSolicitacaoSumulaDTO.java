package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class CalculoSolicitacaoSumulaDTO {

	private Date dataDeposito;

	private Double valorIndiceFator;

	private Double valorFichaParticipante;

	private Double valorFichaPatrocinadora;

	private Double valorIndiceParticipante;

	private Double valorIndicePatrocinadora;

	private Double valorCotaParticipante;

	private Double valorCotaPatrocinadora;
}
