package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;

public class ElegibilidadeDevolucaoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private boolean elegivel;
	private Long tempoIdadeFaltante;
	private Long tempoEmpresaFaltante;
	private Long tempoPlanoFaltante;
	private Long qtdContribuicaoFaltante;
	private Long tempoFaltante;
	private String descricao;
	private boolean naoDesligadoDevolucaoExigeDesligamento;
	private boolean motivoDesligamentoNuloOuDiferenteExigido;
	private RegraElegibilidadeDevolucao regraElegibilidadeDevolucao;

	public boolean isElegivel() {
		return elegivel;
	}

	public void setElegivel(boolean elegivel) {
		this.elegivel = elegivel;
	}

	public Long getTempoIdadeFaltante() {
		return tempoIdadeFaltante;
	}

	public void setTempoIdadeFaltante(Long tempoIdadeFaltante) {
		this.tempoIdadeFaltante = tempoIdadeFaltante;
	}

	public Long getTempoEmpresaFaltante() {
		return tempoEmpresaFaltante;
	}

	public void setTempoEmpresaFaltante(Long tempoEmpresaFaltante) {
		this.tempoEmpresaFaltante = tempoEmpresaFaltante;
	}

	public Long getTempoPlanoFaltante() {
		return tempoPlanoFaltante;
	}

	public void setTempoPlanoFaltante(Long tempoPlanoFaltante) {
		this.tempoPlanoFaltante = tempoPlanoFaltante;
	}

	public Long getQtdContribuicaoFaltante() {
		return qtdContribuicaoFaltante;
	}

	public void setQtdContribuicaoFaltante(Long qtdContribuicaoFaltante) {
		this.qtdContribuicaoFaltante = qtdContribuicaoFaltante;
	}

	public boolean isNaoDesligadoDevolucaoExigeDesligamento() {
		return naoDesligadoDevolucaoExigeDesligamento;
	}

	public void setNaoDesligadoDevolucaoExigeDesligamento(boolean naoDesligadoDevolucaoExigeDesligamento) {
		this.naoDesligadoDevolucaoExigeDesligamento = naoDesligadoDevolucaoExigeDesligamento;
	}

	public Long getTempoFaltante() {
		return tempoFaltante;
	}

	public void setTempoFaltante(Long tempoFaltante) {
		this.tempoFaltante = tempoFaltante;
	}

	public RegraElegibilidadeDevolucao getRegraElegibilidadeDevolucao() {
		return regraElegibilidadeDevolucao;
	}

	public void setRegraElegibilidadeDevolucao(RegraElegibilidadeDevolucao regraElegibilidadeDevolucao) {
		this.regraElegibilidadeDevolucao = regraElegibilidadeDevolucao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public boolean isMotivoDesligamentoNuloOuDiferenteExigido() {
		return motivoDesligamentoNuloOuDiferenteExigido;
	}

	public void setMotivoDesligamentoNuloOuDiferenteExigido(boolean motivoDesligamentoNuloOuDiferenteExigido) {
		this.motivoDesligamentoNuloOuDiferenteExigido = motivoDesligamentoNuloOuDiferenteExigido;
	}

}
