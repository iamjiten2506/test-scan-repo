package br.com.bbprevidencia.devolucao.dto;

import java.util.Date;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;

public class DevolucaoIntegracaoDTO {

	private String codigoPt;
	private String codigoPn;
	private String codigoTDev;
	private String dataReq;
	private String indTDev;
	private String simulacao;
	private String qtdParcela;
	private String dataCota;
	private String indFormaPagRem;
	private String codigoUsuario;
	private Double percentualResgate;

	private Date dataCotaD;

	public Double getPercentualResgate() {
		return percentualResgate;
	}

	public void setPercentualResgate(Double percentualResgate) {
		this.percentualResgate = percentualResgate;
	}

	public String getCodigoPt() {
		return codigoPt;
	}

	public void setCodigoPt(String codigoPt) {
		this.codigoPt = codigoPt;
	}

	public String getCodigoPn() {
		return codigoPn;
	}

	public void setCodigoPn(String codigoPn) {
		this.codigoPn = codigoPn;
	}

	public String getCodigoTDev() {
		return codigoTDev;
	}

	public void setCodigoTDev(String codigoTDev) {
		this.codigoTDev = codigoTDev;
	}

	public String getDataReq() {
		return dataReq;
	}

	public void setDataReq(String dataReq) {
		this.dataReq = dataReq;
	}

	public String getIndTDev() {
		return indTDev;
	}

	public void setIndTDev(String indTDev) {
		this.indTDev = indTDev;
	}

	public String getSimulacao() {
		return simulacao;
	}

	public void setSimulacao(String simulacao) {
		this.simulacao = simulacao;
	}

	public String getQtdParcela() {
		return qtdParcela;
	}

	public void setQtdParcela(String qtdParcela) {
		this.qtdParcela = qtdParcela;
	}

	public String getDataCota() {
		if (this.dataCota == null && this.dataCotaD != null) {
			return UtilJava.formataDataPorPadrao(this.dataCotaD, "dd/MM/yyyy");
		}
		return dataCota;
	}

	public void setDataCota(String dataCota) {
		this.dataCota = dataCota;
	}

	public String getIndFormaPagRem() {
		return indFormaPagRem;
	}

	public void setIndFormaPagRem(String indFormaPagRem) {
		this.indFormaPagRem = indFormaPagRem;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public boolean isResgate() {
		return this.indTDev.equals("R");
	}

	public boolean isPortabilidade() {
		return this.indTDev.equals("P");
	}

	public boolean isPesquisaCalculoPadrao() {
		return this.codigoTDev == null;
	}

	public Date getDataCotaD() {
		return dataCotaD;
	}

	public void setDataCotaD(Date dataCotaD) {
		this.dataCotaD = dataCotaD;
	}

}
