package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;

/**
 * Classe de persistência para tabela PAR_INT_FIN_DEV.
 * 
 * @author  BBPF0333 - Daniel Martins
 * @since   24/01/2017
 * 
 */
@Entity
@Table(name = "PAR_INT_FIN_DEV", schema = "OWN_DCR")
@NamedQuery(name = "ParametroIntegracaoFinanceiraDevolucao.findAll", query = "SELECT q FROM ParametroIntegracaoFinanceiraDevolucao q")
public class ParametroIntegracaoFinanceiraDevolucao implements Serializable, BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PAR_INT_FIN_DEV_GER", sequenceName = "S_PIFD_01", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PAR_INT_FIN_DEV_GER")
	@Column(name = "NUM_SEQ_PAR_INT_FIN_DEV")
	private Long codigo;

	//@NotNull(message = "Plano Previdência: Favor selecionar um Plano.")
	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_PLANO")
	private PlanoPrevidencia planoPrevidencia;

	//@NotNull(message = "Operação Interna: Favor selecionar uma Operação Interna Resgate.")
	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPE_INT_RES")
	private OperacaoInterna operacaoInternaResgate;

	//@NotNull(message = "Operação Interna: Favor selecionar uma Operação Interna Portabilidade Entidade Aberta.")
	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPE_INT_POR_ENT_ABE")
	private OperacaoInterna operacaoInternaPortabilidadeEntidadeAberta;

	//@NotNull(message = "Operação Interna: Favor selecionar uma Operação Interna Portabilidade Entidade Fechada.")
	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPE_INT_POR_ENT_FEC")
	private OperacaoInterna operacaoInternaPortabilidadeEntidadeFechada;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	@ManyToOne
	@JoinColumn(name = "COD_SEQ_OPE_INT_POR_INT")
	private OperacaoInterna operacaoInternaPortabilidadeInterna;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public OperacaoInterna getOperacaoInternaPortabilidadeEntidadeAberta() {
		return operacaoInternaPortabilidadeEntidadeAberta;
	}

	public void setOperacaoInternaPortabilidadeEntidadeAberta(OperacaoInterna operacaoInternaPortabilidadeEntidadeAberta) {
		this.operacaoInternaPortabilidadeEntidadeAberta = operacaoInternaPortabilidadeEntidadeAberta;
	}

	public OperacaoInterna getOperacaoInternaPortabilidadeEntidadeFechada() {
		return operacaoInternaPortabilidadeEntidadeFechada;
	}

	public void setOperacaoInternaPortabilidadeEntidadeFechada(OperacaoInterna operacaoInternaPortabilidadeEntidadeFechada) {
		this.operacaoInternaPortabilidadeEntidadeFechada = operacaoInternaPortabilidadeEntidadeFechada;
	}

	public OperacaoInterna getOperacaoInternaResgate() {
		return operacaoInternaResgate;
	}

	public void setOperacaoInternaResgate(OperacaoInterna operacaoInternaResgate) {
		this.operacaoInternaResgate = operacaoInternaResgate;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	public OperacaoInterna getOperacaoInternaPortabilidadeInterna() {
		return operacaoInternaPortabilidadeInterna;
	}

	public void setOperacaoInternaPortabilidadeInterna(OperacaoInterna operacaoInternaPortabilidadeInterna) {
		this.operacaoInternaPortabilidadeInterna = operacaoInternaPortabilidadeInterna;
	}

}
