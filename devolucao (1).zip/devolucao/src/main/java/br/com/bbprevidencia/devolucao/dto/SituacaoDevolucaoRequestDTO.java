package br.com.bbprevidencia.devolucao.dto;

public class SituacaoDevolucaoRequestDTO {
	private Long codigoDevolucao;
	private Long situacaoDevolucao;
	private String usuarioAlteracao;

	public Long getCodigoDevolucao() {
		return codigoDevolucao;
	}

	public void setCodigoDevolucao(Long codigoDevolucao) {
		this.codigoDevolucao = codigoDevolucao;
	}

	public Long getSituacaoDevolucao() {
		return situacaoDevolucao;
	}

	public void setSituacaoDevolucao(Long situacaoDevolucao) {
		this.situacaoDevolucao = situacaoDevolucao;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}
}