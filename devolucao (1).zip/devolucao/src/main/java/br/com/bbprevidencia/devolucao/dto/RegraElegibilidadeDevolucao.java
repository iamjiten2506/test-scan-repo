package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.bbprevidencia.cadastroweb.dto.BaseEntity;

/**
 * @author  BBPF0333 - Daniel Martins
 * @since   09/03/2017
 * 
 * Classe de persistência para tabela REG_ELE_DEV.
 */
@Entity
@Table(name = "REG_ELE_DEV", schema = "OWN_DCR")
@NamedQuery(name = "RegraElegibilidadeDevolucao.findAll", query = "SELECT q FROM RegraElegibilidadeDevolucao q")
public class RegraElegibilidadeDevolucao implements Serializable, BaseEntity, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "REG_ELE_DEV_GER", sequenceName = "S_RED_01", schema = "OWN_DCR", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REG_ELE_DEV_GER")
	@Column(name = "NUM_SEQ_REG_ELE_DEV")
	private Long codigo;

	@ManyToOne
	@JoinColumn(name = "NUM_SEQ_REG_CAL_DEV")
	private RegraCalculoDevolucao regraCalculoDevolucao;

	@Column(name = "NUM_MES_IDA")
	private Long mesesIdade;

	@Column(name = "NUM_MES_IDA_FUN")
	private Long mesesIdadeFundador;

	@Column(name = "NUM_MES_EMP")
	private Long mesesEmpresa;

	@Column(name = "NUM_MES_EMP_FUN")
	private Long mesesEmpresaFundador;

	@Column(name = "NUM_MES_PLA")
	private Long mesesPlano;

	@Column(name = "NUM_MES_PLA_FUN")
	private Long mesesPlanoFundador;

	@Column(name = "NUM_QTD_CON")
	private Long quantidadeContribuicao;

	@Column(name = "NUM_QTD_CON_FUN")
	private Long quantidadeContribuicaoFundador;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALT_REG")
	private Date dataAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INC_REG")
	private Date dataInclusao;

	@Column(name = "COD_USU_ALT_REG")
	private String nomeUsuarioAlteracao;

	@Column(name = "COD_USU_INC_REG")
	private String nomeUsuarioInclusao;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public RegraCalculoDevolucao getRegraCalculoDevolucao() {
		return regraCalculoDevolucao;
	}

	public void setRegraCalculoDevolucao(RegraCalculoDevolucao regraCalculoDevolucao) {
		this.regraCalculoDevolucao = regraCalculoDevolucao;
	}

	public Long getMesesIdade() {
		return mesesIdade;
	}

	public void setMesesIdade(Long mesesIdade) {

		if (mesesIdade == null) {
			mesesIdade = 0L;
		}

		this.mesesIdade = mesesIdade;
	}

	public Long getMesesIdadeFundador() {
		return mesesIdadeFundador;
	}

	public void setMesesIdadeFundador(Long mesesIdadeFundador) {
		if (mesesIdadeFundador == null) {
			mesesIdadeFundador = 0L;
		}
		this.mesesIdadeFundador = mesesIdadeFundador;
	}

	public Long getMesesEmpresa() {
		return mesesEmpresa;
	}

	public void setMesesEmpresa(Long mesesEmpresa) {
		if (mesesEmpresa == null) {
			mesesEmpresa = 0L;
		}
		this.mesesEmpresa = mesesEmpresa;
	}

	public Long getMesesEmpresaFundador() {
		return mesesEmpresaFundador;
	}

	public void setMesesEmpresaFundador(Long mesesEmpresaFundador) {
		if (mesesEmpresaFundador == null) {
			mesesEmpresaFundador = 0L;
		}
		this.mesesEmpresaFundador = mesesEmpresaFundador;
	}

	public Long getMesesPlano() {
		return mesesPlano;
	}

	public void setMesesPlano(Long mesesPlano) {
		if (mesesPlano == null) {
			mesesPlano = 0L;
		}
		this.mesesPlano = mesesPlano;
	}

	public Long getMesesPlanoFundador() {
		return mesesPlanoFundador;
	}

	public void setMesesPlanoFundador(Long mesesPlanoFundador) {
		if (mesesPlanoFundador == null) {
			mesesPlanoFundador = 0L;
		}
		this.mesesPlanoFundador = mesesPlanoFundador;
	}

	public Long getQuantidadeContribuicao() {
		return quantidadeContribuicao;
	}

	public void setQuantidadeContribuicao(Long quantidadeContribuicao) {
		if (quantidadeContribuicao == null) {
			quantidadeContribuicao = 0L;
		}
		this.quantidadeContribuicao = quantidadeContribuicao;
	}

	public Long getQuantidadeContribuicaoFundador() {
		return quantidadeContribuicaoFundador;
	}

	public void setQuantidadeContribuicaoFundador(Long quantidadeContribuicaoFundador) {
		if (quantidadeContribuicaoFundador == null) {
			quantidadeContribuicaoFundador = 0L;
		}
		this.quantidadeContribuicaoFundador = quantidadeContribuicaoFundador;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	@Override
	public RegraElegibilidadeDevolucao clone() throws CloneNotSupportedException {
		RegraElegibilidadeDevolucao regraElegibilidadeDevolucao = (RegraElegibilidadeDevolucao) super.clone();
		regraElegibilidadeDevolucao.setCodigo(null);

		return regraElegibilidadeDevolucao;
	}

}