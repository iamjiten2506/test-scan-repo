package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.contabilidade.bo.OperacaoInternaBO;
import br.com.bbprevidencia.contabilidade.dto.OperacaoInterna;
import br.com.bbprevidencia.devolucao.bo.ParametroIntegracaoContabilFinanceiraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RubricaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.ParametroIntegracaoContabilFinanceiraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RubricaDevolucao;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;

/**
 * Classe controller que manipula as requisições do Parâmetro de Integração Contábil e Financeiro.
 * 
 * @author Magson Dias
 * @since 16/02/2017
 * 
 * Copyright notice (c) 2016 BBPrevidência S/A
 */

@Scope("session")
@Component("parametroIntegracaoContabilFinanceiraDevolucaoVisao")
public class ParametroIntegracaoContabilFinanceiraDevolucaoVisao {
	private static String FW_PARAMETRO_INTEGRACAO_CONTABIL_FINANCEIRA_DEV = "/paginas/parametroIntegracaoContabilFinanceiraDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;

	@Autowired
	private ParametroIntegracaoContabilFinanceiraDevolucaoBO parametroIntegracaoContabilFinanceiraDevolucaoBO;

	@Autowired
	private RubricaDevolucaoBO rubricaDevolucaoBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private OperacaoInternaBO operacaoInternaContabilBO;

	@Autowired
	private OperacaoInternaBO operacaoInternaTesourariaBO;

	private List<ParametroIntegracaoContabilFinanceiraDevolucao> listarParametroIntegracaoContabilFinanceiraDevolucao;

	private List<RubricaDevolucao> listaRubricaDevolucao;

	private List<PlanoPrevidencia> listaPlanoPrevidencia;

	private List<OperacaoInterna> listaOperacaoInternaContabil;

	private List<OperacaoInterna> listaOperacaoInternaTesouraria;

	private ParametroIntegracaoContabilFinanceiraDevolucao parametroIntegracaoContabilFinanceiraDevolucao;

	private boolean possuiAcessoTotal;

	private LoginBBPrevWebDTO loginTemporariaDTO;

	private boolean listarStatus;

	private RubricaDevolucao rubricaDevolucao;
	private PlanoPrevidencia planoPrevidencia;
	private OperacaoInterna operacaoInternaContabil;
	private OperacaoInterna operacaoInternaTesouraria;

	public String iniciarParametroIntegracaoContabilFinanceiraDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		//Valida Tipo de Acesso
		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("parametroIntegracaoContabilFinanceiraDevolucao");
		} else {
			this.possuiAcessoTotal = false;
		}
		this.listarStatus = true;
		this.limparTela();

		this.listaRubricaDevolucao = new ArrayList<RubricaDevolucao>(rubricaDevolucaoBO.listarRubricaDevolucao());
		this.listaPlanoPrevidencia = new ArrayList<PlanoPrevidencia>(planoPrevidenciaBO.listarPlanoPrevidencia());
		this.listaOperacaoInternaContabil = new ArrayList<OperacaoInterna>(operacaoInternaContabilBO.listarTodasOperacaoInterna());
		this.listaOperacaoInternaTesouraria = new ArrayList<OperacaoInterna>(operacaoInternaTesourariaBO.listarTodasOperacaoInterna());
		this.listarParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>(parametroIntegracaoContabilFinanceiraDevolucaoBO
				.listarParametroIntegracaoContabilFinanceiraDevolucao());
		return FW_PARAMETRO_INTEGRACAO_CONTABIL_FINANCEIRA_DEV;
	}

	/**
	 * Método encarregado de limpar a pesquisa e voltar o estado original da página
	 * 
	 * @author  BBPF0170 - Magson
	 * @since 	16/02/2017
	 * 
	 */
	public void limparTela() {
		this.rubricaDevolucao = null;
		this.planoPrevidencia = null;
		this.operacaoInternaContabil = null;
		this.operacaoInternaTesouraria = null;
		this.listarParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>(parametroIntegracaoContabilFinanceiraDevolucaoBO
				.listarParametroIntegracaoContabilFinanceiraDevolucao());
	}

	/**
	 * Método que controla o modo de visualização e edição/inserção da página
	 * 
	 * @author  BBPF0170 - Magson Dias
	 * @since 16/02/2017
	 */
	public void controlarEdicaoVisualizacao() {
		if (isListarStatus()) {
			rubricaDevolucao = new RubricaDevolucao();
			planoPrevidencia = new PlanoPrevidencia();
			operacaoInternaContabil = new OperacaoInterna();
			operacaoInternaTesouraria = new OperacaoInterna();
			this.listarParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>(parametroIntegracaoContabilFinanceiraDevolucaoBO
					.listarParametroIntegracaoContabilFinanceiraDevolucao());
		}
		listarStatus = listarStatus == true ? false : true;
	}

	/**
	 * Método que seleciona um Parâmetro de Integração Contábil e financeiro, e a colocar em modo de edição. 
	 * 
	 * @author  BBPF0170 - Magson Dias.
	 * @since 15/02/2017
	 * @param {@link ParametroIntegracaoContabilFinanceiraDevolucao}
	 */
	public void editarParamIntContabilFinanceira(ParametroIntegracaoContabilFinanceiraDevolucao parametroIntegracaoContabilFinanceiraDevolucao) {
		System.out.println(parametroIntegracaoContabilFinanceiraDevolucao.toString());
		parametroIntegracaoContabilFinanceiraDevolucao.setDataAlteracao(new Date());
		parametroIntegracaoContabilFinanceiraDevolucao.setNomeUsuarioAlteracao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
		setParametroIntegracaoContabilFinanceiraDevolucao(parametroIntegracaoContabilFinanceiraDevolucao);
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método que chama a tela para um novo cadastro de Parâmetro de integração Contábil e financeiro.
	 * @author BBPF0170	- MAGSON 
	 * @since 15/02/2017
	 */
	public void cadastrarNovaParametroIntegracaoContabilFinanceira() {
		parametroIntegracaoContabilFinanceiraDevolucao = new ParametroIntegracaoContabilFinanceiraDevolucao();
		controlarEdicaoVisualizacao();
	}

	/**
	 * Método para salvar ou atualizar um Parametro Integracao Contabil Financeira 
	 * 
	 * @author BBPF0170
	 * @since 15/02/2017
	 */
	public String salvarParametroIntegracaoContabilFinanceira() {
		try {
			if (parametroIntegracaoContabilFinanceiraDevolucao.getOperacaoInternaContabil() == null && parametroIntegracaoContabilFinanceiraDevolucao.getOperacaoInternaTesouraria() == null) {
				throw new PrevidenciaException("Uma Operação Interna (Contábil ou Financeira) deve ser selecionada antes de salvar.");
			}

			if (parametroIntegracaoContabilFinanceiraDevolucao.getCodigo() == null) {
				parametroIntegracaoContabilFinanceiraDevolucao.setDataInclusao(new Date());
				parametroIntegracaoContabilFinanceiraDevolucao.setNomeUsuarioInclusao(loginTemporariaDTO.getUsuarioSessao().getDescricaoLogin());
			}
			parametroIntegracaoContabilFinanceiraDevolucaoBO.salvarParametroIntegracaoContabilFinanceiraDevolucao(parametroIntegracaoContabilFinanceiraDevolucao);
			controlarEdicaoVisualizacao();

			this.listarParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>(parametroIntegracaoContabilFinanceiraDevolucaoBO
					.listarParametroIntegracaoContabilFinanceiraDevolucao());

			Mensagens.addMessage("DEV_VMSG022", parametroIntegracaoContabilFinanceiraDevolucao.getCodigo() == null ? "salvo" : "atualizado");
			return "FW_PARAMETRO_INTEGRACAO_CONTABIL_FINANCEIRA_DEV";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de salvar Parâmetro Integração Contabil Financeira.");
			return "";
		}

	}

	/**
	 * Método encarregado de deletar um registro Parâmetro de Integração Contábil e financeira.
	 * 
	 * @author  BBPF00170 - MAGSON 
	 * @since 16/02/2017
	 * @param {@link ParametroIntegracaoContabilFinanceiraDevolucao}
	 * @return {@link String}
	 */
	public String deletarParametroIntegracaoContabilFinanceira(ParametroIntegracaoContabilFinanceiraDevolucao parametroIntegracaoContabilFinanceiraDevolucao) {
		try {
			parametroIntegracaoContabilFinanceiraDevolucaoBO.apagarParametroIntegracaoContabilFinanceiraDevolucao(parametroIntegracaoContabilFinanceiraDevolucao);
			this.listarParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>(parametroIntegracaoContabilFinanceiraDevolucaoBO
					.listarParametroIntegracaoContabilFinanceiraDevolucao());
			Mensagens.addMsgInfo("Parâmentro excluído com sucesso!");
			return "FW_PARAMETRO_INTEGRACAO_CONTABIL_FINANCEIRA_DEV";
		} catch (PrevidenciaException pEx) {
			Mensagens.addMsgErro(pEx.getMessage());
			return "";
		} catch (Exception ex) {
			Mensagens.addMsgErro("Erro ocorrido na hora de deletar o Parâmetro");
			return "";
		}
	}

	/**
	 * Método para retornar a Lista de Parâmetros Integração Contábil e finaceiro, que atenda os critérios de pesquisa.
	 * 
	 * @author  
	 * @since 	23/01/2017
	 * @return  List<{@link }>
	 */
	public void filtrarListaParametroInterno() {
		if (this.planoPrevidencia != null || this.rubricaDevolucao != null || this.operacaoInternaContabil != null || this.operacaoInternaTesouraria != null) {
			this.listarParametroIntegracaoContabilFinanceiraDevolucao = listarParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>(
					parametroIntegracaoContabilFinanceiraDevolucaoBO.filtrarListaParametroIntegracaoContabilFinanceiraDevolucao(
							planoPrevidencia,
							rubricaDevolucao,
							operacaoInternaContabil,
							operacaoInternaTesouraria));
		} else {
			this.listarParametroIntegracaoContabilFinanceiraDevolucao = new ArrayList<ParametroIntegracaoContabilFinanceiraDevolucao>(parametroIntegracaoContabilFinanceiraDevolucaoBO
					.listarParametroIntegracaoContabilFinanceiraDevolucao());
		}
	}

	public ParametroIntegracaoContabilFinanceiraDevolucaoBO getParametroIntegracaoContabilFinanceiraDevolucaoBO() {
		return parametroIntegracaoContabilFinanceiraDevolucaoBO;
	}

	public void setParametroIntegracaoContabilFinanceiraDevolucaoBO(ParametroIntegracaoContabilFinanceiraDevolucaoBO parametroIntegracaoContabilFinanceiraDevolucaoBO) {
		this.parametroIntegracaoContabilFinanceiraDevolucaoBO = parametroIntegracaoContabilFinanceiraDevolucaoBO;
	}

	public RubricaDevolucaoBO getRubricaDevolucaoBO() {
		return rubricaDevolucaoBO;
	}

	public void setRubricaDevolucaoBO(RubricaDevolucaoBO rubricaDevolucaoBO) {
		this.rubricaDevolucaoBO = rubricaDevolucaoBO;
	}

	public PlanoPrevidenciaBO getPlanoPrevidenciaBO() {
		return planoPrevidenciaBO;
	}

	public void setPlanoPrevidenciaBO(PlanoPrevidenciaBO planoPrevidenciaBO) {
		this.planoPrevidenciaBO = planoPrevidenciaBO;
	}

	public OperacaoInternaBO getOperacaoInternaContabilBO() {
		return operacaoInternaContabilBO;
	}

	public void setOperacaoInternaContabilBO(OperacaoInternaBO operacaoInternaContabilBO) {
		this.operacaoInternaContabilBO = operacaoInternaContabilBO;
	}

	public OperacaoInternaBO getOperacaoInternaTesourariaBO() {
		return operacaoInternaTesourariaBO;
	}

	public void setOperacaoInternaTesourariaBO(OperacaoInternaBO operacaoInternaTesourariaBO) {
		this.operacaoInternaTesourariaBO = operacaoInternaTesourariaBO;
	}

	public List<ParametroIntegracaoContabilFinanceiraDevolucao> getListarParametroIntegracaoContabilFinanceiraDevolucao() {
		return listarParametroIntegracaoContabilFinanceiraDevolucao;
	}

	public void setListarParametroIntegracaoContabilFinanceiraDevolucao(List<ParametroIntegracaoContabilFinanceiraDevolucao> listarParametroIntegracaoContabilFinanceiraDevolucao) {
		this.listarParametroIntegracaoContabilFinanceiraDevolucao = listarParametroIntegracaoContabilFinanceiraDevolucao;
	}

	public List<RubricaDevolucao> getListaRubricaDevolucao() {
		return listaRubricaDevolucao;
	}

	public void setListaRubricaDevolucao(List<RubricaDevolucao> listaRubricaDevolucao) {
		this.listaRubricaDevolucao = listaRubricaDevolucao;
	}

	public List<PlanoPrevidencia> getListaPlanoPrevidencia() {
		return listaPlanoPrevidencia;
	}

	public void setListaPlanoPrevidencia(List<PlanoPrevidencia> listaPlanoPrevidencia) {
		this.listaPlanoPrevidencia = listaPlanoPrevidencia;
	}

	public List<OperacaoInterna> getListaOperacaoInternaContabil() {
		return listaOperacaoInternaContabil;
	}

	public void setListaOperacaoInternaContabil(List<OperacaoInterna> listaOperacaoInternaContabil) {
		this.listaOperacaoInternaContabil = listaOperacaoInternaContabil;
	}

	public List<OperacaoInterna> getListaOperacaoInternaTesouraria() {
		return listaOperacaoInternaTesouraria;
	}

	public void setListaOperacaoInternaTesouraria(List<OperacaoInterna> listaOperacaoInternaTesouraria) {
		this.listaOperacaoInternaTesouraria = listaOperacaoInternaTesouraria;
	}

	public ParametroIntegracaoContabilFinanceiraDevolucao getParametroIntegracaoContabilFinanceiraDevolucao() {
		return parametroIntegracaoContabilFinanceiraDevolucao;
	}

	public void setParametroIntegracaoContabilFinanceiraDevolucao(ParametroIntegracaoContabilFinanceiraDevolucao parametroIntegracaoContabilFinanceiraDevolucao) {
		this.parametroIntegracaoContabilFinanceiraDevolucao = parametroIntegracaoContabilFinanceiraDevolucao;
	}

	public boolean isPossuiAcessoTotal() {
		return possuiAcessoTotal;
	}

	public void setPossuiAcessoTotal(boolean possuiAcessoTotal) {
		this.possuiAcessoTotal = possuiAcessoTotal;
	}

	public LoginBBPrevWebDTO getLoginTemporariaDTO() {
		return loginTemporariaDTO;
	}

	public void setLoginTemporariaDTO(LoginBBPrevWebDTO loginTemporariaDTO) {
		this.loginTemporariaDTO = loginTemporariaDTO;
	}

	public boolean isListarStatus() {
		return listarStatus;
	}

	public void setListarStatus(boolean listarStatus) {
		this.listarStatus = listarStatus;
	}

	public RubricaDevolucao getRubricaDevolucao() {
		return rubricaDevolucao;
	}

	public void setRubricaDevolucao(RubricaDevolucao rubricaDevolucao) {
		this.rubricaDevolucao = rubricaDevolucao;
	}

	public PlanoPrevidencia getPlanoPrevidencia() {
		return planoPrevidencia;
	}

	public void setPlanoPrevidencia(PlanoPrevidencia planoPrevidencia) {
		this.planoPrevidencia = planoPrevidencia;
	}

	public OperacaoInterna getOperacaoInternaContabil() {
		return operacaoInternaContabil;
	}

	public void setOperacaoInternaContabil(OperacaoInterna operacaoInternaContabil) {
		this.operacaoInternaContabil = operacaoInternaContabil;
	}

	public OperacaoInterna getOperacaoInternaTesouraria() {
		return operacaoInternaTesouraria;
	}

	public void setOperacaoInternaTesouraria(OperacaoInterna operacaoInternaTesouraria) {
		this.operacaoInternaTesouraria = operacaoInternaTesouraria;
	}

}
