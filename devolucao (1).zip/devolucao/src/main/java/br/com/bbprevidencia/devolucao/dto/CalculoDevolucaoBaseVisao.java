package br.com.bbprevidencia.devolucao.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Classe complementar para o processo de comunicação entre a página de cálculo da devolução
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 02/07/2017
 *
 */
public class CalculoDevolucaoBaseVisao implements Serializable {

	private static final long serialVersionUID = -263302581811692757L;

	private static final Double VALORZERO = 0D;

	private Date dataRequerimento;

	// Totais das contas de devolução
	private Double totalCotasContrib = VALORZERO;

	private Double totalCotasJuros = VALORZERO;

	private Double totalCotasCorrecao = VALORZERO;

	private Double totalCotasMulta = VALORZERO;

	private Double totalCotas = VALORZERO;

	private Double totalValorContrib = VALORZERO;

	private Double totalValorJuros = VALORZERO;

	private Double totalValorCorrecao = VALORZERO;

	private Double totalValorMulta = VALORZERO;

	private Double totalValor = VALORZERO;

	//Totais das parcelas das Contas de Devolução

	private Double totalCotasParcela = VALORZERO;

	private Double totalValorCotasParcela = VALORZERO;

	private Double totalValorImpostos = VALORZERO;

	private Double totalValorLiquido = VALORZERO;

	//Totais dos saldo atual da Ficha financeira
	private Double totalCotasSaldoContrib = VALORZERO;

	private Double totalCotasSaldoJuros = VALORZERO;

	private Double totalCotasSaldoCorrecao = VALORZERO;

	private Double totalCotasSaldoMulta = VALORZERO;

	private Double totalValorSaldoContrib = VALORZERO;

	private Double totalValorSaldoJuros = VALORZERO;

	private Double totalValorSaldoCorrecao = VALORZERO;

	private Double totalValorSaldoMulta = VALORZERO;

	// atributos acrescentados por BBPF0170 - Magson 10/11/2017

	private Double totalCotasParcelaPgto = VALORZERO;

	private Double totalValorCotasParcelaPgto = VALORZERO;

	private Double totalValorImpostosPgto = VALORZERO;

	private Double totalValorLiquidoPgto = VALORZERO;

	/**
	 * Construtor padrão
	 */
	public CalculoDevolucaoBaseVisao() {
		super();
	}

	/**
	 * Método encarregado de calcular os totais da Lista de Parcelas de Contas de Devolução quando o Datatable é ordenado
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * 
	 * @param listaParcelaContaDevoluaco
	 * @param valorIndiceAjustado
	 * @param valorOrdenacao
	 * @param numColuna
	 */
	public void calcularTotaisContasParcelas(List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevoluacoDetalheImposto, List<ParcelaContaDevolucao> listaParcelaContaDevolucao,
			double valorIndiceAjustado, String valorOrdenacao, int numColuna) {

		zerarValoresTotaisParcela();
		for (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto : listaParcelaContaDevoluacoDetalheImposto) {

			//Para a tela de devolução não deve pegar os valores com cronograma
			if (parcelaContaDevolucaoDetalheImposto.getCronogramaDevolucao() == null) {
				switch (numColuna) {
				case 1:
					if (parcelaContaDevolucaoDetalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().getTipoContaDevolucao().getNomeTipoConta().equalsIgnoreCase(valorOrdenacao)) {
						this.totalValorImpostos += parcelaContaDevolucaoDetalheImposto.getValorIrrf();
					}
					break;
				case 2:
					if (parcelaContaDevolucaoDetalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().getIndicadorParcelaPaga().equalsIgnoreCase(valorOrdenacao)) {
						this.totalValorImpostos += parcelaContaDevolucaoDetalheImposto.getValorIrrf();
					}
					break;
				}
			}
		}

		for (ParcelaContaDevolucao parcelaContaDevolucao : listaParcelaContaDevolucao) {
			switch (numColuna) {
			case 1:
				if (parcelaContaDevolucao.getTipoContaDevolucao().getNomeTipoConta().equalsIgnoreCase(valorOrdenacao)) {
					this.totalCotasParcela += parcelaContaDevolucao.getQtdCotaParcela();
					this.totalValorCotasParcela = this.totalCotasParcela * valorIndiceAjustado;
				}
				break;
			case 2:
				if (parcelaContaDevolucao.getIndicadorParcelaPaga().equalsIgnoreCase(valorOrdenacao)) {
					this.totalCotasParcela += parcelaContaDevolucao.getQtdCotaParcela();
					this.totalValorCotasParcela = this.totalCotasParcela * valorIndiceAjustado;
				}
				break;
			}
		}

		this.totalValorLiquido = this.totalValorCotasParcela - this.totalValorImpostos;
	}

	/**
	 * Método encarregado de calcular os totais da Lista de Contas de Devolução Paga.
	 * 
	 * @author  BBPF0170 - magson 
	 * @since 13/11/2017
	 * 
	 * @param listaParcelaContaDevoluacoPgto
	 * @param List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevoluacoDetalheImposto
	 * @param valorOrdenacao
	 * 
	 */
	public void calcularTotaisContasParcelasPgto(List<ParcelaContaDevolucaoDetalheImposto> listaParcelaContaDevoluacoDetalheImposto, List<ParcelaContaDevolucaoPagto> listaParcelaContaDevolucaoPgto,
			String valorOrdenacao) {
		zerarValoresTotaisParcelaPgto();
		for (ParcelaContaDevolucaoDetalheImposto parcelaContaDevolucaoDetalheImposto : listaParcelaContaDevoluacoDetalheImposto) {
			//Para a tela de devolução não deve pegar os valores com cronograma
			if (parcelaContaDevolucaoDetalheImposto.getCronogramaDevolucao() != null) {
				if (parcelaContaDevolucaoDetalheImposto.getParcelaContaDevolucaoDetalhe().getParcelaContaDevolucao().getTipoContaDevolucao().getNomeTipoConta().equalsIgnoreCase(valorOrdenacao)) {
					this.totalValorImpostosPgto += parcelaContaDevolucaoDetalheImposto.getValorIrrf();
				}
			}
		}
		for (ParcelaContaDevolucaoPagto parcelaContaDevolucaoPagto : listaParcelaContaDevolucaoPgto) {
			if (parcelaContaDevolucaoPagto.getParcelaContaDevolucao().getTipoContaDevolucao().getNomeTipoConta().equalsIgnoreCase(valorOrdenacao)) {
				this.totalCotasParcelaPgto += parcelaContaDevolucaoPagto.getParcelaContaDevolucao().getQtdCotaParcela();
				this.totalValorCotasParcelaPgto = this.totalCotasParcelaPgto * parcelaContaDevolucaoPagto.getValorIndiceAjustado();
			}
		}
		this.totalValorLiquidoPgto = this.totalValorCotasParcelaPgto - this.totalValorImpostosPgto;
	}

	/**
	 * Método encarregado de calcular os totais da Lista de Contas de Devolução quando o Datatable é ordenado
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 03/02/2017
	 * 
	 * @param listaContaDevoluaco
	 * @param valorIndiceAjustado
	 * @param valorOrdenacao
	 * @param numColuna
	 */
	public void calcularTotaisContasDevolucao(List<ContaDevolucao> listaContaDevoluaco, double valorIndiceAjustado, String valorOrdenacao, int numColuna) {
		zerarValoresTotais();
		for (ContaDevolucao contaDevolucao : listaContaDevoluaco) {
			switch (numColuna) {
			case 1:
				if (contaDevolucao.getTipoContaDevolucao().getNomeTipoConta().equalsIgnoreCase(valorOrdenacao)) {
					calcularTotaisContasAux(contaDevolucao, valorIndiceAjustado);
				}
				break;
			case 2:
				if (contaDevolucao.getIndicadorMantenedor().equalsIgnoreCase(valorOrdenacao)) {
					calcularTotaisContasAux(contaDevolucao, valorIndiceAjustado);
				}
				break;
			case 3:
				if (contaDevolucao.getIndicadorAutoMantenedor().equalsIgnoreCase(valorOrdenacao)) {
					calcularTotaisContasAux(contaDevolucao, valorIndiceAjustado);
				}
				break;
			}
		}
	}

	/**
	 * Método para calcular os valores totais das contas de devolução
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param {@link ContaDevolucao}
	 * @param valorIndiceAjustado
	 */
	public void calcularTotaisContasAux(ContaDevolucao contaDevolucao, double valorIndiceAjustado) {
		this.totalCotasContrib += contaDevolucao.getQtdTotalCotasContribuicao();
		this.totalCotasCorrecao += contaDevolucao.getQtdTotalCotasCorrecao();
		this.totalCotasJuros += contaDevolucao.getQtdTotalCotasJuros();
		this.totalCotasMulta += contaDevolucao.getQtdTotalCotasMulta();
		this.totalCotas = this.totalCotasContrib + this.totalCotasCorrecao + this.totalCotasJuros + this.totalCotasMulta;

		this.totalValorContrib = this.totalCotasContrib * valorIndiceAjustado;
		this.totalValorCorrecao = this.totalCotasCorrecao * valorIndiceAjustado;
		this.totalValorJuros = this.totalCotasJuros * valorIndiceAjustado;
		this.totalValorMulta = this.totalCotasMulta * valorIndiceAjustado;
		this.totalValor = this.totalCotas * valorIndiceAjustado;

	}

	/**
	 * Método encarregado de zerar os totais
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 */
	public void zerarValoresTotais() {
		this.totalCotasContrib = 0D;
		this.totalCotasCorrecao = 0D;
		this.totalCotasJuros = 0D;
		this.totalCotasMulta = 0D;
		this.totalCotas = 0D;

		this.totalValorContrib = 0D;
		this.totalValorCorrecao = 0D;
		this.totalValorJuros = 0D;
		this.totalValorMulta = 0D;
		this.totalValor = 0D;
	}

	/**
	 * Método encarregado de zerar os totais das parcelas
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 */
	public void zerarValoresTotaisParcela() {
		this.totalCotasParcela = 0D;
		this.totalValorCotasParcela = 0D;
		this.totalValorImpostos = 0D;
	}

	/**
	 * Método encarregado de zerar os totais das parcelas
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 */
	public void zerarValoresTotaisParcelaPgto() {
		this.totalCotasParcelaPgto = 0D;
		this.totalValorCotasParcelaPgto = 0D;
		this.totalValorImpostosPgto = 0D;
	}

	/**
	 * 
	 * @param listaSaldoHFPDevolucaoDTO
	 * @param valorIndiceAjustado
	 */
	public void calcularTotaisSaldoAtual(List<SaldoHFPDevolucaoDTO> listaSaldoHFPDevolucaoDTO, double valorIndiceAjustado) {
		zerarValoresTotaisSaldo();
		for (SaldoHFPDevolucaoDTO saldo : listaSaldoHFPDevolucaoDTO) {
			this.totalCotasSaldoContrib += saldo.getQtdCotaContribuicao();
			this.totalCotasSaldoJuros += saldo.getQtdCotaJuros();
			this.totalCotasSaldoCorrecao += saldo.getQtdCotaCorrecao();
			this.totalCotasSaldoMulta += saldo.getQtdCotaMulta();

			this.totalValorSaldoContrib = this.totalCotasSaldoContrib * valorIndiceAjustado;
			this.totalValorSaldoJuros = this.totalCotasSaldoJuros * valorIndiceAjustado;
			this.totalValorSaldoCorrecao = this.totalCotasSaldoCorrecao * valorIndiceAjustado;
			this.totalValorSaldoMulta = this.totalCotasSaldoMulta * valorIndiceAjustado;
		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * 
	 */
	public void zerarValoresTotaisSaldo() {
		this.totalCotasSaldoContrib = VALORZERO;
		this.totalCotasSaldoJuros = VALORZERO;
		this.totalCotasSaldoCorrecao = VALORZERO;
		this.totalCotasSaldoMulta = VALORZERO;
		this.totalValorSaldoContrib = VALORZERO;
		this.totalValorSaldoJuros = VALORZERO;
		this.totalValorSaldoCorrecao = VALORZERO;
		this.totalValorSaldoMulta = VALORZERO;
	}

	public Date getDataRequerimento() {
		return dataRequerimento;
	}

	public void setDataRequerimento(Date dataRequerimento) {
		this.dataRequerimento = dataRequerimento;
	}

	public Double getTotalCotasContrib() {
		return totalCotasContrib;
	}

	public void setTotalCotasContrib(Double totalCotasContrib) {
		this.totalCotasContrib = totalCotasContrib;
	}

	public Double getTotalCotasJuros() {
		return totalCotasJuros;
	}

	public void setTotalCotasJuros(Double totalCotasJuros) {
		this.totalCotasJuros = totalCotasJuros;
	}

	public Double getTotalCotasCorrecao() {
		return totalCotasCorrecao;
	}

	public void setTotalCotasCorrecao(Double totalCotasCorrecao) {
		this.totalCotasCorrecao = totalCotasCorrecao;
	}

	public Double getTotalCotasMulta() {
		return totalCotasMulta;
	}

	public void setTotalCotasMulta(Double totalCotasMulta) {
		this.totalCotasMulta = totalCotasMulta;
	}

	public Double getTotalValorContrib() {
		return totalValorContrib;
	}

	public void setTotalValorContrib(Double totalValorContrib) {
		this.totalValorContrib = totalValorContrib;
	}

	public Double getTotalValorJuros() {
		return totalValorJuros;
	}

	public void setTotalValorJuros(Double totalValorJuros) {
		this.totalValorJuros = totalValorJuros;
	}

	public Double getTotalValorCorrecao() {
		return totalValorCorrecao;
	}

	public void setTotalValorCorrecao(Double totalValorCorrecao) {
		this.totalValorCorrecao = totalValorCorrecao;
	}

	public Double getTotalValorMulta() {
		return totalValorMulta;
	}

	public void setTotalValorMulta(Double totalValorMulta) {
		this.totalValorMulta = totalValorMulta;
	}

	public Double getTotalCotas() {
		return totalCotas;
	}

	public void setTotalCotas(Double totalCotas) {
		this.totalCotas = totalCotas;
	}

	public Double getTotalValor() {
		return totalValor;
	}

	public void setTotalValor(Double totalValor) {
		this.totalValor = totalValor;
	}

	public Double getTotalCotasParcela() {
		return totalCotasParcela;
	}

	public void setTotalCotasParcela(Double totalCotasParcela) {
		this.totalCotasParcela = totalCotasParcela;
	}

	public Double getTotalValorCotasParcela() {
		return totalValorCotasParcela;
	}

	public void setTotalValorCotasParcela(Double totalValorCotasParcela) {
		this.totalValorCotasParcela = totalValorCotasParcela;
	}

	public Double getTotalValorImpostos() {
		return totalValorImpostos;
	}

	public void setTotalValorImpostos(Double totalValorImpostos) {
		this.totalValorImpostos = totalValorImpostos;
	}

	public Double getTotalValorLiquido() {
		return totalValorLiquido;
	}

	public void setTotalValorLiquido(Double totalValorLiquido) {
		this.totalValorLiquido = totalValorLiquido;
	}

	public Double getTotalCotasSaldoContrib() {
		return totalCotasSaldoContrib;
	}

	public void setTotalCotasSaldoContrib(Double totalCotasSaldoContrib) {
		this.totalCotasSaldoContrib = totalCotasSaldoContrib;
	}

	public Double getTotalCotasSaldoJuros() {
		return totalCotasSaldoJuros;
	}

	public void setTotalCotasSaldoJuros(Double totalCotasSaldoJuros) {
		this.totalCotasSaldoJuros = totalCotasSaldoJuros;
	}

	public Double getTotalCotasSaldoCorrecao() {
		return totalCotasSaldoCorrecao;
	}

	public void setTotalCotasSaldoCorrecao(Double totalCotasSaldoCorrecao) {
		this.totalCotasSaldoCorrecao = totalCotasSaldoCorrecao;
	}

	public Double getTotalCotasSaldoMulta() {
		return totalCotasSaldoMulta;
	}

	public void setTotalCotasSaldoMulta(Double totalCotasSaldoMulta) {
		this.totalCotasSaldoMulta = totalCotasSaldoMulta;
	}

	public Double getTotalValorSaldoContrib() {
		return totalValorSaldoContrib;
	}

	public void setTotalValorSaldoContrib(Double totalValorSaldoContrib) {
		this.totalValorSaldoContrib = totalValorSaldoContrib;
	}

	public Double getTotalValorSaldoJuros() {
		return totalValorSaldoJuros;
	}

	public void setTotalValorSaldoJuros(Double totalValorSaldoJuros) {
		this.totalValorSaldoJuros = totalValorSaldoJuros;
	}

	public Double getTotalValorSaldoCorrecao() {
		return totalValorSaldoCorrecao;
	}

	public void setTotalValorSaldoCorrecao(Double totalValorSaldoCorrecao) {
		this.totalValorSaldoCorrecao = totalValorSaldoCorrecao;
	}

	public Double getTotalValorSaldoMulta() {
		return totalValorSaldoMulta;
	}

	public void setTotalValorSaldoMulta(Double totalValorSaldoMulta) {
		this.totalValorSaldoMulta = totalValorSaldoMulta;
	}

	public Double getTotalCotasParcelaPgto() {
		return totalCotasParcelaPgto;
	}

	public void setTotalCotasParcelaPgto(Double totalCotasParcelaPgto) {
		this.totalCotasParcelaPgto = totalCotasParcelaPgto;
	}

	public Double getTotalValorCotasParcelaPgto() {
		return totalValorCotasParcelaPgto;
	}

	public void setTotalValorCotasParcelaPgto(Double totalValorCotasParcelaPgto) {
		this.totalValorCotasParcelaPgto = totalValorCotasParcelaPgto;
	}

	public Double getTotalValorImpostosPgto() {
		return totalValorImpostosPgto;
	}

	public void setTotalValorImpostosPgto(Double totalValorImpostosPgto) {
		this.totalValorImpostosPgto = totalValorImpostosPgto;
	}

	public Double getTotalValorLiquidoPgto() {
		return totalValorLiquidoPgto;
	}

	public void setTotalValorLiquidoPgto(Double totalValorLiquidoPgto) {
		this.totalValorLiquidoPgto = totalValorLiquidoPgto;
	}

}
