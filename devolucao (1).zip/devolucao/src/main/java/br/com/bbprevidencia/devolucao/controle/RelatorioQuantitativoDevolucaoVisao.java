package br.com.bbprevidencia.devolucao.controle;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.bbprevidencia.bbpcomum.util.UtilJava;
import br.com.bbprevidencia.bbpcomum.util.UtilSession;
import br.com.bbprevidencia.cadastroweb.bo.EntidadeParticipanteBO;
import br.com.bbprevidencia.cadastroweb.dto.EntidadeParticipante;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.ParcelaContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoAnaliticoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.RelatorioQuantitativoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.util.FacesUtils;
import br.com.bbprevidencia.devolucao.util.Mensagens;
import br.com.bbprevidencia.devolucao.util.RelatorioUtil;

/**
 * Classe de comunicação entre a interface de usuário e as classes de negócio
 * para Solicitar o relatório Quantitativo de Devoluções.
 * 
 * @author BBPF0415 - Yanisley Mora Ritchie
 * @since 15/03/2017
 * 
 *        Copyright notice (c) 2017 BBPrevidência S/A
 *
 */

@Scope("session")
@Component("relatorioQuantitativoDevolucaoVisao")
public class RelatorioQuantitativoDevolucaoVisao {

	private static final String FW_RELATORIO_QUANTITATIVO_DEVOLUCAO = "/paginas/relatorioQuantitativoDevolucao.xhtml" + FacesUtils.PARAMETRO_JSF_REDIRECT;
	private static Logger log = Logger.getLogger(RelatorioQuantitativoDevolucaoVisao.class);

	@Autowired
	ParcelaContaDevolucaoBO parcelaContaDevolucaoBO;

	@Autowired
	RelatorioUtil relatorioUtil;

	@Autowired
	private EntidadeParticipanteBO entidadeParticipanteBO;

	private boolean possuiAcessoTotal;
	private LoginBBPrevWebDTO loginTemporariaDTO;

	private Date dataInicio;
	private Date dataFim;

	private String tipoDevolucao;

	private String relatorioSaida;

	private List<EntidadeParticipante> listaEntidadeParticipante;

	private List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas;

	/**
	 * Método encarregado de carregar a página incial de pesquisa
	 * 
	 * @author BBPF0415 - Yanisley Mora Ritchie
	 * @since 08/02/2017
	 * @return
	 */
	public String iniciarRelatorioQuantitativoDevolucao() {
		this.possuiAcessoTotal = false;
		this.loginTemporariaDTO = UtilSession.getLoginSessao();

		if (this.loginTemporariaDTO != null) {
			this.possuiAcessoTotal = this.loginTemporariaDTO.usuarioPossuiFuncionalidadeAcessoTotal("mantemFuncioUnidOrgFuncionario");
		}

		this.dataInicio = null;
		this.dataFim = null;
		this.relatorioSaida = "A";
		this.tipoDevolucao = "T";
		this.listaEntidadeParticipanteSelecionadas = null;

		this.listaEntidadeParticipante = new ArrayList<EntidadeParticipante>(this.entidadeParticipanteBO.listarEntidadeParticipante());

		return FW_RELATORIO_QUANTITATIVO_DEVOLUCAO;
	}

	/**
	 * Método encarregado de emitir o relatório
	 * 
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @since 15/03/2017
	 */
	public void exportarRelatorio(ActionEvent e) {
		try {
			if (this.relatorioSaida.equalsIgnoreCase("S")) {
				List<RelatorioQuantitativoDevolucaoDTO> relatorioQuantitativoDevolucao = new ArrayList<RelatorioQuantitativoDevolucaoDTO>();

				relatorioQuantitativoDevolucao.addAll(parcelaContaDevolucaoBO.pesquisaQuantitativoDevolucoes(this.getDataInicio(), this.getDataFim(), (this.tipoDevolucao.equalsIgnoreCase("T") ? null
						: this.tipoDevolucao), this.listaEntidadeParticipanteSelecionadas));

				if (UtilJava.isColecaoVazia(relatorioQuantitativoDevolucao)) {
					Mensagens.addMsgInfo("Não foram encontradas informações para os parâmetros informados!");
				} else {
					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

					String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
					parametros.put("logo", logo);
					//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(relatorioQuantitativoDevolucao);
					//GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "quantitativoDevolucao", dataSource);
					imprimirRelatorioSintetico("quantitativoDevolucao", relatorioQuantitativoDevolucao, parametros);
				}
			} else {
				List<RelatorioQuantitativoAnaliticoDevolucaoDTO> relatorioQuantitativoAnaliticoDevolucao = new ArrayList<RelatorioQuantitativoAnaliticoDevolucaoDTO>();

				relatorioQuantitativoAnaliticoDevolucao.addAll(parcelaContaDevolucaoBO.pesquisaQuantitativoAnaliticoDevolucoes(this.getDataInicio(), this.getDataFim(), (this.tipoDevolucao
						.equalsIgnoreCase("T") ? null : this.tipoDevolucao), this.listaEntidadeParticipanteSelecionadas));

				if (UtilJava.isColecaoVazia(relatorioQuantitativoAnaliticoDevolucao)) {
					Mensagens.addMsgInfo("Não foram encontradas informações para os parâmetros informados!");
				} else {
					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));

					String logo = UtilSession.getRealPath("imagens/LogotiposExterno/Logomarca_BBPREVIDENCIA.jpg");
					parametros.put("logo", logo);
					//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(relatorioQuantitativoAnaliticoDevolucao);
					//GerenciaRelatorioUtil.geraRelatorioPDF(parametros, "quantitativoAnaliticoDevolucao", dataSource);
					imprimirRelatorioAnalitico("quantitativoAnaliticoDevolucao", relatorioQuantitativoAnaliticoDevolucao, parametros);
				}
			}
		} catch (PrevidenciaException pEx) {
			log.error("Erro ao exportar relatório.", pEx);
			Mensagens.addMsgErro(pEx.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
			Mensagens.addMsgErro("Erro ao exportar relatório: " + ex.getMessage());
		}

	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param relatorio
	 * @param dados
	 * @param param
	 */
	public void imprimirRelatorioAnalitico(String relatorio, List<RelatorioQuantitativoAnaliticoDevolucaoDTO> dados, Map<String, Object> parametros) {
		try {
			String nomeArquivo = relatorioUtil.gerarRelatorio(relatorio, dados, parametros);
			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (Exception e) {
			log.error("Erro ao exportar relatório.", e);
			throw new PrevidenciaException(e);
		}
	}

	/**
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @param relatorio
	 * @param dados
	 * @param param
	 */
	public void imprimirRelatorioSintetico(String relatorio, List<RelatorioQuantitativoDevolucaoDTO> dados, Map<String, Object> parametros) {
		try {
			String nomeArquivo = relatorioUtil.gerarRelatorio(relatorio, dados, parametros);
			relatorioUtil.abrirPoupUp(nomeArquivo);
		} catch (Exception e) {
			log.error("Erro ao exportar relatório.", e);
			throw new PrevidenciaException(e);
		}
	}

	/**
	 * Limpa os valores de pesquisa
	 * @author  BBPF0415 - Yanisley Mora Ritchie
	 * @return
	 */
	public String limparPesquisa() {
		PrimeFaces.current().resetInputs("formRQD");
		return iniciarRelatorioQuantitativoDevolucao();
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public String getTipoDevolucao() {
		return tipoDevolucao;
	}

	public void setTipoDevolucao(String tipoDevolucao) {
		this.tipoDevolucao = tipoDevolucao;
	}

	public String getRelatorioSaida() {
		return relatorioSaida;
	}

	public void setRelatorioSaida(String relatorioSaida) {
		this.relatorioSaida = relatorioSaida;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipante() {
		return listaEntidadeParticipante;
	}

	public void setListaEntidadeParticipante(List<EntidadeParticipante> listaEntidadeParticipante) {
		this.listaEntidadeParticipante = listaEntidadeParticipante;
	}

	public List<EntidadeParticipante> getListaEntidadeParticipanteSelecionadas() {
		return listaEntidadeParticipanteSelecionadas;
	}

	public void setListaEntidadeParticipanteSelecionadas(List<EntidadeParticipante> listaEntidadeParticipanteSelecionadas) {
		this.listaEntidadeParticipanteSelecionadas = listaEntidadeParticipanteSelecionadas;
	}

}
