package br.com.bbprevidencia.devolucao.enumerador;

public enum TipoIntegracaoEnum {

	LIQUIDO("1", "Liquido Folha Devolução - Tesouraria"),
	RUBRICA("2", "Rubricas Folha Devolução - Tesouraria"),
	CONSIGNATARIO("3", "Consignatarios Folha Devolução - Tesouraria"),
	CONTABILIDADE("4", "Rubricas Folha - Contabilidade"),
	GESTAOTRIB("5", "Erro ocorrido durante cálculo"),
	COTAS("6", "Integração Folha Devolução - Sistema de Cotas"),
	FUNDOPREVIDENCIAL("7", "Integração Folha Devolução - Sistema de Fundo Previdencial");

	private String codigo;
	private String descricao;

	private TipoIntegracaoEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @param codigo
	 * @return TipoIntegracaoEnum
	 */
	public static TipoIntegracaoEnum getTipoIntegracaoEnum(String codigo) {
		if (codigo != null) {
			for (TipoIntegracaoEnum tipoIntegracaoEnum : values()) {
				if (tipoIntegracaoEnum.getCodigo().equals(codigo)) {
					return tipoIntegracaoEnum;
				}
			}
		}
		return null;
	}

}