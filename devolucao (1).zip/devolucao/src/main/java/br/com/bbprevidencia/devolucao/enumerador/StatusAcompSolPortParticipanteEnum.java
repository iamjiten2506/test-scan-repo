package br.com.bbprevidencia.devolucao.enumerador;

public enum StatusAcompSolPortParticipanteEnum {

	ANALISE("1", "ANÁLISE", "Prezado Participante,\n Sua solicitação está em análise."),
	AGUARDANDO_TSP("2", "AGUARDANDO TSP", "Prezado Participante,\n Sua solicitação está aguardando TSP."),
	PENDENCIA("3", "PENDÊNCIA", "Prezado Participante,\n Sua solicitação está com pendências na documentação."),
	AGUARDANDO_FECHAMENTO_PROCESSAMENTO("4", "AGUARDANDO FECHAR PROCESSAMENTO", "Prezado Participante,\n Sua solicitação está aguardando processamento."),
	CONCLUIDA("5", "CONCLUÍDA", "Prezado Participante,\n Sua solicitação está sendo concluída.\nEm breve você receberá um email informando a conclusão."),
	PROCESSADA("6", "PROCESSADA", "Prezado Participante,\n Sua solicitação foi processada com sucesso.");

	private String codigo;
	private String descricao;
	private String msgEmail;

	private StatusAcompSolPortParticipanteEnum(String codigo, String descricao, String msgEmail) {
		this.codigo = codigo;
		this.descricao = descricao;
		this.msgEmail = msgEmail;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getMsgEmail() {
		return msgEmail;
	}

	public void setMsgEmail(String msgEmail) {
		this.msgEmail = msgEmail;
	}

	public static String getDescricao(String codigo) {
		if (codigo != null) {
			for (StatusAcompSolPortParticipanteEnum acompSolPortParticipante : values()) {
				if (acompSolPortParticipante.getCodigo().equals(codigo)) {
					return acompSolPortParticipante.getDescricao();
				}
			}
		}
		return null;
	}

	public static String getMsgEmail(String codigo) {
		if (codigo != null) {
			for (StatusAcompSolPortParticipanteEnum acompSolPortParticipante : values()) {
				if (acompSolPortParticipante.getCodigo().equals(codigo)) {
					return acompSolPortParticipante.getMsgEmail();
				}
			}
		}
		return null;
	}

}
