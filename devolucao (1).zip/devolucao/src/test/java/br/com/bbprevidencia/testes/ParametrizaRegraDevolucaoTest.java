package br.com.bbprevidencia.testes;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.comum.exception.PrevidenciaException;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoRegraBO;
import br.com.bbprevidencia.devolucao.controle.ParametrizaRegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitario parta verificar o cadastr de uma nova regra de devoluçaõ via Clone
 * 
 * @author  BBPF0415 - Yanisley Mora Ritchie
 *
 */
public class ParametrizaRegraDevolucaoTest extends TesteBase {

	@Autowired
	ParametrizaRegraDevolucao parametrizaRegraDevolucao;

	@Autowired
	RegraDevolucaoBO regraDevolucaoBO;

	@Autowired
	SituacaoRegraBO situacaoRegraBO;

	@Test
	public void testSalvarRegraDevolucao() throws CloneNotSupportedException {
		try {
			RegraDevolucao regraDevolucao = regraDevolucaoBO.pesquisarRegraDevolucaoPorCodigo(2L);
			parametrizaRegraDevolucao.setNovaRegraDevolucao(regraDevolucao.clone());
			parametrizaRegraDevolucao.getNovaRegraDevolucao().setSituacaoRegraDevolucao(situacaoRegraBO.pesquisarSituacaoRegraPorCodigo(1L));

			parametrizaRegraDevolucao.salvarRegraDevolucao();
			System.out.println(parametrizaRegraDevolucao.getNovaRegraDevolucao().toString());
		} catch (Exception ex) {
			throw new PrevidenciaException(ex);
		}
	}

}
