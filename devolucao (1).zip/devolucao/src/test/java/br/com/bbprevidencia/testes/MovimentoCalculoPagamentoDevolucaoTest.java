package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.TotalPerfilPartePlanoDTO;
import br.com.bbprevidencia.testes.base.TesteBase;

public class MovimentoCalculoPagamentoDevolucaoTest extends TesteBase {

	@Autowired
	private MovimentoCalculoPagamentoDevolucaoBO movBO;

	@Test
	public void testarPesquisaValoresPorperfil() {
		try {
			List<TotalPerfilPartePlanoDTO> lista = new ArrayList<TotalPerfilPartePlanoDTO>(movBO.extrairTotalPorPerfilPlanoTipoFolha());

			System.out.println(lista);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
