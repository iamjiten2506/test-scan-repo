package br.com.bbprevidencia.testes;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.bo.PlanoPrevidenciaBO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoDevolucaoVisaoItemBO;
import br.com.bbprevidencia.devolucao.bo.DocumentoPlanoTipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.LoteProcessamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MensagemLoteProcessamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraCalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.SituacaoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoMensagemProcessoDevolucaoBO;
import br.com.bbprevidencia.devolucao.controle.LoginDevolucaoController;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.folha.bo.RecebedorBO;
import br.com.bbprevidencia.pessoa.bo.AtuacaoPessoaBO;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação de métodos diversos
 *
 * @author  BBPF0333 - Daniel Martins
 * @since   25/01/2017
 * 
 * Copyright notice (c) 2017 BBPrevidência S/A
 */
/**
 * @author  BBPF0333 - Daniel Martins
 *
 */
public class TesteMetodos extends TesteBase {

	@Autowired
	private LoginDevolucaoController loginDevolucaoController;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private LoteProcessamentoDevolucaoBO loteProcessamentoDevolucaoBO;

	@Autowired
	private MensagemLoteProcessamentoDevolucaoBO mensagemLoteProcessamentoDevolucaoBO;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Autowired
	private SituacaoDevolucaoBO situacaoDevolucaoBO;

	@Autowired
	private TipoMensagemProcessoDevolucaoBO tipoMensagemProcessoDevolucaoBO;

	@Autowired
	private DocumentoPlanoTipoDevolucaoBO documentoPlanoTipoDevolucaoBO;

	@Autowired
	private DocumentoDevolucaoVisaoBO documentoDevolucaoVisaoBO;

	@Autowired
	private DocumentoDevolucaoVisaoItemBO documentoDevolucaoVisaoItemBO;

	@Autowired
	private RecebedorBO recebedorBO;

	@Autowired
	private AtuacaoPessoaBO atuacaoPessoaBO;

	@Autowired
	private RegraCalculoDevolucaoBO regraCalculoDevolucaoBO;

	@Autowired
	private PlanoPrevidenciaBO planoPrevidenciaBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	/*
	@Test
	public void testeMetodo() {

		try {

			CronogramaDevolucao cronogramaDevolucao = new CronogramaDevolucao();
			Devolucao devolucao = new Devolucao();
			TipoMensagemProcessoDevolucao tipoMensagemProcessoDevolucao;
			Recebedor recebedor = new Recebedor();
			recebedor = null;
			AtuacaoPessoa atuacaoPessoa = new AtuacaoPessoa();
			atuacaoPessoa = null;

			devolucao = devolucaoBO.pesquisarDevolucaoPorCodigo(15l);
			devolucao = null;

			tipoMensagemProcessoDevolucao = tipoMensagemProcessoDevolucaoBO.pesquisarTipoMensagemProcessoDevolucaoPorCodigo(28L);

			if (devolucao != null) {
				System.out.println(devolucao.getCodigo().toString());
			}

			List<LoteProcessamentoDevolucao> lista = new ArrayList<LoteProcessamentoDevolucao>();
			List<MensagemLoteProcessamentoDevolucao> listaMsg = new ArrayList<MensagemLoteProcessamentoDevolucao>();

			cronogramaDevolucao = cronogramaDevolucaoBO.pesquisarCronogramaDevolucaoPorCodigo(11l);

			lista = loteProcessamentoDevolucaoBO.listarLoteProcessamentoDevolucaoTipoProcessamentoPorCronogramaDevolucao(cronogramaDevolucao);

			for (LoteProcessamentoDevolucao item : lista) {

				System.out.println("Lote: " + item.getCodigo().toString() + " - " + item.getTipoProcessamento().toString());

				//listaMsg = mensagemLoteProcessamentoDevolucaoBO.listarMensagemLoteProcessamentoDevolucaoPorFiltros(loteProcessamentoDevolucao, devolucao, recebedor, atuacaoPessoa, tipoMensagemProcessoDevolucao, tipoMensagemEnum)
				listaMsg = mensagemLoteProcessamentoDevolucaoBO.listarMensagemLoteProcessamentoDevolucaoPorFiltros(
						item,
						devolucao,
						recebedor,
						atuacaoPessoa,
						tipoMensagemProcessoDevolucao,
						TipoMensagemEnum.ERRO);

				for (MensagemLoteProcessamentoDevolucao itemMsg : listaMsg) {
					System.out.println("Mensagem : " + itemMsg.getCodigo().toString() + " - " + itemMsg.getMensagemLoteProcessamentoDevPrimario() + " - "
							+ itemMsg.getMensagemLoteProcessamentoDevComplementar());
				}

			}

			System.out.println("Final do Processo ");

		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	 */
	/*
	
	 @Test
	 public void testeMetodo() {

	 try {

	 List<Devolucao> listaDevolucao = new ArrayList<Devolucao>();

	 SituacaoDevolucao situacaoDevolucao = new SituacaoDevolucao();

	 situacaoDevolucao = situacaoDevolucaoBO.pesquisarSituacaoDevolucaoPorCodigo(1l);
	 
	 System.out.println(situacaoDevolucao.getNome());
	 

	 listaDevolucao = devolucaoBO.listarDevolucaoPorSituacao(situacaoDevolucao);

	 for (Devolucao devolucao : listaDevolucao) {
	 System.out.println(devolucao.getCodigo().toString());
	 }

	 System.out.println("Final do Processo ");
	 

	 } catch (Exception e) {
	 System.out.println(e);
	 } 

	 }
	 */

	/*
	@Test
	public void testeMetodo() {

		try {

			System.out.println("");
			System.out.println("Início do Processo ");
			System.out.println("");

			LoginBBPrevWebDTO loginBBPrevWebDTO = new LoginBBPrevWebDTO();

			loginBBPrevWebDTO = this.loginDevolucaoController.loginAdminSistemasDevolucaoExterno("7lVtRpitgIjhJtodRgA8zg");

			Devolucao devolucao = new Devolucao();

			devolucao = devolucaoBO.pesquisarDevolucaoPorCodigo(1l);

			System.out.println("Devolução: " + devolucao.getDescricao());

			Recebedor recebedor = new Recebedor();

			recebedor = recebedorBO.pesquisarRecebedorCodigo(16930l);

			System.out.println("Recebedor : " + recebedor.getNome());

			//AtuacaoPessoa atuacaoPessoa = new AtuacaoPessoa();

			//atuacaoPessoa = atuacaoPessoaBO.pesquisarAtuacaoPessoaPorPessoa(pessoa)

			List<DocumentoPlanoTipoDevolucao> listaDocumentoPlanoTipoDevolucao = new ArrayList<DocumentoPlanoTipoDevolucao>();

			listaDocumentoPlanoTipoDevolucao = documentoPlanoTipoDevolucaoBO.listarDocumentoPlanoTipoDevolucaoPorDevolucaoDeDevolucaoRecebedor(devolucao);

			System.out.println("");
			System.out.println("Documentos Recebedor");
			System.out.println("");

			for (DocumentoPlanoTipoDevolucao documentoPlanoTipoDevolucao : listaDocumentoPlanoTipoDevolucao) {
				System.out.println(documentoPlanoTipoDevolucao.getDocumentoDevolucao().getNome());
			}

			listaDocumentoPlanoTipoDevolucao = documentoPlanoTipoDevolucaoBO.listarDocumentoPlanoTipoDevolucaoPorDevolucaoDeDevolucaoPessoa(devolucao);

			System.out.println("");
			System.out.println("Documentos Pessoa");
			System.out.println("");

			for (DocumentoPlanoTipoDevolucao documentoPlanoTipoDevolucao : listaDocumentoPlanoTipoDevolucao) {
				System.out.println(documentoPlanoTipoDevolucao.getDocumentoDevolucao().getNome());
			}

			//DocumentoDevolucaoVisao documentoDevolucaoVisao = new DocumentoDevolucaoVisao();

			//documentoDevolucaoVisao = documentoDevolucaoVisaoBO.verificarDocumentoDevolucaoVisaoDevolucao(devolucao, loginBBPrevWebDTO);

			//System.out.println( "Código documento:  " + documentoDevolucaoVisao.getCodigo());

			/*
			if (documentoDevolucaoVisaoItemBO.verificarDocumentosPorDevolucao(devolucao, loginBBPrevWebDTO)) {
			//				System.out.println("Tem Documento");
			} else {
				System.out.println("Não Tem Documento");
			}

			if (documentoDevolucaoVisaoItemBO.isDocumentoDevolucaoVisaoItemPendentePorDevolucao(devolucao)) {

				System.out.println("");
				System.out.println("Tem Documento pendente.");
				System.out.println("");
				System.out.println("Documentos Pendente: ");
				System.out.println("");

				List<DocumentoDevolucaoVisaoItem> listaDocumentoDevolucaoVisaoItem = new ArrayList<DocumentoDevolucaoVisaoItem>();

				listaDocumentoDevolucaoVisaoItem = documentoDevolucaoVisaoItemBO.listarDocumentoDevolucaoVisaoItemPendentePorDevolucao(devolucao);

				for (DocumentoDevolucaoVisaoItem documentoDevolucaoVisaoItem : listaDocumentoDevolucaoVisaoItem) {
					System.out.println(documentoDevolucaoVisaoItem.getDocumentoDevolucao().getNome());
				}

				System.out.println("");
				System.out.println("Ações: ");
				System.out.println("");

				List<String> listaAcoes = new ArrayList<String>();

				listaAcoes = documentoDevolucaoVisaoItemBO.listarAcoesDocumentoDevolucaoVisaoItemPendentePorDevolucaoDeDevolucao(devolucao);

				for (String Acoes : listaAcoes) {

					System.out.println(Acoes);
				}

			} else {
				System.out.println("Não Tem Documento pendente.");
			}
	 */

	/*
	
	
	List<DocumentoPlanoTipoDevolucao> listaDocumentoPlanoTipoDevolucao = new ArrayList<DocumentoPlanoTipoDevolucao>();
	
	listaDocumentoPlanoTipoDevolucao = documentoPlanoTipoDevolucaoBO.listarDocumentoPlanoTipoDevolucaoPorDevolucao(devolucao);
	
	
	for (DocumentoPlanoTipoDevolucao documentoPlanoTipoDevolucao : listaDocumentoPlanoTipoDevolucao) {
		System.out.println(documentoPlanoTipoDevolucao.getDocumentoDevolucao().getNome() + " - " + documentoPlanoTipoDevolucao.getIndicativoValido() + " - " + documentoPlanoTipoDevolucao.getDataInicio());
	}
	
	 */
	/*
	 System.out.println("");
	 System.out.println("Final do Processo ");
	 System.out.println("");

	 } catch (Exception e) {
	 System.out.println(e);
	 }

	 }
	 */
	/*
	@Test
	public void testeMetodo() {

		try {
			System.out.println("Início do Processo ");
			
			PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();
			
			planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(103l);

			List<RegraCalculoDevolucao> listaRegraCalculoDevolucao = new ArrayList<RegraCalculoDevolucao>();
			
			listaRegraCalculoDevolucao = regraCalculoDevolucaoBO.listarTodosRegraCalculoDevolucaoSitEmProducaoVigenteHojePorPlanoPrevidencia(planoPrevidencia);
			

			for (RegraCalculoDevolucao regraCalculoDevolucao : listaRegraCalculoDevolucao) {
				System.out.println(regraCalculoDevolucao.getRegraDevolucao().getPlanoVigenciaDevolucao().getPlanoPrevidencia().getNomeAbreviadoPlano() + " - " +
						regraCalculoDevolucao.getTipoDevolucao().getNome() + "-" + 
						regraCalculoDevolucao.getRegraDevolucao().getSituacaoRegraDevolucao().getNome() 
						);
			}

			System.out.println("Final do Processo ");

		} catch (Exception e) {
			System.out.println(e);
		}

	}
	 */

	/*
	@Test
	public void testeMetodo() {

		try {
			System.out.println("Início do Processo ");

			PlanoPrevidencia planoPrevidencia = new PlanoPrevidencia();

			planoPrevidencia = planoPrevidenciaBO.consultarPlanoPrevidenciaPorCodigo(103l);

			List<TipoDevolucao> listaTipoDevolucao = new ArrayList<TipoDevolucao>();

			listaTipoDevolucao = tipoDevolucaoBO.listarTodosTipoDevolucaoPorPlanoPrevidencia(planoPrevidencia);

			for (TipoDevolucao tipoDevolucao : listaTipoDevolucao) {
				System.out.println(tipoDevolucao.getNome());
			}

			System.out.println("Final do Processo ");

		} catch (Exception e) {
			System.out.println(e);
		}

	}*/

	@Test
	public void testeMetodo() {
		try {
			System.out.println("Pesquisando Cronograma");

			CronogramaDevolucao cronogramaDevolucao = new CronogramaDevolucao();
			cronogramaDevolucao = cronogramaDevolucaoBO.pesquisarCronogramaDevolucaoPorCodigo(22L);

			System.out.println("Início de Envio");

			this.historicoPagamentoDevolucaoBO.gerarRelatorioEmprestimosFechamentoCronograma(cronogramaDevolucao);

			System.out.println("Fim de Envio");

		} catch (Exception e) {
			System.out.println(e);
		}
	}

}