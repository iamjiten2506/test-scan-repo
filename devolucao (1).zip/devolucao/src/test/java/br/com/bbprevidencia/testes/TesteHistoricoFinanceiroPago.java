package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.bo.HistoricoFinanceiroPagoBO;
import br.com.bbprevidencia.cadastroweb.bo.HistoricoPercentualParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.dto.HistoricoFinanceiroPago;
import br.com.bbprevidencia.cadastroweb.dto.HistoricoPercentualParticipante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PlanoPrevidencia;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação e pesquisa do historico financeiro pago
 *
 * @author Marco Figueiredo
 * @since 29/11/2016
 * 
 * Copyright notice (c) 2016 BBPrevidência S/AX
 */
public class TesteHistoricoFinanceiroPago extends TesteBase {

	@Autowired
	HistoricoFinanceiroPagoBO historicoFinanceiroPagoBO;

	@Autowired
	ParticipantePlanoBO participantePlanoBO;

	@Autowired
	HistoricoPercentualParticipanteBO historicoPercentualParticipanteBO;

	@Test
	public void testePesquisaHistoricoFinanceiroPago() {

		try {

			List<ParticipantePlano> listaParticipantePlano = new ArrayList<ParticipantePlano>();

			listaParticipantePlano = this.participantePlanoBO.consultparPlanoPorParticipante(998128L, new PlanoPrevidencia());

			ParticipantePlano participantePlano = listaParticipantePlano.get(0);

			List<HistoricoPercentualParticipante> historico = new ArrayList<HistoricoPercentualParticipante>();
			historico = this.historicoPercentualParticipanteBO.listarHistoricoParticipantePorParticipante(participantePlano.getParticipante());

			participantePlano.setHistoricoPercentualParticipante(historico);

			System.out.println(participantePlano.getCodigo());

			List<HistoricoFinanceiroPago> listaHistoricoFinancPago = new ArrayList<HistoricoFinanceiroPago>();

			listaHistoricoFinancPago = this.historicoFinanceiroPagoBO.listarPorParticPlano(participantePlano);

			for (HistoricoFinanceiroPago historicoFinanceiroPago : listaHistoricoFinancPago) {
				System.out.println("Deposito: " + historicoFinanceiroPago.getChavePrimaria().getDataDeposito());
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
