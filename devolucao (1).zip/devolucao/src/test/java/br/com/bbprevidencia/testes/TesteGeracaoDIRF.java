package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.bo.SistemaBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.controle.LoginDevolucaoController;
import br.com.bbprevidencia.folha.bo.LoteProcessamentoDirfBO;
import br.com.bbprevidencia.folha.dto.LoteProcessamentoDirf;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação de dirf
 *
 * @author Marco Figueiredo
 * @since 15/01/2018
 * 
 * Copyright notice (c) 2016 BBPrevidência S/AX
 */
public class TesteGeracaoDIRF extends TesteBase {

	@Autowired
	private LoteProcessamentoDirfBO loteProcessamentoDirfBO;

	@Autowired
	private LoginDevolucaoController loginDevolucaoController;

	@Autowired
	private SistemaBO sistemaBO;

	@Test
	public void testeCalculoDevolucao() {

		try {

			LoteProcessamentoDirf loteProcessamentoDirf = new LoteProcessamentoDirf();

			LoginBBPrevWebDTO loginBBPrevWebDTO = new LoginBBPrevWebDTO();

			loginBBPrevWebDTO = this.loginDevolucaoController.loginAdminSistemasDevolucaoExterno("7lVtRpitgIjhJtodRgA8zg");
			List<String> listaCPF = new ArrayList<String>();
			listaCPF.add("27355469851");

			loteProcessamentoDirf = this.loteProcessamentoDirfBO.gerarDadosProcessamentoDirf(listaCPF, null, sistemaBO.consultarSistemaPorCodigo(251L), "2018", loginBBPrevWebDTO, "Teste");
			System.out.println(loteProcessamentoDirf);

			this.loteProcessamentoDirfBO.salvarLoteProcessamentoDirf(loteProcessamentoDirf);

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}