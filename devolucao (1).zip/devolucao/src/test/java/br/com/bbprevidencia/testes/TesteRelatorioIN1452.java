package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.HistoricoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.MovimentoCalculoPagamentoDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioValoresDevolucaoDTO;
import br.com.bbprevidencia.testes.base.TesteBase;
import junit.framework.Assert;

public class TesteRelatorioIN1452 extends TesteBase {

	@Autowired
	HistoricoPagamentoDevolucaoBO historicoPagamentoDevolucaoBO;

	@Autowired
	MovimentoCalculoPagamentoDevolucaoBO movimentoCalculoPagamentoDevolucaoBO;

	@Autowired
	CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Test
	public void TestGerarValoresIN452() {
		try {
			List<RelatorioValoresDevolucaoDTO> listaRelatorioValoresDevolucaoDTO = new ArrayList<RelatorioValoresDevolucaoDTO>();

			listaRelatorioValoresDevolucaoDTO = this.historicoPagamentoDevolucaoBO.pesquisarValoresRelatorioIN1452("201710");

			Assert.assertNotNull("ListaPreenchida", listaRelatorioValoresDevolucaoDTO);

			for (RelatorioValoresDevolucaoDTO relatorioValoresDevolucaoDTO : listaRelatorioValoresDevolucaoDTO) {
				System.out.println(relatorioValoresDevolucaoDTO.toString());
			}

			/*listaRelatorioValoresDevolucaoDTO = this.movimentoCalculoPagamentoDevolucaoBO.pesquisarValoresRelatorioTesouraria(this.cronogramaDevolucaoBO.pesquisarCronogramaDevolucaoPorCodigo(48L));
			
			Assert.assertNotNull("ListaPreenchida", listaRelatorioValoresDevolucaoDTO);*/

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}
