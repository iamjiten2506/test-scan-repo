package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.pessoa.bo.PessoaEntidadeBO;
import br.com.bbprevidencia.pessoa.dto.PessoaEntidade;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação de métodos diversos
 *
 * @author  BBPF0333 - Daniel Martins
 * @since   25/01/2017
 * 
 * Copyright notice (c) 2017 BBPrevidência S/A
 */
/**
 * @author  BBPF0333 - Daniel Martins
 *
 */
public class TestePessoaEntidade extends TesteBase {

	@Autowired
	private PessoaEntidadeBO pessoaEntidadeBO;

	@Test
	public void testeListaTodos() {

		try {

			List<PessoaEntidade> listaPessoa = new ArrayList<PessoaEntidade>();

			listaPessoa = this.pessoaEntidadeBO.listarTodasPessoasEntidades();

			for (PessoaEntidade pessoaEntidade : listaPessoa) {
				System.out.println(pessoaEntidade.toString());
			}

			System.out.println("Final do Processo ");

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}