package br.com.bbprevidencia.testes;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.CalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.controle.LoginDevolucaoController;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação e cálculo de devolução
 *
 * @author Marco Figueiredo
 * @since 16/12/2016
 * 
 * Copyright notice (c) 2016 BBPrevidência S/AX
 */
public class TesteCalculoDevolucao extends TesteBase {
	private final static Long[] codPartic;

	static {
		codPartic = new Long[70];
		/*codPartic[10] =967164L;
		codPartic[11] =967166L;
		codPartic[12] =967176L;
		codPartic[13] =967186L;
		codPartic[14] =967187L;
		codPartic[15] =967189L;
		codPartic[16] =967191L;
		codPartic[17] =967192L;
		codPartic[18] =967199L;
		codPartic[19] =967214L;
		codPartic[20] =967215L;
		codPartic[21] =967218L;
		codPartic[22] =967219L;
		codPartic[23] =967222L;
		codPartic[24] =967223L;
		codPartic[25] =967232L;
		codPartic[26] =967236L;
		codPartic[27] =967241L;
		codPartic[28] =967243L;
		codPartic[29] =967245L;
		codPartic[30] =967251L;
		codPartic[31] =967260L;
		codPartic[32] =967262L;
		codPartic[33] =967271L;
		codPartic[34] =967280L;
		codPartic[35] =967295L;
		codPartic[36] =967299L;
		codPartic[37] =967303L;
		codPartic[38] =967304L;
		codPartic[39] =967306L;
		codPartic[40] =967308L;
		codPartic[41] =967311L;
		codPartic[42] =967313L;
		codPartic[43] =967318L;*/
		codPartic[44] = 967320L;
		codPartic[45] = 967324L;
		codPartic[46] = 967325L;
		codPartic[47] = 967328L;
		codPartic[48] = 967329L;
		codPartic[49] = 967330L;

	}

	@Autowired
	private CalculoDevolucaoBO calculoDevolucao;

	@Autowired
	private LoginDevolucaoController loginDevolucaoController;

	@Test
	public void testeCalculoDevolucao() {

		try {

			DevolucaoCompletoDTO devolucaoCompletoDTO = new DevolucaoCompletoDTO();

			LoginBBPrevWebDTO loginBBPrevWebDTO = new LoginBBPrevWebDTO();

			loginBBPrevWebDTO = this.loginDevolucaoController.loginAdminSistemasDevolucaoExterno("7lVtRpitgIjhJtodRgA8zg");

			/*
			public DevolucaoCompletoDTO calcularDevolucao(
			@RequestParam final Long codigoPt, 
			@RequestParam final Long codigoPn, 
			@RequestParam final Long codigoTDev, 
			@RequestParam final String dataReq,
			@RequestParam String indTDev, 
			@RequestParam String simulacao, 
			@RequestParam final Integer qtdParcelas, 
			@RequestParam final String dataCota, 
			@RequestParam final String indFormaPagRem,
			@RequestParam final String codigoUsuario, 
			@RequestParam final Double percentualDevolucao) throws PrevidenciaException {
			 * 
			 * */
			for (int i = 44; i < 50; i++) {
				System.out.println("Processo de cálculo: " + i);
				devolucaoCompletoDTO = this.calculoDevolucao.calcularDevolucao(codPartic[i], 105L, 1L, "13/03/2017", "R", "S", 3, "29/04/2015", "F", "7lVtRpitgIjhJtodRgA8zg", 100D);
				this.calculoDevolucao.salvarDevolucao(devolucaoCompletoDTO);
				//devolucaoCompletoDTO = this.calculoDevolucao.calcularDevolucao(782204L, 94L, 1L,/"01/08/2015", "R", "S", 1, "01/08/2015", "F");
				System.out.println(devolucaoCompletoDTO);
			}
			/*System.out.println(devolucaoCompletoDTO.getListaContaDevolucao());
			System.out.println(devolucaoCompletoDTO.getListaParcelaContaDevolucaoDetalhe());
			System.out.println(devolucaoCompletoDTO.getListaParcelaContaDevolucaoDetalheImposto());
			 */

			//this.calculoDevolucao.salvarDevolucao(devolucaoCompletoDTO);

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}