package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.CalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.DevolucaoBO;
import br.com.bbprevidencia.devolucao.controle.LoginDevolucaoController;
import br.com.bbprevidencia.devolucao.dto.DevolucaoAntigoDTO;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.testes.base.TesteBase;
import br.com.bbprevidencia.utils.data.UtilData;

/**
 * Teste unitário para verificação e cálculo de devolução
 *
 * @author Marco Figueiredo
 * @since 16/12/2016
 * 
 * Copyright notice (c) 2016 BBPrevidência S/AX
 */
public class TesteCalculoDevolucaoMigracao extends TesteBase {

	@Autowired
	private CalculoDevolucaoBO calculoDevolucao;

	@Autowired
	private LoginDevolucaoController loginDevolucaoController;

	@Autowired
	private DevolucaoBO devolucaoBO;

	@Test
	public void testeCalculoDevolucao() {

		try {

			DevolucaoCompletoDTO devolucaoCompletoDTO = new DevolucaoCompletoDTO();
			List<DevolucaoAntigoDTO> listaDevolucao = new ArrayList<DevolucaoAntigoDTO>();

			LoginBBPrevWebDTO loginBBPrevWebDTO = new LoginBBPrevWebDTO();

			loginBBPrevWebDTO = this.loginDevolucaoController.loginAdminSistemasDevolucaoExterno("7lVtRpitgIjhJtodRgA8zg");

			//listaDevolucao = devolucaoBO.consultarDevolucaoPorDevolucaoSistemaAntigoParcelados();

			for (DevolucaoAntigoDTO devolucaoAntigoDTO : listaDevolucao) {

				String indicadoCarencia = "V";

				if (devolucaoAntigoDTO.getIndicadorCarenciaInstituidor() != null) {
					indicadoCarencia = devolucaoAntigoDTO.getIndicadorCarenciaInstituidor().equals("M") ? "V" : "F";
				}

				int qtdParcela = devolucaoAntigoDTO.getQtdParcela();

				//Migração Valores Mutua
				if (devolucaoAntigoDTO.getQtdParcela() == 2
						&& devolucaoAntigoDTO.getParticipantePlano().getParticipante().getEntidadeParticipante().getChavePrimaria().getCodigoEntidadeParticipante() == 34) {
					qtdParcela = 1;
				}

				System.out.println(devolucaoAntigoDTO);
				devolucaoCompletoDTO = this.calculoDevolucao.calcularDevolucaoMigracao(
						devolucaoAntigoDTO.getParticipantePlano().getParticipante().getCodigo(),
						devolucaoAntigoDTO.getParticipantePlano().getPlanoPrevidencia().getCodigo(),
						1L,
						UtilData.formataDataPorPadrao(devolucaoAntigoDTO.getDataRequerimento(), "dd/MM/yyyy"),
						"R",
						"S",
						qtdParcela,
						UtilData.formataDataPorPadrao(devolucaoAntigoDTO.getDataCota(), "dd/MM/yyyy"),
						indicadoCarencia,
						"7lVtRpitgIjhJtodRgA8zg",
						100D,
						devolucaoAntigoDTO.getValorEmprestimo());

				System.out.println(devolucaoCompletoDTO);
				this.calculoDevolucao.salvarDevolucao(devolucaoCompletoDTO);
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}