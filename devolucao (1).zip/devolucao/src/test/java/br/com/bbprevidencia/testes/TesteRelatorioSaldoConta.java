package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.devolucao.bo.ContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.dto.RelatorioSaldoContaDTO;
import br.com.bbprevidencia.testes.base.TesteBase;

public class TesteRelatorioSaldoConta extends TesteBase {

	@Autowired
	ContaDevolucaoBO contaDevolucaoBO;

	@Test
	public void testeGerarInformacoes() {
		try {
			Calendar c = Calendar.getInstance();
			c.set(2017, Calendar.JANUARY, 1);

			Date dataInicio = c.getTime();

			List<RelatorioSaldoContaDTO> relatorioSaldoConta = new ArrayList<RelatorioSaldoContaDTO>();

			relatorioSaldoConta.addAll(contaDevolucaoBO.pesquisarInformacoesSaldoConta(dataInicio, null, null, null, null));

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}
