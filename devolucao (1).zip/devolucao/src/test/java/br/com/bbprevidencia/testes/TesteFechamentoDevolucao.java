package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.FechamentoFolhaBO;
import br.com.bbprevidencia.devolucao.controle.LoginDevolucaoController;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.devolucao.dto.LiquidoDevolucaoDTO;
import br.com.bbprevidencia.devolucao.dto.MovimentoCalculoPagamentoDevolucao;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação e cálculo de devolução
 *
 * @author Marco Figueiredo
 * @since 16/12/2016
 * 
 * Copyright notice (c) 2016 BBPrevidência S/AX
 */
public class TesteFechamentoDevolucao extends TesteBase {

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private FechamentoFolhaBO fechamentoFolhaDevolucao;

	@Autowired
	private LoginDevolucaoController loginDevolucaoController;

	@Test
	public void testeCalculoDevolucao() {

		try {
			List<MovimentoCalculoPagamentoDevolucao> listaMovimentoCalculoPagamentoDevolucao = new ArrayList<MovimentoCalculoPagamentoDevolucao>();
			List<LiquidoDevolucaoDTO> listaLiquidoDevolucaoDTO = new ArrayList<LiquidoDevolucaoDTO>();

			LoginBBPrevWebDTO loginBBPrevWebDTO = new LoginBBPrevWebDTO();

			loginBBPrevWebDTO = this.loginDevolucaoController.loginAdminSistemasDevolucaoExterno("7lVtRpitgIjhJtodRgA8zg");

			CronogramaDevolucao cronograma = new CronogramaDevolucao();

			cronograma = this.cronogramaDevolucaoBO.pesquisarCronogramaDevolucaoPorCodigo(1L);

			String teste = fechamentoFolhaDevolucao.fecharFolhaDevolucao(cronograma, loginBBPrevWebDTO);

			System.out.println(teste);
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}