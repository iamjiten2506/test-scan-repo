package br.com.bbprevidencia.testes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.bo.ParticipanteBO;
import br.com.bbprevidencia.cadastroweb.bo.ParticipantePlanoBO;
import br.com.bbprevidencia.cadastroweb.bo.PerfilInvestimentoBO;
import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.cadastroweb.dto.Participante;
import br.com.bbprevidencia.cadastroweb.dto.ParticipantePlano;
import br.com.bbprevidencia.cadastroweb.dto.PerfilInvestimento;
import br.com.bbprevidencia.cotas.bo.ValorCotaPlanoBO;
import br.com.bbprevidencia.cotas.dto.ValorCotaPlano;
import br.com.bbprevidencia.devolucao.bo.CalculoDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.RegraDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoContaDevolucaoBO;
import br.com.bbprevidencia.devolucao.bo.TipoDevolucaoBO;
import br.com.bbprevidencia.devolucao.controle.LoginDevolucaoController;
import br.com.bbprevidencia.devolucao.dto.ContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.Devolucao;
import br.com.bbprevidencia.devolucao.dto.DevolucaoCompletoDTO;
import br.com.bbprevidencia.devolucao.dto.RegraCalculoDevolucao;
import br.com.bbprevidencia.devolucao.dto.RegraDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoContaDevolucao;
import br.com.bbprevidencia.devolucao.dto.TipoDevolucao;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação e cálculo de devolução Manual
 *
 * @author  BBPF0415 - Yanisley Mora Ritchie
 * @since 22/05/2017
 * 
 * Copyright notice (c) 2017 BBPrevidência S/AX
 */
public class TesteCalculoDevolucaoManual extends TesteBase {

	@Autowired
	private CalculoDevolucaoBO calculoDevolucao;

	@Autowired
	TipoContaDevolucaoBO tipoContaDevolucaoBO;

	@Autowired
	private LoginDevolucaoController loginDevolucaoController;

	@Autowired
	private ParticipantePlanoBO participantePlanoBO;

	@Autowired
	private ParticipanteBO participanteBO;

	@Autowired
	private PerfilInvestimentoBO perfilInvestimentoBO;

	@Autowired
	private ValorCotaPlanoBO valorCotaPlanoBO;

	@Autowired
	private TipoDevolucaoBO tipoDevolucaoBO;

	@Autowired
	private RegraDevolucaoBO regraDevolucaoBO;

	@Test
	public void testarCalculoDevolucaoManual() {
		DevolucaoCompletoDTO devolucaoCompletoDTO = new DevolucaoCompletoDTO();

		LoginBBPrevWebDTO loginBBPrevWebDTO = new LoginBBPrevWebDTO();

		loginBBPrevWebDTO = this.loginDevolucaoController.loginAdminSistemasDevolucaoExterno("7lVtRpitgIjhJtodRgA8zg");

		// Cria uma nova devolução
		Devolucao devolucao = new Devolucao();

		devolucao.setDataCadastro(new Date());
		devolucao.setIndicadorDevManual("S");
		devolucao.setNumeroTotalParcelas(3);
		devolucao.setIndicadorFormaPagtoContribCarencia("T");

		devolucao.setPercentualDevolucao(100D);
		devolucao.setDataCadastro(new Date());
		devolucao.setDataUltimaSituacao(new Date());
		devolucao.setDataInclusao(new Date());
		devolucao.setNomeUsuarioInclusao(loginBBPrevWebDTO.getUsuarioSessao().getDescricaoLogin());

		//Prenche e carrega a lista de contas de devolução
		List<ContaDevolucao> listaContaDevolucao = new ArrayList<ContaDevolucao>();
		List<TipoContaDevolucao> listaTipoContaDEvolucao = new ArrayList<TipoContaDevolucao>(this.tipoContaDevolucaoBO.listarTodos());
		for (TipoContaDevolucao tipoContaDevolucao : listaTipoContaDEvolucao) {
			for (int i = 0; i < 3; i++) {
				ContaDevolucao contaDevolucao;
				if (i == 0) {
					contaDevolucao = new ContaDevolucao(devolucao, tipoContaDevolucao, "1", "N");
				} else if (i == 1) {
					contaDevolucao = new ContaDevolucao(devolucao, tipoContaDevolucao, "2", "N");
				} else {
					contaDevolucao = new ContaDevolucao(devolucao, tipoContaDevolucao, "1", "S");
				}
				listaContaDevolucao.add(contaDevolucao);
			}
		}

		Participante participante = new Participante();
		participante = participanteBO.consultarParticipantePorCodigo(1041224L);

		ParticipantePlano participantePlano = new ParticipantePlano();
		participantePlano = participante.getListaParticipantePlano().get(0);

		devolucao.setParticipantePlano(participantePlano);

		// Pesquisar e setar data da cota e valor da cota
		List<PerfilInvestimento> listaPefilIvestimento = new ArrayList<PerfilInvestimento>(perfilInvestimentoBO.listarPerfilInvestimentoPorParticipantePlano(participantePlano));

		for (PerfilInvestimento perfilInvestimento : listaPefilIvestimento) {

			ValorCotaPlano valorCotaPlano = valorCotaPlanoBO.pesquisarCotaPlanoPorEmpresaPlanoPerfil(
					new Date(),
					participante.getEntidadeParticipante(),
					participantePlano.getPlanoPrevidencia(),
					perfilInvestimento);

			if (valorCotaPlano != null) {
				devolucao.setDataCota(valorCotaPlano.getChavePrimaria().getDataPosicaoCota());
				devolucao.setValorCota(valorCotaPlano.getValorCota().doubleValue());
			}
		}

		//Tipo de devolução e regra devolução
		TipoDevolucao tipoDevolucao = new TipoDevolucao();
		tipoDevolucao = tipoDevolucaoBO.pesquisarTipoDevolucaoPorCodigo(1L);

		RegraDevolucao regraDevolucao = this.regraDevolucaoBO.pesquisarRegraDevolucaoPorPlanoVigencia(participantePlano.getPlanoPrevidencia(), new Date());

		RegraCalculoDevolucao regraCalculoDevolucao = new RegraCalculoDevolucao();

		for (RegraCalculoDevolucao rCd : regraDevolucao.getListaRegraCalculoDevolucao()) {
			if (rCd.getTipoDevolucao().equals(tipoDevolucao)) {
				regraCalculoDevolucao = rCd;
				devolucao.setRegraCalculoDevolucao(rCd);
			}
		}

		devolucaoCompletoDTO = calculoDevolucao.calculoDevolucaoManual(devolucao, listaContaDevolucao, 0D, "S");

		System.out.println(devolucaoCompletoDTO);
	}
}
