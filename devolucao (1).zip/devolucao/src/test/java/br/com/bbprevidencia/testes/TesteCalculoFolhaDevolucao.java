package br.com.bbprevidencia.testes;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.bbprevidencia.cadastroweb.dto.LoginBBPrevWebDTO;
import br.com.bbprevidencia.devolucao.bo.CalculoFolhaBO;
import br.com.bbprevidencia.devolucao.bo.CronogramaDevolucaoBO;
import br.com.bbprevidencia.devolucao.controle.LoginDevolucaoController;
import br.com.bbprevidencia.devolucao.dto.CronogramaDevolucao;
import br.com.bbprevidencia.testes.base.TesteBase;

/**
 * Teste unitário para verificação e cálculo de devolução
 *
 * @author Marco Figueiredo
 * @since 16/12/2016
 * 
 * Copyright notice (c) 2016 BBPrevidência S/AX
 */
public class TesteCalculoFolhaDevolucao extends TesteBase {

	@Autowired
	private CalculoFolhaBO calculoFolhaDevolucao;

	@Autowired
	private CronogramaDevolucaoBO cronogramaDevolucaoBO;

	@Autowired
	private LoginDevolucaoController loginDevolucaoController;

	@Test
	public void testeCalculoDevolucao() {

		try {
			LoginBBPrevWebDTO loginBBPrevWebDTO = new LoginBBPrevWebDTO();

			loginBBPrevWebDTO = this.loginDevolucaoController.loginAdminSistemasDevolucaoExterno("7lVtRpitgIjhJtodRgA8zg");

			CronogramaDevolucao cronograma = new CronogramaDevolucao();

			cronograma = this.cronogramaDevolucaoBO.pesquisarCronogramaDevolucaoPorCodigo(37L);

			String teste = this.calculoFolhaDevolucao.calcularFolhaDevolucao(cronograma, null, null, null, loginBBPrevWebDTO);

			System.out.println(teste);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}